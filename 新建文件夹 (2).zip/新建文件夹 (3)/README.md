# 🏢 建筑立面优化系统 v2.0

## 🌟 项目概述

本项目是一个基于多目标优化算法的建筑立面优化系统，集成了**专业级可视化模块**，旨在通过智能算法优化建筑立面设计，提高建筑的能效性能、热舒适度和整体性能。

### ✨ v2.0 新特性
- 🎨 **11类专业级分析图表** - SCI期刊级别的图表质量
- 📊 **完整的数据分析体系** - 从算法收敛到参数相关性
- 🎯 **智能数据生成器** - 支持多种建筑类型和气候区域
- 📈 **交互式可视化** - 支持3D展示和动态分析
- 🔬 **深度性能分析** - 热工性能、能耗分解、聚类分析

## 📊 专业可视化图表体系

### 🎯 第一类：优化过程分析图纸
1. **算法收敛分析图** (01_algorithm_convergence.png)
   - NSGA-III收敛曲线
   - 超体积指标变化
   - 分布性指标分析
   - 算法性能统计

2. **帕累托前沿分析图** (02_pareto_frontier_analysis.png)
   - 3D帕累托前沿散点图
   - 多维度2D投影
   - 帕累托层级分布
   - 拥挤距离分析

### 🏗️ 第二类：建筑性能分析图纸
3. **热工性能综合分析图** (03_thermal_performance_analysis.png)
   - 传热系数分布热力图
   - 热桥效应分析
   - 热惰性时间常数
   - 季节性热工性能对比

4. **能耗分解分析图** (04_energy_breakdown_analysis.png)
   - 年度能耗分解饼图
   - 月度能耗变化曲线
   - 日负荷曲线分析
   - 节能潜力评估

### 🎨 第三类：方案对比展示图纸
5. **最佳方案对比图** (05_best_solutions_comparison.png)
   - 雷达图性能对比
   - 关键指标柱状图
   - 成本效益分析
   - 实施难度评估

6. **方案网格展示图** (06_solutions_grid_layout.png)
   - 100个方案网格布局
   - 帕累托最优解标记
   - 性能指标颜色编码
   - 精致建筑立面展示

7. **最佳方案详细对比图** (07_detailed_best_solutions.png)
   - 原始方案vs三个最佳方案
   - 精致墙体窗户窗框展示
   - 遮阳板细节呈现
   - 详细性能数据表格

8. **方案3D展示图** (08_3d_solutions.png)
   - 轴测图3D效果
   - 窗户大小变化展示
   - 窗框遮阳厚度对比
   - 专业建筑制图风格

### 📈 第四类：综合分析图纸
9. **综合性能雷达图** (09_comprehensive_performance_radar.png)
   - 多维性能雷达图
   - 基准对比分析
   - 改进效果展示
   - 综合评分排序

10. **解聚类分析图** (10_solution_clustering_analysis.png)
    - K-means聚类结果
    - 聚类中心特征
    - 聚类质量评估
    - 典型方案代表

11. **参数相关性分析图** (11_parameter_correlation_analysis.png)
    - 参数相关性热力图
    - 主成分分析
    - 参数重要性排序
    - 交互效应分析

## 🚀 主要功能

### 1. 🖼️ 图像处理模块
- **YOLO目标检测**: 自动识别建筑立面中的窗户、门、阳台等关键元素
- **几何计算**: 精确计算建筑元素的尺寸、位置和比例关系
- **立面分析**: 提取建筑立面的关键参数用于优化

### 2. 🌡️ 气候数据处理
- **EPW文件解析**: 支持标准EPW气候数据文件
- **朝向调整**: 根据建筑朝向调整气候数据
- **微气候分析**: 考虑建筑周边环境影响

### 3. 🧬 多目标优化算法
- **NSGA-III算法**: 先进的多目标遗传算法
- **帕累托前沿**: 生成多个最优解的帕累托前沿
- **动态优化**: 支持实时调整优化参数

### 4. 📊 性能评估
- **能耗分析**: 计算建筑年度能耗
- **热舒适度**: 评估室内热环境舒适性
- **热工性能**: 分析建筑围护结构热工性能

### 5. 🎨 专业可视化系统
- **11类专业图表**: SCI期刊级别的图表质量
- **3D可视化**: 建筑立面3D模型展示
- **性能图表**: 多维度性能分析图表
- **对比分析**: 优化前后效果对比

## 🏗️ 技术架构

```
建筑立面优化系统 v2.0
├── 图像处理层
│   ├── YOLO目标检测
│   ├── 几何计算
│   └── 立面分析
├── 数据处理层
│   ├── EPW气候数据
│   ├── 建筑参数
│   └── 性能指标
├── 优化算法层
│   ├── NSGA-III
│   ├── 遗传操作
│   └── 收敛控制
├── 性能评估层
│   ├── 能耗计算
│   ├── 热舒适评估
│   └── 热工分析
├── 数据生成层 [NEW]
│   ├── 智能数据生成
│   ├── 多场景模拟
│   └── 参数关联建模
└── 专业可视化层 [ENHANCED]
    ├── 11类专业图表
    ├── 3D建模展示
    ├── 交互式分析
    └── SCI级别输出
```

## 📦 安装说明

### 环境要求
- Python 3.8+
- Windows/Linux/macOS

### 安装步骤

1. 克隆项目
```bash
git clone [项目地址]
cd building-facade-optimizer
```

2. 创建虚拟环境
```bash
python -m venv venv
source venv/bin/activate  # Linux/macOS
# 或
venv\Scripts\activate  # Windows
```

3. 安装依赖
```bash
pip install -r requirements.txt
```

4. 运行系统
```bash
python main.py
```

## 🎮 使用指南

### 🚀 快速开始
```bash
python main.py
```

选择操作模式：
1. **🚀 运行完整优化和可视化流程** - 完整功能体验
2. **📊 仅生成可视化图表** - 使用模拟数据快速生成图表
3. **🔧 自定义参数优化** - 自定义建筑类型和气候区域
4. **📋 查看系统状态** - 检查系统状态和已生成文件

### 📊 可视化模式
- **快速模式**: 50个解，适合快速预览
- **标准模式**: 100个解，平衡质量和速度
- **详细模式**: 200个解，最高质量分析

### 🏢 支持的建筑类型
- 办公建筑 (Office)
- 住宅建筑 (Residential)
- 商业建筑 (Commercial)
- 教育建筑 (Educational)

### 🌡️ 支持的气候区域
- 严寒地区
- 寒冷地区
- 夏热冬冷地区
- 夏热冬暖地区
- 温和地区

## 📁 输出结果

### 📊 专业图表 (300 DPI, A4尺寸)
```
output/
├── analysis_charts/           # 主要分析图纸
│   ├── 01_algorithm_convergence.png
│   ├── 02_pareto_frontier_analysis.png
│   ├── 03_thermal_performance_analysis.png
│   ├── 04_energy_breakdown_analysis.png
│   ├── 05_best_solutions_comparison.png
│   ├── 06_solutions_grid_layout.png
│   ├── 07_detailed_best_solutions.png
│   ├── 08_3d_solutions.png
│   ├── 09_comprehensive_performance_radar.png
│   ├── 10_solution_clustering_analysis.png
│   └── 11_parameter_correlation_analysis.png
├── detailed_charts/          # 详细子图
├── optimization_dataset.json # 完整数据集
└── analysis_report.md        # 分析报告
```

### 📈 分析报告
- 数据概览统计
- 性能指标分析
- 最佳方案详情
- 图表索引目录

## 🏗️ 项目结构

```
building-facade-optimizer/
├── src/                      # 源代码
│   ├── core/                # 核心模块
│   ├── image_processing/    # 图像处理
│   ├── climate_data/        # 气候数据
│   ├── optimization/        # 优化算法
│   ├── performance/         # 性能评估
│   └── visualization/       # 专业可视化 [NEW]
│       ├── visualization_engine.py
│       ├── chart_generator.py
│       └── data_generator.py
├── data/                    # 数据文件
├── output/                  # 输出结果
├── docs/                    # 文档
├── tests/                   # 测试文件
├── main.py                 # 主程序 [UPDATED]
├── requirements.txt        # 依赖包 [UPDATED]
└── README.md              # 说明文档
```

## ⚙️ 配置说明

### config.yaml
系统配置文件，包含：
- 算法参数设置
- 性能评估权重
- 输出格式配置
- 可视化样式设置

### 建筑类型配置
支持多种建筑类型的预设配置：
- 办公建筑 (能耗权重: 0.5, 热工权重: 0.3, 遮阳权重: 0.2)
- 住宅建筑 (能耗权重: 0.4, 热工权重: 0.4, 遮阳权重: 0.2)
- 商业建筑 (能耗权重: 0.6, 热工权重: 0.25, 遮阳权重: 0.15)
- 教育建筑 (能耗权重: 0.45, 热工权重: 0.35, 遮阳权重: 0.2)

## 🔧 扩展开发

### 添加新的图表类型
1. 在 `src/visualization/chart_generator.py` 中添加新的图表生成方法
2. 更新 `visualization_engine.py` 的图表生成流程
3. 添加相应的数据生成逻辑

### 集成新的优化算法
1. 在 `src/optimization/` 中实现新算法
2. 继承基础优化器接口
3. 更新主程序的算法选择逻辑

## 🤝 贡献指南

1. Fork 项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 创建 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 详见 [LICENSE](LICENSE) 文件

## 📞 联系方式

- 项目维护者: [维护者姓名]
- 邮箱: [邮箱地址]
- 项目主页: [项目地址]

## 📝 更新日志

### v2.0.0 (2024-XX-XX) 🎉
- ✨ 新增专业级可视化模块
- 📊 11类SCI级别分析图表
- 🎯 智能数据生成器
- 🏢 多建筑类型支持
- 🌡️ 多气候区域适配
- 📈 交互式3D展示
- 🔬 深度数据分析功能

### v1.0.0 (2024-XX-XX)
- 🚀 初始版本发布
- 🧬 基础优化功能
- 📊 基础可视化系统
- 📈 性能评估模块

## 🙏 致谢

感谢所有为本项目做出贡献的开发者和研究人员。特别感谢在可视化模块开发过程中提供支持的团队成员。