
"""
多目标函数计算系统
管理两个目标函数：能耗和热力性能
"""

import numpy as np
from typing import List, Dict, Tuple, Optional, Any
from dataclasses import dataclass
import math

from ..core.config import config_manager
from ..core.logging_config import get_logger, LogContext
from ..core.exceptions import ObjectiveFunctionError, OptimizationError
from ..core.data_structures import Individual, FacadeData, ClimateData, ClimateDataPoint
from ..core.utils import GeometryUtils

# 获取日志记录器
logger = get_logger(__name__)


@dataclass
class ObjectiveWeights:
    """目标函数权重配置"""
    energy_weight: float = 1.0          # 能耗权重
    thermal_weight: float = 1.0         # 热力性能权重


@dataclass
class BuildingParameters:
    """建筑参数配置"""
    # 热力学参数
    wall_u_value: float = 0.4           # 墙体传热系数 W/m²·K
    window_base_u_value: float = 2.5    # 窗户基础传热系数 W/m²·K
    
    # HVAC参数
    hvac_efficiency: float = 0.85       # HVAC系统效率
    internal_heat_gain: float = 5.0     # 内部得热 W/m²
    infiltration_rate: float = 0.5      # 渗透率 ACH
    
    # 温度控制参数
    target_temp_heating: float = 20.0   # 供暖目标温度 °C
    target_temp_cooling: float = 26.0   # 制冷目标温度 °C


class EnergyCalculator:
    """建筑能耗计算器"""
    
    def __init__(self, building_params: BuildingParameters):
        self.params = building_params
        logger.debug("能耗计算器初始化完成")
    
    def calculate_annual_energy_consumption(self, individual: Individual, 
                                          facade_data: FacadeData, 
                                          climate_data: ClimateData) -> float:
        """
        计算年度总能耗 - 优化版本
        
        Args:
            individual: 优化个体
            facade_data: 立面数据
            climate_data: 气候数据
            
        Returns:
            年度总能耗 (kWh/m²·year)
        """
        try:
            # 优化：使用向量化计算提高性能
            hourly_temps = np.array([hour.dry_bulb_temp for hour in climate_data.hourly_data])
            hourly_radiation = np.array([hour.global_radiation for hour in climate_data.hourly_data])
            hourly_humidity = np.array([hour.relative_humidity for hour in climate_data.hourly_data])
            
            # 计算传热负荷（向量化）
            transmission_loads = self._calculate_vectorized_transmission_load(
                individual, facade_data, hourly_temps
            )
            
            # 计算太阳得热（向量化）
            solar_gains = self._calculate_vectorized_solar_gain(
                individual, facade_data, hourly_radiation
            )
            
            # 计算内部得热（常数）
            internal_gain = self._calculate_internal_gain(facade_data)
            
            # 计算通风负荷（向量化）
            ventilation_loads = self._calculate_vectorized_ventilation_load(
                facade_data, hourly_temps
            )
            
            # 计算净负荷 - 增强个体差异
            net_loads = transmission_loads + ventilation_loads - solar_gains - internal_gain
            
            # 考虑HVAC效率和COP
            heating_loads = np.maximum(0, net_loads)
            cooling_loads = np.maximum(0, -net_loads)
            
            # 优化：分季节计算HVAC效率
            seasonal_heating_cop = self._get_seasonal_heating_cop(hourly_temps)
            seasonal_cooling_cop = self._get_seasonal_cooling_cop(hourly_temps)
            
            # 增强个体差异的能耗计算
            base_energy_consumption = (heating_loads / seasonal_heating_cop + 
                                     cooling_loads / seasonal_cooling_cop)
            
            # 窗户面积对能耗的额外影响 - 极大增强个体差异
            total_window_area = sum([window.area * individual.window_width_scales[i] 
                                   if len(individual.window_width_scales) > i 
                                   else window.area 
                                   for i, window in enumerate(facade_data.windows)])
            
            window_area_factor = total_window_area / 9.0  # 基准面积9m²
            
            # 面积影响系数 - 极大非线性放大以增加个体差异和帕累托解数量
            if window_area_factor > 2.0:  # 极大窗户
                area_impact_factor = 1.0 + (window_area_factor - 1.0) * 8.0  # 极大放大
            elif window_area_factor > 1.5:  # 很大窗户
                area_impact_factor = 1.0 + (window_area_factor - 1.0) * 6.0  # 大幅放大
            elif window_area_factor > 1.2:  # 大窗户
                area_impact_factor = 1.0 + (window_area_factor - 1.0) * 4.5  # 显著放大
            elif window_area_factor < 0.3:  # 极小窗户
                area_impact_factor = 1.0 - (1.0 - window_area_factor) * 4.0  # 极大减小
            elif window_area_factor < 0.5:  # 很小窗户
                area_impact_factor = 1.0 - (1.0 - window_area_factor) * 3.5  # 大幅减小
            elif window_area_factor < 0.8:  # 小窗户
                area_impact_factor = 1.0 - (1.0 - window_area_factor) * 3.0  # 显著减小
            else:  # 正常范围
                area_impact_factor = 1.0 + (window_area_factor - 1.0) * 3.5  # 增强正常范围影响
            
            # 遮阳类型对能耗的影响
            shading_impact_factor = self._calculate_shading_energy_impact(individual)
            
            # 综合影响因子
            total_impact_factor = area_impact_factor * shading_impact_factor
            
            # 应用影响因子
            enhanced_energy_consumption = base_energy_consumption * total_impact_factor
            
            # 年度总能耗
            total_energy = np.sum(enhanced_energy_consumption)
            
            # 转换为年度能耗密度 (kWh/m²·year)
            facade_area = facade_data.total_facade_area
            if facade_area > 0:
                annual_energy = total_energy / facade_area / 1000  # Wh -> kWh
            else:
                annual_energy = total_energy / 1000
            
            # 优化：添加能耗合理性检查
            logger.debug(f"原始计算能耗: {annual_energy:.3f} kWh/m²·year")
            validated_energy = self._validate_energy_consumption(annual_energy, facade_data)
            logger.debug(f"验证后能耗: {validated_energy:.3f} kWh/m²·year")
            
            return float(validated_energy)
            
        except Exception as e:
            logger.error(f"年度能耗计算失败: {str(e)}")
            return 1000.0  # 返回较高的默认值
    
    def _calculate_hourly_energy(self, individual: Individual, 
                               facade_data: FacadeData, 
                               hour_data: ClimateDataPoint) -> float:
        """计算单小时能耗"""
        try:
            # 计算传热负荷
            transmission_load = self._calculate_transmission_load(
                individual, facade_data, hour_data
            )
            
            # 计算太阳得热
            solar_gain = self._calculate_solar_gain(
                individual, facade_data, hour_data
            )
            
            # 计算内部得热
            internal_gain = self._calculate_internal_gain(facade_data)
            
            # 计算通风负荷
            ventilation_load = self._calculate_ventilation_load(
                facade_data, hour_data
            )
            
            # 计算净负荷
            net_load = transmission_load + ventilation_load - solar_gain - internal_gain
            
            # 考虑HVAC效率
            if net_load > 0:  # 供暖需求
                energy_consumption = net_load / self.params.hvac_efficiency
            else:  # 制冷需求
                energy_consumption = abs(net_load) / (self.params.hvac_efficiency * 3.0)  # COP=3
            
            return max(0, energy_consumption)
            
        except Exception as e:
            logger.warning(f"小时能耗计算失败: {str(e)}")
            return 10.0  # 默认值
    
    def _calculate_transmission_load(self, individual: Individual, 
                                   facade_data: FacadeData, 
                                   hour_data: ClimateDataPoint) -> float:
        """计算传热负荷 - 增强个体差异版本"""
        try:
            total_transmission = 0.0
            
            # 计算墙体传热
            wall_area = facade_data.total_wall_area
            wall_transmission = (wall_area * self.params.wall_u_value * 
                               (hour_data.dry_bulb_temp - 22.0))  # 假设室内温度22°C
            total_transmission += wall_transmission
            
            # 计算窗户传热（大幅增强个体差异影响）
            for i, window in enumerate(facade_data.windows):
                # 获取窗户宽度缩放因子，如果没有则使用默认值1.0
                if len(individual.window_width_scales) > i:
                    width_scale = individual.window_width_scales[i]
                else:
                    width_scale = 1.0
                
                # 根据优化参数调整窗户面积 - 增强面积影响
                adjusted_width = window.width * width_scale
                adjusted_area = adjusted_width * window.height
                
                # 面积变化的非线性影响 - 大窗户影响更大
                area_amplification = 1.0 + (width_scale - 1.0) * 2.0  # 放大面积影响
                effective_area = adjusted_area * area_amplification
                
                # 遮阳设施对传热系数的影响
                base_u = self.params.window_base_u_value
                # 遮阳深度的影响 - 深度越大，传热系数越小
                if len(individual.shading_depths) > i:
                    depth_reduction = min(0.4, individual.shading_depths[i] * 0.3)  # 最大40%改善
                    u_value = base_u * (1 - depth_reduction)
                else:
                    u_value = base_u
                
                # 计算窗户传热负荷 - 使用增强的面积和传热系数
                window_transmission = (effective_area * u_value * 
                                     (hour_data.dry_bulb_temp - 22.0))
                total_transmission += window_transmission
            
            return total_transmission
            
        except Exception as e:
            logger.warning(f"传热负荷计算失败: {str(e)}")
            return 0.0
    
    def _calculate_solar_gain(self, individual: Individual, 
                            facade_data: FacadeData, 
                            hour_data: ClimateDataPoint) -> float:
        """计算太阳得热 - 增强个体差异版本"""
        try:
            total_solar_gain = 0.0
            
            # 只有窗户有太阳得热
            for i, window in enumerate(facade_data.windows):
                # 获取窗户宽度缩放因子，如果没有则使用默认值1.0
                if len(individual.window_width_scales) > i:
                    width_scale = individual.window_width_scales[i]
                else:
                    width_scale = 1.0
                
                # 调整后的窗户面积 - 增强面积影响
                adjusted_width = window.width * width_scale
                adjusted_area = adjusted_width * window.height
                
                # 面积变化的非线性影响 - 大窗户太阳得热影响更大
                area_solar_factor = 1.0 + (width_scale - 1.0) * 3.0  # 大幅放大太阳得热影响
                effective_solar_area = adjusted_area * area_solar_factor
                
                # 计算增强的遮阳系数
                enhanced_shading_factor = self._calculate_enhanced_shading_factor(individual, i)
                
                # 遮阳系统的太阳得热系数（SHGC）
                base_shgc = 0.65  # 遮阳系统配合的玻璃SHGC
                
                # 应用遮阳影响
                effective_shgc = base_shgc * (1 - enhanced_shading_factor)
                
                # 太阳得热计算 - 使用增强的面积和SHGC
                solar_gain = (effective_solar_area * hour_data.global_radiation * 
                            effective_shgc / 1000)  # Wh/m² -> W
                
                total_solar_gain += solar_gain
            
            return total_solar_gain
            
        except Exception as e:
            logger.warning(f"太阳得热计算失败: {str(e)}")
            return 0.0
    
    def _calculate_enhanced_shading_factor(self, individual: Individual, window_index: int) -> float:
        """计算增强的遮阳系数"""
        try:
            if len(individual.shading_depths) <= window_index:
                return 0.0
            
            depth = individual.shading_depths[window_index]
            
            # 遮阳系统效果 - 非线性增强
            base_shading = min(0.7, depth * 0.6)  # 基础遮阳效果
            # 深度越大，效果增强越明显
            depth_bonus = min(0.2, (depth - 0.5) * 0.4) if depth > 0.5 else 0
            return base_shading + depth_bonus
                
        except Exception:
            return 0.0
    
    def _calculate_shading_factor(self, individual: Individual, window_index: int) -> float:
        """计算遮阳系数"""
        try:
            if window_index >= len(individual.shading_depths):
                return 0.0
            
            depth = individual.shading_depths[window_index]
            
            # 遮阳的遮阳效果
            return min(0.8, depth * 0.8)
                
        except Exception:
            return 0.0
    
    def _calculate_vectorized_transmission_load(self, individual: Individual, 
                                              facade_data: FacadeData, 
                                              hourly_temps: np.ndarray) -> np.ndarray:
        """向量化计算传热负荷"""
        try:
            # 室内设定温度（动态调整）
            indoor_temp = 22.0
            temp_diff = hourly_temps - indoor_temp
            
            # 墙体传热
            wall_area = facade_data.total_wall_area
            wall_transmission = wall_area * self.params.wall_u_value * temp_diff
            
            # 窗户传热（考虑优化参数）
            window_transmission = np.zeros_like(temp_diff)
            for i, window in enumerate(facade_data.windows):
                if len(individual.window_width_scales) > i:
                    adjusted_width = window.width * individual.window_width_scales[i]
                    adjusted_area = adjusted_width * window.height
                    
                    # 动态传热系数（考虑遮阳影响）
                    u_value = self._get_dynamic_u_value(individual, i)
                    window_transmission += adjusted_area * u_value * temp_diff
            
            return wall_transmission + window_transmission
            
        except Exception as e:
            logger.warning(f"向量化传热负荷计算失败: {str(e)}")
            return np.zeros_like(hourly_temps)
    
    def _calculate_vectorized_solar_gain(self, individual: Individual, 
                                       facade_data: FacadeData, 
                                       hourly_radiation: np.ndarray) -> np.ndarray:
        """向量化计算太阳得热"""
        try:
            total_solar_gain = np.zeros_like(hourly_radiation)
            
            for i, window in enumerate(facade_data.windows):
                if len(individual.window_width_scales) > i:
                    adjusted_width = window.width * individual.window_width_scales[i]
                    adjusted_area = adjusted_width * window.height
                    
                    # 动态遮阳系数（考虑太阳角度）
                    shading_factor = self._get_dynamic_shading_factor(individual, i, hourly_radiation)
                    
                    # 优化的SHGC计算
                    shgc = self._get_dynamic_shgc(individual, i, shading_factor)
                    
                    # 太阳得热计算
                    solar_gain = adjusted_area * hourly_radiation * shgc / 1000
                    total_solar_gain += solar_gain
            
            return total_solar_gain
            
        except Exception as e:
            logger.warning(f"向量化太阳得热计算失败: {str(e)}")
            return np.zeros_like(hourly_radiation)
    
    def _calculate_vectorized_ventilation_load(self, facade_data: FacadeData, 
                                             hourly_temps: np.ndarray) -> np.ndarray:
        """向量化计算通风负荷"""
        try:
            facade_area = facade_data.total_facade_area
            air_density = 1.2  # kg/m³
            specific_heat = 1005  # J/kg·K
            
            # 动态通风率（基于温差调整）
            base_ventilation_rate = facade_area * self.params.infiltration_rate / 3600
            temp_diff = hourly_temps - 22.0
            
            # 温差越大，通风负荷越大
            ventilation_loads = (base_ventilation_rate * air_density * specific_heat * temp_diff)
            
            return ventilation_loads
            
        except Exception:
            return np.zeros_like(hourly_temps)
    
    def _get_seasonal_heating_cop(self, hourly_temps: np.ndarray) -> np.ndarray:
        """获取季节性供暖COP"""
        try:
            # 基础COP
            base_cop = 3.0
            
            # 温度越低，COP越低
            temp_factor = np.maximum(0.5, 1.0 - (5.0 - hourly_temps) * 0.02)
            seasonal_cop = base_cop * temp_factor
            
            return np.maximum(1.5, seasonal_cop)  # 最低COP限制
            
        except Exception:
            return np.full_like(hourly_temps, 3.0)
    
    def _get_seasonal_cooling_cop(self, hourly_temps: np.ndarray) -> np.ndarray:
        """获取季节性制冷COP"""
        try:
            # 基础COP
            base_cop = 2.5
            
            # 温度越高，COP越低
            temp_factor = np.maximum(0.6, 1.0 - (hourly_temps - 30.0) * 0.01)
            seasonal_cop = base_cop * temp_factor
            
            return np.maximum(1.8, seasonal_cop)  # 最低COP限制
            
        except Exception:
            return np.full_like(hourly_temps, 2.5)
    
    def _get_dynamic_u_value(self, individual: Individual, window_index: int) -> float:
        """获取动态传热系数"""
        try:
            base_u = self.params.window_base_u_value
            # 遮阳深度影响
            if len(individual.shading_depths) > window_index:
                depth_factor = 1.0 - individual.shading_depths[window_index] * 0.08
                return base_u * depth_factor
            
            return base_u
            
        except Exception:
            return self.params.window_base_u_value
    
    def _get_dynamic_shading_factor(self, individual: Individual, window_index: int, 
                                  hourly_radiation: np.ndarray) -> np.ndarray:
        """获取动态遮阳系数"""
        try:
            if len(individual.shading_depths) <= window_index:
                return np.zeros_like(hourly_radiation)
            
            depth = individual.shading_depths[window_index]
            
            # 遮阳系统的遮阳效果
            base_shading = min(0.6, depth * 0.4)  # 最大60%遮阳
            
            # 根据辐射强度动态调整
            radiation_factor = np.minimum(1.0, hourly_radiation / 800.0)  # 标准化到800 W/m²
            dynamic_shading = base_shading * radiation_factor
            
            return dynamic_shading
            
        except Exception:
            return np.zeros_like(hourly_radiation)
    
    def _get_dynamic_shgc(self, individual: Individual, window_index: int, 
                         shading_factor: np.ndarray) -> np.ndarray:
        """获取动态太阳得热系数"""
        try:
            base_shgc = 0.65  # 遮阳系统配合的玻璃SHGC
            
            # 遮阳影响
            dynamic_shgc = base_shgc * (1 - shading_factor)
            
            return np.maximum(0.1, dynamic_shgc)  # 最小SHGC限制
            
        except Exception:
            return np.full_like(shading_factor, 0.65)
    
    def _calculate_shading_energy_impact(self, individual: Individual) -> float:
        """计算遮阳系统对能耗的影响因子 - 极大增强版本以获得更多帕累托解"""
        try:
            if not hasattr(individual, 'shading_depths') or len(individual.shading_depths) == 0:
                return 1.0
            
            if not hasattr(individual, 'shading_types') or len(individual.shading_types) == 0:
                return 1.0
            
            total_impact = 0.0
            count = 0
            
            for i in range(min(len(individual.shading_depths), len(individual.shading_types))):
                has_shading = individual.shading_types[i] == 1
                depth = individual.shading_depths[i]
                
                if has_shading and depth > 0:
                    # 遮阳系统的节能效果极其显著 - 极大增强个体差异和帕累托解数量
                    if depth <= 0.2:
                        impact = 1.0 - depth * 1.5  # 极大增强浅遮阳效果
                    elif depth <= 0.5:
                        impact = 0.70 - (depth - 0.2) * 1.0  # 中浅深度大幅节能
                    elif depth <= 1.0:
                        impact = 0.40 - (depth - 0.5) * 0.8  # 中等深度持续节能
                    elif depth <= 2.0:
                        impact = 0.00 - (depth - 1.0) * 0.3  # 深度遮阳持续节能
                    else:
                        impact = max(0.05, 0.30 - (depth - 2.0) * 0.15)  # 极深遮阳，边际递减但仍显著
                else:
                    # 无遮阳设施，能耗大幅增加 - 进一步增强惩罚
                    impact = 1.6  # 进一步增加能耗惩罚以增强差异
                
                total_impact += impact
                count += 1
            
            if count > 0:
                avg_impact = total_impact / count
                return max(0.05, min(2.5, avg_impact))  # 进一步扩大影响范围
            else:
                return 1.0
                
        except Exception as e:
            logger.warning(f"遮阳能耗影响计算失败: {str(e)}")
            return 1.0
    
    def _validate_energy_consumption(self, annual_energy: float, facade_data: FacadeData) -> float:
        """验证能耗合理性 - 极大放宽以增加个体差异"""
        try:
            # 基于建筑类型的合理范围 - 极大放宽以允许更多变化和帕累托解
            min_energy = 0.1    # kWh/m²·year - 极大降低下限
            max_energy = 800.0  # kWh/m²·year - 大幅提高上限
            
            # 基于窗墙比调整范围 - 进一步放宽
            window_wall_ratio = facade_data.total_window_area / facade_data.total_facade_area
            if window_wall_ratio > 0.8:  # 极高窗墙比
                max_energy *= 1.8  # 大幅提高上限
            elif window_wall_ratio > 0.6:  # 高窗墙比
                max_energy *= 1.5
            elif window_wall_ratio < 0.1:  # 极低窗墙比
                min_energy *= 0.1  # 极大降低下限
            elif window_wall_ratio < 0.2:  # 低窗墙比
                min_energy *= 0.3
            
            validated_energy = max(min_energy, min(max_energy, annual_energy))
            logger.debug(f"能耗验证: 原始={annual_energy:.3f}, 范围=[{min_energy:.3f}, {max_energy:.3f}], 验证后={validated_energy:.3f}")
            return validated_energy
            
        except Exception:
            return annual_energy
    
    def _calculate_internal_gain(self, facade_data: FacadeData) -> float:
        """计算内部得热"""
        try:
            facade_area = facade_data.total_facade_area
            return facade_area * self.params.internal_heat_gain
        except Exception:
            return 0.0
    
    def _calculate_ventilation_load(self, facade_data: FacadeData, 
                                  hour_data: ClimateDataPoint) -> float:
        """计算通风负荷"""
        try:
            facade_area = facade_data.total_facade_area
            air_density = 1.2  # kg/m³
            specific_heat = 1005  # J/kg·K
            
            # 通风量计算
            ventilation_rate = facade_area * self.params.infiltration_rate / 3600  # m³/s
            
            # 通风负荷
            ventilation_load = (ventilation_rate * air_density * specific_heat * 
                              (hour_data.dry_bulb_temp - 22.0))  # W
            
            return ventilation_load
            
        except Exception:
            return 0.0


# ThermalComfortEvaluator类已删除 - 不再需要舒适度评估
        """计算室内温度（简化模型）"""
        try:
            outdoor_temp = hour_data.dry_bulb_temp
            
            # 简化的室内温度计算
            # 考虑建筑热惰性和太阳得热影响
            
            # 基础室内外温差
            base_temp_diff = 2.0  # 假设室内比室外高2度
            
            # 太阳得热对室内温度的影响
            solar_effect = 0.0
            for i, window in enumerate(facade_data.windows):
                if len(individual.window_width_scales) > i:
                    adjusted_area = window.area * individual.window_width_scales[i]
                    shading_factor = self._calculate_shading_factor(individual, i)
                    
                    # 太阳辐射对室内温度的贡献
                    solar_contribution = (hour_data.global_radiation * adjusted_area * 
                                        (1 - shading_factor) / 1000000)  # 简化计算
                    solar_effect += solar_contribution
            
            # 计算室内温度
            indoor_temp = outdoor_temp + base_temp_diff + solar_effect
            
            # 限制在合理范围内
            return max(10.0, min(40.0, indoor_temp))
            
        except Exception:
            return hour_data.dry_bulb_temp + 2.0  # 默认比室外高2度
    
    def _calculate_shading_factor(self, individual: Individual, window_index: int) -> float:
        """计算遮阳系数（与能耗计算器中的方法相同）"""
        try:
            if len(individual.shading_depths) <= window_index:
                return 0.0
            
            depth = individual.shading_depths[window_index]
            shading_type = individual.shading_types[window_index] if len(individual.shading_types) > window_index else 0
            
            if shading_type == 0:  # 窗框
                return min(0.2, depth * 2.0)  # 窗框遮阳效果较小
            else:  # 遮阳
                return min(0.6, depth * 0.4)  # 遮阳系统效果适中
                
        except Exception:
            return 0.0
    
    def _calculate_vectorized_indoor_temperature(self, individual: Individual, 
                                               facade_data: FacadeData, 
                                               hourly_temps: np.ndarray,
                                               hourly_radiation: np.ndarray) -> np.ndarray:
        """向量化计算室内温度"""
        try:
            # 基础室内外温差（考虑建筑热惰性）
            base_temp_diff = 2.0
            
            # 太阳得热对室内温度的影响
            solar_effect = np.zeros_like(hourly_temps)
            
            for i, window in enumerate(facade_data.windows):
                if len(individual.window_width_scales) > i:
                    width_scale = individual.window_width_scales[i]
                    adjusted_area = window.area * width_scale
                    
                    # 获取遮阳类型
                    shading_type = individual.shading_types[i] if len(individual.shading_types) > i else 0
                    shading_depth = individual.shading_depths[i] if len(individual.shading_depths) > i else 0.1
                    
                    # 窗户面积变化的非线性影响 - 极大增强
                    if width_scale > 1.3:  # 大窗户
                        area_amplification = 1.0 + (width_scale - 1.0) * 6.0  # 极大放大大窗户影响
                    elif width_scale > 1.1:  # 中大窗户
                        area_amplification = 1.0 + (width_scale - 1.0) * 4.5  # 大幅放大
                    elif width_scale < 0.7:  # 小窗户
                        area_amplification = 1.0 - (1.0 - width_scale) * 3.0  # 小窗户影响大幅减小
                    elif width_scale < 0.9:  # 中小窗户
                        area_amplification = 1.0 - (1.0 - width_scale) * 2.0  # 中等减小
                    else:
                        area_amplification = 1.0 + (width_scale - 1.0) * 3.0  # 正常范围也增强
                    
                    effective_area = adjusted_area * area_amplification
                    
                    # 极大增强的遮阳计算
                    if shading_type == 0:  # 窗框
                        # 窗框遮阳效果有限，但深度影响极大增强
                        shading_effectiveness = min(0.4, shading_depth * 6.0)  # 增强系数和上限
                    else:  # 遮阳
                        # 遮阳系统效果极其显著，深度影响高度非线性
                        base_effectiveness = min(0.7, shading_depth * 1.0)  # 提高基础效果
                        # 深度奖励 - 深遮阳效果极大增强
                        if shading_depth > 0.8:  # 深遮阳额外奖励
                            depth_bonus = min(0.25, (shading_depth - 0.8) * 1.0)
                        elif shading_depth > 0.4:  # 中等深度奖励
                            depth_bonus = min(0.15, (shading_depth - 0.4) * 0.8)
                        else:
                            depth_bonus = 0
                        shading_effectiveness = base_effectiveness + depth_bonus
                    
                    # 太阳辐射对室内温度的贡献 - 大幅增强个体差异
                    thermal_mass_factor = 1.0
                    # 极大增加太阳效应的影响，使个体差异更明显
                    solar_contribution = (hourly_radiation * effective_area * 
                                        (1 - shading_effectiveness) * thermal_mass_factor / 10)  # 从20改为10，极大增强
                    solar_effect += solar_contribution
            
            # 优化：考虑建筑朝向和风速影响
            orientation_factor = self._get_orientation_factor()
            wind_effect = self._get_wind_cooling_effect(hourly_temps)
            
            # 计算室内温度
            indoor_temps = (hourly_temps + base_temp_diff + solar_effect * orientation_factor - wind_effect)
            
            # 限制在合理范围内
            return np.maximum(15.0, np.minimum(35.0, indoor_temps))
            
        except Exception:
            return hourly_temps + 2.0
    
# 所有舒适度相关方法已删除
            return max(-3.0, min(3.0, pmv))
            
        except Exception:
            return 0.0  # 默认舒适


class ThermalPerformanceAnalyzer:
    """热力性能分析器"""
    
    def __init__(self, building_params: BuildingParameters):
        self.params = building_params
        logger.debug("热力性能分析器初始化完成")
    
    def calculate_overall_thermal_performance(self, individual: Individual, 
                                            facade_data: FacadeData) -> float:
        """
        计算整体热力性能指标 - 优化版本
        
        Returns:
            综合热力性能指标 (W/m²·K) - 越小越好
        """
        try:
            # 计算整体传热系数
            overall_u_value = self._calculate_enhanced_overall_u_value(individual, facade_data)
            
            # 计算热桥效应（优化版本）
            thermal_bridge_effect = self._calculate_enhanced_thermal_bridge_effect(individual, facade_data)
            
            # 计算热惰性影响（优化版本）
            thermal_inertia_factor = self._calculate_enhanced_thermal_inertia_factor(individual, facade_data)
            
            # 新增：计算动态热力性能
            dynamic_thermal_factor = self._calculate_dynamic_thermal_factor(individual, facade_data)
            
            # 新增：计算遮阳系统热力影响
            shading_thermal_impact = self._calculate_shading_thermal_impact(individual, facade_data)
            
            # 综合热力性能指标（优化公式）
            thermal_performance = (overall_u_value * 
                                 (1 + thermal_bridge_effect) * 
                                 thermal_inertia_factor * 
                                 dynamic_thermal_factor * 
                                 (1 + shading_thermal_impact))
            
            # 优化：添加性能等级评估
            performance_grade = self._assess_thermal_performance_grade(thermal_performance)
            
            return float(thermal_performance)
            
        except Exception as e:
            logger.error(f"热力性能计算失败: {str(e)}")
            return 5.0  # 返回较差的默认值
    
    def _calculate_overall_u_value(self, individual: Individual, 
                                 facade_data: FacadeData) -> float:
        """计算整体传热系数"""
        try:
            total_area = 0.0
            weighted_u_value = 0.0
            
            # 墙体贡献
            wall_area = facade_data.total_wall_area
            wall_u_contribution = wall_area * self.params.wall_u_value
            
            total_area += wall_area
            weighted_u_value += wall_u_contribution
            
            # 窗户贡献（考虑优化参数）
            for i, window in enumerate(facade_data.windows):
                if i < len(individual.window_width_scales):
                    # 调整后的窗户面积
                    adjusted_width = window.width * individual.window_width_scales[i]
                    adjusted_area = adjusted_width * window.height
                    
                    # 根据遮阳类型确定传热系数
                    if i < len(individual.shading_types):
                        if individual.shading_types[i] == 0:  # 窗框
                            u_value = self.params.frame_u_value
                        else:  # 遮阳
                            # 遮阳可以降低有效传热系数
                            shading_depth = individual.shading_depths[i] if i < len(individual.shading_depths) else 0.1
                            reduction_factor = min(0.3, shading_depth * 0.1)
                            u_value = self.params.window_base_u_value * (1 - reduction_factor)
                    else:
                        u_value = self.params.window_base_u_value
                    
                    window_u_contribution = adjusted_area * u_value
                    
                    total_area += adjusted_area
                    weighted_u_value += window_u_contribution
            
            # 计算加权平均传热系数
            if total_area > 0:
                overall_u_value = weighted_u_value / total_area
            else:
                overall_u_value = self.params.wall_u_value
            
            return overall_u_value
            
        except Exception as e:
            logger.warning(f"整体传热系数计算失败: {str(e)}")
            return 3.0
    
    def _calculate_thermal_bridge_effect(self, individual: Individual, 
                                       facade_data: FacadeData) -> float:
        """计算热桥效应"""
        try:
            # 简化的热桥效应计算
            # 主要考虑窗户周边和结构连接处的热桥
            
            thermal_bridge_factor = 0.0
            
            # 窗户周边热桥
            for i, window in enumerate(facade_data.windows):
                if i < len(individual.window_width_scales):
                    adjusted_width = window.width * individual.window_width_scales[i]
                    perimeter = 2 * (adjusted_width + window.height)
                    
                    # 窗框类型影响热桥效应
                    if i < len(individual.shading_types):
                        if individual.shading_types[i] == 0:  # 窗框
                            bridge_intensity = 0.1  # 窗框热桥较明显
                        else:  # 遮阳
                            bridge_intensity = 0.05  # 遮阳可以减少热桥
                    else:
                        bridge_intensity = 0.08
                    
                    thermal_bridge_factor += perimeter * bridge_intensity
            
            # 归一化热桥效应
            facade_area = facade_data.total_facade_area
            if facade_area > 0:
                normalized_bridge_effect = thermal_bridge_factor / facade_area
            else:
                normalized_bridge_effect = 0.1
            
            return min(0.5, normalized_bridge_effect)  # 限制最大影响
            
        except Exception:
            return 0.1  # 默认热桥效应
    
    def _calculate_enhanced_overall_u_value(self, individual: Individual, 
                                          facade_data: FacadeData) -> float:
        """计算增强版整体传热系数"""
        try:
            total_area = 0.0
            weighted_u_value = 0.0
            
            # 墙体贡献
            wall_area = facade_data.total_wall_area
            wall_u_contribution = wall_area * self.params.wall_u_value
            
            total_area += wall_area
            weighted_u_value += wall_u_contribution
            
            # 窗户贡献（考虑优化参数和动态效应）
            for i, window in enumerate(facade_data.windows):
                if len(individual.window_width_scales) > i:
                    # 调整后的窗户面积
                    adjusted_width = window.width * individual.window_width_scales[i]
                    adjusted_area = adjusted_width * window.height
                    
                    # 动态传热系数（考虑多种因素）
                    u_value = self._get_enhanced_window_u_value(individual, i)
                    
                    window_u_contribution = adjusted_area * u_value
                    
                    total_area += adjusted_area
                    weighted_u_value += window_u_contribution
            
            # 计算加权平均传热系数
            if total_area > 0:
                overall_u_value = weighted_u_value / total_area
            else:
                overall_u_value = self.params.wall_u_value
            
            return overall_u_value
            
        except Exception as e:
            logger.warning(f"增强版整体传热系数计算失败: {str(e)}")
            return 3.0
    
    def _get_enhanced_window_u_value(self, individual: Individual, window_index: int) -> float:
        """获取增强版窗户传热系数"""
        try:
            base_u = self.params.window_base_u_value
            
            if len(individual.shading_types) > window_index:
                if individual.shading_types[window_index] == 0:  # 窗框
                    base_u = self.params.frame_u_value
                    
                    # 窗框深度和材料影响
                    if len(individual.shading_depths) > window_index:
                        depth = individual.shading_depths[window_index]
                        # 窗框深度增加，传热系数略微改善
                        depth_improvement = min(0.15, depth * 0.05)
                        base_u *= (1 - depth_improvement)
                        
                else:  # 遮阳
                    # 遮阳系统对窗户传热的影响
                    if len(individual.shading_depths) > window_index:
                        depth = individual.shading_depths[window_index]
                        # 遮阳深度增加，有效传热系数改善
                        shading_improvement = min(0.25, depth * 0.08)
                        base_u *= (1 - shading_improvement)
                        
                        # 考虑遮阳角度的影响
                        if hasattr(individual, 'shading_angles') and len(individual.shading_angles) > window_index:
                            angle = individual.shading_angles[window_index]
                            # 最优角度45度，偏离时效果降低
                            angle_factor = 1.0 - abs(angle - 45.0) / 90.0 * 0.1
                            base_u *= angle_factor
            
            return max(0.8, base_u)  # 设置最小传热系数
            
        except Exception:
            return self.params.window_base_u_value
    
    def _calculate_enhanced_thermal_bridge_effect(self, individual: Individual, 
                                                facade_data: FacadeData) -> float:
        """计算增强版热桥效应"""
        try:
            thermal_bridge_factor = 0.0
            
            # 窗户周边热桥（考虑安装方式）
            for i, window in enumerate(facade_data.windows):
                if len(individual.window_width_scales) > i:
                    adjusted_width = window.width * individual.window_width_scales[i]
                    perimeter = 2 * (adjusted_width + window.height)
                    
                    # 根据遮阳/窗框类型计算热桥强度
                    if len(individual.shading_types) > i:
                        if individual.shading_types[i] == 0:  # 窗框
                            # 窗框材料和深度影响热桥
                            depth = individual.shading_depths[i] if len(individual.shading_depths) > i else 0.1
                            bridge_intensity = 0.08 + depth * 0.02  # 深度增加热桥
                        else:  # 遮阳
                            # 遮阳系统可能增加热桥，但也可能遮挡热桥
                            depth = individual.shading_depths[i] if len(individual.shading_depths) > i else 0.5
                            bridge_intensity = 0.05 + depth * 0.01  # 遮阳系统的热桥影响较小
                    else:
                        bridge_intensity = 0.08
                    
                    thermal_bridge_factor += perimeter * bridge_intensity
            
            # 结构热桥（墙体与楼板连接等）
            structural_bridge = facade_data.total_facade_area * 0.02  # 2%的结构热桥
            thermal_bridge_factor += structural_bridge
            
            # 归一化热桥效应
            facade_area = facade_data.total_facade_area
            if facade_area > 0:
                normalized_bridge_effect = thermal_bridge_factor / facade_area
            else:
                normalized_bridge_effect = 0.1
            
            return min(0.6, normalized_bridge_effect)  # 限制最大影响
            
        except Exception:
            return 0.1  # 默认热桥效应
    
    def _calculate_enhanced_thermal_inertia_factor(self, individual: Individual, 
                                                 facade_data: FacadeData) -> float:
        """计算增强版热惰性因子"""
        try:
            # 基础热惰性计算
            wall_area = facade_data.total_wall_area
            window_area = facade_data.total_window_area
            
            if wall_area + window_area > 0:
                wall_ratio = wall_area / (wall_area + window_area)
            else:
                wall_ratio = 0.5
            
            # 基础热惰性因子
            base_inertia = 0.8 + 0.4 * wall_ratio
            
            # 考虑遮阳系统对热惰性的影响
            shading_inertia_effect = 0.0
            window_count = 0
            
            for i, window in enumerate(facade_data.windows):
                if len(individual.shading_types) > i:
                    window_count += 1
                    if individual.shading_types[i] == 1:  # 遮阳
                        # 遮阳系统增加建筑的热惰性
                        depth = individual.shading_depths[i] if len(individual.shading_depths) > i else 0.5
                        shading_inertia_effect += depth * 0.05  # 每米深度增加5%热惰性
            
            if window_count > 0:
                avg_shading_effect = shading_inertia_effect / window_count
                enhanced_inertia = base_inertia * (1 + avg_shading_effect)
            else:
                enhanced_inertia = base_inertia
            
            return min(1.5, max(0.6, enhanced_inertia))  # 限制在合理范围内
            
        except Exception:
            return 1.0  # 默认热惰性因子
    
    def _calculate_dynamic_thermal_factor(self, individual: Individual, 
                                        facade_data: FacadeData) -> float:
        """计算动态热力因子"""
        try:
            # 基于窗户尺寸变化的动态效应
            dynamic_factor = 1.0
            
            for i, window in enumerate(facade_data.windows):
                if len(individual.window_width_scales) > i:
                    width_scale = individual.window_width_scales[i]
                    
                    # 窗户尺寸变化对动态热力性能的影响
                    if width_scale > 1.2:  # 窗户增大
                        dynamic_factor *= 1.05  # 略微降低热力性能
                    elif width_scale < 0.8:  # 窗户减小
                        dynamic_factor *= 0.98  # 略微改善热力性能
            
            return max(0.95, min(1.1, dynamic_factor))
            
        except Exception:
            return 1.0
    
    def _calculate_shading_thermal_impact(self, individual: Individual, 
                                        facade_data: FacadeData) -> float:
        """计算遮阳系统热力影响"""
        try:
            total_thermal_impact = 0.0
            window_count = 0
            
            for i, window in enumerate(facade_data.windows):
                if len(individual.shading_types) > i:
                    window_count += 1
                    
                    if individual.shading_types[i] == 1:  # 遮阳系统
                        depth = individual.shading_depths[i] if len(individual.shading_depths) > i else 0.5
                        
                        # 遮阳深度对热力性能的正面影响
                        thermal_benefit = -depth * 0.03  # 负值表示改善
                        
                        # 但过深的遮阳可能增加结构热桥
                        if depth > 1.0:
                            thermal_penalty = (depth - 1.0) * 0.02
                            thermal_benefit += thermal_penalty
                        
                        total_thermal_impact += thermal_benefit
                    
                    else:  # 窗框
                        # 窗框对热力性能的影响较小
                        depth = individual.shading_depths[i] if len(individual.shading_depths) > i else 0.1
                        thermal_impact = depth * 0.01  # 轻微负面影响
                        total_thermal_impact += thermal_impact
            
            if window_count > 0:
                avg_impact = total_thermal_impact / window_count
            else:
                avg_impact = 0.0
            
            return max(-0.15, min(0.1, avg_impact))  # 限制影响范围
            
        except Exception:
            return 0.0
    
    def _assess_thermal_performance_grade(self, thermal_performance: float) -> str:
        """评估热力性能等级"""
        try:
            if thermal_performance <= 1.5:
                return 'A'  # 优秀
            elif thermal_performance <= 2.0:
                return 'B'  # 良好
            elif thermal_performance <= 2.5:
                return 'C'  # 一般
            elif thermal_performance <= 3.0:
                return 'D'  # 较差
            else:
                return 'E'  # 差
        except Exception:
            return 'C'
    
    def _calculate_thermal_inertia_factor(self, facade_data: FacadeData) -> float:
        """计算热惰性因子 - 保留原方法用于兼容性"""
        try:
            # 简化的热惰性计算
            # 主要基于墙体面积和窗户面积的比例
            
            wall_area = facade_data.total_wall_area
            window_area = facade_data.total_window_area
            
            if wall_area + window_area > 0:
                wall_ratio = wall_area / (wall_area + window_area)
            else:
                wall_ratio = 0.5
            
            # 墙体提供热惰性，窗户降低热惰性
            # 热惰性因子：1.0表示标准，>1.0表示热惰性好，<1.0表示热惰性差
            thermal_inertia_factor = 0.8 + 0.4 * wall_ratio
            
            return thermal_inertia_factor
            
        except Exception:
            return 1.0  # 默认热惰性因子


class ObjectiveFunctionManager:
    """多目标函数管理器"""
    
    def __init__(self, building_params: Optional[BuildingParameters] = None,
                 objective_weights: Optional[ObjectiveWeights] = None):
        """
        初始化目标函数管理器
        
        Args:
            building_params: 建筑参数配置
            objective_weights: 目标函数权重配置
        """
        self.building_params = building_params or BuildingParameters()
        self.objective_weights = objective_weights or ObjectiveWeights()
        
        # 初始化各个计算器
        self.energy_calculator = EnergyCalculator(self.building_params)
        self.thermal_analyzer = ThermalPerformanceAnalyzer(self.building_params)
        
        logger.info("目标函数管理器初始化完成")
    
    def calculate_objectives(self, individual: Individual, 
                           facade_data: FacadeData, 
                           climate_data: ClimateData) -> List[float]:
        """
        计算个体的所有目标函数值
        
        Args:
            individual: 优化个体
            facade_data: 立面数据
            climate_data: 气候数据
            
        Returns:
            目标函数值列表 [能耗, 热力性能] - 已删除舒适度目标
        """
        try:
            with LogContext("目标函数计算"):
                # 目标1: 年度能耗 (kWh/m²·year) - 最小化
                energy_consumption = self.energy_calculator.calculate_annual_energy_consumption(
                    individual, facade_data, climate_data
                )
                
                # 目标2: 热力性能 (传热系数 W/m²·K) - 最小化
                thermal_performance = self.thermal_analyzer.calculate_overall_thermal_performance(
                    individual, facade_data
                )
                
                # 应用权重 - 只保留能耗和热力性能
                objectives = [
                    energy_consumption * self.objective_weights.energy_weight,
                    thermal_performance * self.objective_weights.thermal_weight
                ]
                
                # 记录计算结果
                logger.debug(f"目标函数计算完成: 能耗={energy_consumption:.2f}, "
                           f"热力性能={thermal_performance:.3f}")
                
                return objectives
                
        except Exception as e:
            logger.error(f"目标函数计算失败: {str(e)}")
            # 返回较差的默认值
            return [1000.0, 5.0]
    
    def calculate_single_objective(self, objective_type: str, 
                                 individual: Individual, 
                                 facade_data: FacadeData, 
                                 climate_data: ClimateData) -> float:
        """
        计算单个目标函数值
        
        Args:
            objective_type: 目标类型 ('energy', 'thermal') - 已删除comfort
            individual: 优化个体
            facade_data: 立面数据
            climate_data: 气候数据
            
        Returns:
            单个目标函数值
        """
        try:
            if objective_type == 'energy':
                return self.energy_calculator.calculate_annual_energy_consumption(
                    individual, facade_data, climate_data
                )
            elif objective_type == 'thermal':
                return self.thermal_analyzer.calculate_overall_thermal_performance(
                    individual, facade_data
                )
            else:
                raise ObjectiveFunctionError(f"未知的目标类型: {objective_type}")
                
        except Exception as e:
            logger.error(f"单个目标函数计算失败 ({objective_type}): {str(e)}")
            return 0.0
    
    def get_objective_names(self) -> List[str]:
        """获取目标函数名称列表 - 已删除舒适度"""
        return ['能耗 (kWh/m²·year)', '传热系数 (W/m²·K)']
    
    def get_objective_units(self) -> List[str]:
        """获取目标函数单位列表 - 已删除舒适度"""
        return ['kWh/m²·year', 'W/m²·K']
    
    def get_objective_directions(self) -> List[str]:
        """获取目标函数优化方向列表 - 已删除舒适度"""
        return ['minimize', 'minimize']
    
    def normalize_objectives(self, objectives: List[float], 
                           reference_values: Optional[List[float]] = None) -> List[float]:
        """
        归一化目标函数值
        
        Args:
            objectives: 原始目标函数值
            reference_values: 参考值（用于归一化）
            
        Returns:
            归一化后的目标函数值
        """
        try:
            if reference_values is None:
                # 使用默认参考值
                reference_values = [200.0, 2000.0, 3.0]  # 能耗、不舒适小时、传热系数
            
            normalized = []
            for i, (obj, ref) in enumerate(zip(objectives, reference_values)):
                if ref > 0:
                    normalized.append(obj / ref)
                else:
                    normalized.append(obj)
            
            return normalized
            
        except Exception as e:
            logger.warning(f"目标函数归一化失败: {str(e)}")
            return objectives
    
    def evaluate_performance_improvement(self, optimized_individual: Individual,
                                       baseline_individual: Individual,
                                       facade_data: FacadeData,
                                       climate_data: ClimateData) -> Dict[str, float]:
        """
        评估性能改进效果
        
        Args:
            optimized_individual: 优化后的个体
            baseline_individual: 基准个体
            facade_data: 立面数据
            climate_data: 气候数据
            
        Returns:
            性能改进字典
        """
        try:
            # 计算优化前后的目标函数值
            baseline_objectives = self.calculate_objectives(
                baseline_individual, facade_data, climate_data
            )
            optimized_objectives = self.calculate_objectives(
                optimized_individual, facade_data, climate_data
            )
            
            # 计算改进百分比
            improvements = {}
            objective_names = ['energy', 'comfort', 'thermal']
            
            for i, name in enumerate(objective_names):
                if baseline_objectives[i] > 0:
                    improvement = ((baseline_objectives[i] - optimized_objectives[i]) / 
                                 baseline_objectives[i] * 100)
                    improvements[name] = improvement
                else:
                    improvements[name] = 0.0
            
            # 计算综合改进指标
            improvements['overall'] = sum(improvements.values()) / len(improvements)
            
            return improvements
            
        except Exception as e:
            logger.error(f"性能改进评估失败: {str(e)}")
            return {'energy': 0.0, 'comfort': 0.0, 'thermal': 0.0, 'overall': 0.0}
    
    def validate_objectives(self, objectives: List[float]) -> bool:
        """
        验证目标函数值的有效性
        
        Args:
            objectives: 目标函数值列表
            
        Returns:
            是否有效
        """
        try:
            if len(objectives) != 3:
                return False
            
            # 检查数值范围
            energy, comfort, thermal = objectives
            
            # 能耗应在合理范围内 (0-2000 kWh/m²·year)
            if not (0 <= energy <= 2000):
                return False
            
            # 不舒适小时数应在0-8760之间
            if not (0 <= comfort <= 8760):
                return False
            
            # 传热系数应在合理范围内 (0-10 W/m²·K)
            if not (0 <= thermal <= 10):
                return False
            
            # 检查是否为有效数值
            for obj in objectives:
                if not isinstance(obj, (int, float)) or math.isnan(obj) or math.isinf(obj):
                    return False
            
            return True
            
        except Exception:
            return False
    
    def get_objective_statistics(self, population_objectives: List[List[float]]) -> Dict[str, Dict[str, float]]:
        """
        计算种群目标函数统计信息
        
        Args:
            population_objectives: 种群目标函数值列表
            
        Returns:
            统计信息字典
        """
        try:
            if not population_objectives:
                return {}
            
            objectives_array = np.array(population_objectives)
            objective_names = ['energy', 'comfort', 'thermal']
            
            statistics = {}
            for i, name in enumerate(objective_names):
                obj_values = objectives_array[:, i]
                statistics[name] = {
                    'min': float(np.min(obj_values)),
                    'max': float(np.max(obj_values)),
                    'mean': float(np.mean(obj_values)),
                    'std': float(np.std(obj_values)),
                    'median': float(np.median(obj_values))
                }
            
            return statistics
            
        except Exception as e:
            logger.error(f"目标函数统计计算失败: {str(e)}")
            return {}


# 工厂函数
def create_objective_function_manager(config: Optional[Dict[str, Any]] = None) -> ObjectiveFunctionManager:
    """
    创建目标函数管理器的工厂函数
    
    Args:
        config: 配置字典
        
    Returns:
        目标函数管理器实例
    """
    try:
        if config is None:
            config = {}
        
        # 解析建筑参数
        building_config = config.get('building_parameters', {})
        building_params = BuildingParameters(**building_config)
        
        # 解析目标权重
        weights_config = config.get('objective_weights', {})
        objective_weights = ObjectiveWeights(**weights_config)
        
        return ObjectiveFunctionManager(building_params, objective_weights)
        
    except Exception as e:
        logger.error(f"目标函数管理器创建失败: {str(e)}")
        return ObjectiveFunctionManager()  # 返回默认配置的管理器
