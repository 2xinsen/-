
"""
NSGA-III优化器
实现NSGA-III多目标优化算法的核心功能
"""

import numpy as np
from typing import List, Dict, Tuple, Optional, Any, Callable
import random
import copy
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
import time

from ..core.config import config_manager
from ..core.logging_config import get_logger, LogContext, monitor_performance
from ..core.exceptions import NSGA3Error, OptimizationError
from ..core.data_structures import Individual, OptimizationResults, FacadeData, ClimateData
from .constraint_handler import ConstraintHandler, ConstraintConfig
from .genetic_operators import GeneticOperatorManager, GeneticOperatorConfig
from .convergence_control import OptimizationMonitor, ConvergenceConfig

# 获取日志记录器
logger = get_logger(__name__)


@dataclass
class NSGA3Config:
    """NSGA-III算法配置 - 优化以获得更多帕累托解并减缓收敛"""
    population_size: int = 300          # 增加种群大小以提高多样性
    max_generations: int = 500          # 增加最大代数以获得更多优化机会
    crossover_probability: float = 0.6  # 降低交叉概率以增加多样性
    mutation_probability: float = 0.6   # 提高变异概率以增加随机度
    reference_points_divisions: int = 20 # 增加参考点数量以获得更多帕累托解
    max_stagnation_generations: int = 100 # 增加停滞容忍度以减缓收敛
    tolerance: float = 1e-10            # 降低收敛容差以减缓收敛
    min_improvement: float = 0.0001     # 降低最小改进阈值以减缓收敛
    parallel_evaluation: bool = True
    max_workers: int = 4

    max_workers: int = 4


class ReferencePointGenerator:
    """参考点生成器"""
    
    @staticmethod
    def generate_reference_points(n_objectives: int, n_divisions: int) -> np.ndarray:
        """生成NSGA-III参考点"""
        try:
            if n_objectives == 2:
                # 2目标问题的参考点生成
                points = []
                for i in range(n_divisions + 1):
                    j = n_divisions - i
                    point = [i/n_divisions, j/n_divisions]
                    points.append(point)
                return np.array(points)
            elif n_objectives == 3:
                points = []
                for i in range(n_divisions + 1):
                    for j in range(n_divisions + 1 - i):
                        k = n_divisions - i - j
                        point = [i/n_divisions, j/n_divisions, k/n_divisions]
                        points.append(point)
                return np.array(points)
            else:
                return ReferencePointGenerator._generate_recursive(n_objectives, n_divisions)
        except Exception as e:
            logger.error(f"参考点生成失败: {str(e)}")
            return np.eye(n_objectives)
    
    @staticmethod
    def _generate_recursive(n_objectives: int, n_divisions: int, 
                          current_point: List[float] = None, 
                          remaining_sum: float = 1.0) -> np.ndarray:
        """递归生成参考点"""
        if current_point is None:
            current_point = []
        
        if len(current_point) == n_objectives - 1:
            current_point.append(remaining_sum)
            return np.array([current_point])
        
        points = []
        for i in range(int(remaining_sum * n_divisions) + 1):
            value = i / n_divisions
            if value <= remaining_sum:
                new_point = current_point + [value]
                sub_points = ReferencePointGenerator._generate_recursive(
                    n_objectives, n_divisions, new_point, remaining_sum - value
                )
                points.extend(sub_points)
        
        return np.array(points) if points else np.eye(n_objectives)


class NonDominatedSorting:
    """非支配排序"""
    
    @staticmethod
    def fast_non_dominated_sort(population: List[Individual]) -> List[List[int]]:
        """快速非支配排序"""
        try:
            n = len(population)
            if n == 0:
                return []
            
            domination_count = [0] * n
            dominated_solutions = [[] for _ in range(n)]
            fronts = [[]]
            
            for i in range(n):
                for j in range(n):
                    if i != j:
                        if NonDominatedSorting._dominates(population[i], population[j]):
                            dominated_solutions[i].append(j)
                        elif NonDominatedSorting._dominates(population[j], population[i]):
                            domination_count[i] += 1
                
                if domination_count[i] == 0:
                    population[i].rank = 0
                    fronts[0].append(i)
            
            current_front = 0
            while current_front < len(fronts) and len(fronts[current_front]) > 0:
                next_front = []
                for i in fronts[current_front]:
                    for j in dominated_solutions[i]:
                        domination_count[j] -= 1
                        if domination_count[j] == 0:
                            population[j].rank = current_front + 1
                            next_front.append(j)
                
                if next_front:
                    fronts.append(next_front)
                current_front += 1
            
            # 移除空的最后一个前沿
            while fronts and not fronts[-1]:
                fronts.pop()
            
            return fronts if fronts else [[i for i in range(len(population))]]
            
        except Exception as e:
            logger.error(f"非支配排序失败: {str(e)}")
            return [[i for i in range(len(population))]]
    
    @staticmethod
    def _dominates(individual1: Individual, individual2: Individual) -> bool:
        """判断individual1是否支配individual2"""
        try:
            if individual1.objectives is None or individual2.objectives is None:
                return False
            
            obj1 = individual1.objectives
            obj2 = individual2.objectives
            
            if len(obj1) != len(obj2):
                return False
            
            better_in_any = False
            for i in range(len(obj1)):
                if obj1[i] > obj2[i]:
                    return False
                elif obj1[i] < obj2[i]:
                    better_in_any = True
            
            return better_in_any
            
        except Exception:
            return False


class NSGA3Optimizer:
    """NSGA-III优化器"""
    
    def __init__(self, config: Optional[NSGA3Config] = None):
        """初始化NSGA-III优化器"""
        self.config = config or NSGA3Config()
        
        # 从系统配置加载参数
        opt_config = config_manager.get_optimization_config()
        if opt_config and opt_config.nsga3:
            self.config.population_size = opt_config.nsga3.get('population_size', self.config.population_size)
            self.config.max_generations = opt_config.nsga3.get('max_generations', self.config.max_generations)
        
        self.reference_points = None
        self.current_generation = 0
        self.evolution_history = []
        self.objective_function: Optional[Callable] = None
        self.constraint_handler: Optional[ConstraintHandler] = None
        
        # 初始化遗传算子管理器
        genetic_config = GeneticOperatorConfig(
            crossover_probability=self.config.crossover_probability,
            mutation_probability=self.config.mutation_probability
        )
        self.genetic_operators = GeneticOperatorManager(genetic_config)
        
        # 初始化收敛控制
        convergence_config = ConvergenceConfig(
            max_stagnation_generations=self.config.max_stagnation_generations,
            tolerance=self.config.tolerance,
            min_improvement=self.config.min_improvement
        )
        self.monitor = OptimizationMonitor(convergence_config)
        
        logger.info(f"NSGA-III优化器初始化完成")
    
    def set_objective_function(self, objective_function: Callable):
        """设置目标函数"""
        self.objective_function = objective_function
        logger.info("目标函数已设置")
    
    def optimize(self, facade_data: FacadeData, climate_data: ClimateData, 
                n_objectives: int = 2) -> OptimizationResults:
        """执行NSGA-III优化"""
        try:
            if self.objective_function is None:
                raise NSGA3Error("未设置目标函数")
            
            # 保存facade_data供多样性生成使用
            self._current_facade_data = facade_data
            
            # 初始化约束处理器
            self.constraint_handler = ConstraintHandler(facade_data)
            
            results = OptimizationResults(
                algorithm_name="NSGA-III",
                population_size=self.config.population_size,
                max_generations=self.config.max_generations
            )
            
            # 生成参考点
            self.reference_points = ReferencePointGenerator.generate_reference_points(
                n_objectives, self.config.reference_points_divisions
            )
            
            # 初始化种群
            population = self._initialize_population(facade_data)
            
            # 评估初始种群
            self._evaluate_population(population, facade_data, climate_data)
            
            # 主优化循环
            for generation in range(self.config.max_generations):
                self.current_generation = generation
                
                # 生成子代
                offspring = self._generate_offspring(population, facade_data)
                
                # 评估子代
                self._evaluate_population(offspring, facade_data, climate_data)
                
                # 合并父代和子代
                combined_population = population + offspring
                
                # 环境选择
                population = self._environmental_selection(combined_population)
                
                # 记录进化历史和监控
                generation_stats = self.monitor.record_generation(generation, population)
                self.evolution_history.append(generation_stats)
                
                # 更新自适应参数
                self.genetic_operators.update_adaptive_parameters(generation, population)
                
                # 极大增强的多样性保持机制 - 每代都检查
                if generation % 2 == 0:  # 每2代检查一次，更频繁
                    population = self._maintain_diversity_enhanced(population, facade_data, generation)
                
                # 极大增强的自适应重启机制 - 更早触发
                stagnation_count = self.monitor.get_stagnation_count()
                if stagnation_count > 5:  # 5代无改进时触发重启，更早干预
                    population = self._adaptive_restart(population, facade_data, generation)
                    logger.info(f"第{generation}代触发自适应重启，重新初始化60%种群")
                
                # 新增：极端多样性注入机制
                if generation % 3 == 0 and generation > 10:  # 每3代注入极端个体
                    extreme_count = self.config.population_size // 8
                    population = self._inject_extreme_diversity(population, facade_data, extreme_count)
                    logger.info(f"第{generation}代注入{extreme_count}个极端多样化个体")
                
                # 检查收敛和早停
                if self.monitor.check_convergence():
                    logger.info(f"第{generation}代检测到收敛，提前结束优化")
                    break
                
                if self.monitor.check_early_stopping(generation):
                    logger.info(f"第{generation}代触发早停，结束优化")
                    break
            
            # 提取最终结果
            pareto_front = self._extract_pareto_front(population)
            results.pareto_solutions = pareto_front
            results.actual_generations = self.current_generation + 1
            results.evolution_history = self.evolution_history
            results.total_evaluations = results.actual_generations * self.config.population_size
            
            return results
            
        except Exception as e:
            error_msg = f"NSGA-III优化失败: {str(e)}"
            logger.error(error_msg)
            raise NSGA3Error(error_msg) from e  
  
    def _initialize_population(self, facade_data: FacadeData) -> List[Individual]:
        """初始化种群 - 大幅增加随机度以获得更多帕累托解"""
        try:
            population = []
            num_windows = len(facade_data.windows)
            
            for i in range(self.config.population_size):
                individual = Individual()
                
                # 极大增加随机度：窗户横向长度变化范围进一步扩大以获得更多帕累托解
                individual.window_width_scales = np.random.uniform(0.05, 6.0, num_windows)  # 极大扩大范围
                
                # 进一步增加遮阳类型的随机性和多样性
                individual.shading_types = np.random.choice([0, 1], size=num_windows, p=[0.3, 0.7])  # 30%无遮阳，70%有遮阳
                individual.shading_depths = np.random.uniform(0.01, 4.0, num_windows)  # 极大扩大深度范围
                
                # 简化后的系统：只允许窗户宽度变化，高度和位置固定
                individual.window_height_scales = np.ones(num_windows)
                individual.window_positions_x = np.zeros(num_windows)
                individual.window_positions_y = np.zeros(num_windows)
                
                individual.shading_widths = np.ones(num_windows)
                individual.shading_angles = np.random.uniform(-45, 45, num_windows)  # 增加角度随机性
                
                individual.generation = 0
                population.append(individual)
            
            # 额外生成一些极端多样化的个体以增加帕累托解数量
            extreme_count = min(20, self.config.population_size // 10)
            for i in range(extreme_count):
                individual = Individual()
                
                # 极端参数设置
                individual.window_width_scales = np.random.choice(
                    [np.random.uniform(0.05, 0.3, num_windows),  # 极小窗户
                     np.random.uniform(3.0, 5.0, num_windows),   # 极大窗户
                     np.random.uniform(0.8, 1.2, num_windows)]   # 标准窗户
                )
                
                individual.shading_types = np.random.choice([0, 1], size=num_windows)
                individual.shading_depths = np.random.choice(
                    [np.random.uniform(0.01, 0.1, num_windows),  # 极浅遮阳
                     np.random.uniform(2.0, 4.0, num_windows),   # 极深遮阳
                     np.random.uniform(0.3, 0.8, num_windows)]   # 标准遮阳
                )
                
                individual.window_height_scales = np.ones(num_windows)
                individual.window_positions_x = np.zeros(num_windows)
                individual.window_positions_y = np.zeros(num_windows)
                individual.shading_widths = np.ones(num_windows)
                individual.shading_angles = np.random.uniform(-60, 60, num_windows)
                
                individual.generation = 0
                population.append(individual)
            
            # 确保种群大小正确
            population = population[:self.config.population_size]
            
            logger.info(f"初始化种群完成，种群大小: {len(population)}，包含{extreme_count}个极端多样化个体")
            return population
            
        except Exception as e:
            logger.error(f"种群初始化失败: {str(e)}")
            raise NSGA3Error(f"种群初始化失败: {str(e)}") from e
    
    def _evaluate_population(self, population: List[Individual], 
                           facade_data: FacadeData, climate_data: ClimateData):
        """评估种群"""
        try:
            for individual in population:
                if individual.objectives is None:
                    try:
                        # 检查约束并修复个体
                        if self.constraint_handler:
                            individual = self.constraint_handler.repair_individual(individual)
                            individual.constraint_violations = self.constraint_handler.check_constraints(individual)
                        
                        # 计算目标函数值
                        individual.objectives = self.objective_function(
                            individual, facade_data, climate_data
                        )
                        
                        # 如果违反约束，添加惩罚
                        if self.constraint_handler and individual.constraint_violations:
                            penalty = self.constraint_handler.calculate_penalty(individual.constraint_violations)
                            individual.objectives = [obj + penalty for obj in individual.objectives]
                        
                    except Exception as e:
                        logger.warning(f"个体评估失败: {str(e)}")
                        individual.objectives = [float('inf')] * 2
        except Exception as e:
            logger.error(f"种群评估失败: {str(e)}")
            raise NSGA3Error(f"种群评估失败: {str(e)}") from e
    
    def _generate_offspring(self, population: List[Individual], 
                          facade_data: FacadeData) -> List[Individual]:
        """生成子代"""
        try:
            offspring = []
            
            # 使用选择算子选择父代
            parents = self.genetic_operators.select(population, self.config.population_size * 2)
            
            for i in range(0, len(parents), 2):
                parent1 = parents[i]
                parent2 = parents[min(i + 1, len(parents) - 1)]
                
                # 使用遗传算子管理器进行交叉
                child1, child2 = self.genetic_operators.crossover(parent1, parent2, facade_data)
                
                # 使用遗传算子管理器进行变异
                child1 = self.genetic_operators.mutate(child1, facade_data)
                child2 = self.genetic_operators.mutate(child2, facade_data)
                
                # 设置代数信息
                child1.generation = self.current_generation + 1
                child2.generation = self.current_generation + 1
                
                offspring.extend([child1, child2])
                
                # 确保不超过所需数量
                if len(offspring) >= self.config.population_size:
                    break
            
            return offspring[:self.config.population_size]
            
        except Exception as e:
            logger.error(f"子代生成失败: {str(e)}")
            raise NSGA3Error(f"子代生成失败: {str(e)}") from e
    
    def _crossover(self, parent1: Individual, parent2: Individual) -> Individual:
        """交叉操作 - 强制原图比例和窗框/遮阳约束"""
        try:
            child = Individual()
            alpha = random.random()
            
            # 强制约束：窗户位置不变
            child.window_positions_x = np.zeros_like(parent1.window_positions_x)
            child.window_positions_y = np.zeros_like(parent1.window_positions_y)
            
            # 强制约束：窗户高度不变
            child.window_height_scales = np.ones_like(parent1.window_height_scales)
            
            # 允许宽度调整（在合理范围内）
            child.window_width_scales = (alpha * parent1.window_width_scales + 
                                       (1 - alpha) * parent2.window_width_scales)
            # 限制宽度缩放范围
            child.window_width_scales = np.clip(child.window_width_scales, 0.7, 1.5)
            
            # 遮阳深度交叉
            child.shading_depths = (alpha * parent1.shading_depths + 
                                  (1 - alpha) * parent2.shading_depths)
            # 限制遮阳深度范围
            child.shading_depths = np.clip(child.shading_depths, 0.2, 0.8)
            
            # 遮阳类型交叉
            child.shading_types = np.where(
                np.random.random(len(parent1.shading_types)) < 0.5,
                parent1.shading_types,
                parent2.shading_types
            )
            
            # 强制约束：确保每个窗户都有窗框或遮阳
            self._enforce_frame_or_shading_constraint(child)
            
            # 复制其他参数
            child.shading_widths = parent1.shading_widths.copy()
            child.shading_angles = parent1.shading_angles.copy()
            
            return child
            
        except Exception as e:
            logger.warning(f"交叉操作失败: {str(e)}")
            return parent1.copy()
    
    def _mutate(self, individual: Individual) -> Individual:
        """变异操作 - 大幅增加随机度以获得更多帕累托解"""
        try:
            # 大幅增加变异强度
            mutation_strength = 0.3  # 从0.1增加到0.3
            
            # 强制约束：窗户位置不变
            individual.window_positions_x = np.zeros_like(individual.window_positions_x)
            individual.window_positions_y = np.zeros_like(individual.window_positions_y)
            
            # 强制约束：窗户高度不变
            individual.window_height_scales = np.ones_like(individual.window_height_scales)
            
            # 窗户宽度变异（大幅扩大范围和增加变异概率）
            for i in range(len(individual.window_width_scales)):
                if random.random() < 0.4:  # 从0.15增加到0.4
                    # 使用更强的变异
                    mutation_value = random.gauss(0, mutation_strength)
                    individual.window_width_scales[i] += mutation_value
                    # 扩大允许范围
                    individual.window_width_scales[i] = np.clip(individual.window_width_scales[i], 0.1, 4.0)
                    
                    # 10%概率进行极端变异
                    if random.random() < 0.1:
                        individual.window_width_scales[i] = random.choice([
                            random.uniform(0.05, 0.3),  # 极小窗户
                            random.uniform(3.0, 5.0),   # 极大窗户
                            random.uniform(0.8, 1.2)    # 标准窗户
                        ])
            
            # 遮阳深度变异（大幅扩大范围和增加变异概率）
            for i in range(len(individual.shading_depths)):
                if random.random() < 0.4:  # 从0.15增加到0.4
                    mutation_value = random.gauss(0, mutation_strength)
                    individual.shading_depths[i] += mutation_value
                    # 扩大允许范围
                    individual.shading_depths[i] = np.clip(individual.shading_depths[i], 0.01, 3.0)
                    
                    # 10%概率进行极端变异
                    if random.random() < 0.1:
                        individual.shading_depths[i] = random.choice([
                            random.uniform(0.01, 0.1),  # 极浅遮阳
                            random.uniform(2.0, 4.0),   # 极深遮阳
                            random.uniform(0.3, 0.8)    # 标准遮阳
                        ])
            
            # 遮阳类型变异（增加变异概率）
            for i in range(len(individual.shading_types)):
                if random.random() < 0.2:  # 从0.1增加到0.2
                    individual.shading_types[i] = random.choice([0, 1])
            
            # 遮阳角度变异（增加角度随机性）
            if hasattr(individual, 'shading_angles'):
                for i in range(len(individual.shading_angles)):
                    if random.random() < 0.3:
                        individual.shading_angles[i] += random.gauss(0, 15)  # 增加角度变异强度
                        individual.shading_angles[i] = np.clip(individual.shading_angles[i], -60, 60)
            
            # 强制约束：确保每个窗户都有窗框或遮阳
            self._enforce_frame_or_shading_constraint(individual)
            
            # 使用约束处理器修复变异后的个体
            if self.constraint_handler:
                individual = self.constraint_handler.repair_individual(individual)
            
            return individual
            
        except Exception as e:
            logger.warning(f"变异操作失败: {str(e)}")
            return individual
    
    def _enforce_frame_or_shading_constraint(self, individual: Individual):
        """强制每个窗户都有窗框或遮阳的约束"""
        try:
            for i in range(len(individual.shading_types)):
                # 如果没有遮阳，确保有合理的窗框深度
                if individual.shading_types[i] == 0:
                    # 窗框深度将在窗户提取时设置为0.1
                    pass
                else:
                    # 如果有遮阳，确保遮阳深度合理
                    if i < len(individual.shading_depths) and individual.shading_depths[i] < 0.2:
                        individual.shading_depths[i] = 0.2
        except Exception as e:
            logger.warning(f"强制约束失败: {str(e)}")
    
    def _environmental_selection(self, population: List[Individual]) -> List[Individual]:
        """
        环境选择 - 高度优化版本，显著提升收敛速度和帕累托解数量
        
        这个方法是NSGA3算法的核心，通过多层次选择策略来：
        1. 快速收敛到帕累托前沿
        2. 保持解的多样性
        3. 增加帕累托解的数量
        4. 防止过早收敛
        
        Args:
            population: 合并后的种群（父代+子代）
            
        Returns:
            选择后的新种群
        """
        try:
            # 执行非支配排序，将个体分层
            fronts = NonDominatedSorting.fast_non_dominated_sort(population)
            selected_individuals = []
            
            # === 第一阶段：智能精英保留策略 ===
            generation_progress = self.current_generation / self.config.max_generations
            
            # 进一步降低精英比例以大幅增加多样性和帕累托解数量
            if generation_progress < 0.3:  # 前30%代数
                elite_ratio = 0.10  # 降低精英保留，增加探索
            elif generation_progress < 0.7:  # 中期30%-70%
                elite_ratio = 0.05  # 降低精英保留，重点维护多样性
            else:  # 后期70%以后
                elite_ratio = 0.02  # 极低精英保留，最大化多样性和帕累托解数量
            
            elite_count = max(5, int(self.config.population_size * elite_ratio))
            
            if fronts and fronts[0]:
                # 从第一前沿选择最优秀的个体作为精英
                first_front = [population[i] for i in fronts[0]]
                # 计算拥挤距离并选择分布最好的精英
                self._calculate_crowding_distance(first_front)
                first_front.sort(key=lambda x: x.crowding_distance, reverse=True)
                elite_individuals = first_front[:min(elite_count, len(first_front))]
                selected_individuals.extend(elite_individuals)
                logger.debug(f"第{self.current_generation}代选择{len(elite_individuals)}个精英个体")
            
            # === 第二阶段：多样性检测和增强 ===
            current_diversity = self._calculate_population_diversity(population)
            
            # 大幅提高多样性阈值以获得更多帕累托解
            if generation_progress < 0.4:
                diversity_threshold = 0.30  # 早期要求极高多样性
            elif generation_progress < 0.8:
                diversity_threshold = 0.25  # 中期保持极高多样性
            else:
                diversity_threshold = 0.20  # 后期仍保持很高多样性
            
            # 如果多样性不足，主动注入多样化个体
            if current_diversity < diversity_threshold:
                logger.info(f"第{self.current_generation}代多样性不足({current_diversity:.4f} < {diversity_threshold:.4f})，注入多样化个体")
                
                # 大幅增加注入比例以获得更多帕累托解
                diversity_deficit = (diversity_threshold - current_diversity) / diversity_threshold
                injection_ratio = min(0.70, 0.40 + diversity_deficit * 0.45)  # 40%-70%
                injection_count = int(self.config.population_size * injection_ratio)
                
                # 生成高质量的多样化个体
                diverse_individuals = self._generate_diverse_individuals_enhanced(
                    population, injection_count
                )
                selected_individuals.extend(diverse_individuals)
                logger.info(f"注入{len(diverse_individuals)}个多样化个体，注入比例{injection_ratio:.2%}")
            
            # === 第三阶段：分层选择策略 ===
            remaining_slots = self.config.population_size - len(selected_individuals)
            
            if remaining_slots > 0:
                # 按前沿层级逐层选择
                for front_idx, front_indices in enumerate(fronts):
                    if remaining_slots <= 0:
                        break
                    
                    # 排除已选择的个体
                    selected_ids = {id(ind) for ind in selected_individuals}
                    available_indices = [i for i in front_indices 
                                       if id(population[i]) not in selected_ids]
                    
                    if not available_indices:
                        continue
                    
                    current_front = [population[i] for i in available_indices]
                    
                    if len(current_front) <= remaining_slots:
                        # 当前前沿所有个体都可以选择
                        selected_individuals.extend(current_front)
                        remaining_slots -= len(current_front)
                        logger.debug(f"完整选择第{front_idx}前沿的{len(current_front)}个个体")
                    else:
                        # 需要从当前前沿中部分选择
                        if front_idx == 0:
                            # 第一前沿：使用拥挤距离选择，保证解的分布均匀
                            selected_from_front = self._select_by_crowding_distance_enhanced(
                                current_front, remaining_slots
                            )
                        elif front_idx == 1:
                            # 第二前沿：平衡质量和多样性
                            selected_from_front = self._select_balanced_individuals(
                                current_front, remaining_slots
                            )
                        else:
                            # 其他前沿：重点选择多样化个体
                            selected_from_front = self._select_diverse_individuals_enhanced(
                                current_front, remaining_slots
                            )
                        
                        selected_individuals.extend(selected_from_front)
                        remaining_slots -= len(selected_from_front)
                        logger.debug(f"部分选择第{front_idx}前沿的{len(selected_from_front)}个个体")
                        break
            
            # === 第四阶段：最终优化调整 ===
            final_selection = self._final_quality_adjustment_enhanced(selected_individuals)
            
            # 确保返回正确数量的个体
            result = final_selection[:self.config.population_size]
            
            # 记录选择统计信息
            pareto_count = len([ind for ind in result if hasattr(ind, 'rank') and ind.rank == 0])
            logger.debug(f"第{self.current_generation}代环境选择完成：选择{len(result)}个个体，其中{pareto_count}个帕累托解")
            
            return result
            
        except Exception as e:
            logger.error(f"环境选择失败: {str(e)}")
            # 失败时返回前N个个体作为备选方案
            return population[:self.config.population_size]
    
    def _extract_pareto_front(self, population: List[Individual]) -> List[Individual]:
        """提取帕累托前沿"""
        try:
            fronts = NonDominatedSorting.fast_non_dominated_sort(population)
            if fronts and fronts[0]:
                return [population[i] for i in fronts[0]]
            return []
        except Exception:
            return []
    
    def _calculate_population_diversity(self, population: List[Individual]) -> float:
        """计算种群多样性"""
        try:
            if len(population) < 2:
                return 0.0
            
            # 计算目标空间多样性
            objectives = [ind.objectives for ind in population if ind.objectives]
            if not objectives:
                return 0.0
            
            objectives_array = np.array(objectives)
            
            # 计算平均欧几里得距离
            total_distance = 0.0
            count = 0
            
            for i in range(len(objectives_array)):
                for j in range(i + 1, len(objectives_array)):
                    distance = np.linalg.norm(objectives_array[i] - objectives_array[j])
                    total_distance += distance
                    count += 1
            
            return total_distance / count if count > 0 else 0.0
            
        except Exception as e:
            logger.warning(f"多样性计算失败: {str(e)}")
            return 0.0
    
    def _generate_diverse_individuals(self, population: List[Individual], 
                                    count: int) -> List[Individual]:
        """生成多样化个体"""
        try:
            diverse_individuals = []
            facade_data = getattr(self, '_current_facade_data', None)
            
            if not facade_data:
                return []
            
            for _ in range(count):
                # 创建新个体，参数范围更广
                individual = Individual()
                num_windows = len(facade_data.windows)
                
                # 使用更大的参数变化范围
                individual.window_width_scales = np.random.uniform(0.3, 2.5, num_windows)
                individual.shading_types = np.random.choice([0, 1], size=num_windows, p=[0.4, 0.6])  # 恢复窗框和遮阳的选择
                individual.shading_depths = np.random.uniform(0.05, 1.2, num_windows)
                
                # 其他参数
                individual.window_height_scales = np.ones(num_windows)
                individual.window_positions_x = np.zeros(num_windows)
                individual.window_positions_y = np.zeros(num_windows)
                individual.shading_widths = np.ones(num_windows)
                individual.shading_angles = np.random.uniform(-30, 30, num_windows)
                
                individual.generation = self.current_generation
                diverse_individuals.append(individual)
            
            return diverse_individuals
            
        except Exception as e:
            logger.warning(f"多样化个体生成失败: {str(e)}")
            return []
    
    def _inject_extreme_diversity(self, population: List[Individual], 
                                facade_data: FacadeData, count: int) -> List[Individual]:
        """注入极端多样化个体以获得更多帕累托解"""
        try:
            if not hasattr(self, '_current_facade_data'):
                self._current_facade_data = facade_data
            
            num_windows = len(facade_data.windows)
            
            # 替换种群中表现最差的个体
            population_copy = population.copy()
            
            # 按适应度排序（假设有objectives属性）
            try:
                population_copy.sort(key=lambda x: sum(x.objectives) if x.objectives else float('inf'), reverse=True)
            except:
                # 如果没有objectives，随机选择
                import random
                random.shuffle(population_copy)
            
            for i in range(min(count, len(population_copy))):
                # 创建极端个体
                extreme_individual = Individual()
                
                # 策略1：极端窗户尺寸
                if i % 4 == 0:  # 极大窗户
                    extreme_individual.window_width_scales = np.random.uniform(3.0, 5.0, num_windows)
                elif i % 4 == 1:  # 极小窗户
                    extreme_individual.window_width_scales = np.random.uniform(0.05, 0.2, num_windows)
                elif i % 4 == 2:  # 混合极端
                    extreme_individual.window_width_scales = np.array([
                        np.random.choice([np.random.uniform(0.05, 0.3), np.random.uniform(2.5, 4.0)])
                        for _ in range(num_windows)
                    ])
                else:  # 随机极端
                    extreme_individual.window_width_scales = np.random.uniform(0.1, 4.5, num_windows)
                
                # 策略2：极端遮阳配置
                if i % 3 == 0:  # 全遮阳
                    extreme_individual.shading_types = np.ones(num_windows, dtype=int)
                    extreme_individual.shading_depths = np.random.uniform(1.5, 3.0, num_windows)
                elif i % 3 == 1:  # 无遮阳
                    extreme_individual.shading_types = np.zeros(num_windows, dtype=int)
                    extreme_individual.shading_depths = np.random.uniform(0.01, 0.1, num_windows)
                else:  # 混合极端
                    extreme_individual.shading_types = np.random.choice([0, 1], size=num_windows)
                    extreme_individual.shading_depths = np.array([
                        np.random.choice([np.random.uniform(0.01, 0.1), np.random.uniform(2.0, 3.5)])
                        for _ in range(num_windows)
                    ])
                
                # 其他参数
                extreme_individual.window_height_scales = np.ones(num_windows)
                extreme_individual.window_positions_x = np.zeros(num_windows)
                extreme_individual.window_positions_y = np.zeros(num_windows)
                extreme_individual.shading_widths = np.ones(num_windows)
                extreme_individual.shading_angles = np.random.uniform(-90, 90, num_windows)
                extreme_individual.generation = self.current_generation
                
                # 替换表现最差的个体
                population_copy[-(i+1)] = extreme_individual
            
            return population_copy
            
        except Exception as e:
            logger.warning(f"极端多样性注入失败: {str(e)}")
            return population

    def _generate_diverse_individuals_enhanced(self, population: List[Individual], 
                                             count: int) -> List[Individual]:
        """
        生成增强的多样化个体
        
        这个方法使用多种策略生成高质量的多样化个体：
        1. 分析当前种群的参数分布
        2. 在稀疏区域生成新个体
        3. 使用多种随机化策略
        4. 确保参数的合理性
        
        Args:
            population: 当前种群
            count: 需要生成的个体数量
            
        Returns:
            多样化个体列表
        """
        try:
            diverse_individuals = []
            facade_data = getattr(self, '_current_facade_data', None)
            
            if not facade_data or count <= 0:
                return []
            
            num_windows = len(facade_data.windows)
            
            # 分析当前种群的参数分布，找到稀疏区域
            existing_params = []
            for ind in population:
                if hasattr(ind, 'window_width_scales') and hasattr(ind, 'shading_depths'):
                    params = np.concatenate([ind.window_width_scales, ind.shading_depths])
                    existing_params.append(params)
            
            # 使用多种策略生成多样化个体
            strategies = ['random_extreme', 'sparse_region', 'hybrid_combination', 'guided_mutation']
            strategy_counts = [count // 4] * 4
            strategy_counts[0] += count % 4  # 将余数分配给第一个策略
            
            for strategy, strategy_count in zip(strategies, strategy_counts):
                for _ in range(strategy_count):
                    individual = Individual()
                    
                    if strategy == 'random_extreme':
                        # 策略1：极端随机化 - 探索参数空间的边界
                        individual.window_width_scales = np.random.choice(
                            [np.random.uniform(0.3, 0.8, num_windows),   # 小窗户
                             np.random.uniform(1.8, 2.5, num_windows),   # 大窗户
                             np.random.uniform(0.3, 2.5, num_windows)]   # 完全随机
                        )
                        
                        individual.shading_depths = np.random.choice([
                            np.random.uniform(0.05, 0.3, num_windows),   # 浅遮阳
                            np.random.uniform(0.8, 1.5, num_windows),    # 深遮阳
                            np.random.uniform(0.05, 1.5, num_windows)    # 完全随机
                        ])
                        
                        # 遮阳类型也使用极端分布
                        if np.random.random() < 0.3:
                            individual.shading_types = np.zeros(num_windows, dtype=int)  # 全无遮阳
                        elif np.random.random() < 0.3:
                            individual.shading_types = np.ones(num_windows, dtype=int)   # 全有遮阳
                        else:
                            individual.shading_types = np.random.choice([0, 1], size=num_windows, p=[0.3, 0.7])
                    
                    elif strategy == 'sparse_region' and existing_params:
                        # 策略2：稀疏区域填充 - 在种群密度低的区域生成个体
                        individual = self._generate_in_sparse_region(existing_params, num_windows)
                    
                    elif strategy == 'hybrid_combination':
                        # 策略3：混合组合 - 结合现有个体的优秀特征
                        individual = self._generate_hybrid_individual(population, num_windows)
                    
                    elif strategy == 'guided_mutation':
                        # 策略4：引导变异 - 基于优秀个体进行大幅变异
                        individual = self._generate_guided_mutant(population, num_windows)
                    
                    else:
                        # 默认策略：标准随机化
                        individual.window_width_scales = np.random.uniform(0.5, 2.0, num_windows)
                        individual.shading_depths = np.random.uniform(0.1, 1.0, num_windows)
                        individual.shading_types = np.random.choice([0, 1], size=num_windows, p=[0.4, 0.6])
                    
                    # 设置其他固定参数
                    individual.window_height_scales = np.ones(num_windows)
                    individual.window_positions_x = np.zeros(num_windows)
                    individual.window_positions_y = np.zeros(num_windows)
                    individual.shading_widths = np.ones(num_windows)
                    individual.shading_angles = np.random.uniform(10, 80, num_windows)
                    
                    # 设置代数信息
                    individual.generation = self.current_generation
                    
                    # 应用约束修复
                    if self.constraint_handler:
                        individual = self.constraint_handler.repair_individual(individual)
                    
                    diverse_individuals.append(individual)
            
            logger.debug(f"使用增强策略生成{len(diverse_individuals)}个多样化个体")
            return diverse_individuals
            
        except Exception as e:
            logger.warning(f"增强多样化个体生成失败: {str(e)}")
            # 失败时使用简单策略
            return self._generate_diverse_individuals(population, count)
    
    def _generate_in_sparse_region(self, existing_params: List[np.ndarray], 
                                  num_windows: int) -> Individual:
        """在稀疏区域生成个体"""
        try:
            individual = Individual()
            
            # 计算参数空间的密度分布
            if existing_params:
                existing_array = np.array(existing_params)
                
                # 使用k-means聚类找到稀疏区域
                from sklearn.cluster import KMeans
                n_clusters = min(5, len(existing_params))
                kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
                cluster_labels = kmeans.fit_predict(existing_array)
                
                # 找到最小的聚类（稀疏区域）
                cluster_sizes = [np.sum(cluster_labels == i) for i in range(n_clusters)]
                sparse_cluster = np.argmin(cluster_sizes)
                sparse_center = kmeans.cluster_centers_[sparse_cluster]
                
                # 在稀疏区域中心附近生成个体，但增加随机性
                noise_scale = 0.3
                new_params = sparse_center + np.random.normal(0, noise_scale, len(sparse_center))
                
                # 分离窗户宽度和遮阳深度参数
                individual.window_width_scales = np.clip(new_params[:num_windows], 0.3, 2.5)
                individual.shading_depths = np.clip(new_params[num_windows:], 0.05, 1.5)
                
            else:
                # 如果没有现有参数，使用随机生成
                individual.window_width_scales = np.random.uniform(0.5, 2.0, num_windows)
                individual.shading_depths = np.random.uniform(0.1, 1.0, num_windows)
            
            # 随机生成遮阳类型
            individual.shading_types = np.random.choice([0, 1], size=num_windows, p=[0.4, 0.6])
            
            return individual
            
        except Exception as e:
            logger.warning(f"稀疏区域个体生成失败: {str(e)}")
            # 失败时返回随机个体
            individual = Individual()
            individual.window_width_scales = np.random.uniform(0.5, 2.0, num_windows)
            individual.shading_depths = np.random.uniform(0.1, 1.0, num_windows)
            individual.shading_types = np.random.choice([0, 1], size=num_windows, p=[0.4, 0.6])
            return individual
    
    def _generate_hybrid_individual(self, population: List[Individual], 
                                   num_windows: int) -> Individual:
        """生成混合个体"""
        try:
            individual = Individual()
            
            # 选择2-3个优秀个体进行混合
            pareto_individuals = [ind for ind in population if ind.rank == 0]
            if len(pareto_individuals) < 2:
                pareto_individuals = sorted(population, key=lambda x: x.rank)[:3]
            
            selected_parents = np.random.choice(pareto_individuals, 
                                              size=min(3, len(pareto_individuals)), 
                                              replace=False)
            
            # 混合窗户宽度参数
            width_contributions = []
            for parent in selected_parents:
                if hasattr(parent, 'window_width_scales'):
                    width_contributions.append(parent.window_width_scales)
            
            if width_contributions:
                # 使用加权平均，权重随机
                weights = np.random.dirichlet(np.ones(len(width_contributions)))
                individual.window_width_scales = np.zeros(num_windows)
                for i, contrib in enumerate(width_contributions):
                    individual.window_width_scales += weights[i] * contrib
                
                # 添加随机扰动
                noise = np.random.normal(0, 0.1, num_windows)
                individual.window_width_scales += noise
                individual.window_width_scales = np.clip(individual.window_width_scales, 0.3, 2.5)
            else:
                individual.window_width_scales = np.random.uniform(0.5, 2.0, num_windows)
            
            # 混合遮阳深度参数
            depth_contributions = []
            for parent in selected_parents:
                if hasattr(parent, 'shading_depths'):
                    depth_contributions.append(parent.shading_depths)
            
            if depth_contributions:
                weights = np.random.dirichlet(np.ones(len(depth_contributions)))
                individual.shading_depths = np.zeros(num_windows)
                for i, contrib in enumerate(depth_contributions):
                    individual.shading_depths += weights[i] * contrib
                
                noise = np.random.normal(0, 0.05, num_windows)
                individual.shading_depths += noise
                individual.shading_depths = np.clip(individual.shading_depths, 0.05, 1.5)
            else:
                individual.shading_depths = np.random.uniform(0.1, 1.0, num_windows)
            
            # 混合遮阳类型（多数投票）
            type_votes = np.zeros(num_windows)
            for parent in selected_parents:
                if hasattr(parent, 'shading_types'):
                    type_votes += parent.shading_types
            
            individual.shading_types = (type_votes > len(selected_parents) / 2).astype(int)
            
            # 添加一些随机变化
            for i in range(num_windows):
                if np.random.random() < 0.2:  # 20%概率随机改变
                    individual.shading_types[i] = 1 - individual.shading_types[i]
            
            return individual
            
        except Exception as e:
            logger.warning(f"混合个体生成失败: {str(e)}")
            individual = Individual()
            individual.window_width_scales = np.random.uniform(0.5, 2.0, num_windows)
            individual.shading_depths = np.random.uniform(0.1, 1.0, num_windows)
            individual.shading_types = np.random.choice([0, 1], size=num_windows, p=[0.4, 0.6])
            return individual
    
    def _generate_guided_mutant(self, population: List[Individual], 
                               num_windows: int) -> Individual:
        """生成引导变异个体"""
        try:
            # 选择一个优秀个体作为基础
            pareto_individuals = [ind for ind in population if ind.rank == 0]
            if not pareto_individuals:
                pareto_individuals = sorted(population, key=lambda x: x.rank)[:5]
            
            base_individual = np.random.choice(pareto_individuals)
            individual = base_individual.copy()
            
            # 应用大幅度变异
            mutation_strength = 0.4  # 较强的变异强度
            
            # 窗户宽度大幅变异
            for i in range(num_windows):
                if np.random.random() < 0.6:  # 60%概率变异
                    if np.random.random() < 0.3:
                        # 30%概率完全随机重置
                        individual.window_width_scales[i] = np.random.uniform(0.3, 2.5)
                    else:
                        # 70%概率大幅度变异
                        change = np.random.normal(0, mutation_strength)
                        individual.window_width_scales[i] += change
                        individual.window_width_scales[i] = np.clip(individual.window_width_scales[i], 0.3, 2.5)
            
            # 遮阳深度大幅变异
            for i in range(num_windows):
                if np.random.random() < 0.5:  # 50%概率变异
                    if np.random.random() < 0.25:
                        # 25%概率完全随机重置
                        individual.shading_depths[i] = np.random.uniform(0.05, 1.5)
                    else:
                        # 75%概率大幅度变异
                        change = np.random.normal(0, mutation_strength * 0.5)
                        individual.shading_depths[i] += change
                        individual.shading_depths[i] = np.clip(individual.shading_depths[i], 0.05, 1.5)
            
            # 遮阳类型变异
            for i in range(num_windows):
                if np.random.random() < 0.4:  # 40%概率切换
                    individual.shading_types[i] = 1 - individual.shading_types[i]
            
            return individual
            
        except Exception as e:
            logger.warning(f"引导变异个体生成失败: {str(e)}")
            individual = Individual()
            individual.window_width_scales = np.random.uniform(0.5, 2.0, num_windows)
            individual.shading_depths = np.random.uniform(0.1, 1.0, num_windows)
            individual.shading_types = np.random.choice([0, 1], size=num_windows, p=[0.4, 0.6])
            return individual
    
    def _select_diverse_individuals(self, candidates: List[Individual], 
                                  count: int) -> List[Individual]:
        """从候选个体中选择多样化个体"""
        try:
            if len(candidates) <= count:
                return candidates
            
            selected = []
            remaining = candidates.copy()
            
            # 首先选择拥挤距离最大的个体
            remaining.sort(key=lambda x: x.crowding_distance, reverse=True)
            selected.append(remaining.pop(0))
            
            # 迭代选择与已选个体距离最远的个体
            while len(selected) < count and remaining:
                max_min_distance = -1
                best_candidate = None
                best_index = -1
                
                for i, candidate in enumerate(remaining):
                    if not candidate.objectives:
                        continue
                    
                    # 计算与已选个体的最小距离
                    min_distance = float('inf')
                    for selected_ind in selected:
                        if selected_ind.objectives:
                            distance = np.linalg.norm(
                                np.array(candidate.objectives) - np.array(selected_ind.objectives)
                            )
                            min_distance = min(min_distance, distance)
                    
                    # 选择最小距离最大的个体
                    if min_distance > max_min_distance:
                        max_min_distance = min_distance
                        best_candidate = candidate
                        best_index = i
                
                if best_candidate:
                    selected.append(best_candidate)
                    remaining.pop(best_index)
                else:
                    break
            
            return selected
            
        except Exception as e:
            logger.warning(f"多样化选择失败: {str(e)}")
            return candidates[:count]
    
    def _select_diverse_individuals_enhanced(self, candidates: List[Individual], 
                                           count: int) -> List[Individual]:
        """
        增强的多样化个体选择
        
        使用多种策略确保选择的个体在目标空间和参数空间都具有良好的多样性：
        1. 目标空间距离最大化
        2. 参数空间分布均匀性
        3. 拥挤距离优化
        4. 聚类分析辅助选择
        
        Args:
            candidates: 候选个体列表
            count: 需要选择的个体数量
            
        Returns:
            选择的多样化个体列表
        """
        try:
            if len(candidates) <= count:
                return candidates
            
            # 计算所有候选个体的拥挤距离
            self._calculate_crowding_distance(candidates)
            
            selected = []
            remaining = candidates.copy()
            
            # 第一步：选择拥挤距离最大的个体作为起始点
            remaining.sort(key=lambda x: getattr(x, 'crowding_distance', 0), reverse=True)
            if remaining:
                selected.append(remaining.pop(0))
            
            # 第二步：使用改进的最大最小距离策略
            while len(selected) < count and remaining:
                best_candidate = None
                best_index = -1
                best_score = -1
                
                for i, candidate in enumerate(remaining):
                    if not candidate.objectives:
                        continue
                    
                    # 计算综合多样性得分
                    diversity_score = self._calculate_diversity_score(candidate, selected)
                    
                    if diversity_score > best_score:
                        best_score = diversity_score
                        best_candidate = candidate
                        best_index = i
                
                if best_candidate:
                    selected.append(best_candidate)
                    remaining.pop(best_index)
                else:
                    # 如果没有找到合适的候选者，选择剩余中拥挤距离最大的
                    if remaining:
                        remaining.sort(key=lambda x: getattr(x, 'crowding_distance', 0), reverse=True)
                        selected.append(remaining.pop(0))
            
            logger.debug(f"增强多样化选择完成：从{len(candidates)}个候选者中选择{len(selected)}个")
            return selected
            
        except Exception as e:
            logger.warning(f"增强多样化选择失败: {str(e)}")
            return self._select_diverse_individuals(candidates, count)
    
    def _calculate_diversity_score(self, candidate: Individual, 
                                  selected: List[Individual]) -> float:
        """
        计算个体的多样性得分
        
        综合考虑目标空间距离、参数空间距离和拥挤距离
        
        Args:
            candidate: 候选个体
            selected: 已选择的个体列表
            
        Returns:
            多样性得分（越高越好）
        """
        try:
            if not candidate.objectives or not selected:
                return getattr(candidate, 'crowding_distance', 0)
            
            # 1. 目标空间最小距离
            min_obj_distance = float('inf')
            for selected_ind in selected:
                if selected_ind.objectives:
                    obj_distance = np.linalg.norm(
                        np.array(candidate.objectives) - np.array(selected_ind.objectives)
                    )
                    min_obj_distance = min(min_obj_distance, obj_distance)
            
            # 2. 参数空间最小距离（如果可用）
            min_param_distance = 0.0
            if (hasattr(candidate, 'window_width_scales') and 
                hasattr(candidate, 'shading_depths')):
                
                candidate_params = np.concatenate([
                    candidate.window_width_scales, 
                    candidate.shading_depths
                ])
                
                min_param_distance = float('inf')
                for selected_ind in selected:
                    if (hasattr(selected_ind, 'window_width_scales') and 
                        hasattr(selected_ind, 'shading_depths')):
                        
                        selected_params = np.concatenate([
                            selected_ind.window_width_scales,
                            selected_ind.shading_depths
                        ])
                        
                        param_distance = np.linalg.norm(candidate_params - selected_params)
                        min_param_distance = min(min_param_distance, param_distance)
                
                if min_param_distance == float('inf'):
                    min_param_distance = 0.0
            
            # 3. 拥挤距离
            crowding_distance = getattr(candidate, 'crowding_distance', 0)
            
            # 综合得分：加权组合三个距离指标
            # 目标空间距离权重最高，参数空间距离次之，拥挤距离最低
            diversity_score = (0.5 * min_obj_distance + 
                             0.3 * min_param_distance + 
                             0.2 * crowding_distance)
            
            return diversity_score
            
        except Exception as e:
            logger.warning(f"多样性得分计算失败: {str(e)}")
            return getattr(candidate, 'crowding_distance', 0)
    
    def _select_by_crowding_distance_enhanced(self, candidates: List[Individual], 
                                            count: int) -> List[Individual]:
        """
        增强的拥挤距离选择
        
        在原有拥挤距离基础上，增加额外的多样性考虑
        
        Args:
            candidates: 候选个体列表
            count: 需要选择的个体数量
            
        Returns:
            选择的个体列表
        """
        try:
            if len(candidates) <= count:
                return candidates
            
            # 计算拥挤距离
            self._calculate_crowding_distance(candidates)
            
            # 增强拥挤距离计算：考虑参数空间分布
            for candidate in candidates:
                enhanced_distance = getattr(candidate, 'crowding_distance', 0)
                
                # 如果拥挤距离为无穷大，保持不变
                if enhanced_distance == float('inf'):
                    candidate.enhanced_crowding_distance = enhanced_distance
                    continue
                
                # 计算参数空间的局部密度
                param_density = self._calculate_parameter_density(candidate, candidates)
                
                # 增强拥挤距离 = 原拥挤距离 + 参数密度惩罚
                candidate.enhanced_crowding_distance = enhanced_distance + (1.0 / (param_density + 1e-6))
            
            # 按增强拥挤距离排序选择
            candidates.sort(key=lambda x: getattr(x, 'enhanced_crowding_distance', 0), reverse=True)
            
            selected = candidates[:count]
            logger.debug(f"增强拥挤距离选择完成：选择{len(selected)}个个体")
            
            return selected
            
        except Exception as e:
            logger.warning(f"增强拥挤距离选择失败: {str(e)}")
            return self._select_by_crowding_distance(candidates, count)
    
    def _calculate_parameter_density(self, individual: Individual, 
                                   population: List[Individual]) -> float:
        """
        计算个体在参数空间的局部密度
        
        Args:
            individual: 目标个体
            population: 种群
            
        Returns:
            局部密度值
        """
        try:
            if not (hasattr(individual, 'window_width_scales') and 
                   hasattr(individual, 'shading_depths')):
                return 1.0
            
            individual_params = np.concatenate([
                individual.window_width_scales,
                individual.shading_depths
            ])
            
            # 计算与其他个体的参数距离
            distances = []
            for other in population:
                if (id(other) != id(individual) and 
                    hasattr(other, 'window_width_scales') and 
                    hasattr(other, 'shading_depths')):
                    
                    other_params = np.concatenate([
                        other.window_width_scales,
                        other.shading_depths
                    ])
                    
                    distance = np.linalg.norm(individual_params - other_params)
                    distances.append(distance)
            
            if not distances:
                return 1.0
            
            # 使用k近邻密度估计
            k = min(5, len(distances))  # 使用5个最近邻
            distances.sort()
            knn_distances = distances[:k]
            
            # 密度 = 1 / 平均k近邻距离
            avg_knn_distance = np.mean(knn_distances)
            density = 1.0 / (avg_knn_distance + 1e-6)
            
            return density
            
        except Exception as e:
            logger.warning(f"参数密度计算失败: {str(e)}")
            return 1.0
    
    def _select_balanced_individuals(self, candidates: List[Individual], 
                                   count: int) -> List[Individual]:
        """
        平衡选择个体
        
        在质量和多样性之间寻找平衡
        
        Args:
            candidates: 候选个体列表
            count: 需要选择的个体数量
            
        Returns:
            选择的个体列表
        """
        try:
            if len(candidates) <= count:
                return candidates
            
            # 计算每个个体的综合得分
            for candidate in candidates:
                quality_score = self._calculate_quality_score(candidate)
                diversity_score = getattr(candidate, 'crowding_distance', 0)
                
                # 平衡质量和多样性（权重可调）
                candidate.balanced_score = 0.6 * quality_score + 0.4 * diversity_score
            
            # 按综合得分排序选择
            candidates.sort(key=lambda x: getattr(x, 'balanced_score', 0), reverse=True)
            
            selected = candidates[:count]
            logger.debug(f"平衡选择完成：选择{len(selected)}个个体")
            
            return selected
            
        except Exception as e:
            logger.warning(f"平衡选择失败: {str(e)}")
            return candidates[:count]
    
    def _calculate_quality_score(self, individual: Individual) -> float:
        """
        计算个体质量得分
        
        Args:
            individual: 个体
            
        Returns:
            质量得分
        """
        try:
            if not individual.objectives:
                return 0.0
            
            # 基于目标函数值计算质量得分
            # 这里假设目标函数值越小越好
            objectives = np.array(individual.objectives)
            
            # 使用倒数作为质量指标，避免除零
            quality_scores = []
            for obj in objectives:
                if obj > 0:
                    quality_scores.append(1.0 / obj)
                else:
                    quality_scores.append(1000.0)  # 给予很高的质量得分
            
            # 返回平均质量得分
            return np.mean(quality_scores)
            
        except Exception as e:
            logger.warning(f"质量得分计算失败: {str(e)}")
            return 0.0
    
    def _select_by_crowding_distance(self, candidates: List[Individual], 
                                   count: int) -> List[Individual]:
        """基于拥挤距离选择个体"""
        try:
            if len(candidates) <= count:
                return candidates
            
            # 计算拥挤距离
            self._calculate_crowding_distance(candidates)
            
            # 按拥挤距离降序排序
            candidates.sort(key=lambda x: getattr(x, 'crowding_distance', 0), reverse=True)
            
            return candidates[:count]
            
        except Exception as e:
            logger.warning(f"拥挤距离选择失败: {str(e)}")
            return candidates[:count]
    
    def _calculate_crowding_distance(self, individuals: List[Individual]):
        """计算拥挤距离"""
        try:
            if len(individuals) <= 2:
                for ind in individuals:
                    ind.crowding_distance = float('inf')
                return
            
            # 初始化拥挤距离
            for ind in individuals:
                ind.crowding_distance = 0.0
            
            # 获取目标值
            objectives = [ind.objectives for ind in individuals if ind.objectives]
            if not objectives:
                return
            
            objectives_array = np.array(objectives)
            n_objectives = objectives_array.shape[1]
            
            # 对每个目标计算拥挤距离
            for obj_idx in range(n_objectives):
                # 按当前目标排序
                sorted_indices = np.argsort(objectives_array[:, obj_idx])
                
                # 边界个体设为无穷大
                individuals[sorted_indices[0]].crowding_distance = float('inf')
                individuals[sorted_indices[-1]].crowding_distance = float('inf')
                
                # 计算目标范围
                obj_range = objectives_array[sorted_indices[-1], obj_idx] - objectives_array[sorted_indices[0], obj_idx]
                if obj_range == 0:
                    continue
                
                # 计算中间个体的拥挤距离
                for i in range(1, len(sorted_indices) - 1):
                    if individuals[sorted_indices[i]].crowding_distance != float('inf'):
                        distance = (objectives_array[sorted_indices[i+1], obj_idx] - 
                                  objectives_array[sorted_indices[i-1], obj_idx]) / obj_range
                        individuals[sorted_indices[i]].crowding_distance += distance
                        
        except Exception as e:
            logger.warning(f"拥挤距离计算失败: {str(e)}")
            for ind in individuals:
                ind.crowding_distance = 0.0
    
    def _final_quality_adjustment_enhanced(self, selected_individuals: List[Individual]) -> List[Individual]:
        """
        增强的最终质量调整
        
        对选择的个体进行最后的质量检查和优化调整：
        1. 移除重复或过于相似的个体
        2. 确保帕累托前沿的完整性
        3. 平衡种群的多样性分布
        4. 修复可能的约束违反
        
        Args:
            selected_individuals: 初步选择的个体列表
            
        Returns:
            最终调整后的个体列表
        """
        try:
            if not selected_individuals:
                return selected_individuals
            
            adjusted_individuals = []
            
            # 第一步：移除重复个体
            unique_individuals = self._remove_duplicates(selected_individuals)
            logger.debug(f"去重后剩余{len(unique_individuals)}个个体")
            
            # 第二步：确保帕累托前沿个体优先
            pareto_individuals = [ind for ind in unique_individuals if ind.rank == 0]
            non_pareto_individuals = [ind for ind in unique_individuals if ind.rank > 0]
            
            # 优先保留所有帕累托个体
            adjusted_individuals.extend(pareto_individuals)
            
            # 第三步：从非帕累托个体中选择补充
            remaining_slots = self.config.population_size - len(adjusted_individuals)
            if remaining_slots > 0 and non_pareto_individuals:
                # 按rank排序，优先选择rank较小的个体
                non_pareto_individuals.sort(key=lambda x: (x.rank, -getattr(x, 'crowding_distance', 0)))
                
                # 选择多样性最好的非帕累托个体
                selected_non_pareto = self._select_diverse_individuals_enhanced(
                    non_pareto_individuals, remaining_slots
                )
                adjusted_individuals.extend(selected_non_pareto)
            
            # 第四步：如果个体不足，生成补充个体
            if len(adjusted_individuals) < self.config.population_size:
                shortage = self.config.population_size - len(adjusted_individuals)
                logger.info(f"个体不足，需要生成{shortage}个补充个体")
                
                supplementary_individuals = self._generate_diverse_individuals(
                    adjusted_individuals, shortage
                )
                adjusted_individuals.extend(supplementary_individuals)
            
            # 第五步：约束修复和验证
            for individual in adjusted_individuals:
                if self.constraint_handler:
                    individual = self.constraint_handler.repair_individual(individual)
                    
                # 确保个体有有效的目标函数值
                if individual.objectives is None:
                    individual.objectives = [float('inf')] * 2  # 默认2个目标
            
            # 第六步：最终多样性优化
            if len(adjusted_individuals) > self.config.population_size:
                # 如果个体过多，进行最终的多样性选择
                final_individuals = self._select_diverse_individuals_enhanced(
                    adjusted_individuals, self.config.population_size
                )
            else:
                final_individuals = adjusted_individuals
            
            # 记录调整统计信息
            pareto_count = len([ind for ind in final_individuals if ind.rank == 0])
            logger.debug(f"最终质量调整完成：{len(final_individuals)}个个体，{pareto_count}个帕累托解")
            
            return final_individuals
            
        except Exception as e:
            logger.error(f"最终质量调整失败: {str(e)}")
            return selected_individuals[:self.config.population_size]
    
    def _remove_duplicates(self, individuals: List[Individual], 
                          tolerance: float = 1e-6) -> List[Individual]:
        """
        移除重复个体
        
        Args:
            individuals: 个体列表
            tolerance: 相似度容忍度
            
        Returns:
            去重后的个体列表
        """
        try:
            if not individuals:
                return individuals
            
            unique_individuals = []
            
            for candidate in individuals:
                is_duplicate = False
                
                for unique_ind in unique_individuals:
                    # 检查目标函数值相似度
                    if (candidate.objectives and unique_ind.objectives and
                        len(candidate.objectives) == len(unique_ind.objectives)):
                        
                        obj_diff = np.linalg.norm(
                            np.array(candidate.objectives) - np.array(unique_ind.objectives)
                        )
                        
                        if obj_diff < tolerance:
                            is_duplicate = True
                            break
                    
                    # 检查参数相似度
                    if (hasattr(candidate, 'window_width_scales') and 
                        hasattr(unique_ind, 'window_width_scales') and
                        hasattr(candidate, 'shading_depths') and 
                        hasattr(unique_ind, 'shading_depths')):
                        
                        param_diff = (np.linalg.norm(candidate.window_width_scales - unique_ind.window_width_scales) +
                                     np.linalg.norm(candidate.shading_depths - unique_ind.shading_depths))
                        
                        if param_diff < tolerance * 10:  # 参数容忍度稍大
                            is_duplicate = True
                            break
                
                if not is_duplicate:
                    unique_individuals.append(candidate)
            
            return unique_individuals
            
        except Exception as e:
            logger.warning(f"去重处理失败: {str(e)}")
            return individuals
    
    def _maintain_diversity_enhanced(self, population: List[Individual], 
                                   facade_data: FacadeData, generation: int) -> List[Individual]:
        """
        增强的多样性维护机制
        
        定期检查和维护种群多样性，防止过早收敛
        
        Args:
            population: 当前种群
            facade_data: 立面数据
            generation: 当前代数
            
        Returns:
            多样性维护后的种群
        """
        try:
            # 计算当前多样性指标
            current_diversity = self._calculate_population_diversity(population)
            param_diversity = self._calculate_parameter_diversity_population(population)
            
            # 动态多样性阈值
            generation_progress = generation / self.config.max_generations
            diversity_threshold = 0.1 * (1 - generation_progress * 0.5)  # 0.1->0.05
            
            logger.debug(f"第{generation}代多样性检查：目标多样性={current_diversity:.4f}, "
                        f"参数多样性={param_diversity:.4f}, 阈值={diversity_threshold:.4f}")
            
            # 如果多样性不足，采取维护措施
            if current_diversity < diversity_threshold or param_diversity < diversity_threshold * 0.5:
                logger.info(f"第{generation}代触发多样性维护")
                
                # 计算需要替换的个体数量
                replacement_ratio = min(0.3, (diversity_threshold - current_diversity) / diversity_threshold + 0.1)
                replacement_count = int(len(population) * replacement_ratio)
                
                # 选择要替换的个体（优先替换rank较高且拥挤距离较小的个体）
                population_sorted = sorted(population, 
                                         key=lambda x: (x.rank, -getattr(x, 'crowding_distance', 0)))
                
                # 保留前沿个体和高多样性个体
                pareto_individuals = [ind for ind in population if ind.rank == 0]
                high_diversity_individuals = sorted(population, 
                                                  key=lambda x: getattr(x, 'crowding_distance', 0), 
                                                  reverse=True)[:len(population)//3]
                
                protected_individuals = list(set(pareto_individuals + high_diversity_individuals))
                replaceable_individuals = [ind for ind in population if ind not in protected_individuals]
                
                # 选择要替换的个体
                to_replace = replaceable_individuals[-replacement_count:] if replaceable_individuals else []
                
                # 生成替换个体
                if to_replace:
                    new_individuals = self._generate_diverse_individuals_enhanced(
                        population, len(to_replace)
                    )
                    
                    # 替换个体
                    for i, old_ind in enumerate(to_replace):
                        if i < len(new_individuals):
                            population[population.index(old_ind)] = new_individuals[i]
                    
                    logger.info(f"多样性维护：替换{len(to_replace)}个个体")
            
            return population
            
        except Exception as e:
            logger.warning(f"多样性维护失败: {str(e)}")
            return population
    
    def _calculate_parameter_diversity_population(self, population: List[Individual]) -> float:
        """
        计算种群的参数多样性
        
        Args:
            population: 种群
            
        Returns:
            参数多样性值
        """
        try:
            if len(population) < 2:
                return 0.0
            
            # 提取所有个体的参数
            all_params = []
            for ind in population:
                if (hasattr(ind, 'window_width_scales') and 
                    hasattr(ind, 'shading_depths')):
                    params = np.concatenate([ind.window_width_scales, ind.shading_depths])
                    all_params.append(params)
            
            if len(all_params) < 2:
                return 0.0
            
            # 计算参数的标准差作为多样性指标
            params_array = np.array(all_params)
            param_std = np.mean(np.std(params_array, axis=0))
            
            return param_std
            
        except Exception as e:
            logger.warning(f"参数多样性计算失败: {str(e)}")
            return 0.0
    
    def _adaptive_restart(self, population: List[Individual], 
                         facade_data: FacadeData, generation: int) -> List[Individual]:
        """
        自适应重启机制
        
        当检测到严重停滞时，部分重启种群以跳出局部最优
        
        Args:
            population: 当前种群
            facade_data: 立面数据
            generation: 当前代数
            
        Returns:
            重启后的种群
        """
        try:
            logger.info(f"第{generation}代触发自适应重启")
            
            # 保留最优个体
            pareto_individuals = [ind for ind in population if ind.rank == 0]
            elite_individuals = sorted(population, key=lambda x: x.rank)[:len(population)//4]
            
            # 合并并去重保留个体
            preserved_individuals = list(set(pareto_individuals + elite_individuals))
            
            # 计算需要重新生成的个体数量
            restart_ratio = 0.7  # 重启70%的种群
            restart_count = int(len(population) * restart_ratio)
            
            # 生成新个体
            new_individuals = self._generate_diverse_individuals_enhanced(
                preserved_individuals, restart_count
            )
            
            # 构建重启后的种群
            restarted_population = preserved_individuals + new_individuals
            
            # 如果个体数量不足，补充随机个体
            while len(restarted_population) < len(population):
                additional_individuals = self._generate_diverse_individuals_enhanced(
                    restarted_population, len(population) - len(restarted_population)
                )
                restarted_population.extend(additional_individuals)
            
            # 截取到正确的种群大小
            restarted_population = restarted_population[:len(population)]
            
            # 重置停滞计数器
            self.monitor.reset_stagnation_count()
            
            logger.info(f"自适应重启完成：保留{len(preserved_individuals)}个精英，"
                       f"生成{len(new_individuals)}个新个体")
            
            return restarted_population
            
        except Exception as e:
            logger.error(f"自适应重启失败: {str(e)}")
            return population
    
    def _remove_duplicate_solutions(self, individuals: List[Individual]) -> List[Individual]:
        """移除重复解"""
        try:
            unique_individuals = []
            seen_objectives = set()
            
            for ind in individuals:
                if ind.objectives:
                    # 将目标值转换为可哈希的元组（保留3位小数）
                    obj_tuple = tuple(round(obj, 3) for obj in ind.objectives)
                    if obj_tuple not in seen_objectives:
                        seen_objectives.add(obj_tuple)
                        unique_individuals.append(ind)
                else:
                    unique_individuals.append(ind)
            
            return unique_individuals
            
        except Exception as e:
            logger.warning(f"重复解移除失败: {str(e)}")
            return individuals
    
    def _calculate_generation_statistics(self, population: List[Individual]) -> Dict[str, Any]:
        """计算代统计信息"""
        try:
            pareto_front = self._extract_pareto_front(population)
            
            stats = {
                'generation': self.current_generation,
                'population_size': len(population),
                'pareto_front_size': len(pareto_front),
                'diversity': self._calculate_population_diversity(population),
                'timestamp': time.time()
            }
            
            if pareto_front:
                objectives_matrix = np.array([ind.objectives for ind in pareto_front if ind.objectives])
                if objectives_matrix.size > 0:
                    stats['min_objectives'] = objectives_matrix.min(axis=0).tolist()
                    stats['max_objectives'] = objectives_matrix.max(axis=0).tolist()
                    stats['mean_objectives'] = objectives_matrix.mean(axis=0).tolist()
            
            return stats
            
        except Exception as e:
            logger.warning(f"统计信息计算失败: {str(e)}")
            return {'generation': self.current_generation, 'error': str(e)}


    def _maintain_diversity(self, population: List[Individual], facade_data: FacadeData, 
                          generation: int) -> List[Individual]:
        """
        优化的多样性保持机制 - 智能注入和自适应调整
        
        Args:
            population: 当前种群
            facade_data: 立面数据
            generation: 当前代数
            
        Returns:
            维护多样性后的种群
        """
        try:
            # 计算种群多样性
            diversity_score = self._calculate_population_diversity(population)
            generation_progress = generation / self.config.max_generations
            
            # 自适应多样性阈值：早期要求更高，后期适当放宽
            base_threshold = 0.12
            diversity_threshold = base_threshold * (1.0 - 0.3 * generation_progress)
            
            if diversity_score < diversity_threshold:
                logger.info(f"第{generation}代多样性不足({diversity_score:.4f}<{diversity_threshold:.4f})，智能注入新个体")
                
                # 自适应精英保留比例
                elite_ratio = 0.25 + 0.1 * generation_progress  # 25%->35%
                elite_count = int(len(population) * elite_ratio)
                
                # 多层次精英选择
                elites = self._select_multi_tier_elites(population, elite_count)
                
                # 智能生成多样化个体
                new_individuals_count = len(population) - elite_count
                new_individuals = self._generate_smart_diverse_individuals(
                    population, new_individuals_count, generation
                )
                
                # 合并并验证
                new_population = elites + new_individuals
                
                # 验证新种群质量
                new_diversity = self._calculate_population_diversity(new_population)
                logger.info(f"多样性提升: {diversity_score:.4f} -> {new_diversity:.4f}")
                
                return new_population
            
            return population
            
        except Exception as e:
            logger.error(f"多样性保持失败: {str(e)}")
            return population
    
    def _select_multi_tier_elites(self, population: List[Individual], 
                                elite_count: int) -> List[Individual]:
        """多层次精英选择"""
        try:
            fronts = NonDominatedSorting.fast_non_dominated_sort(population)
            elites = []
            
            # 从各个前沿选择精英
            for front_indices in fronts:
                if len(elites) >= elite_count:
                    break
                
                front_individuals = [population[i] for i in front_indices]
                remaining_slots = elite_count - len(elites)
                
                if len(front_individuals) <= remaining_slots:
                    elites.extend(front_individuals)
                else:
                    # 从当前前沿选择最优个体
                    self._calculate_crowding_distance(front_individuals)
                    front_individuals.sort(key=lambda x: x.crowding_distance, reverse=True)
                    elites.extend(front_individuals[:remaining_slots])
            
            return elites
            
        except Exception as e:
            logger.warning(f"多层次精英选择失败: {str(e)}")
            return population[:elite_count]
    
    def _generate_smart_diverse_individuals(self, population: List[Individual], 
                                          count: int, generation: int) -> List[Individual]:
        """智能生成多样化个体"""
        try:
            diverse_individuals = []
            facade_data = getattr(self, '_current_facade_data', None)
            
            if not facade_data:
                return self._generate_diverse_individuals(population, count)
            
            # 分析当前种群的参数分布
            param_stats = self._analyze_population_parameters(population)
            
            for i in range(count):
                individual = Individual()
                num_windows = len(facade_data.windows)
                
                # 基于参数统计生成反向多样化个体
                individual.window_width_scales = self._generate_diverse_parameter(
                    param_stats.get('window_width_scales', {}), num_windows, (0.3, 2.5)
                )
                
                individual.shading_depths = self._generate_diverse_parameter(
                    param_stats.get('shading_depths', {}), num_windows, (0.05, 1.2)
                )
                
                individual.shading_types = np.random.randint(0, 2, num_windows)
                
                # 其他参数
                individual.window_height_scales = np.ones(num_windows)
                individual.window_positions_x = np.zeros(num_windows)
                individual.window_positions_y = np.zeros(num_windows)
                individual.shading_widths = np.ones(num_windows)
                individual.shading_angles = np.random.uniform(-30, 30, num_windows)
                
                individual.generation = generation
                diverse_individuals.append(individual)
            
            return diverse_individuals
            
        except Exception as e:
            logger.warning(f"智能多样化个体生成失败: {str(e)}")
            return self._generate_diverse_individuals(population, count)
            
    def _initialize_population(self, facade_data: FacadeData) -> List[Individual]:
        """初始化种群"""
        try:
            population = []
            num_windows = len(facade_data.windows)
            
            for i in range(self.config.population_size):
                individual = Individual()
                
                # 根据任务4.3要求：窗户横向长度变化，窗框/遮阳深度控制阴影
                individual.window_width_scales = np.random.uniform(0.3, 2.5, num_windows)  # 扩大范围
                individual.shading_types = np.random.randint(0, 2, num_windows)  # 0:窗框, 1:遮阳
                individual.shading_depths = np.random.uniform(0.05, 1.5, num_windows)  # 扩大范围
                
                # 其他参数设为固定值
                individual.window_height_scales = np.ones(num_windows)
                individual.window_positions_x = np.zeros(num_windows)
                individual.window_positions_y = np.zeros(num_windows)
                individual.shading_widths = np.ones(num_windows)
                individual.shading_angles = np.random.uniform(-80, 80, num_windows)  # 扩大角度范围
                
                individual.generation = 0
                population.append(individual)
            
            return population
            
        except Exception as e:
            logger.error(f"种群初始化失败: {str(e)}")
            raise NSGA3Error(f"种群初始化失败: {str(e)}") from e

        except Exception as e:
            logger.warning(f"智能多样化个体生成失败: {str(e)}")
            return self._generate_diverse_individuals(population, count)
    
    def _analyze_population_parameters(self, population: List[Individual]) -> Dict[str, Dict]:
        """分析种群参数分布"""
        try:
            param_stats = {}
            
            # 收集参数数据
            width_scales = []
            shading_depths = []
            
            for ind in population:
                if hasattr(ind, 'window_width_scales') and ind.window_width_scales is not None:
                    width_scales.extend(ind.window_width_scales)
                if hasattr(ind, 'shading_depths') and ind.shading_depths is not None:
                    shading_depths.extend(ind.shading_depths)
            
            # 计算统计信息
            if width_scales:
                param_stats['window_width_scales'] = {
                    'mean': np.mean(width_scales),
                    'std': np.std(width_scales),
                    'min': np.min(width_scales),
                    'max': np.max(width_scales)
                }
            
            if shading_depths:
                param_stats['shading_depths'] = {
                    'mean': np.mean(shading_depths),
                    'std': np.std(shading_depths),
                    'min': np.min(shading_depths),
                    'max': np.max(shading_depths)
                }
            
            return param_stats
            
        except Exception as e:
            logger.warning(f"参数分析失败: {str(e)}")
            return {}
    
    def _generate_diverse_parameter(self, stats: Dict, size: int, 
                                  bounds: Tuple[float, float]) -> np.ndarray:
        """生成多样化参数"""
        try:
            if not stats:
                return np.random.uniform(bounds[0], bounds[1], size)
            
            mean = stats.get('mean', (bounds[0] + bounds[1]) / 2)
            std = stats.get('std', (bounds[1] - bounds[0]) / 6)
            
            # 生成远离均值的多样化参数
            diverse_params = []
            for _ in range(size):
                if np.random.random() < 0.5:
                    # 生成低于均值的参数
                    param = np.random.normal(mean - 2*std, std/2)
                else:
                    # 生成高于均值的参数
                    param = np.random.normal(mean + 2*std, std/2)
                
                # 确保在边界内
                param = np.clip(param, bounds[0], bounds[1])
                diverse_params.append(param)
            
            return np.array(diverse_params)
            
        except Exception as e:
            logger.warning(f"多样化参数生成失败: {str(e)}")
            return np.random.uniform(bounds[0], bounds[1], size)
    
    def _calculate_population_diversity(self, population: List[Individual]) -> float:
        """
        计算种群多样性
        
        Args:
            population: 种群
            
        Returns:
            多样性分数 (0-1)
        """
        try:
            if len(population) < 2:
                return 0.0
            
            # 计算参数空间的多样性
            param_diversity = 0.0
            
            # 窗户宽度缩放因子的多样性
            width_scales = [ind.window_width_scales for ind in population]
            if width_scales:
                width_matrix = np.array(width_scales)
                width_std = np.mean(np.std(width_matrix, axis=0))
                param_diversity += width_std
            
            # 遮阳深度的多样性
            shading_depths = [ind.shading_depths for ind in population]
            if shading_depths:
                depth_matrix = np.array(shading_depths)
                depth_std = np.mean(np.std(depth_matrix, axis=0))
                param_diversity += depth_std
            
            # 遮阳类型的多样性
            shading_types = [ind.shading_types for ind in population]
            if shading_types:
                type_matrix = np.array(shading_types)
                type_entropy = 0.0
                for i in range(type_matrix.shape[1]):
                    col = type_matrix[:, i]
                    unique, counts = np.unique(col, return_counts=True)
                    probs = counts / len(col)
                    entropy = -np.sum(probs * np.log2(probs + 1e-10))
                    type_entropy += entropy
                param_diversity += type_entropy / type_matrix.shape[1]
            
            # 目标空间的多样性
            objectives = [ind.objectives for ind in population if ind.objectives]
            if objectives:
                obj_matrix = np.array(objectives)
                obj_std = np.mean(np.std(obj_matrix, axis=0))
                param_diversity += obj_std * 0.1  # 降低目标空间多样性的权重
            
            return min(1.0, param_diversity / 3.0)  # 归一化到0-1
            
        except Exception as e:
            logger.error(f"多样性计算失败: {str(e)}")
            return 0.5
    
    def _generate_diverse_individuals_advanced(self, facade_data: FacadeData, count: int,
                                             existing_population: List[Individual]) -> List[Individual]:
        """
        生成多样化的新个体
        
        Args:
            facade_data: 立面数据
            count: 需要生成的个体数量
            existing_population: 现有种群
            
        Returns:
            新生成的多样化个体列表
        """
        try:
            new_individuals = []
            num_windows = len(facade_data.windows)
            
            # 分析现有种群的参数分布
            existing_width_scales = [ind.window_width_scales for ind in existing_population]
            existing_depths = [ind.shading_depths for ind in existing_population]
            
            if existing_width_scales and existing_depths:
                width_mean = np.mean(existing_width_scales, axis=0)
                width_std = np.std(existing_width_scales, axis=0)
                depth_mean = np.mean(existing_depths, axis=0)
                depth_std = np.std(existing_depths, axis=0)
            else:
                width_mean = np.ones(num_windows)
                width_std = np.ones(num_windows) * 0.3
                depth_mean = np.ones(num_windows) * 0.5
                depth_std = np.ones(num_windows) * 0.2
            
            for i in range(count):
                individual = Individual()
                
                # 生成与现有种群差异较大的参数
                if i < count // 3:
                    # 1/3 的个体使用反向采样
                    individual.window_width_scales = np.clip(
                        2.5 - width_mean + np.random.normal(0, width_std * 1.5, num_windows),
                        0.5, 2.0
                    )
                    individual.shading_depths = np.clip(
                        1.1 - depth_mean + np.random.normal(0, depth_std * 1.5, num_windows),
                        0.1, 1.0
                    )
                elif i < 2 * count // 3:
                    # 1/3 的个体使用极值采样
                    individual.window_width_scales = np.random.choice(
                        [0.5, 2.0], num_windows, p=[0.5, 0.5]
                    ) + np.random.normal(0, 0.1, num_windows)
                    individual.window_width_scales = np.clip(individual.window_width_scales, 0.5, 2.0)
                    
                    individual.shading_depths = np.random.choice(
                        [0.1, 1.0], num_windows, p=[0.5, 0.5]
                    ) + np.random.normal(0, 0.05, num_windows)
                    individual.shading_depths = np.clip(individual.shading_depths, 0.1, 1.0)
                else:
                    # 1/3 的个体使用完全随机采样
                    individual.window_width_scales = np.random.uniform(0.5, 2.0, num_windows)
                    individual.shading_depths = np.random.uniform(0.1, 1.0, num_windows)
                
                # 遮阳类型随机分配
                individual.shading_types = np.random.randint(0, 2, num_windows)
                
                # 其他参数设为默认值
                individual.window_height_scales = np.ones(num_windows)
                individual.window_positions_x = np.zeros(num_windows)
                individual.window_positions_y = np.zeros(num_windows)
                individual.shading_widths = np.ones(num_windows)
                individual.shading_angles = np.zeros(num_windows)
                
                individual.generation = self.current_generation + 1
                new_individuals.append(individual)
            
            return new_individuals
            
        except Exception as e:
            logger.error(f"多样化个体生成失败: {str(e)}")
            # 返回基本的随机个体
            return self._initialize_population(facade_data)[:count]


    def _maintain_diversity_enhanced(self, population: List[Individual], facade_data: FacadeData, generation: int) -> List[Individual]:
        """增强的多样性保持机制"""
        try:
            # 计算种群多样性
            diversity = self._calculate_population_diversity(population)
            
            # 动态调整多样性阈值
            base_threshold = 0.15
            adaptive_threshold = base_threshold * (1 - generation / self.config.max_generations * 0.5)
            
            if diversity < adaptive_threshold:
                # 根据多样性丢失程度决定注入比例
                if diversity < 0.05:
                    injection_ratio = 0.25  # 严重丢失，注入25%
                elif diversity < 0.1:
                    injection_ratio = 0.15  # 中等丢失，注入15%
                else:
                    injection_ratio = 0.1   # 轻微丢失，注入10%
                
                num_new_individuals = int(self.config.population_size * injection_ratio)
                logger.info(f"第{generation}代多样性过低({diversity:.3f})，注入{num_new_individuals}个新个体")
                
                # 使用多种策略生成新个体
                population = self._inject_diverse_individuals(population, facade_data, num_new_individuals)
            
            return population
            
        except Exception as e:
            logger.warning(f"增强多样性保持失败: {str(e)}")
            return population
    
    def _adaptive_restart(self, population: List[Individual], facade_data: FacadeData, generation: int) -> List[Individual]:
        """自适应重启机制"""
        try:
            # 保留最好的70%个体
            population.sort(key=lambda x: x.fitness if hasattr(x, 'fitness') else float('inf'))
            num_keep = int(self.config.population_size * 0.7)
            num_restart = self.config.population_size - num_keep
            
            # 重新初始化30%的个体
            for i in range(num_restart):
                new_individual = self._create_diverse_individual(facade_data, population[:num_keep])
                population[num_keep + i] = new_individual
            
            # 重置停滞计数器
            if hasattr(self.monitor, 'reset_stagnation_count'):
                self.monitor.reset_stagnation_count()
            
            return population
            
        except Exception as e:
            logger.warning(f"自适应重启失败: {str(e)}")
            return population
    
    def _inject_diverse_individuals(self, population: List[Individual], facade_data: FacadeData, num_inject: int) -> List[Individual]:
        """注入多样化个体"""
        try:
            # 按适应度排序，替换最差的个体
            population.sort(key=lambda x: x.fitness if hasattr(x, 'fitness') else float('inf'))
            
            for i in range(num_inject):
                # 使用不同策略生成新个体
                if i % 3 == 0:
                    # 完全随机个体
                    new_individual = self._create_random_individual(facade_data)
                elif i % 3 == 1:
                    # 基于最佳个体的变异
                    new_individual = self._create_mutated_individual(population[0], facade_data)
                else:
                    # 基于多样性的个体
                    new_individual = self._create_diverse_individual(facade_data, population)
                
                population[-(i+1)] = new_individual
            
            return population
            
        except Exception as e:
            logger.warning(f"注入多样化个体失败: {str(e)}")
            return population
    
    def _create_random_individual(self, facade_data: FacadeData) -> Individual:
        """创建完全随机的个体"""
        try:
            individual = Individual()
            num_windows = len(facade_data.windows)
            
            # 随机窗户宽度缩放
            individual.window_width_scales = np.random.uniform(0.7, 1.4, num_windows)
            individual.window_height_scales = np.ones(num_windows)  # 高度保持不变
            
            # 随机位置偏移
            individual.window_positions_x = np.random.uniform(-0.3, 0.3, num_windows)
            individual.window_positions_y = np.random.uniform(-0.2, 0.2, num_windows)
            
            # 随机遮阳配置
            individual.shading_types = np.random.choice([0, 1], num_windows)
            individual.shading_depths = np.random.uniform(0.2, 1.2, num_windows)
            
            return individual
            
        except Exception as e:
            logger.warning(f"创建随机个体失败: {str(e)}")
            return Individual()
    
    def _create_mutated_individual(self, parent: Individual, facade_data: FacadeData) -> Individual:
        """基于父个体创建变异个体"""
        try:
            individual = copy.deepcopy(parent)
            
            # 强变异
            mutation_strength = 0.3
            num_windows = len(facade_data.windows)
            
            # 变异窗户宽度
            if hasattr(individual, 'window_width_scales'):
                noise = np.random.normal(0, mutation_strength, num_windows)
                individual.window_width_scales = np.clip(
                    individual.window_width_scales + noise, 0.7, 1.4
                )
            
            # 变异遮阳深度
            if hasattr(individual, 'shading_depths'):
                noise = np.random.normal(0, mutation_strength, num_windows)
                individual.shading_depths = np.clip(
                    individual.shading_depths + noise, 0.2, 1.2
                )
            
            return individual
            
        except Exception as e:
            logger.warning(f"创建变异个体失败: {str(e)}")
            return self._create_random_individual(facade_data)
    
    def _maintain_diversity_enhanced(self, population: List[Individual], 
                                   facade_data: FacadeData, generation: int) -> List[Individual]:
        """增强的多样性保持机制 - 优化版本，提升个体差异性"""
        try:
            current_diversity = self._calculate_population_diversity(population)
            
            # 动态多样性阈值 - 更严格的多样性要求
            generation_progress = generation / self.config.max_generations
            diversity_threshold = 0.12 - 0.04 * generation_progress  # 0.12->0.08，提高阈值
            
            if current_diversity < diversity_threshold:
                logger.info(f"第{generation}代多样性不足({current_diversity:.4f})，执行增强多样性保持")
                
                # 增加替换比例，确保足够的多样性
                replacement_count = max(8, int(self.config.population_size * 0.2))  # 提高到20%
                
                # 选择多样性最差的个体进行替换
                diversity_scores = []
                for i, ind in enumerate(population):
                    if ind.objectives:
                        # 计算与其他个体的平均距离
                        distances = []
                        for j, other in enumerate(population):
                            if i != j and other.objectives:
                                dist = np.linalg.norm(np.array(ind.objectives) - np.array(other.objectives))
                                distances.append(dist)
                        avg_distance = np.mean(distances) if distances else 0
                        diversity_scores.append((i, avg_distance))
                
                # 按多样性得分排序，选择最差的进行替换
                diversity_scores.sort(key=lambda x: x[1])
                worst_indices = [idx for idx, _ in diversity_scores[:replacement_count]]
                
                # 生成高度多样化的替换个体
                diverse_individuals = self._generate_highly_diverse_individuals(
                    population, replacement_count, facade_data
                )
                
                # 替换多样性最差的个体
                for i, new_ind in enumerate(diverse_individuals):
                    if i < len(worst_indices):
                        population[worst_indices[i]] = new_ind
                        
                # 记录多样性改善情况
                new_diversity = self._calculate_population_diversity(population)
                logger.info(f"多样性改善: {current_diversity:.4f} -> {new_diversity:.4f}")
            
            return population
            
        except Exception as e:
            logger.warning(f"多样性保持失败: {str(e)}")
            return population
    
    def _generate_highly_diverse_individuals(self, population: List[Individual], 
                                           count: int, facade_data: FacadeData) -> List[Individual]:
        """生成高度多样化个体 - 极大增强个体差异"""
        try:
            diverse_individuals = []
            num_windows = len(facade_data.windows)
            
            # 分析现有种群的参数分布
            existing_widths = []
            existing_depths = []
            for ind in population:
                if hasattr(ind, 'window_width_scales') and len(ind.window_width_scales) > 0:
                    existing_widths.extend(ind.window_width_scales)
                if hasattr(ind, 'shading_depths') and len(ind.shading_depths) > 0:
                    existing_depths.extend(ind.shading_depths)
            
            # 计算现有参数的统计信息
            width_mean = np.mean(existing_widths) if existing_widths else 1.0
            width_std = np.std(existing_widths) if existing_widths else 0.5
            depth_mean = np.mean(existing_depths) if existing_depths else 0.5
            depth_std = np.std(existing_depths) if existing_depths else 0.3
            
            for i in range(count):
                individual = Individual()
                
                # 策略1: 极端参数组合 (30%概率)
                if np.random.random() < 0.3:
                    # 极大窗户 + 深遮阳
                    if np.random.random() < 0.5:
                        individual.window_width_scales = np.random.uniform(2.0, 2.8, num_windows)
                        individual.shading_depths = np.random.uniform(0.8, 1.4, num_windows)
                    # 极小窗户 + 浅遮阳
                    else:
                        individual.window_width_scales = np.random.uniform(0.2, 0.6, num_windows)
                        individual.shading_depths = np.random.uniform(0.05, 0.3, num_windows)
                
                # 策略2: 反向分布 (30%概率)
                elif np.random.random() < 0.6:
                    # 生成与现有分布相反的参数
                    if width_mean > 1.0:
                        individual.window_width_scales = np.random.uniform(0.3, 0.8, num_windows)
                    else:
                        individual.window_width_scales = np.random.uniform(1.5, 2.5, num_windows)
                    
                    if depth_mean > 0.5:
                        individual.shading_depths = np.random.uniform(0.05, 0.4, num_windows)
                    else:
                        individual.shading_depths = np.random.uniform(0.7, 1.3, num_windows)
                
                # 策略3: 混合极端 (25%概率)
                elif np.random.random() < 0.85:
                    # 部分窗户极大，部分极小
                    individual.window_width_scales = np.zeros(num_windows)
                    individual.shading_depths = np.zeros(num_windows)
                    
                    for j in range(num_windows):
                        if np.random.random() < 0.5:
                            individual.window_width_scales[j] = np.random.uniform(2.0, 2.8)
                            individual.shading_depths[j] = np.random.uniform(0.05, 0.3)
                        else:
                            individual.window_width_scales[j] = np.random.uniform(0.2, 0.6)
                            individual.shading_depths[j] = np.random.uniform(0.8, 1.4)
                
                # 策略4: 完全随机 (15%概率)
                else:
                    individual.window_width_scales = np.random.uniform(0.2, 2.8, num_windows)
                    individual.shading_depths = np.random.uniform(0.05, 1.4, num_windows)
                
                # 遮阳类型：增加变化
                individual.shading_types = np.random.choice([0, 1], size=num_windows, p=[0.3, 0.7])
                
                # 其他参数保持简化
                individual.window_height_scales = np.ones(num_windows)
                individual.window_positions_x = np.zeros(num_windows)
                individual.window_positions_y = np.zeros(num_windows)
                individual.shading_widths = np.ones(num_windows)
                individual.shading_angles = np.random.uniform(-20, 20, num_windows)
                
                individual.generation = self.current_generation
                diverse_individuals.append(individual)
            
            logger.info(f"生成{count}个高度多样化个体")
            return diverse_individuals
            
        except Exception as e:
            logger.warning(f"高度多样化个体生成失败: {str(e)}")
            return self._generate_diverse_individuals(population, count)
    
    def _adaptive_restart(self, population: List[Individual], 
                         facade_data: FacadeData, generation: int) -> List[Individual]:
        """自适应重启机制 - 应对严重停滞"""
        try:
            logger.info(f"第{generation}代执行自适应重启")
            
            # 保留最优的30%个体
            elite_count = int(self.config.population_size * 0.3)
            
            # 按适应度排序（假设目标值越小越好）
            population_with_fitness = []
            for ind in population:
                if ind.objectives:
                    # 简单的适应度计算：两个目标的加权和
                    fitness = ind.objectives[0] + ind.objectives[1]
                    population_with_fitness.append((fitness, ind))
            
            # 排序并选择精英
            population_with_fitness.sort(key=lambda x: x[0])
            elite_individuals = [ind for _, ind in population_with_fitness[:elite_count]]
            
            # 重新初始化剩余70%的种群
            restart_count = self.config.population_size - elite_count
            new_individuals = []
            
            for i in range(restart_count):
                # 50%完全随机，50%基于精英变异
                if i < restart_count // 2:
                    # 完全随机个体
                    new_ind = self._create_random_individual(facade_data)
                else:
                    # 基于精英的强变异
                    parent = random.choice(elite_individuals)
                    new_ind = self._create_strong_mutated_individual(parent, facade_data)
                
                new_ind.generation = generation
                new_individuals.append(new_ind)
            
            # 合并精英和新个体
            restarted_population = elite_individuals + new_individuals
            
            # 重置监控器的停滞计数
            self.monitor.reset_stagnation_count()
            
            logger.info(f"自适应重启完成：保留{elite_count}个精英，生成{restart_count}个新个体")
            return restarted_population
            
        except Exception as e:
            logger.warning(f"自适应重启失败: {str(e)}")
            return population
    
    def _create_strong_mutated_individual(self, parent: Individual, facade_data: FacadeData) -> Individual:
        """创建强变异个体"""
        try:
            individual = copy.deepcopy(parent)
            num_windows = len(facade_data.windows)
            
            # 强变异参数
            strong_mutation_strength = 0.8
            
            # 强变异窗户宽度 - 更大的变化范围
            if hasattr(individual, 'window_width_scales'):
                for i in range(num_windows):
                    if np.random.random() < 0.7:  # 70%概率变异
                        noise = np.random.normal(0, strong_mutation_strength)
                        individual.window_width_scales[i] = np.clip(
                            individual.window_width_scales[i] + noise, 0.2, 2.8
                        )
            
            # 强变异遮阳深度
            if hasattr(individual, 'shading_depths'):
                for i in range(num_windows):
                    if np.random.random() < 0.7:  # 70%概率变异
                        noise = np.random.normal(0, strong_mutation_strength)
                        individual.shading_depths[i] = np.clip(
                            individual.shading_depths[i] + noise, 0.05, 1.4
                        )
            
            # 遮阳类型也可能变异
            if hasattr(individual, 'shading_types'):
                for i in range(num_windows):
                    if np.random.random() < 0.3:  # 30%概率变异
                        individual.shading_types[i] = 1 - individual.shading_types[i]
            
            return individual
            
        except Exception as e:
            logger.warning(f"创建强变异个体失败: {str(e)}")
            return self._create_random_individual(facade_data)
    
    def _final_quality_adjustment(self, selected_individuals: List[Individual]) -> List[Individual]:
        """最终质量调整 - 确保选择的个体质量"""
        try:
            if not selected_individuals:
                return selected_individuals
            
            # 检查是否有无效个体
            valid_individuals = []
            invalid_count = 0
            
            for ind in selected_individuals:
                if (hasattr(ind, 'objectives') and ind.objectives and 
                    all(obj != float('inf') for obj in ind.objectives)):
                    valid_individuals.append(ind)
                else:
                    invalid_count += 1
            
            if invalid_count > 0:
                logger.warning(f"发现{invalid_count}个无效个体，已移除")
            
            # 如果有效个体不足，用最好的个体填充
            if len(valid_individuals) < self.config.population_size:
                shortage = self.config.population_size - len(valid_individuals)
                if valid_individuals:
                    # 复制最好的个体
                    valid_individuals.sort(key=lambda x: sum(x.objectives) if x.objectives else float('inf'))
                    best_individuals = valid_individuals[:min(10, len(valid_individuals))]
                    
                    for _ in range(shortage):
                        selected_ind = random.choice(best_individuals)
                        valid_individuals.append(copy.deepcopy(selected_ind))
            
            return valid_individuals[:self.config.population_size]
            
        except Exception as e:
            logger.warning(f"最终质量调整失败: {str(e)}")
            return selected_individuals[:self.config.population_size]


def create_nsga3_optimizer(config: Optional[NSGA3Config] = None) -> NSGA3Optimizer:
    """创建NSGA-III优化器实例"""
    return NSGA3Optimizer(config)
