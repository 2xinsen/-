
"""
解决方案排序器模块

该模块实现建筑立面优化的解决方案智能排序功能，包括：
- 五个维度的最优解选择（能耗、舒适、热力、成本、综合）
- 多准则决策和权重分析
- 解的多样性评估和去重机制
- 智能排序算法

作者: Kiro AI Assistant
日期: 2025-01-25
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any, Union
import logging
from dataclasses import dataclass
import json
from pathlib import Path
import copy
from scipy.stats import rankdata
from sklearn.preprocessing import MinMaxScaler

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class RankingCriteria:
    """排序标准数据类"""
    name: str                           # 标准名称
    weight: float                       # 权重
    minimize: bool                      # 是否最小化
    description: str                    # 描述


@dataclass
class SolutionRanking:
    """解决方案排序结果数据类"""
    solution: Any                       # 解决方案
    overall_score: float               # 综合得分
    dimension_scores: Dict[str, float] # 各维度得分
    rank: int                          # 排名
    ranking_reason: str                # 排序原因


@dataclass
class Top3Solutions:
    """前3最优解数据类"""
    energy_optimal: Optional[SolutionRanking] = None      # 能耗最优
    thermal_optimal: Optional[SolutionRanking] = None     # 热工最优
    comprehensive_optimal: Optional[SolutionRanking] = None # 综合最优


class SolutionRanker:
    """
    解决方案排序器
    
    实现智能排序算法和五个维度的最优解选择
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """
        初始化解决方案排序器
        
        Args:
            config: 配置参数字典
        """
        self.config = config or self._get_default_config()
        self.scaler = MinMaxScaler()
        
        # 定义排序标准
        self.ranking_criteria = self._define_ranking_criteria()
        
        logger.info("解决方案排序器初始化完成")
    
    def _get_default_config(self) -> Dict:
        """获取默认配置"""
        return {
            # 权重配置
            'energy_weight': 0.6,          # 能耗权重
            'thermal_weight': 0.4,         # 热力性能权重
            
            # 排序参数
            'diversity_threshold': 0.1,    # 多样性阈值
            'similarity_threshold': 0.05,  # 相似性阈值
            'min_performance_threshold': 0.3,  # 最小性能阈值
            
            # 成本估算参数
            'window_cost_per_m2': 500,     # 窗户成本 元/m²
            'shading_cost_per_m2': 200,    # 遮阳成本 元/m²
            'installation_cost_factor': 1.2,  # 安装成本系数
            
            # 推荐参数
            'max_recommendations': 5,      # 最大推荐数量
            'enable_cost_estimation': True, # 启用成本估算
            'enable_diversity_check': True, # 启用多样性检查
        }
    
    def _define_ranking_criteria(self) -> Dict[str, RankingCriteria]:
        """定义排序标准"""
        return {
            'energy': RankingCriteria(
                name='energy_consumption',
                weight=self.config['energy_weight'],
                minimize=True,
                description='年度能耗 (kWh/m²·year)'
            ),

            'thermal': RankingCriteria(
                name='overall_u_value',
                weight=self.config['thermal_weight'],
                minimize=True,
                description='整体传热系数 (W/m²·K)'
            ),
            'cost': RankingCriteria(
                name='estimated_cost',
                weight=self.config['cost_weight'],
                minimize=True,
                description='估算成本 (元)'
            )
        }
    
    def rank_solutions(self, pareto_solutions: List[Any], 
                      performance_results: List[Any]) -> List[SolutionRanking]:
        """
        对解决方案进行排序
        
        Args:
            pareto_solutions: 帕累托解列表
            performance_results: 性能评估结果列表
            
        Returns:
            List[SolutionRanking]: 排序后的解决方案列表
        """
        try:
            logger.info(f"开始对{len(pareto_solutions)}个解进行排序")
            
            # 1. 估算成本
            cost_estimates = self._estimate_costs(pareto_solutions)
            
            # 2. 准备评分数据
            scoring_data = self._prepare_scoring_data(
                pareto_solutions, performance_results, cost_estimates
            )
            
            # 3. 标准化数据
            normalized_data = self._normalize_data(scoring_data)
            
            # 4. 计算综合得分
            solution_rankings = self._calculate_comprehensive_scores(
                pareto_solutions, performance_results, normalized_data, cost_estimates
            )
            
            # 5. 排序
            solution_rankings.sort(key=lambda x: x.overall_score, reverse=True)
            
            # 6. 更新排名
            for i, ranking in enumerate(solution_rankings):
                ranking.rank = i + 1
            
            logger.info(f"解决方案排序完成")
            return solution_rankings
            
        except Exception as e:
            logger.error(f"解决方案排序失败: {e}")
            return []
    
    def _estimate_costs(self, solutions: List[Any]) -> List[float]:
        """估算解决方案成本"""
        if not self.config['enable_cost_estimation']:
            return [1000.0] * len(solutions)  # 默认成本
        
        costs = []
        
        for solution in solutions:
            try:
                # 基础成本
                base_cost = 5000.0  # 基础改造成本
                
                # 窗户成本
                window_cost = 0.0
                if hasattr(solution, 'genes'):
                    width_scales = solution.genes.get('window_width_scales', np.array([1.0]))
                    height_scales = solution.genes.get('window_height_scales', np.array([1.0]))
                    
                    # 估算窗户面积变化
                    for w_scale, h_scale in zip(width_scales, height_scales):
                        base_window_area = 3.0  # 基础窗户面积 m²
                        new_area = base_window_area * w_scale * h_scale
                        area_change = abs(new_area - base_window_area)
                        window_cost += area_change * self.config['window_cost_per_m2']
                
                # 遮阳成本
                shading_cost = 0.0
                if hasattr(solution, 'genes'):
                    shading_depths = solution.genes.get('shading_depths', np.array([0.0]))
                    
                    for depth in shading_depths:
                        if depth > 0.1:  # 只有深度大于10cm才计算成本
                            shading_area = 2.0 * depth  # 简化的遮阳面积计算
                            shading_cost += shading_area * self.config['shading_cost_per_m2']
                
                # 总成本
                total_cost = (base_cost + window_cost + shading_cost) * self.config['installation_cost_factor']
                costs.append(total_cost)
                
            except Exception as e:
                logger.warning(f"成本估算失败: {e}")
                costs.append(8000.0)  # 默认成本
        
        return costs
    
    def _prepare_scoring_data(self, solutions: List[Any], 
                            performance_results: List[Any],
                            cost_estimates: List[float]) -> np.ndarray:
        """准备评分数据"""
        data = []
        
        for i, (solution, performance, cost) in enumerate(zip(solutions, performance_results, cost_estimates)):
            row = [
                performance.energy_consumption,
                performance.thermal_comfort_hours,
                performance.overall_u_value,
                cost
            ]
            data.append(row)
        
        return np.array(data)
    
    def _normalize_data(self, data: np.ndarray) -> np.ndarray:
        """标准化数据 - 改进版本，处理相同值的情况"""
        try:
            normalized_data = np.zeros_like(data)
            
            for i in range(data.shape[1]):
                col = data[:, i]
                col_min = np.min(col)
                col_max = np.max(col)
                col_range = col_max - col_min
                
                if col_range > 1e-10:
                    # 正常标准化
                    normalized_data[:, i] = (col - col_min) / col_range
                else:
                    # 如果所有值相同，根据值的好坏给予不同的得分
                    # 对于最小化目标，值越小越好
                    if i < 3:  # 前3个是最小化目标（能耗、舒适性、热力性能）
                        # 根据绝对值大小给予得分
                        avg_val = np.mean(col)
                        if avg_val < 20:  # 能耗很低
                            normalized_data[:, i] = 0.1  # 给予高分（标准化后1-0.1=0.9）
                        elif avg_val < 50:  # 能耗中等
                            normalized_data[:, i] = 0.3
                        elif avg_val < 100:  # 能耗较高
                            normalized_data[:, i] = 0.5
                        else:  # 能耗很高
                            normalized_data[:, i] = 0.8
                    else:  # 成本也是最小化目标
                        avg_val = np.mean(col)
                        if avg_val < 5000:  # 成本很低
                            normalized_data[:, i] = 0.1
                        elif avg_val < 8000:  # 成本中等
                            normalized_data[:, i] = 0.3
                        elif avg_val < 12000:  # 成本较高
                            normalized_data[:, i] = 0.5
                        else:  # 成本很高
                            normalized_data[:, i] = 0.8
                    
                    # 添加小的随机扰动以增加多样性
                    noise = np.random.normal(0, 0.01, len(col))
                    normalized_data[:, i] += noise
                    normalized_data[:, i] = np.clip(normalized_data[:, i], 0, 1)
            
            return normalized_data
            
        except Exception as e:
            logger.warning(f"数据标准化失败: {e}")
            # 备用方案：使用MinMaxScaler
            try:
                return self.scaler.fit_transform(data)
            except:
                # 最后的备用方案
                return np.full_like(data, 0.5)
    
    def _calculate_comprehensive_scores(self, solutions: List[Any],
                                      performance_results: List[Any],
                                      normalized_data: np.ndarray,
                                      cost_estimates: List[float]) -> List[SolutionRanking]:
        """计算综合得分"""
        rankings = []
        
        for i, (solution, performance, cost) in enumerate(zip(solutions, performance_results, cost_estimates)):
            # 各维度得分（标准化后，最小化目标需要取反）
            energy_score = 1.0 - normalized_data[i, 0]  # 能耗越低越好
            comfort_score = 1.0 - normalized_data[i, 1]  # 不舒适小时越少越好
            thermal_score = 1.0 - normalized_data[i, 2]  # 传热系数越低越好
            cost_score = 1.0 - normalized_data[i, 3]     # 成本越低越好
            
            # 综合得分
            overall_score = (
                energy_score * self.config['energy_weight'] +
                comfort_score * self.config['comfort_weight'] +
                thermal_score * self.config['thermal_weight'] +
                cost_score * self.config['cost_weight']
            )
            
            # 创建排序结果
            ranking = SolutionRanking(
                solution=solution,
                overall_score=overall_score,
                dimension_scores={
                    'energy': energy_score,
                    'comfort': comfort_score,
                    'thermal': thermal_score,
                    'cost': cost_score
                },
                rank=0,  # 将在排序后更新
                ranking_reason=self._generate_ranking_reason(
                    energy_score, comfort_score, thermal_score, cost_score
                )
            )
            
            rankings.append(ranking)
        
        return rankings
    
    def _generate_ranking_reason(self, energy_score: float, comfort_score: float,
                               thermal_score: float, cost_score: float) -> str:
        """生成排序原因"""
        scores = {
            '能耗': energy_score,
            '舒适性': comfort_score,
            '热力性能': thermal_score,
            '成本': cost_score
        }
        
        # 找出最强和最弱的维度
        best_dimension = max(scores, key=scores.get)
        worst_dimension = min(scores, key=scores.get)
        
        reason = f"在{best_dimension}方面表现最佳"
        if scores[worst_dimension] < 0.3:
            reason += f"，但{worst_dimension}方面需要改进"
        
        return reason
    
    def select_top3_solutions(self, solution_rankings: List[SolutionRanking],
                            performance_results: List[Any]) -> Top3Solutions:
        """
        选择三个维度的最优解：综合、热工、能耗
        
        Args:
            solution_rankings: 排序后的解决方案列表
            performance_results: 性能评估结果列表
            
        Returns:
            Top3Solutions: 三个维度的最优解
        """
        try:
            logger.info(f"开始选择三个维度的最优解，可用解数量: {len(solution_rankings)}")
            
            if not solution_rankings:
                logger.warning("没有可用的解决方案进行选择")
                return Top3Solutions()
            
            # 如果解数量不足3个，复制最佳解
            if len(solution_rankings) < 3:
                logger.warning(f"解数量不足3个({len(solution_rankings)})，将复制最佳解")
                best_solution = solution_rankings[0]
                
                return Top3Solutions(
                    comprehensive_optimal=copy.deepcopy(best_solution),
                    thermal_optimal=copy.deepcopy(best_solution),
                    energy_optimal=copy.deepcopy(best_solution)
                )
            
            # 1. 综合最优解（排名第一的解）
            comprehensive_optimal = copy.deepcopy(solution_rankings[0])
            comprehensive_optimal.ranking_reason = '综合性能最优'
            
            # 2. 热工最优解
            thermal_optimal = self._find_optimal_by_dimension(
                solution_rankings, 'thermal', '热工性能最优'
            )
            
            # 3. 能耗最优解
            energy_optimal = self._find_optimal_by_dimension(
                solution_rankings, 'energy', '能耗最优'
            )
            
            # 确保多样性
            selected_solutions = [comprehensive_optimal, thermal_optimal, energy_optimal]
            
            if self.config.get('enable_diversity_check', True):
                selected_solutions = self._ensure_diversity(selected_solutions, solution_rankings)
            
            # 确保所有解都不为None
            final_solutions = []
            for i, solution in enumerate(selected_solutions):
                if solution is not None:
                    final_solutions.append(solution)
                else:
                    # 如果某个解为None，使用最佳解替代
                    backup_solution = copy.deepcopy(solution_rankings[0])
                    backup_solution.ranking_reason = f'备用解{i+1}'
                    final_solutions.append(backup_solution)
            
            # 确保有3个解
            while len(final_solutions) < 3:
                backup_solution = copy.deepcopy(solution_rankings[0])
                backup_solution.ranking_reason = f'补充解{len(final_solutions)+1}'
                final_solutions.append(backup_solution)
            
            top3 = Top3Solutions(
                comprehensive_optimal=final_solutions[0],
                thermal_optimal=final_solutions[1],
                energy_optimal=final_solutions[2]
            )
            
            logger.info("三个维度最优解选择完成")
            return top3
            
        except Exception as e:
            logger.error(f"最优解选择失败: {e}")
            # 备用方案：返回最佳解的3个副本
            if solution_rankings:
                best_solution = solution_rankings[0]
                return Top3Solutions(
                    comprehensive_optimal=copy.deepcopy(best_solution),
                    thermal_optimal=copy.deepcopy(best_solution),
                    energy_optimal=copy.deepcopy(best_solution)
                )
            return Top3Solutions()
    
    def _find_optimal_by_dimension(self, solution_rankings: List[SolutionRanking],
                                 dimension: str, reason: str) -> SolutionRanking:
        """按维度查找最优解"""
        # 按指定维度排序
        sorted_by_dimension = sorted(
            solution_rankings, 
            key=lambda x: x.dimension_scores[dimension], 
            reverse=True
        )
        
        optimal = copy.deepcopy(sorted_by_dimension[0])
        optimal.ranking_reason = reason
        
        return optimal
    
    def _ensure_diversity(self, selected_solutions: List[SolutionRanking],
                        all_solutions: List[SolutionRanking]) -> List[SolutionRanking]:
        """确保解的多样性"""
        try:
            diverse_solutions = []
            
            for i, solution in enumerate(selected_solutions):
                if solution is None:
                    continue
                
                # 检查与已选解的相似性
                is_diverse = True
                similarity_threshold = self.config.get('similarity_threshold', 0.05)
                for existing in diverse_solutions:
                    if self._calculate_similarity(solution, existing) > similarity_threshold:
                        is_diverse = False
                        break
                
                if is_diverse:
                    diverse_solutions.append(solution)
                else:
                    # 寻找替代解
                    alternative = self._find_alternative_solution(
                        solution, diverse_solutions, all_solutions
                    )
                    if alternative:
                        diverse_solutions.append(alternative)
                    else:
                        diverse_solutions.append(solution)  # 如果找不到替代，保留原解
            
            # 确保有5个解
            while len(diverse_solutions) < 5 and len(all_solutions) > len(diverse_solutions):
                for solution in all_solutions:
                    if solution not in diverse_solutions:
                        diverse_solutions.append(solution)
                        break
            
            return diverse_solutions[:5]
            
        except Exception as e:
            logger.warning(f"多样性检查失败: {e}")
            return selected_solutions[:5]
    
    def _calculate_similarity(self, solution1: SolutionRanking, 
                            solution2: SolutionRanking) -> float:
        """计算两个解的相似性"""
        try:
            # 基于维度得分计算相似性
            scores1 = np.array(list(solution1.dimension_scores.values()))
            scores2 = np.array(list(solution2.dimension_scores.values()))
            
            # 欧几里得距离
            distance = np.sqrt(np.sum((scores1 - scores2) ** 2))
            
            # 转换为相似性（0-1，1表示完全相似）
            max_distance = np.sqrt(len(scores1))  # 最大可能距离
            similarity = 1.0 - (distance / max_distance)
            
            return similarity
            
        except Exception as e:
            logger.warning(f"相似性计算失败: {e}")
            return 0.0
    
    def _find_alternative_solution(self, original: SolutionRanking,
                                 existing_solutions: List[SolutionRanking],
                                 all_solutions: List[SolutionRanking]) -> Optional[SolutionRanking]:
        """寻找替代解"""
        try:
            # 按综合得分排序，寻找与现有解不相似的高分解
            candidates = [s for s in all_solutions if s not in existing_solutions and s != original]
            candidates.sort(key=lambda x: x.overall_score, reverse=True)
            
            for candidate in candidates:
                is_diverse = True
                similarity_threshold = self.config.get('similarity_threshold', 0.05)
                for existing in existing_solutions:
                    if self._calculate_similarity(candidate, existing) > similarity_threshold:
                        is_diverse = False
                        break
                
                if is_diverse:
                    return candidate
            
            return None
            
        except Exception as e:
            logger.warning(f"替代解查找失败: {e}")
            return None
    
    def analyze_solution_diversity(self, solution_rankings: List[SolutionRanking]) -> Dict[str, Any]:
        """分析解的多样性"""
        try:
            if len(solution_rankings) < 2:
                return {'diversity_score': 0.0, 'analysis': '解数量不足'}
            
            # 计算所有解之间的平均距离
            total_distance = 0.0
            count = 0
            
            for i in range(len(solution_rankings)):
                for j in range(i + 1, len(solution_rankings)):
                    similarity = self._calculate_similarity(
                        solution_rankings[i], solution_rankings[j]
                    )
                    distance = 1.0 - similarity
                    total_distance += distance
                    count += 1
            
            avg_distance = total_distance / count if count > 0 else 0.0
            diversity_score = avg_distance
            
            # 分析各维度的分布
            dimension_analysis = {}
            for dim in ['energy', 'comfort', 'thermal', 'cost']:
                scores = [s.dimension_scores[dim] for s in solution_rankings]
                dimension_analysis[dim] = {
                    'mean': np.mean(scores),
                    'std': np.std(scores),
                    'range': np.max(scores) - np.min(scores)
                }
            
            return {
                'diversity_score': diversity_score,
                'average_distance': avg_distance,
                'dimension_analysis': dimension_analysis,
                'analysis': f'解集多样性{"良好" if diversity_score > 0.3 else "一般" if diversity_score > 0.1 else "较差"}'
            }
            
        except Exception as e:
            logger.error(f"多样性分析失败: {e}")
            return {'diversity_score': 0.0, 'analysis': '分析失败'}
    
    def remove_duplicate_solutions(self, solution_rankings: List[SolutionRanking]) -> List[SolutionRanking]:
        """去除重复解"""
        try:
            unique_solutions = []
            
            for solution in solution_rankings:
                is_duplicate = False
                
                for existing in unique_solutions:
                    if self._calculate_similarity(solution, existing) > 0.95:  # 95%相似度认为是重复
                        is_duplicate = True
                        break
                
                if not is_duplicate:
                    unique_solutions.append(solution)
            
            logger.info(f"去重完成，从{len(solution_rankings)}个解中保留{len(unique_solutions)}个")
            return unique_solutions
            
        except Exception as e:
            logger.error(f"去重失败: {e}")
            return solution_rankings
    
    def export_ranking_results(self, solution_rankings: List[SolutionRanking],
                             top3_solutions: Top3Solutions,
                             output_path: str) -> bool:
        """
        导出排序结果
        
        Args:
            solution_rankings: 排序结果
            top3_solutions: 前3最优解
            output_path: 输出路径
            
        Returns:
            bool: 导出是否成功
        """
        try:
            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            # 准备导出数据
            export_data = {
                'ranking_summary': {
                    'total_solutions': len(solution_rankings),
                    'ranking_criteria': {
                        name: {
                            'weight': criteria.weight,
                            'minimize': criteria.minimize,
                            'description': criteria.description
                        }
                        for name, criteria in self.ranking_criteria.items()
                    }
                },
                'solution_rankings': [],
                'top5_solutions': {}
            }
            
            # 导出所有排序结果
            for ranking in solution_rankings:
                export_data['solution_rankings'].append({
                    'rank': ranking.rank,
                    'overall_score': ranking.overall_score,
                    'dimension_scores': ranking.dimension_scores,
                    'ranking_reason': ranking.ranking_reason
                })
            
            # 导出前3最优解
            top3_dict = {}
            if top3_solutions.comprehensive_optimal:
                top3_dict['comprehensive_optimal'] = self._solution_ranking_to_dict(top3_solutions.comprehensive_optimal)
            if top3_solutions.thermal_optimal:
                top3_dict['thermal_optimal'] = self._solution_ranking_to_dict(top3_solutions.thermal_optimal)
            if top3_solutions.energy_optimal:
                top3_dict['energy_optimal'] = self._solution_ranking_to_dict(top3_solutions.energy_optimal)
            
            export_data['top3_solutions'] = top3_dict
            
            # 保存到文件
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
            
            logger.info(f"排序结果已导出到: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"排序结果导出失败: {e}")
            return False
    
    def _solution_ranking_to_dict(self, ranking: SolutionRanking) -> Dict[str, Any]:
        """将排序结果转换为字典"""
        return {
            'rank': ranking.rank,
            'overall_score': ranking.overall_score,
            'dimension_scores': ranking.dimension_scores,
            'ranking_reason': ranking.ranking_reason
        }


# 便捷函数
def rank_pareto_solutions(pareto_solutions: List[Any],
                        performance_results: List[Any],
                        config: Optional[Dict] = None) -> List[SolutionRanking]:
    """
    便捷函数：对帕累托解进行排序
    """
    ranker = SolutionRanker(config)
    return ranker.rank_solutions(pareto_solutions, performance_results)


def select_top3_optimal_solutions(pareto_solutions: List[Any],
                                performance_results: List[Any],
                                config: Optional[Dict] = None) -> Top3Solutions:
    """
    便捷函数：选择三个维度的最优解
    """
    ranker = SolutionRanker(config)
    solution_rankings = ranker.rank_solutions(pareto_solutions, performance_results)
    return ranker.select_top3_solutions(solution_rankings, performance_results)
