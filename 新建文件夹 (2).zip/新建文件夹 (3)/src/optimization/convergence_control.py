
"""
收敛控制模块
实现收敛判断、早停机制和优化过程监控
"""

import numpy as np
from typing import List, Dict, Tuple, Optional, Any, Callable
import time
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
import math

from ..core.config import config_manager
from ..core.logging_config import get_logger
from ..core.exceptions import OptimizationError
from ..core.data_structures import Individual, OptimizationResults

logger = get_logger(__name__)


@dataclass
class ConvergenceConfig:
    """收敛控制配置 - 优化以减缓收敛并获得更多帕累托解"""
    # 收敛判断参数
    max_stagnation_generations: int = 100     # 大幅增加最大停滞代数以减缓收敛
    tolerance: float = 1e-8                   # 降低收敛容差以减缓收敛
    min_improvement: float = 0.0002           # 降低最小改进阈值以减缓收敛
    
    # 早停参数
    early_stopping_enabled: bool = False      # 禁用早停以获得更多代数
    patience: int = 60                        # 增加早停耐心值
    min_delta: float = 1e-6                   # 降低最小改进量
    
    # 性能监控参数
    monitoring_enabled: bool = True           # 是否启用监控
    monitoring_frequency: int = 5             # 监控频率（代数）
    save_checkpoint: bool = True              # 是否保存检查点
    checkpoint_frequency: int = 20            # 检查点保存频率
    
    # 多样性控制参数
    diversity_threshold: float = 0.01         # 多样性阈值
    diversity_weight: float = 0.3             # 多样性权重


@dataclass
class GenerationStatistics:
    """代统计信息"""
    generation: int = 0
    timestamp: float = field(default_factory=time.time)
    
    # 目标函数统计
    best_objectives: List[float] = field(default_factory=list)
    worst_objectives: List[float] = field(default_factory=list)
    mean_objectives: List[float] = field(default_factory=list)
    std_objectives: List[float] = field(default_factory=list)
    
    # 种群统计
    population_size: int = 0
    pareto_front_size: int = 0
    feasible_solutions: int = 0
    
    # 多样性统计
    objective_diversity: float = 0.0
    parameter_diversity: float = 0.0
    crowding_distance_avg: float = 0.0
    
    # 性能指标
    hypervolume: float = 0.0
    convergence_metric: float = 0.0
    
    # 算子统计
    crossover_success_rate: float = 0.0
    mutation_success_rate: float = 0.0
    
    # 约束统计
    constraint_violations: int = 0
    average_penalty: float = 0.0


class ConvergenceDetector(ABC):
    """收敛检测器基类"""
    
    @abstractmethod
    def check_convergence(self, statistics_history: List[GenerationStatistics]) -> bool:
        """检查是否收敛"""
        pass


class ObjectiveBasedConvergence(ConvergenceDetector):
    """基于目标函数的收敛检测"""
    
    def __init__(self, tolerance: float = 1e-6, min_improvement: float = 0.001,
                 stagnation_generations: int = 50):
        """
        初始化基于目标函数的收敛检测器
        
        Args:
            tolerance: 收敛容差
            min_improvement: 最小改进阈值
            stagnation_generations: 停滞代数阈值
        """
        self.tolerance = tolerance
        self.min_improvement = min_improvement
        self.stagnation_generations = stagnation_generations
    
    def check_convergence(self, statistics_history: List[GenerationStatistics]) -> bool:
        """检查基于目标函数的收敛"""
        try:
            if len(statistics_history) < self.stagnation_generations:
                return False
            
            # 获取最近的统计信息
            recent_stats = statistics_history[-self.stagnation_generations:]
            
            # 检查目标函数改进
            improvements = []
            for i in range(1, len(recent_stats)):
                current_best = recent_stats[i].best_objectives
                previous_best = recent_stats[i-1].best_objectives
                
                if current_best and previous_best:
                    # 计算相对改进
                    relative_improvement = 0.0
                    for j in range(len(current_best)):
                        if previous_best[j] != 0:
                            improvement = abs(current_best[j] - previous_best[j]) / abs(previous_best[j])
                            relative_improvement += improvement
                    
                    improvements.append(relative_improvement / len(current_best))
            
            # 检查是否停滞
            if improvements:
                avg_improvement = np.mean(improvements)
                max_improvement = max(improvements)
                
                # 收敛条件：平均改进小于阈值且最大改进小于容差
                if avg_improvement < self.min_improvement and max_improvement < self.tolerance:
                    logger.info(f"目标函数收敛检测: 平均改进={avg_improvement:.6f}, "
                              f"最大改进={max_improvement:.6f}")
                    return True
            
            return False
            
        except Exception as e:
            logger.warning(f"目标函数收敛检测失败: {str(e)}")
            return False


class DiversityBasedConvergence(ConvergenceDetector):
    """基于多样性的收敛检测"""
    
    def __init__(self, diversity_threshold: float = 0.01, window_size: int = 20):
        """
        初始化基于多样性的收敛检测器
        
        Args:
            diversity_threshold: 多样性阈值
            window_size: 评估窗口大小
        """
        self.diversity_threshold = diversity_threshold
        self.window_size = window_size
    
    def check_convergence(self, statistics_history: List[GenerationStatistics]) -> bool:
        """检查基于多样性的收敛"""
        try:
            if len(statistics_history) < self.window_size:
                return False
            
            # 获取最近的多样性统计
            recent_stats = statistics_history[-self.window_size:]
            diversities = [stat.objective_diversity for stat in recent_stats]
            
            # 检查多样性趋势
            avg_diversity = np.mean(diversities)
            diversity_trend = np.polyfit(range(len(diversities)), diversities, 1)[0]
            
            # 收敛条件：多样性低且呈下降趋势
            if avg_diversity < self.diversity_threshold and diversity_trend < 0:
                logger.info(f"多样性收敛检测: 平均多样性={avg_diversity:.6f}, "
                          f"趋势={diversity_trend:.6f}")
                return True
            
            return False
            
        except Exception as e:
            logger.warning(f"多样性收敛检测失败: {str(e)}")
            return False


class HypervolumeBasedConvergence(ConvergenceDetector):
    """基于超体积的收敛检测"""
    
    def __init__(self, improvement_threshold: float = 1e-4, window_size: int = 15):
        """
        初始化基于超体积的收敛检测器
        
        Args:
            improvement_threshold: 改进阈值
            window_size: 评估窗口大小
        """
        self.improvement_threshold = improvement_threshold
        self.window_size = window_size
    
    def check_convergence(self, statistics_history: List[GenerationStatistics]) -> bool:
        """检查基于超体积的收敛"""
        try:
            if len(statistics_history) < self.window_size:
                return False
            
            # 获取最近的超体积统计
            recent_stats = statistics_history[-self.window_size:]
            hypervolumes = [stat.hypervolume for stat in recent_stats if stat.hypervolume > 0]
            
            if len(hypervolumes) < 2:
                return False
            
            # 计算超体积改进
            improvements = []
            for i in range(1, len(hypervolumes)):
                if hypervolumes[i-1] > 0:
                    improvement = (hypervolumes[i] - hypervolumes[i-1]) / hypervolumes[i-1]
                    improvements.append(improvement)
            
            # 检查改进趋势
            if improvements:
                avg_improvement = np.mean(improvements)
                if avg_improvement < self.improvement_threshold:
                    logger.info(f"超体积收敛检测: 平均改进={avg_improvement:.6f}")
                    return True
            
            return False
            
        except Exception as e:
            logger.warning(f"超体积收敛检测失败: {str(e)}")
            return False


class EarlyStoppingController:
    """早停控制器"""
    
    def __init__(self, patience: int = 30, min_delta: float = 1e-4):
        """
        初始化早停控制器
        
        Args:
            patience: 耐心值（等待代数）
            min_delta: 最小改进量
        """
        self.patience = patience
        self.min_delta = min_delta
        self.best_metric = float('inf')
        self.wait_counter = 0
        self.best_generation = 0
    
    def check_early_stopping(self, current_generation: int, 
                           current_metric: float) -> bool:
        """
        检查是否应该早停
        
        Args:
            current_generation: 当前代数
            current_metric: 当前性能指标
            
        Returns:
            是否应该早停
        """
        try:
            # 检查是否有改进
            if current_metric < self.best_metric - self.min_delta:
                self.best_metric = current_metric
                self.best_generation = current_generation
                self.wait_counter = 0
                return False
            else:
                self.wait_counter += 1
                
                if self.wait_counter >= self.patience:
                    logger.info(f"早停触发: 在第{current_generation}代停止，"
                              f"最佳性能在第{self.best_generation}代")
                    return True
                
                return False
                
        except Exception as e:
            logger.warning(f"早停检查失败: {str(e)}")
            return False
    
    def reset(self):
        """重置早停控制器"""
        self.best_metric = float('inf')
        self.wait_counter = 0
        self.best_generation = 0


class OptimizationMonitor:
    """优化过程监控器"""
    
    def __init__(self, config: ConvergenceConfig):
        """
        初始化优化监控器
        
        Args:
            config: 收敛控制配置
        """
        self.config = config
        self.statistics_history: List[GenerationStatistics] = []
        self.start_time = time.time()
        self.checkpoints: Dict[int, Dict[str, Any]] = {}
        self.stagnation_count = 0  # 添加停滞计数器
        
        # 初始化收敛检测器
        self.convergence_detectors = [
            ObjectiveBasedConvergence(
                config.tolerance, 
                config.min_improvement, 
                config.max_stagnation_generations
            ),
            DiversityBasedConvergence(config.diversity_threshold),
            HypervolumeBasedConvergence()
        ]
        
        # 初始化早停控制器
        self.early_stopping = EarlyStoppingController(
            config.patience, 
            config.min_delta
        ) if config.early_stopping_enabled else None
        
        logger.info("优化监控器初始化完成")
    
    def record_generation(self, generation: int, population: List[Individual],
                         additional_stats: Optional[Dict[str, Any]] = None) -> GenerationStatistics:
        """
        记录代统计信息
        
        Args:
            generation: 代数
            population: 当前种群
            additional_stats: 额外统计信息
            
        Returns:
            代统计信息
        """
        try:
            stats = GenerationStatistics(generation=generation)
            
            # 计算目标函数统计
            objectives = [ind.objectives for ind in population if ind.objectives]
            if objectives:
                objectives_array = np.array(objectives)
                stats.best_objectives = objectives_array.min(axis=0).tolist()
                stats.worst_objectives = objectives_array.max(axis=0).tolist()
                stats.mean_objectives = objectives_array.mean(axis=0).tolist()
                stats.std_objectives = objectives_array.std(axis=0).tolist()
                
                # 计算目标空间多样性
                stats.objective_diversity = np.mean(np.std(objectives_array, axis=0))
            
            # 计算种群统计
            stats.population_size = len(population)
            stats.pareto_front_size = len([ind for ind in population if ind.rank == 0])
            stats.feasible_solutions = len([ind for ind in population if ind.is_feasible()])
            
            # 计算多样性统计
            stats.crowding_distance_avg = np.mean([ind.crowding_distance for ind in population])
            
            # 计算约束统计
            stats.constraint_violations = len([ind for ind in population 
                                             if ind.constraint_violations and 
                                             any(v > 0 for v in ind.constraint_violations)])
            
            # 添加额外统计信息
            if additional_stats:
                for key, value in additional_stats.items():
                    if hasattr(stats, key):
                        setattr(stats, key, value)
            
            # 记录统计信息
            self.statistics_history.append(stats)
            
            # 定期监控输出
            if (self.config.monitoring_enabled and 
                generation % self.config.monitoring_frequency == 0):
                self._log_progress(stats)
            
            # 保存检查点
            if (self.config.save_checkpoint and 
                generation % self.config.checkpoint_frequency == 0):
                self._save_checkpoint(generation, population, stats)
            
            return stats
            
        except Exception as e:
            logger.error(f"记录代统计信息失败: {str(e)}")
            return GenerationStatistics(generation=generation)
    
    def check_convergence(self) -> bool:
        """检查是否收敛"""
        try:
            if len(self.statistics_history) < 10:  # 至少需要10代数据
                return False
            
            # 使用多个收敛检测器
            convergence_votes = 0
            for detector in self.convergence_detectors:
                if detector.check_convergence(self.statistics_history):
                    convergence_votes += 1
            
            # 多数投票决定收敛
            return convergence_votes >= 2
            
        except Exception as e:
            logger.warning(f"收敛检查失败: {str(e)}")
            return False
    
    def check_early_stopping(self, generation: int) -> bool:
        """检查是否应该早停"""
        try:
            if not self.early_stopping or len(self.statistics_history) < 2:
                return False
            
            # 使用最新的收敛指标
            latest_stats = self.statistics_history[-1]
            metric = latest_stats.convergence_metric
            
            if metric == 0.0 and latest_stats.objective_diversity > 0:
                metric = 1.0 / (1.0 + latest_stats.objective_diversity)
            
            return self.early_stopping.check_early_stopping(generation, metric)
            
        except Exception as e:
            logger.warning(f"早停检查失败: {str(e)}")
            return False
    
    def _log_progress(self, stats: GenerationStatistics):
        """记录进度日志"""
        try:
            elapsed_time = time.time() - self.start_time
            
            logger.info(f"第{stats.generation}代进度报告:")
            logger.info(f"  运行时间: {elapsed_time:.2f}秒")
            logger.info(f"  种群大小: {stats.population_size}")
            logger.info(f"  帕累托前沿大小: {stats.pareto_front_size}")
            logger.info(f"  可行解数量: {stats.feasible_solutions}")
            
            if stats.best_objectives:
                logger.info(f"  最佳目标值: {[f'{obj:.6f}' for obj in stats.best_objectives]}")
            
            logger.info(f"  目标多样性: {stats.objective_diversity:.6f}")
            logger.info(f"  平均拥挤距离: {stats.crowding_distance_avg:.6f}")
            
            if stats.constraint_violations > 0:
                logger.info(f"  约束违反数: {stats.constraint_violations}")
                
        except Exception as e:
            logger.warning(f"进度日志记录失败: {str(e)}")
    
    def _save_checkpoint(self, generation: int, population: List[Individual], 
                        stats: GenerationStatistics):
        """保存检查点"""
        try:
            checkpoint = {
                'generation': generation,
                'population_size': len(population),
                'statistics': stats,
                'timestamp': time.time(),
                'elapsed_time': time.time() - self.start_time
            }
            
            self.checkpoints[generation] = checkpoint
            logger.debug(f"检查点已保存: 第{generation}代")
            
        except Exception as e:
            logger.warning(f"检查点保存失败: {str(e)}")
    
    def get_optimization_summary(self) -> Dict[str, Any]:
        """获取优化总结"""
        try:
            if not self.statistics_history:
                return {'error': '无统计数据'}
            
            total_time = time.time() - self.start_time
            final_stats = self.statistics_history[-1]
            
            # 计算改进趋势
            if len(self.statistics_history) > 1:
                initial_stats = self.statistics_history[0]
                if (initial_stats.best_objectives and final_stats.best_objectives and
                    len(initial_stats.best_objectives) == len(final_stats.best_objectives)):
                    
                    improvements = []
                    for i in range(len(final_stats.best_objectives)):
                        if initial_stats.best_objectives[i] != 0:
                            improvement = ((initial_stats.best_objectives[i] - 
                                          final_stats.best_objectives[i]) / 
                                         abs(initial_stats.best_objectives[i]))
                            improvements.append(improvement)
                else:
                    improvements = []
            else:
                improvements = []
            
            summary = {
                'total_generations': len(self.statistics_history),
                'total_time': total_time,
                'final_population_size': final_stats.population_size,
                'final_pareto_front_size': final_stats.pareto_front_size,
                'final_feasible_solutions': final_stats.feasible_solutions,
                'final_best_objectives': final_stats.best_objectives,
                'final_diversity': final_stats.objective_diversity,
                'objective_improvements': improvements,
                'convergence_achieved': self.check_convergence(),
                'checkpoints_saved': len(self.checkpoints),
                'average_generation_time': total_time / len(self.statistics_history) if self.statistics_history else 0
            }
            
            return summary
            
        except Exception as e:
            logger.error(f"优化总结生成失败: {str(e)}")
            return {'error': str(e)}
    
    def get_statistics_history(self) -> List[GenerationStatistics]:
        """获取统计历史"""
        return self.statistics_history.copy()
    
    def reset(self):
        """重置监控器"""
        self.statistics_history.clear()
        self.checkpoints.clear()
        self.start_time = time.time()
        if self.early_stopping:
            self.early_stopping.reset()
        logger.info("优化监控器已重置")


    def get_stagnation_count(self) -> int:
        """获取停滞计数"""
        return self.stagnation_count
    
    def reset_stagnation_count(self):
        """重置停滞计数器"""
        self.stagnation_count = 0
        logger.info("停滞计数器已重置")
    
    def update_stagnation_count(self, has_improvement: bool):
        """
        更新停滞计数
        
        Args:
            has_improvement: 是否有改进
        """
        if has_improvement:
            self.stagnation_count = 0
        else:
            self.stagnation_count += 1
    
    def detect_improvement(self, current_stats: GenerationStatistics) -> bool:
        """
        检测是否有改进 - 增强版本
        
        综合考虑多个指标来判断算法是否有实质性改进：
        1. 帕累托前沿大小增长
        2. 目标函数值改善
        3. 多样性维持
        4. 解的质量提升
        
        Args:
            current_stats: 当前代统计信息
            
        Returns:
            是否有改进
        """
        try:
            if len(self.statistics_history) < 2:
                return True  # 前几代默认有改进
            
            # 获取历史统计信息
            previous_stats = self.statistics_history[-2]
            
            # === 改进指标1：帕累托前沿大小 ===
            pareto_improvement = (current_stats.pareto_front_size > previous_stats.pareto_front_size)
            
            # === 改进指标2：目标函数改善 ===
            objective_improvement = False
            if (current_stats.best_objectives and previous_stats.best_objectives and
                len(current_stats.best_objectives) == len(previous_stats.best_objectives)):
                
                # 检查是否有任何目标函数值改善
                for i in range(len(current_stats.best_objectives)):
                    if current_stats.best_objectives[i] < previous_stats.best_objectives[i] * 0.999:  # 0.1%改善阈值
                        objective_improvement = True
                        break
            
            # === 改进指标3：多样性维持 ===
            diversity_maintained = (current_stats.objective_diversity >= 
                                   previous_stats.objective_diversity * 0.95)  # 允许5%的多样性下降
            
            # === 改进指标4：解的质量 ===
            quality_improvement = False
            if len(self.statistics_history) >= 5:
                # 比较最近5代的平均质量
                recent_quality = np.mean([stats.pareto_front_size for stats in self.statistics_history[-3:]])
                baseline_quality = np.mean([stats.pareto_front_size for stats in self.statistics_history[-6:-3]])
                quality_improvement = recent_quality > baseline_quality * 1.02  # 2%质量提升
            
            # === 综合判断 ===
            # 任何一个主要指标改善都认为有改进
            has_improvement = (pareto_improvement or objective_improvement or 
                             (diversity_maintained and quality_improvement))
            
            # 更新停滞计数
            self.update_stagnation_count(has_improvement)
            
            # 记录改进信息
            if has_improvement:
                improvement_reasons = []
                if pareto_improvement:
                    improvement_reasons.append("帕累托前沿扩大")
                if objective_improvement:
                    improvement_reasons.append("目标函数改善")
                if diversity_maintained and quality_improvement:
                    improvement_reasons.append("质量提升")
                
                logger.debug(f"检测到改进: {', '.join(improvement_reasons)}")
            else:
                logger.debug(f"未检测到改进，停滞计数: {self.stagnation_count}")
            
            return has_improvement
            
        except Exception as e:
            logger.warning(f"改进检测失败: {str(e)}")
            return True  # 失败时默认有改进


def create_optimization_monitor(config: Optional[ConvergenceConfig] = None) -> OptimizationMonitor:
    """
    创建优化监控器实例
    
    Args:
        config: 收敛控制配置
        
    Returns:
        优化监控器实例
    """
    return OptimizationMonitor(config or ConvergenceConfig())
