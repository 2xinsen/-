"""
遗传算法优化日志分析器
分析优化过程中的性能数据并提供改进建议
"""

import json
import os
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import pandas as pd
from dataclasses import dataclass

from ..core.logging_config import get_logger

logger = get_logger(__name__)


@dataclass
class AnalysisResult:
    """分析结果"""
    summary: Dict[str, Any]
    trends: Dict[str, List[float]]
    recommendations: List[str]
    performance_score: float
    bottlenecks: List[str]
    optimization_suggestions: List[str]


class LogAnalyzer:
    """日志分析器"""
    
    def __init__(self, log_file_path: Optional[str] = None):
        self.log_file_path = log_file_path
        self.log_data: List[Dict[str, Any]] = []
        self.analysis_cache: Dict[str, Any] = {}
        
    def load_log_file(self, file_path: str) -> bool:
        """加载日志文件"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                self.log_data = json.load(f)
            
            logger.info(f"成功加载日志文件: {file_path}")
            logger.info(f"日志条目数量: {len(self.log_data)}")
            return True
            
        except Exception as e:
            logger.error(f"日志文件加载失败: {str(e)}")
            return False
    
    def analyze_optimization_performance(self) -> AnalysisResult:
        """分析优化性能"""
        try:
            if not self.log_data:
                raise ValueError("无日志数据")
            
            # 提取关键指标
            iterations = []
            performance_scores = []
            pareto_counts = []
            execution_times = []
            diversity_values = []
            convergence_rates = []
            
            for entry in self.log_data:
                iterations.append(entry.get("iteration_id", 0))
                
                # 性能得分
                success_metrics = entry.get("success_metrics", {})
                performance_scores.append(success_metrics.get("performance_score", 0))
                
                # 帕累托解数量
                results_summary = entry.get("results_summary", {})
                pareto_counts.append(results_summary.get("pareto_solutions_count", 0))
                
                # 执行时间
                execution_times.append(entry.get("duration", 0))
                
                # 多样性和收敛率
                diversity_values.append(success_metrics.get("current_diversity", 0))
                convergence_rates.append(success_metrics.get("current_convergence_rate", 0))
            
            # 计算趋势
            trends = {
                "performance_scores": performance_scores,
                "pareto_counts": pareto_counts,
                "execution_times": execution_times,
                "diversity_values": diversity_values,
                "convergence_rates": convergence_rates
            }
            
            # 生成摘要
            summary = self._generate_summary(trends)
            
            # 生成建议
            recommendations = self._generate_recommendations(trends, summary)
            
            # 识别瓶颈
            bottlenecks = self._identify_bottlenecks(trends)
            
            # 优化建议
            optimization_suggestions = self._generate_optimization_suggestions(trends, bottlenecks)
            
            # 计算总体性能得分
            overall_score = self._calculate_overall_performance_score(trends)
            
            result = AnalysisResult(
                summary=summary,
                trends=trends,
                recommendations=recommendations,
                performance_score=overall_score,
                bottlenecks=bottlenecks,
                optimization_suggestions=optimization_suggestions
            )
            
            return result
            
        except Exception as e:
            logger.error(f"性能分析失败: {str(e)}")
            raise
    
    def _generate_summary(self, trends: Dict[str, List[float]]) -> Dict[str, Any]:
        """生成摘要统计"""
        summary = {}
        
        try:
            for key, values in trends.items():
                if values:
                    summary[key] = {
                        "mean": np.mean(values),
                        "std": np.std(values),
                        "min": np.min(values),
                        "max": np.max(values),
                        "trend": np.polyfit(range(len(values)), values, 1)[0] if len(values) > 1 else 0,
                        "final_value": values[-1],
                        "improvement": values[-1] - values[0] if len(values) > 1 else 0
                    }
            
            # 计算稳定性指标
            if trends["performance_scores"]:
                recent_scores = trends["performance_scores"][-5:]
                summary["