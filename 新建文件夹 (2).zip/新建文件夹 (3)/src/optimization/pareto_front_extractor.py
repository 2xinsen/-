
"""
帕累托前沿提取算法模块

该模块实现建筑立面优化的帕累托前沿提取功能，包括：
- 快速非支配排序算法
- 支配关系判断和前沿分层
- 拥挤距离计算和多样性保持
- 帕累托解集的筛选和排序

作者: Kiro AI Assistant
日期: 2025-01-25
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any, Union
import logging
from dataclasses import dataclass
import json
from pathlib import Path
import copy

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class ParetoSolution:
    """帕累托解数据类"""
    individual: Any                     # 个体
    objectives: List[float]             # 目标函数值
    rank: int                          # 非支配排序等级
    crowding_distance: float           # 拥挤距离
    performance_data: Optional[Dict] = None  # 性能数据
    solution_id: Optional[str] = None   # 解的唯一标识


@dataclass
class ParetoFront:
    """帕累托前沿数据类"""
    solutions: List[ParetoSolution]     # 前沿中的解
    front_rank: int                     # 前沿等级
    hypervolume: Optional[float] = None # 超体积指标
    spread: Optional[float] = None      # 分布性指标


@dataclass
class ParetoAnalysisResult:
    """帕累托分析结果数据类"""
    pareto_fronts: List[ParetoFront]    # 所有前沿
    total_solutions: int                # 总解数量
    dominated_solutions: int            # 被支配解数量
    non_dominated_solutions: int        # 非支配解数量
    objective_ranges: Dict[str, Tuple[float, float]]  # 目标函数范围
    convergence_metrics: Dict[str, float]  # 收敛性指标


class ParetoFrontExtractor:
    """
    帕累托前沿提取器
    
    实现快速非支配排序算法和帕累托前沿提取功能
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """
        初始化帕累托前沿提取器
        
        Args:
            config: 配置参数字典
        """
        self.config = config or self._get_default_config()
        self.objective_names = ['energy_consumption', 'thermal_comfort_hours', 'overall_u_value']
        self.minimize_objectives = [True, True, True]  # 所有目标都是最小化
        
        logger.info("帕累托前沿提取器初始化完成")
    
    def _get_default_config(self) -> Dict:
        """获取默认配置 - 极大优化以获得更多帕累托解"""
        return {
            'max_fronts': 500,              # 大幅增加最大前沿数量
            'crowding_distance_threshold': 1e-12,  # 进一步降低拥挤距离阈值
            'diversity_threshold': 0.0001,  # 大幅降低多样性阈值以允许更多解
            'epsilon_dominance': 0.001,     # 大幅放宽ε支配阈值，优先增加解数量
            'normalize_objectives': True,   # 启用标准化以确保公平比较
            'use_reference_point': False,   # 是否使用参考点
            'reference_point': [100.0, 300.0, 4.0],  # 参考点（能耗、舒适性、热力）
        }
    
    def extract_pareto_fronts(self, individuals: List[Any], 
                            performance_results: List[Any]) -> ParetoAnalysisResult:
        """
        提取帕累托前沿
        
        Args:
            individuals: 个体列表
            performance_results: 性能评估结果列表
            
        Returns:
            ParetoAnalysisResult: 帕累托分析结果
        """
        try:
            logger.info(f"开始提取帕累托前沿，个体数量: {len(individuals)}")
            
            # 1. 创建帕累托解
            pareto_solutions = self._create_pareto_solutions(individuals, performance_results)
            
            # 2. 标准化目标函数（如果启用）
            if self.config['normalize_objectives']:
                pareto_solutions = self._normalize_objectives(pareto_solutions)
            
            # 3. 快速非支配排序
            pareto_fronts = self._fast_non_dominated_sort(pareto_solutions)
            
            # 4. 计算拥挤距离
            for front in pareto_fronts:
                self._calculate_crowding_distance(front.solutions)
            
            # 5. 计算分析指标
            analysis_result = self._analyze_pareto_fronts(pareto_fronts, pareto_solutions)
            
            logger.info(f"帕累托前沿提取完成，共{len(pareto_fronts)}个前沿")
            return analysis_result
            
        except Exception as e:
            logger.error(f"帕累托前沿提取失败: {e}")
            return self._get_default_analysis_result()
    
    def _create_pareto_solutions(self, individuals: List[Any], 
                               performance_results: List[Any]) -> List[ParetoSolution]:
        """创建帕累托解"""
        pareto_solutions = []
        
        for i, (individual, performance) in enumerate(zip(individuals, performance_results)):
            # 提取目标函数值
            objectives = [
                performance.energy_consumption,
                performance.thermal_comfort_hours,
                performance.overall_u_value
            ]
            
            # 创建帕累托解
            solution = ParetoSolution(
                individual=individual,
                objectives=objectives,
                rank=0,  # 初始排序等级
                crowding_distance=0.0,  # 初始拥挤距离
                performance_data={
                    'energy_consumption': performance.energy_consumption,
                    'thermal_comfort_hours': performance.thermal_comfort_hours,
                    'overall_u_value': performance.overall_u_value,
                    'performance_grade': performance.performance_grade,
                    'reliability_score': performance.overall_reliability_score
                },
                solution_id=f"solution_{i}"
            )
            
            pareto_solutions.append(solution)
        
        return pareto_solutions
    
    def _normalize_objectives(self, solutions: List[ParetoSolution]) -> List[ParetoSolution]:
        """标准化目标函数值"""
        if not solutions:
            return solutions
        
        # 计算每个目标的范围
        n_objectives = len(solutions[0].objectives)
        obj_min = [float('inf')] * n_objectives
        obj_max = [float('-inf')] * n_objectives
        
        for solution in solutions:
            for i, obj_val in enumerate(solution.objectives):
                obj_min[i] = min(obj_min[i], obj_val)
                obj_max[i] = max(obj_max[i], obj_val)
        
        # 标准化目标函数值
        normalized_solutions = []
        for solution in solutions:
            normalized_objectives = []
            for i, obj_val in enumerate(solution.objectives):
                if obj_max[i] - obj_min[i] > 1e-10:  # 避免除零
                    normalized_val = (obj_val - obj_min[i]) / (obj_max[i] - obj_min[i])
                else:
                    normalized_val = 0.0
                normalized_objectives.append(normalized_val)
            
            # 创建新的解（保持原始目标值在performance_data中）
            normalized_solution = ParetoSolution(
                individual=solution.individual,
                objectives=normalized_objectives,
                rank=solution.rank,
                crowding_distance=solution.crowding_distance,
                performance_data=solution.performance_data,
                solution_id=solution.solution_id
            )
            normalized_solutions.append(normalized_solution)
        
        return normalized_solutions
    
    def _fast_non_dominated_sort(self, solutions: List[ParetoSolution]) -> List[ParetoFront]:
        """快速非支配排序算法"""
        n = len(solutions)
        
        # 初始化数据结构
        domination_count = [0] * n  # 支配该解的解的数量
        dominated_solutions = [[] for _ in range(n)]  # 该解支配的解的列表
        
        # 第一步：计算支配关系
        for i in range(n):
            for j in range(n):
                if i != j:
                    dominance = self._dominance_relation(solutions[i], solutions[j])
                    if dominance == 1:  # i支配j
                        dominated_solutions[i].append(j)
                    elif dominance == -1:  # j支配i
                        domination_count[i] += 1
        
        # 第二步：构建前沿
        fronts = []
        current_front = []
        
        # 找到第一个前沿（非支配解）
        for i in range(n):
            if domination_count[i] == 0:
                solutions[i].rank = 0
                current_front.append(i)
        
        front_rank = 0
        
        while current_front:
            # 创建当前前沿
            front_solutions = [solutions[i] for i in current_front]
            pareto_front = ParetoFront(
                solutions=front_solutions,
                front_rank=front_rank
            )
            fronts.append(pareto_front)
            
            # 准备下一个前沿
            next_front = []
            for i in current_front:
                for j in dominated_solutions[i]:
                    domination_count[j] -= 1
                    if domination_count[j] == 0:
                        solutions[j].rank = front_rank + 1
                        next_front.append(j)
            
            current_front = next_front
            front_rank += 1
            
            # 限制前沿数量
            if front_rank >= self.config['max_fronts']:
                break
        
        return fronts
    
    def _dominance_relation(self, solution1: ParetoSolution, 
                          solution2: ParetoSolution) -> int:
        """
        判断两个解的支配关系 - 大幅放宽版本以获得更多帕累托解
        
        Returns:
            1: solution1支配solution2
            -1: solution2支配solution1
            0: 两解互不支配
        """
        obj1 = solution1.objectives
        obj2 = solution2.objectives
        
        # 检查是否有改进和恶化
        better_count = 0
        worse_count = 0
        equal_count = 0
        
        # 极大放宽epsilon阈值以增加帕累托解数量
        epsilon = self.config['epsilon_dominance'] * 20.0  # 放宽20倍
        
        for i, (minimize) in enumerate(self.minimize_objectives):
            diff = abs(obj1[i] - obj2[i])
            
            if diff < epsilon:
                # 认为相等 - 大幅放宽相等判断
                equal_count += 1
            elif minimize:
                # 最小化目标
                if obj1[i] < obj2[i] - epsilon:  # 需要明显更好才算支配
                    better_count += 1
                elif obj1[i] > obj2[i] + epsilon:  # 需要明显更差才算被支配
                    worse_count += 1
                else:
                    equal_count += 1  # 差异不大认为相等
            else:
                # 最大化目标
                if obj1[i] > obj2[i] + epsilon:
                    better_count += 1
                elif obj1[i] < obj2[i] - epsilon:
                    worse_count += 1
                else:
                    equal_count += 1
        
        # 极大放宽的支配关系判断 - 优先增加帕累托解数量
        if better_count > 0 and worse_count == 0:
            # 传统严格支配：所有目标都不差，至少一个更好
            return 1
        elif worse_count > 0 and better_count == 0:
            # 传统严格被支配
            return -1
        elif better_count >= 2 and worse_count == 0:
            # 放宽支配：至少2个目标更好，没有更差的
            return 1
        elif worse_count >= 2 and better_count == 0:
            # 放宽被支配：至少2个目标更差，没有更好的
            return -1
        elif equal_count >= len(obj1) * 0.6:  # 60%以上相等就认为互不支配
            return 0
        else:
            return 0  # 其他情况都认为互不支配，最大化帕累托解数量
    
    def _calculate_crowding_distance(self, solutions: List[ParetoSolution]):
        """计算拥挤距离"""
        if len(solutions) <= 2:
            # 边界解的拥挤距离设为无穷大
            for solution in solutions:
                solution.crowding_distance = float('inf')
            return
        
        n_solutions = len(solutions)
        n_objectives = len(solutions[0].objectives)
        
        # 初始化拥挤距离
        for solution in solutions:
            solution.crowding_distance = 0.0
        
        # 对每个目标计算拥挤距离
        for obj_idx in range(n_objectives):
            # 按当前目标排序
            solutions.sort(key=lambda x: x.objectives[obj_idx])
            
            # 边界解的拥挤距离设为无穷大
            solutions[0].crowding_distance = float('inf')
            solutions[-1].crowding_distance = float('inf')
            
            # 计算目标函数范围
            obj_range = solutions[-1].objectives[obj_idx] - solutions[0].objectives[obj_idx]
            
            if obj_range > self.config['crowding_distance_threshold']:
                # 计算中间解的拥挤距离
                for i in range(1, n_solutions - 1):
                    if solutions[i].crowding_distance != float('inf'):
                        distance = (solutions[i + 1].objectives[obj_idx] - 
                                  solutions[i - 1].objectives[obj_idx]) / obj_range
                        solutions[i].crowding_distance += distance
    
    def _analyze_pareto_fronts(self, pareto_fronts: List[ParetoFront],
                             all_solutions: List[ParetoSolution]) -> ParetoAnalysisResult:
        """分析帕累托前沿"""
        
        # 基本统计
        total_solutions = len(all_solutions)
        non_dominated_solutions = len(pareto_fronts[0].solutions) if pareto_fronts else 0
        dominated_solutions = total_solutions - non_dominated_solutions
        
        # 计算目标函数范围
        objective_ranges = {}
        if all_solutions:
            for i, obj_name in enumerate(self.objective_names):
                obj_values = [sol.performance_data[obj_name] for sol in all_solutions 
                            if sol.performance_data]
                if obj_values:
                    objective_ranges[obj_name] = (min(obj_values), max(obj_values))
                else:
                    objective_ranges[obj_name] = (0.0, 1.0)
        
        # 计算前沿指标
        for front in pareto_fronts:
            front.hypervolume = self._calculate_hypervolume(front.solutions)
            front.spread = self._calculate_spread(front.solutions)
        
        # 收敛性指标
        convergence_metrics = self._calculate_convergence_metrics(pareto_fronts)
        
        return ParetoAnalysisResult(
            pareto_fronts=pareto_fronts,
            total_solutions=total_solutions,
            dominated_solutions=dominated_solutions,
            non_dominated_solutions=non_dominated_solutions,
            objective_ranges=objective_ranges,
            convergence_metrics=convergence_metrics
        )
    
    def _calculate_hypervolume(self, solutions: List[ParetoSolution]) -> float:
        """计算超体积指标（简化版本）"""
        if not solutions:
            return 0.0
        
        try:
            # 使用参考点计算超体积
            reference_point = self.config.get('reference_point', [100.0, 300.0, 4.0])
            
            # 简化的超体积计算（基于矩形近似）
            total_volume = 0.0
            
            for solution in solutions:
                volume = 1.0
                for i, obj_val in enumerate(solution.objectives):
                    # 使用原始目标值
                    if solution.performance_data:
                        # 获取对应的性能数据值
                        performance_keys = ['energy_consumption', 'thermal_comfort_hours', 'overall_u_value']
                        if i < len(performance_keys):
                            actual_val = solution.performance_data.get(performance_keys[i], obj_val)
                        else:
                            actual_val = obj_val
                    else:
                        actual_val = obj_val
                    
                    # 计算到参考点的距离
                    if i < len(reference_point):
                        distance = max(0, reference_point[i] - actual_val)
                        volume *= distance
                    else:
                        volume *= max(0, 1.0 - actual_val)
                
                total_volume += volume
            
            return total_volume / len(solutions) if solutions else 0.0  # 平均超体积
            
        except Exception as e:
            logger.warning(f"超体积计算失败: {e}")
            return 0.0
    
    def _calculate_spread(self, solutions: List[ParetoSolution]) -> float:
        """计算分布性指标"""
        if len(solutions) <= 1:
            return 0.0
        
        try:
            n_objectives = len(solutions[0].objectives)
            
            # 计算每个目标的分布性
            spreads = []
            
            for obj_idx in range(n_objectives):
                obj_values = [sol.objectives[obj_idx] for sol in solutions]
                obj_values.sort()
                
                if len(obj_values) > 1:
                    # 计算相邻解之间的距离
                    distances = [obj_values[i+1] - obj_values[i] 
                               for i in range(len(obj_values)-1)]
                    
                    if distances:
                        mean_distance = np.mean(distances)
                        spread = np.std(distances) / (mean_distance + 1e-10)
                        spreads.append(spread)
            
            return np.mean(spreads) if spreads else 0.0
            
        except Exception as e:
            logger.warning(f"分布性计算失败: {e}")
            return 0.0
    
    def _calculate_convergence_metrics(self, pareto_fronts: List[ParetoFront]) -> Dict[str, float]:
        """计算收敛性指标"""
        metrics = {
            'front_count': len(pareto_fronts),
            'first_front_size': len(pareto_fronts[0].solutions) if pareto_fronts else 0,
            'average_front_size': 0.0,
            'diversity_index': 0.0
        }
        
        if pareto_fronts:
            # 平均前沿大小
            total_solutions = sum(len(front.solutions) for front in pareto_fronts)
            metrics['average_front_size'] = total_solutions / len(pareto_fronts)
            
            # 多样性指数（基于第一前沿）
            if pareto_fronts[0].solutions:
                metrics['diversity_index'] = self._calculate_diversity_index(
                    pareto_fronts[0].solutions
                )
        
        return metrics
    
    def _calculate_diversity_index(self, solutions: List[ParetoSolution]) -> float:
        """计算多样性指数"""
        if len(solutions) <= 1:
            return 0.0
        
        try:
            # 计算解之间的平均距离
            total_distance = 0.0
            count = 0
            
            for i in range(len(solutions)):
                for j in range(i + 1, len(solutions)):
                    distance = self._euclidean_distance(
                        solutions[i].objectives, solutions[j].objectives
                    )
                    total_distance += distance
                    count += 1
            
            return total_distance / count if count > 0 else 0.0
            
        except Exception as e:
            logger.warning(f"多样性指数计算失败: {e}")
            return 0.0
    
    def _euclidean_distance(self, obj1: List[float], obj2: List[float]) -> float:
        """计算欧几里得距离"""
        return np.sqrt(sum((a - b) ** 2 for a, b in zip(obj1, obj2)))
    
    def select_diverse_solutions(self, pareto_front: ParetoFront, 
                               target_count: int) -> List[ParetoSolution]:
        """
        从帕累托前沿中选择多样化的解
        
        Args:
            pareto_front: 帕累托前沿
            target_count: 目标解数量
            
        Returns:
            List[ParetoSolution]: 选择的多样化解
        """
        solutions = pareto_front.solutions
        
        if len(solutions) <= target_count:
            return solutions.copy()
        
        try:
            # 按拥挤距离排序
            sorted_solutions = sorted(solutions, 
                                    key=lambda x: x.crowding_distance, 
                                    reverse=True)
            
            # 选择拥挤距离最大的解
            selected = []
            
            # 首先选择边界解（拥挤距离为无穷大的解）
            for solution in sorted_solutions:
                if solution.crowding_distance == float('inf'):
                    selected.append(solution)
                    if len(selected) >= target_count:
                        break
            
            # 如果还需要更多解，按拥挤距离选择
            if len(selected) < target_count:
                remaining_solutions = [s for s in sorted_solutions if s not in selected]
                remaining_count = target_count - len(selected)
                
                # 使用均匀采样选择剩余解
                if remaining_solutions:
                    step = max(1, len(remaining_solutions) // remaining_count)
                    for i in range(0, len(remaining_solutions), step):
                        if len(selected) < target_count:
                            selected.append(remaining_solutions[i])
            
            logger.info(f"从{len(solutions)}个解中选择了{len(selected)}个多样化解")
            return selected[:target_count]
            
        except Exception as e:
            logger.error(f"多样化解选择失败: {e}")
            return solutions[:target_count]
    
    def filter_pareto_solutions(self, analysis_result: ParetoAnalysisResult,
                              max_solutions: int = 100) -> List[ParetoSolution]:
        """
        筛选帕累托解 - 修复解数量问题
        
        Args:
            analysis_result: 帕累托分析结果
            max_solutions: 最大解数量
            
        Returns:
            List[ParetoSolution]: 筛选后的帕累托解
        """
        try:
            all_pareto_solutions = []
            
            # 收集所有前沿的解
            for front in analysis_result.pareto_fronts:
                all_pareto_solutions.extend(front.solutions)
            
            # 如果解数量不足，放宽筛选条件
            if len(all_pareto_solutions) < max_solutions * 0.5:
                logger.warning(f"帕累托解数量不足({len(all_pareto_solutions)})，放宽筛选条件")
                # 返回所有可用的解
                logger.info(f"返回所有{len(all_pareto_solutions)}个帕累托解")
                return all_pareto_solutions
            
            if len(all_pareto_solutions) <= max_solutions:
                logger.info(f"帕累托解数量({len(all_pareto_solutions)})未超过限制，返回全部")
                return all_pareto_solutions
            
            # 优先选择第一前沿的解，但确保达到目标数量
            selected_solutions = []
            
            # 策略1：优先选择前几个前沿的所有解
            for front in analysis_result.pareto_fronts:
                if len(selected_solutions) >= max_solutions:
                    break
                
                remaining_slots = max_solutions - len(selected_solutions)
                
                if len(front.solutions) <= remaining_slots:
                    # 全部选择
                    selected_solutions.extend(front.solutions)
                    logger.info(f"选择前沿{front.front_rank}的全部{len(front.solutions)}个解")
                else:
                    # 选择多样化的解
                    diverse_solutions = self.select_diverse_solutions(
                        front, remaining_slots
                    )
                    selected_solutions.extend(diverse_solutions)
                    logger.info(f"从前沿{front.front_rank}选择{len(diverse_solutions)}个多样化解")
            
            # 策略2：如果仍然不足，从所有解中补充
            if len(selected_solutions) < max_solutions:
                remaining_needed = max_solutions - len(selected_solutions)
                remaining_solutions = [s for s in all_pareto_solutions if s not in selected_solutions]
                
                if remaining_solutions:
                    # 按拥挤距离排序选择
                    remaining_solutions.sort(key=lambda x: x.crowding_distance, reverse=True)
                    additional_solutions = remaining_solutions[:remaining_needed]
                    selected_solutions.extend(additional_solutions)
                    logger.info(f"补充选择{len(additional_solutions)}个解，总计{len(selected_solutions)}个")
            
            logger.info(f"筛选帕累托解完成，从{len(all_pareto_solutions)}个解中选择了{len(selected_solutions)}个")
            return selected_solutions
            
        except Exception as e:
            logger.error(f"帕累托解筛选失败: {e}")
            # 备用方案：返回尽可能多的解
            if analysis_result.pareto_fronts:
                backup_solutions = []
                for front in analysis_result.pareto_fronts:
                    backup_solutions.extend(front.solutions)
                    if len(backup_solutions) >= max_solutions:
                        break
                return backup_solutions[:max_solutions]
            return []
    
    def _get_default_analysis_result(self) -> ParetoAnalysisResult:
        """获取默认分析结果"""
        return ParetoAnalysisResult(
            pareto_fronts=[],
            total_solutions=0,
            dominated_solutions=0,
            non_dominated_solutions=0,
            objective_ranges={},
            convergence_metrics={}
        )
    
    def export_pareto_analysis(self, analysis_result: ParetoAnalysisResult,
                             output_path: str) -> bool:
        """
        导出帕累托分析结果
        
        Args:
            analysis_result: 分析结果
            output_path: 输出路径
            
        Returns:
            bool: 导出是否成功
        """
        try:
            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            # 准备导出数据
            export_data = {
                'analysis_summary': {
                    'total_solutions': analysis_result.total_solutions,
                    'non_dominated_solutions': analysis_result.non_dominated_solutions,
                    'dominated_solutions': analysis_result.dominated_solutions,
                    'front_count': len(analysis_result.pareto_fronts),
                    'objective_ranges': analysis_result.objective_ranges,
                    'convergence_metrics': analysis_result.convergence_metrics
                },
                'pareto_fronts': []
            }
            
            # 导出每个前沿的详细信息
            for i, front in enumerate(analysis_result.pareto_fronts):
                front_data = {
                    'front_rank': front.front_rank,
                    'solution_count': len(front.solutions),
                    'hypervolume': front.hypervolume,
                    'spread': front.spread,
                    'solutions': []
                }
                
                for j, solution in enumerate(front.solutions):
                    solution_data = {
                        'solution_id': solution.solution_id or f"front_{i}_sol_{j}",
                        'objectives': solution.objectives,
                        'rank': solution.rank,
                        'crowding_distance': solution.crowding_distance if solution.crowding_distance != float('inf') else 'inf',
                        'performance_data': solution.performance_data
                    }
                    front_data['solutions'].append(solution_data)
                
                export_data['pareto_fronts'].append(front_data)
            
            # 保存到文件
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
            
            logger.info(f"帕累托分析结果已导出到: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"帕累托分析结果导出失败: {e}")
            return False


# 便捷函数
def extract_pareto_fronts(individuals: List[Any], 
                        performance_results: List[Any],
                        config: Optional[Dict] = None) -> ParetoAnalysisResult:
    """
    便捷函数：提取帕累托前沿
    """
    extractor = ParetoFrontExtractor(config)
    return extractor.extract_pareto_fronts(individuals, performance_results)


def select_best_pareto_solutions(individuals: List[Any],
                                performance_results: List[Any],
                                max_solutions: int = 100,
                                config: Optional[Dict] = None) -> List[ParetoSolution]:
    """
    便捷函数：选择最佳帕累托解
    """
    extractor = ParetoFrontExtractor(config)
    analysis_result = extractor.extract_pareto_fronts(individuals, performance_results)
    return extractor.filter_pareto_solutions(analysis_result, max_solutions)
