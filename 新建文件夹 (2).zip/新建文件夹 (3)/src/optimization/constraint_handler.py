
"""
约束处理器
实现工程约束的处理、参数编码和约束违反度量化
"""

import numpy as np
from typing import List, Dict, Any, Tuple, Optional
from dataclasses import dataclass
import math

from ..core.config import config_manager
from ..core.logging_config import get_logger
from ..core.exceptions import OptimizationError
from ..core.data_structures import Individual, FacadeData, BuildingElement

logger = get_logger(__name__)


@dataclass
class ConstraintConfig:
    """约束配置类"""
    # 窗户约束
    min_window_width_scale: float = 0.5      # 最小窗户宽度缩放
    max_window_width_scale: float = 2.0      # 最大窗户宽度缩放
    min_window_area: float = 0.5             # 最小窗户面积 (m²)
    max_window_wall_ratio: float = 0.8       # 最大窗墙比
    
    # 窗户重叠约束 - 新增
    allow_window_overlap: bool = False       # 是否允许窗户重叠（默认不允许）
    min_window_spacing: float = 0.2          # 窗户间最小间距 (m)
    overlap_penalty_factor: float = 100.0    # 重叠惩罚因子
    
    # 遮阳约束
    min_shading_depth: float = 0.1           # 最小遮阳深度 (m)
    max_shading_depth: float = 1.0           # 最大遮阳深度 (m)
    max_shading_projection: float = 1.5      # 最大遮阳投影长度 (m)
    
    # 结构约束
    min_wall_thickness: float = 0.2          # 最小墙体厚度 (m)
    max_opening_span: float = 3.0            # 最大开口跨度 (m)
    min_structural_support: float = 0.3      # 最小结构支撑宽度 (m)
    
    # 建筑规范约束
    min_natural_lighting: float = 0.02       # 最小自然采光系数
    max_solar_heat_gain: float = 200.0       # 最大太阳得热 (W/m²)
    min_ventilation_area: float = 0.05       # 最小通风面积比
    
    # 经济约束
    max_cost_increase: float = 0.3           # 最大成本增加比例
    max_material_usage: float = 1.5          # 最大材料用量倍数
    
    # 惩罚函数参数
    penalty_weight: float = 1000.0           # 惩罚权重
    penalty_exponent: float = 2.0            # 惩罚指数


class ParameterEncoder:
    """参数编码器 - 处理个体编码方案"""
    
    def __init__(self, facade_data: FacadeData, config: ConstraintConfig):
        """
        初始化参数编码器
        
        Args:
            facade_data: 立面数据
            config: 约束配置
        """
        self.facade_data = facade_data
        self.config = config
        self.num_windows = len(facade_data.windows)
        
        logger.info(f"参数编码器初始化完成，窗户数量: {self.num_windows}")
    
    def encode_individual(self, individual: Individual) -> np.ndarray:
        """
        将个体编码为数值向量
        
        Args:
            individual: 个体对象
            
        Returns:
            编码后的参数向量
        """
        try:
            # 根据任务4.3要求：窗户横向长度变化，窗框/遮阳深度控制阴影
            encoded_params = []
            
            # 1. 窗户宽度缩放因子 (每个窗户1个参数)
            encoded_params.extend(individual.window_width_scales)
            
            # 2. 窗户高度缩放因子保持固定为1.0（不可变化）
            # encoded_params.extend(individual.window_height_scales)  # 注释掉，不编码高度
            
            # 3. 遮阳类型 (每个窗户1个参数: 0=窗框, 1=遮阳)
            encoded_params.extend(individual.shading_types)
            
            # 4. 遮阳深度 (每个窗户1个参数)
            encoded_params.extend(individual.shading_depths)
            
            return np.array(encoded_params)
            
        except Exception as e:
            logger.error(f"个体编码失败: {str(e)}")
            return np.zeros(self.get_parameter_count())
    
    def decode_individual(self, encoded_params: np.ndarray) -> Individual:
        """
        将数值向量解码为个体
        
        Args:
            encoded_params: 编码的参数向量
            
        Returns:
            解码后的个体对象
        """
        try:
            individual = Individual()
            
            # 参数分段解码
            param_idx = 0
            
            # 1. 窗户宽度缩放因子
            individual.window_width_scales = encoded_params[param_idx:param_idx + self.num_windows]
            param_idx += self.num_windows
            
            # 2. 遮阳类型
            individual.shading_types = encoded_params[param_idx:param_idx + self.num_windows].astype(int)
            param_idx += self.num_windows
            
            # 3. 遮阳深度
            individual.shading_depths = encoded_params[param_idx:param_idx + self.num_windows]
            param_idx += self.num_windows
            
            # 设置固定参数 - 窗户高度不可变化
            individual.window_height_scales = np.ones(self.num_windows)
            
            # 位置参数保持固定
            individual.window_positions_x = np.zeros(self.num_windows)
            individual.window_positions_y = np.zeros(self.num_windows)
            individual.shading_widths = np.ones(self.num_windows)
            individual.shading_angles = np.zeros(self.num_windows)
            
            return individual
            
        except Exception as e:
            logger.error(f"个体解码失败: {str(e)}")
            return Individual()
    
    def get_parameter_count(self) -> int:
        """获取参数总数"""
        # 窗户宽度 + 遮阳类型 + 遮阳深度（窗户高度固定不变）
        return self.num_windows * 3
    
    def get_parameter_bounds(self) -> Tuple[np.ndarray, np.ndarray]:
        """
        获取参数边界
        
        Returns:
            (下界向量, 上界向量)
        """
        lower_bounds = []
        upper_bounds = []
        
        # 窗户宽度缩放因子边界
        for _ in range(self.num_windows):
            lower_bounds.append(self.config.min_window_width_scale)
            upper_bounds.append(self.config.max_window_width_scale)
        
        # 遮阳类型边界 (0或1)
        for _ in range(self.num_windows):
            lower_bounds.append(0)
            upper_bounds.append(1)
        
        # 遮阳深度边界
        for _ in range(self.num_windows):
            lower_bounds.append(self.config.min_shading_depth)
            upper_bounds.append(self.config.max_shading_depth)
        
        return np.array(lower_bounds), np.array(upper_bounds)


class ConstraintHandler:
    """约束处理器 - 处理工程约束和约束违反"""
    
    def __init__(self, facade_data: FacadeData, config: Optional[ConstraintConfig] = None):
        """
        初始化约束处理器
        
        Args:
            facade_data: 立面数据
            config: 约束配置，如果为None则使用默认配置
        """
        self.facade_data = facade_data
        self.config = config or ConstraintConfig()
        self.encoder = ParameterEncoder(facade_data, self.config)
        self.overlap_resolver = WindowOverlapResolver(facade_data, self.config)
        
        # 从系统配置加载约束参数
        try:
            constraints_config = config_manager.get('optimization.constraints', {})
            if constraints_config:
                self._update_config_from_system(constraints_config)
        except Exception as e:
            logger.warning(f"加载系统约束配置失败: {str(e)}")
        
        logger.info("约束处理器初始化完成")
    
    def _update_config_from_system(self, system_constraints: Dict[str, Any]):
        """从系统配置更新约束参数"""
        for key, value in system_constraints.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
    
    def check_constraints(self, individual: Individual) -> List[float]:
        """
        检查个体的约束违反情况
        
        Args:
            individual: 待检查的个体
            
        Returns:
            约束违反度列表，负值表示满足约束，正值表示违反程度
        """
        try:
            violations = []
            
            # 1. 窗户尺寸约束
            violations.extend(self._check_window_size_constraints(individual))
            
            # 2. 窗墙比约束
            violations.append(self._check_window_wall_ratio_constraint(individual))
            
            # 3. 遮阳几何约束
            violations.extend(self._check_shading_geometry_constraints(individual))
            
            # 4. 结构约束
            violations.extend(self._check_structural_constraints(individual))
            
            # 5. 建筑规范约束
            violations.extend(self._check_building_code_constraints(individual))
            
            # 6. 经济约束
            violations.extend(self._check_economic_constraints(individual))
            
            return violations
            
        except Exception as e:
            logger.error(f"约束检查失败: {str(e)}")
            return [1000.0]  # 返回大的违反度表示严重错误
    
    def _check_window_size_constraints(self, individual: Individual) -> List[float]:
        """检查窗户尺寸约束"""
        violations = []
        
        for i, window in enumerate(self.facade_data.windows):
            # 使用原始窗户尺寸作为基准
            original_width = window.properties.get('original_width', window.width)
            original_height = window.properties.get('original_height', window.height)
            
            # 计算调整后的窗户尺寸（只有横向长度变化）
            new_width = original_width * individual.window_width_scales[i]
            new_area = new_width * original_height  # 高度保持原始值
            
            # 最小窗户面积约束
            min_area_violation = self.config.min_window_area - new_area
            violations.append(max(0, min_area_violation))
            
            # 窗户宽度缩放范围约束
            width_scale = individual.window_width_scales[i]
            min_scale_violation = self.config.min_window_width_scale - width_scale
            max_scale_violation = width_scale - self.config.max_window_width_scale
            violations.append(max(0, min_scale_violation))
            violations.append(max(0, max_scale_violation))
            
            # 窗户绝对尺寸约束（确保窗户不会过小或过大）
            min_window_width = 0.6  # 最小窗户宽度60cm
            max_window_width = 4.0  # 最大窗户宽度4m
            
            min_width_violation = min_window_width - new_width
            max_width_violation = new_width - max_window_width
            violations.append(max(0, min_width_violation))
            violations.append(max(0, max_width_violation))
        
        return violations
    
    def _check_window_wall_ratio_constraint(self, individual: Individual) -> float:
        """检查窗墙比约束"""
        try:
            # 计算调整后的总窗户面积（基于原始尺寸进行缩放）
            total_window_area = 0.0
            for i, window in enumerate(self.facade_data.windows):
                # 使用原始窗户尺寸作为基准
                original_width = window.properties.get('original_width', window.width)
                original_height = window.properties.get('original_height', window.height)
                
                # 只有横向长度可以变化
                new_width = original_width * individual.window_width_scales[i]
                new_area = new_width * original_height  # 高度保持不变
                total_window_area += new_area
            
            # 计算窗墙比
            if self.facade_data.total_wall_area > 0:
                window_wall_ratio = total_window_area / self.facade_data.total_wall_area
                violation = window_wall_ratio - self.config.max_window_wall_ratio
                return max(0, violation)
            
            return 0.0
            
        except Exception as e:
            logger.warning(f"窗墙比约束检查失败: {str(e)}")
            return 0.0
    
    def _check_shading_geometry_constraints(self, individual: Individual) -> List[float]:
        """检查遮阳几何约束"""
        violations = []
        
        for i in range(len(self.facade_data.windows)):
            window = self.facade_data.windows[i]
            depth = individual.shading_depths[i]
            shading_type = individual.shading_types[i]
            
            # 遮阳深度范围约束
            min_depth_violation = self.config.min_shading_depth - depth
            max_depth_violation = depth - self.config.max_shading_depth
            violations.append(max(0, min_depth_violation))
            violations.append(max(0, max_depth_violation))
            
            # 遮阳投影长度约束（考虑角度影响）
            projection_length = depth * math.cos(math.radians(45))  # 假设45度太阳角
            max_projection_violation = projection_length - self.config.max_shading_projection
            violations.append(max(0, max_projection_violation))
            
            # 窗框包围窗户的几何约束
            if shading_type == 0:  # 窗框类型
                # 窗框必须包围窗户，横向长度必须一致
                current_window_width = window.width * individual.window_width_scales[i]
                
                # 窗框宽度必须等于窗户宽度（包围约束）
                frame_width_violation = abs(current_window_width - window.width * individual.window_width_scales[i])
                violations.append(frame_width_violation)  # 应该为0
                
                # 窗框深度必须足够包围窗户（最小深度约束）
                min_frame_depth = 0.05  # 最小窗框深度5cm
                frame_depth_violation = min_frame_depth - depth
                violations.append(max(0, frame_depth_violation))
        
        return violations
    
    def _check_structural_constraints(self, individual: Individual) -> List[float]:
        """检查结构约束"""
        violations = []
        
        # 获取建筑边界信息
        building_width = getattr(self.facade_data, 'image_width', 800)  # 使用图像宽度作为建筑宽度
        building_height = getattr(self.facade_data, 'image_height', 600)  # 使用图像高度作为建筑高度
        
        for i, window in enumerate(self.facade_data.windows):
            # 计算调整后的窗户宽度
            new_width = window.width * individual.window_width_scales[i]
            
            # 窗户边界约束 - 确保窗户不超出建筑边界
            # 左边界约束
            left_boundary_violation = -(window.x - new_width/2)  # 窗户左边不能超出建筑左边界
            violations.append(max(0, left_boundary_violation))
            
            # 右边界约束
            right_boundary_violation = (window.x + new_width/2) - building_width  # 窗户右边不能超出建筑右边界
            violations.append(max(0, right_boundary_violation))
            
            # 最大开口跨度约束
            max_span_violation = new_width - self.config.max_opening_span
            violations.append(max(0, max_span_violation))
        
        # 窗户不重叠约束 - 新增的重要约束
        violations.extend(self._check_window_overlap_constraints(individual))
        
        # 结构支撑约束（检查相邻窗户间距）
        for i, window in enumerate(self.facade_data.windows):
            new_width = window.width * individual.window_width_scales[i]
            
            for j, other_window in enumerate(self.facade_data.windows):
                if i != j and abs(window.y - other_window.y) < window.height * 0.5:
                    # 同一水平线上的窗户
                    other_new_width = other_window.width * individual.window_width_scales[j]
                    
                    # 计算两个窗户边缘之间的距离
                    if window.x < other_window.x:
                        # window在左边
                        distance = (other_window.x - other_new_width/2) - (window.x + new_width/2)
                    else:
                        # window在右边
                        distance = (window.x - new_width/2) - (other_window.x + other_new_width/2)
                    
                    min_support_violation = self.config.min_structural_support - distance
                    violations.append(max(0, min_support_violation))
        
        return violations
    
    def _check_window_overlap_constraints(self, individual: Individual) -> List[float]:
        """
        检查窗户不重叠约束 - 核心几何约束
        
        Args:
            individual: 个体对象
            
        Returns:
            重叠违反度列表
        """
        violations = []
        
        try:
            # 计算每个窗户调整后的边界
            window_bounds = []
            for i, window in enumerate(self.facade_data.windows):
                # 计算调整后的窗户尺寸
                new_width = window.width * individual.window_width_scales[i]
                new_height = window.height  # 高度保持不变
                
                # 计算窗户边界（假设窗户中心位置不变）
                left = window.x - new_width / 2
                right = window.x + new_width / 2
                top = window.y + new_height / 2
                bottom = window.y - new_height / 2
                
                window_bounds.append({
                    'index': i,
                    'left': left,
                    'right': right,
                    'top': top,
                    'bottom': bottom,
                    'width': new_width,
                    'height': new_height,
                    'center_x': window.x,
                    'center_y': window.y
                })
            
            # 检查每对窗户是否重叠
            for i in range(len(window_bounds)):
                for j in range(i + 1, len(window_bounds)):
                    window1 = window_bounds[i]
                    window2 = window_bounds[j]
                    
                    # 计算重叠区域
                    overlap_violation = self._calculate_window_overlap(window1, window2)
                    violations.append(overlap_violation)
                    
                    # 如果有重叠，记录详细信息用于调试
                    if overlap_violation > 0:
                        logger.debug(f"窗户重叠检测: 窗户{i+1}与窗户{j+1}重叠，违反度: {overlap_violation:.4f}")
                        logger.debug(f"  窗户{i+1}: [{window1['left']:.2f}, {window1['right']:.2f}] x [{window1['bottom']:.2f}, {window1['top']:.2f}]")
                        logger.debug(f"  窗户{j+1}: [{window2['left']:.2f}, {window2['right']:.2f}] x [{window2['bottom']:.2f}, {window2['top']:.2f}]")
            
            return violations
            
        except Exception as e:
            logger.error(f"窗户重叠约束检查失败: {str(e)}")
            # 返回大的违反度表示检查失败
            return [1000.0] * (len(self.facade_data.windows) * (len(self.facade_data.windows) - 1) // 2)
    
    def _calculate_window_overlap(self, window1: Dict[str, float], window2: Dict[str, float]) -> float:
        """
        计算两个窗户的重叠违反度
        
        Args:
            window1: 第一个窗户的边界信息
            window2: 第二个窗户的边界信息
            
        Returns:
            重叠违反度，0表示无重叠，正值表示重叠程度
        """
        try:
            # 检查水平方向重叠
            horizontal_overlap = max(0, min(window1['right'], window2['right']) - max(window1['left'], window2['left']))
            
            # 检查垂直方向重叠
            vertical_overlap = max(0, min(window1['top'], window2['top']) - max(window1['bottom'], window2['bottom']))
            
            # 只有当两个方向都有重叠时，才算真正重叠
            # 添加小的容差以避免数值误差
            tolerance = 1e-6
            if horizontal_overlap > tolerance and vertical_overlap > tolerance:
                # 重叠面积作为违反度
                overlap_area = horizontal_overlap * vertical_overlap
                
                # 归一化违反度：重叠面积除以较小窗户的面积
                window1_area = window1['width'] * window1['height']
                window2_area = window2['width'] * window2['height']
                min_area = min(window1_area, window2_area)
                
                if min_area > tolerance:
                    normalized_violation = overlap_area / min_area
                    # 应用重叠惩罚因子
                    return normalized_violation * self.config.overlap_penalty_factor
                else:
                    return overlap_area * self.config.overlap_penalty_factor
            
            return 0.0
            
        except Exception as e:
            logger.warning(f"重叠计算失败: {str(e)}")
            return 0.0
    
    def _check_building_code_constraints(self, individual: Individual) -> List[float]:
        """检查建筑规范约束"""
        violations = []
        
        # 自然采光约束（简化计算）
        total_window_area = sum(
            window.width * individual.window_width_scales[i] * window.height
            for i, window in enumerate(self.facade_data.windows)
        )
        
        if self.facade_data.total_facade_area > 0:
            lighting_ratio = total_window_area / self.facade_data.total_facade_area
            min_lighting_violation = self.config.min_natural_lighting - lighting_ratio
            violations.append(max(0, min_lighting_violation))
        
        # 通风面积约束
        ventilation_ratio = total_window_area * 0.5 / self.facade_data.total_facade_area  # 假设50%可开启
        min_ventilation_violation = self.config.min_ventilation_area - ventilation_ratio
        violations.append(max(0, min_ventilation_violation))
        
        return violations
    
    def _check_economic_constraints(self, individual: Individual) -> List[float]:
        """检查经济约束"""
        violations = []
        
        # 计算成本增加（简化模型）
        cost_increase = 0.0
        
        # 窗户尺寸变化成本
        for i, window in enumerate(self.facade_data.windows):
            scale_change = abs(individual.window_width_scales[i] - 1.0)
            cost_increase += scale_change * window.area * 100  # 假设单价100元/m²
        
        # 遮阳系统成本
        for i in range(len(self.facade_data.windows)):
            shading_cost = individual.shading_depths[i] * 200  # 假设单价200元/m
            cost_increase += shading_cost
        
        # 基准成本（简化）
        base_cost = self.facade_data.total_facade_area * 500  # 假设基准单价500元/m²
        
        if base_cost > 0:
            cost_ratio = cost_increase / base_cost
            max_cost_violation = cost_ratio - self.config.max_cost_increase
            violations.append(max(0, max_cost_violation))
        
        return violations
    
    def repair_individual(self, individual: Individual) -> Individual:
        """
        修复违反约束的个体
        
        Args:
            individual: 待修复的个体
            
        Returns:
            修复后的个体
        """
        try:
            repaired = individual.copy()
            
            # 修复窗户宽度缩放因子
            repaired.window_width_scales = np.clip(
                repaired.window_width_scales,
                self.config.min_window_width_scale,
                self.config.max_window_width_scale
            )
            
            # 修复遮阳类型（确保为0或1）
            repaired.shading_types = np.clip(repaired.shading_types, 0, 1).astype(int)
            
            # 修复遮阳深度
            repaired.shading_depths = np.clip(
                repaired.shading_depths,
                self.config.min_shading_depth,
                self.config.max_shading_depth
            )
            
            # 确保窗户高度缩放因子固定为1.0（不可变化）
            repaired.window_height_scales = np.ones(len(repaired.window_width_scales))
            
            # 检查并修复窗墙比
            repaired = self._repair_window_wall_ratio(repaired)
            
            # 检查并修复窗户重叠 - 新增的重要修复
            repaired = self._repair_window_overlaps(repaired)
            
            return repaired
            
        except Exception as e:
            logger.error(f"个体修复失败: {str(e)}")
            return individual
    
    def _repair_window_wall_ratio(self, individual: Individual) -> Individual:
        """修复窗墙比约束"""
        try:
            # 计算当前窗墙比（基于原始尺寸）
            total_window_area = 0.0
            for i, window in enumerate(self.facade_data.windows):
                original_width = window.properties.get('original_width', window.width)
                original_height = window.properties.get('original_height', window.height)
                
                # 只有横向长度变化
                new_width = original_width * individual.window_width_scales[i]
                window_area = new_width * original_height
                total_window_area += window_area
            
            if self.facade_data.total_wall_area > 0:
                current_ratio = total_window_area / self.facade_data.total_wall_area
                
                if current_ratio > self.config.max_window_wall_ratio:
                    # 按比例缩小所有窗户的宽度缩放因子
                    scale_factor = self.config.max_window_wall_ratio / current_ratio
                    individual.window_width_scales *= scale_factor
                    
                    # 确保不超出单个窗户的约束
                    individual.window_width_scales = np.clip(
                        individual.window_width_scales,
                        self.config.min_window_width_scale,
                        self.config.max_window_width_scale
                    )
            
            return individual
            
        except Exception as e:
            logger.warning(f"窗墙比修复失败: {str(e)}")
            return individual
    
    def _repair_window_overlaps(self, individual: Individual) -> Individual:
        """
        修复窗户重叠问题 - 使用专门的重叠解决器
        
        Args:
            individual: 待修复的个体
            
        Returns:
            修复后的个体
        """
        try:
            # 使用专门的重叠解决器
            repaired = self.overlap_resolver.resolve_all_overlaps(individual)
            
            # 验证修复效果
            remaining_violations = self._check_window_overlap_constraints(repaired)
            serious_violations = [v for v in remaining_violations if v > 0.01]
            
            if serious_violations:
                logger.warning(f"窗户重叠修复后仍有{len(serious_violations)}个严重违反")
            else:
                logger.debug("窗户重叠修复成功")
            
            return repaired
            
        except Exception as e:
            logger.error(f"窗户重叠修复失败: {str(e)}")
            return individual
    
    def _get_window_pair_from_violation_index(self, violation_idx: int) -> Optional[Tuple[int, int]]:
        """
        从违反索引获取窗户对
        
        Args:
            violation_idx: 违反索引
            
        Returns:
            窗户对索引 (i, j) 或 None
        """
        try:
            n_windows = len(self.facade_data.windows)
            pair_count = 0
            
            for i in range(n_windows):
                for j in range(i + 1, n_windows):
                    if pair_count == violation_idx:
                        return (i, j)
                    pair_count += 1
            
            return None
            
        except Exception:
            return None
    
    def _calculate_overlap_amount(self, window1: BuildingElement, window2: BuildingElement, 
                                individual: Individual) -> float:
        """
        计算两个窗户的重叠量
        
        Args:
            window1: 第一个窗户
            window2: 第二个窗户
            individual: 个体对象
            
        Returns:
            重叠量（米）
        """
        try:
            # 获取窗户索引
            idx1 = next(i for i, w in enumerate(self.facade_data.windows) if w == window1)
            idx2 = next(i for i, w in enumerate(self.facade_data.windows) if w == window2)
            
            # 计算调整后的窗户宽度
            width1 = window1.width * individual.window_width_scales[idx1]
            width2 = window2.width * individual.window_width_scales[idx2]
            
            # 计算窗户边界
            left1 = window1.x - width1 / 2
            right1 = window1.x + width1 / 2
            left2 = window2.x - width2 / 2
            right2 = window2.x + width2 / 2
            
            # 计算水平重叠
            horizontal_overlap = max(0, min(right1, right2) - max(left1, left2))
            
            # 检查垂直重叠（简化：假设窗户在同一水平线）
            if abs(window1.y - window2.y) < window1.height * 0.5:
                return horizontal_overlap
            
            return 0.0
            
        except Exception:
            return 0.0
    
    def calculate_penalty(self, violations: List[float]) -> float:
        """
        计算约束违反的惩罚值
        
        Args:
            violations: 约束违反度列表
            
        Returns:
            总惩罚值
        """
        try:
            if not violations:
                return 0.0
            
            # 计算总违反度
            total_violation = sum(max(0, v) for v in violations)
            
            # 应用惩罚函数
            penalty = self.config.penalty_weight * (total_violation ** self.config.penalty_exponent)
            
            return penalty
            
        except Exception as e:
            logger.warning(f"惩罚值计算失败: {str(e)}")
            return 1000.0
    
    def is_feasible(self, individual: Individual) -> bool:
        """
        检查个体是否可行（满足所有约束）
        
        Args:
            individual: 待检查的个体
            
        Returns:
            True如果可行，False如果违反约束
        """
        try:
            violations = self.check_constraints(individual)
            return all(v <= 0 for v in violations)
        except Exception:
            return False
    
    def get_constraint_summary(self, individual: Individual) -> Dict[str, Any]:
        """
        获取约束检查摘要
        
        Args:
            individual: 个体
            
        Returns:
            约束检查摘要字典
        """
        try:
            violations = self.check_constraints(individual)
            penalty = self.calculate_penalty(violations)
            
            return {
                'is_feasible': self.is_feasible(individual),
                'total_violations': len([v for v in violations if v > 0]),
                'max_violation': max(violations) if violations else 0.0,
                'total_penalty': penalty,
                'violation_details': {
                    'window_size': violations[:len(self.facade_data.windows) * 3],
                    'window_wall_ratio': violations[len(self.facade_data.windows) * 3],
                    'shading_geometry': violations[len(self.facade_data.windows) * 3 + 1:],
                }
            }
            
        except Exception as e:
            logger.error(f"约束摘要生成失败: {str(e)}")
            return {'error': str(e)}


class WindowOverlapResolver:
    """
    窗户重叠解决器 - 专门处理窗户重叠问题的辅助类
    """
    
    def __init__(self, facade_data: FacadeData, config: ConstraintConfig):
        """
        初始化窗户重叠解决器
        
        Args:
            facade_data: 立面数据
            config: 约束配置
        """
        self.facade_data = facade_data
        self.config = config
        self.logger = get_logger(__name__)
    
    def resolve_all_overlaps(self, individual: Individual, max_iterations: int = 20) -> Individual:
        """
        解决所有窗户重叠问题
        
        Args:
            individual: 待修复的个体
            max_iterations: 最大迭代次数
            
        Returns:
            修复后的个体
        """
        try:
            repaired = individual.copy()
            
            for iteration in range(max_iterations):
                overlaps = self._find_all_overlaps(repaired)
                
                if not overlaps:
                    self.logger.debug(f"窗户重叠解决完成，迭代次数: {iteration}")
                    break
                
                # 按重叠严重程度排序，优先解决最严重的重叠
                overlaps.sort(key=lambda x: x['overlap_area'], reverse=True)
                
                # 解决最严重的重叠
                most_severe = overlaps[0]
                repaired = self._resolve_single_overlap(repaired, most_severe)
                
                # 验证修复效果
                if iteration % 5 == 0:  # 每5次迭代检查一次
                    remaining_overlaps = self._find_all_overlaps(repaired)
                    if len(remaining_overlaps) >= len(overlaps):
                        # 如果重叠数量没有减少，尝试不同的修复策略
                        repaired = self._apply_alternative_repair_strategy(repaired, overlaps)
            
            if iteration >= max_iterations - 1:
                self.logger.warning("窗户重叠解决达到最大迭代次数")
            
            return repaired
            
        except Exception as e:
            self.logger.error(f"窗户重叠解决失败: {str(e)}")
            return individual
    
    def _find_all_overlaps(self, individual: Individual) -> List[Dict[str, Any]]:
        """
        找到所有窗户重叠
        
        Args:
            individual: 个体对象
            
        Returns:
            重叠信息列表
        """
        overlaps = []
        
        try:
            for i in range(len(self.facade_data.windows)):
                for j in range(i + 1, len(self.facade_data.windows)):
                    overlap_info = self._calculate_overlap_info(individual, i, j)
                    if overlap_info['has_overlap']:
                        overlaps.append(overlap_info)
            
            return overlaps
            
        except Exception as e:
            self.logger.error(f"查找重叠失败: {str(e)}")
            return []
    
    def _calculate_overlap_info(self, individual: Individual, i: int, j: int) -> Dict[str, Any]:
        """
        计算两个窗户的重叠信息
        
        Args:
            individual: 个体对象
            i: 第一个窗户索引
            j: 第二个窗户索引
            
        Returns:
            重叠信息字典
        """
        try:
            window1 = self.facade_data.windows[i]
            window2 = self.facade_data.windows[j]
            
            # 计算调整后的窗户尺寸
            width1 = window1.width * individual.window_width_scales[i]
            width2 = window2.width * individual.window_width_scales[j]
            
            # 计算窗户边界
            left1 = window1.x - width1 / 2
            right1 = window1.x + width1 / 2
            top1 = window1.y + window1.height / 2
            bottom1 = window1.y - window1.height / 2
            
            left2 = window2.x - width2 / 2
            right2 = window2.x + width2 / 2
            top2 = window2.y + window2.height / 2
            bottom2 = window2.y - window2.height / 2
            
            # 计算重叠区域
            overlap_left = max(left1, left2)
            overlap_right = min(right1, right2)
            overlap_top = min(top1, top2)
            overlap_bottom = max(bottom1, bottom2)
            
            horizontal_overlap = max(0, overlap_right - overlap_left)
            vertical_overlap = max(0, overlap_top - overlap_bottom)
            
            has_overlap = horizontal_overlap > 0 and vertical_overlap > 0
            overlap_area = horizontal_overlap * vertical_overlap if has_overlap else 0
            
            return {
                'window1_idx': i,
                'window2_idx': j,
                'has_overlap': has_overlap,
                'overlap_area': overlap_area,
                'horizontal_overlap': horizontal_overlap,
                'vertical_overlap': vertical_overlap,
                'window1_area': width1 * window1.height,
                'window2_area': width2 * window2.height,
                'severity': overlap_area / min(width1 * window1.height, width2 * window2.height) if has_overlap else 0
            }
            
        except Exception as e:
            self.logger.error(f"计算重叠信息失败: {str(e)}")
            return {'has_overlap': False, 'overlap_area': 0}
    
    def _resolve_single_overlap(self, individual: Individual, overlap_info: Dict[str, Any]) -> Individual:
        """
        解决单个窗户重叠
        
        Args:
            individual: 个体对象
            overlap_info: 重叠信息
            
        Returns:
            修复后的个体
        """
        try:
            repaired = individual.copy()
            i = overlap_info['window1_idx']
            j = overlap_info['window2_idx']
            
            window1 = self.facade_data.windows[i]
            window2 = self.facade_data.windows[j]
            
            # 计算当前宽度
            current_width1 = window1.width * repaired.window_width_scales[i]
            current_width2 = window2.width * repaired.window_width_scales[j]
            
            # 计算需要减少的重叠量
            overlap_amount = overlap_info['horizontal_overlap']
            
            # 修复策略：按窗户大小比例分配缩减量
            total_width = current_width1 + current_width2
            if total_width > 0:
                # 计算每个窗户需要缩减的比例
                reduction1 = (overlap_amount * 0.6) * (current_width1 / total_width)
                reduction2 = (overlap_amount * 0.6) * (current_width2 / total_width)
                
                # 应用缩减
                new_width1 = max(current_width1 - reduction1, window1.width * self.config.min_window_width_scale)
                new_width2 = max(current_width2 - reduction2, window2.width * self.config.min_window_width_scale)
                
                # 更新缩放因子
                repaired.window_width_scales[i] = new_width1 / window1.width
                repaired.window_width_scales[j] = new_width2 / window2.width
                
                # 确保在约束范围内
                repaired.window_width_scales[i] = np.clip(
                    repaired.window_width_scales[i],
                    self.config.min_window_width_scale,
                    self.config.max_window_width_scale
                )
                repaired.window_width_scales[j] = np.clip(
                    repaired.window_width_scales[j],
                    self.config.min_window_width_scale,
                    self.config.max_window_width_scale
                )
            
            return repaired
            
        except Exception as e:
            self.logger.error(f"解决单个重叠失败: {str(e)}")
            return individual
    
    def _apply_alternative_repair_strategy(self, individual: Individual, overlaps: List[Dict[str, Any]]) -> Individual:
        """
        应用替代修复策略（当常规策略无效时）
        
        Args:
            individual: 个体对象
            overlaps: 重叠信息列表
            
        Returns:
            修复后的个体
        """
        try:
            repaired = individual.copy()
            
            # 策略：对所有有重叠的窗户进行统一缩减
            affected_windows = set()
            for overlap in overlaps:
                affected_windows.add(overlap['window1_idx'])
                affected_windows.add(overlap['window2_idx'])
            
            # 对受影响的窗户统一缩减10%
            for window_idx in affected_windows:
                current_scale = repaired.window_width_scales[window_idx]
                new_scale = current_scale * 0.9
                new_scale = max(new_scale, self.config.min_window_width_scale)
                repaired.window_width_scales[window_idx] = new_scale
            
            self.logger.debug(f"应用替代修复策略，影响{len(affected_windows)}个窗户")
            return repaired
            
        except Exception as e:
            self.logger.error(f"替代修复策略失败: {str(e)}")
            return individual


def create_constraint_handler(facade_data: FacadeData, 
                            config: Optional[ConstraintConfig] = None) -> ConstraintHandler:
    """
    创建约束处理器实例
    
    Args:
        facade_data: 立面数据
        config: 约束配置
        
    Returns:
        约束处理器实例
    """
    return ConstraintHandler(facade_data, config)
