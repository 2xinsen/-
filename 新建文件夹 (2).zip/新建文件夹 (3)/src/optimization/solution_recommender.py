
"""
方案比较和推荐系统模块

该模块实现建筑立面优化的智能推荐功能，包括：
- 方案间性能差异分析
- 权衡关系识别和可视化
- 用户偏好学习和个性化推荐
- 智能推荐算法

作者: Kiro AI Assistant
日期: 2025-01-25
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any, Union
import logging
from dataclasses import dataclass
import json
from pathlib import Path
import copy
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from scipy.stats import pearsonr

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class PerformanceDifference:
    """性能差异数据类"""
    metric_name: str                    # 指标名称
    solution1_value: float              # 方案1值
    solution2_value: float              # 方案2值
    absolute_difference: float          # 绝对差异
    relative_difference: float          # 相对差异
    significance: str                   # 显著性 (high/medium/low)


@dataclass
class TradeOffRelation:
    """权衡关系数据类"""
    metric1: str                        # 指标1
    metric2: str                        # 指标2
    correlation: float                  # 相关系数
    trade_off_strength: str             # 权衡强度 (strong/moderate/weak)
    description: str                    # 描述


@dataclass
class UserPreference:
    """用户偏好数据类"""
    preference_id: str                  # 偏好ID
    metric_weights: Dict[str, float]    # 指标权重
    constraint_preferences: Dict[str, Any]  # 约束偏好
    historical_selections: List[int]    # 历史选择
    preference_strength: float          # 偏好强度


@dataclass
class RecommendationResult:
    """推荐结果数据类"""
    solution: Any                       # 推荐方案
    recommendation_score: float         # 推荐得分
    recommendation_reason: str          # 推荐理由
    confidence: float                   # 置信度
    alternative_solutions: List[Any]    # 备选方案


class SolutionRecommender:
    """
    方案比较和推荐系统
    
    实现智能推荐算法和用户偏好学习
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """
        初始化方案推荐系统
        
        Args:
            config: 配置参数字典
        """
        self.config = config or self._get_default_config()
        self.user_preferences = {}
        self.historical_data = []
        self.scaler = StandardScaler()
        
        logger.info("方案推荐系统初始化完成")
    
    def _get_default_config(self) -> Dict:
        """获取默认配置"""
        return {
            # 推荐参数
            'max_recommendations': 5,          # 最大推荐数量
            'min_confidence_threshold': 0.6,   # 最小置信度阈值
            'diversity_weight': 0.3,           # 多样性权重
            'performance_weight': 0.7,         # 性能权重
            
            # 差异分析参数
            'significant_difference_threshold': 0.1,  # 显著差异阈值
            'high_difference_threshold': 0.2,         # 高差异阈值
            
            # 权衡关系参数
            'strong_correlation_threshold': 0.7,      # 强相关阈值
            'moderate_correlation_threshold': 0.3,    # 中等相关阈值
            
            # 用户偏好学习参数
            'learning_rate': 0.1,              # 学习率
            'preference_decay': 0.95,          # 偏好衰减
            'min_historical_data': 3,          # 最小历史数据量
            
            # 聚类参数
            'n_clusters': 3,                   # 聚类数量
            'enable_clustering': True,         # 启用聚类
            
            # 默认权重
            'default_weights': {
                'energy_consumption': 0.35,
                'thermal_comfort_hours': 0.30,
                'overall_u_value': 0.25,
                'estimated_cost': 0.10
            }
        }
    
    def analyze_performance_differences(self, solutions: List[Any],
                                      performance_results: List[Any]) -> Dict[str, List[PerformanceDifference]]:
        """
        分析方案间性能差异
        
        Args:
            solutions: 解决方案列表
            performance_results: 性能评估结果列表
            
        Returns:
            Dict[str, List[PerformanceDifference]]: 性能差异分析结果
        """
        try:
            logger.info(f"开始分析{len(solutions)}个方案的性能差异")
            
            if len(solutions) < 2:
                return {}
            
            # 提取性能指标
            performance_data = self._extract_performance_data(performance_results)
            
            # 计算两两差异
            difference_analysis = {}
            
            for i in range(len(solutions)):
                for j in range(i + 1, len(solutions)):
                    pair_key = f"solution_{i}_vs_{j}"
                    differences = []
                    
                    for metric_name in performance_data.keys():
                        diff = self._calculate_performance_difference(
                            metric_name,
                            performance_data[metric_name][i],
                            performance_data[metric_name][j]
                        )
                        differences.append(diff)
                    
                    difference_analysis[pair_key] = differences
            
            logger.info(f"性能差异分析完成，分析了{len(difference_analysis)}个方案对")
            return difference_analysis
            
        except Exception as e:
            logger.error(f"性能差异分析失败: {e}")
            return {}
    
    def _extract_performance_data(self, performance_results: List[Any]) -> Dict[str, List[float]]:
        """提取性能数据"""
        performance_data = {
            'energy_consumption': [],
            'thermal_comfort_hours': [],
            'overall_u_value': [],
            'estimated_cost': []
        }
        
        for result in performance_results:
            performance_data['energy_consumption'].append(result.energy_consumption)
            performance_data['thermal_comfort_hours'].append(result.thermal_comfort_hours)
            performance_data['overall_u_value'].append(result.overall_u_value)
            
            # 简化的成本估算
            estimated_cost = 5000 + result.energy_consumption * 50  # 简化估算
            performance_data['estimated_cost'].append(estimated_cost)
        
        return performance_data
    
    def _calculate_performance_difference(self, metric_name: str,
                                        value1: float, value2: float) -> PerformanceDifference:
        """计算性能差异"""
        abs_diff = abs(value1 - value2)
        rel_diff = abs_diff / (abs(value1) + 1e-10)
        
        # 判断显著性
        if rel_diff > self.config['high_difference_threshold']:
            significance = 'high'
        elif rel_diff > self.config['significant_difference_threshold']:
            significance = 'medium'
        else:
            significance = 'low'
        
        return PerformanceDifference(
            metric_name=metric_name,
            solution1_value=value1,
            solution2_value=value2,
            absolute_difference=abs_diff,
            relative_difference=rel_diff,
            significance=significance
        )
    
    def identify_trade_off_relations(self, performance_results: List[Any]) -> List[TradeOffRelation]:
        """
        识别权衡关系
        
        Args:
            performance_results: 性能评估结果列表
            
        Returns:
            List[TradeOffRelation]: 权衡关系列表
        """
        try:
            logger.info("开始识别权衡关系")
            
            if len(performance_results) < 3:
                return []
            
            # 提取性能数据
            performance_data = self._extract_performance_data(performance_results)
            
            trade_off_relations = []
            metrics = list(performance_data.keys())
            
            # 计算两两相关性
            for i in range(len(metrics)):
                for j in range(i + 1, len(metrics)):
                    metric1 = metrics[i]
                    metric2 = metrics[j]
                    
                    data1 = performance_data[metric1]
                    data2 = performance_data[metric2]
                    
                    # 检查数据变异性，避免常数数组警告
                    std1 = np.std(data1)
                    std2 = np.std(data2)
                    
                    if std1 < 1e-6 or std2 < 1e-6:
                        # 数据几乎不变，跳过相关性分析
                        logger.debug(f"跳过{metric1}与{metric2}的相关性分析：数据变异性不足")
                        continue
                    
                    # 计算相关系数
                    try:
                        correlation, p_value = pearsonr(data1, data2)
                        if np.isnan(correlation):
                            logger.debug(f"跳过{metric1}与{metric2}的相关性分析：相关系数为NaN")
                            continue
                    except Exception as e:
                        logger.debug(f"跳过{metric1}与{metric2}的相关性分析：计算失败 {e}")
                        continue
                    
                    # 判断权衡强度
                    abs_corr = abs(correlation)
                    if abs_corr > self.config['strong_correlation_threshold']:
                        strength = 'strong'
                    elif abs_corr > self.config['moderate_correlation_threshold']:
                        strength = 'moderate'
                    else:
                        strength = 'weak'
                    
                    # 生成描述
                    description = self._generate_trade_off_description(
                        metric1, metric2, correlation, strength
                    )
                    
                    trade_off = TradeOffRelation(
                        metric1=metric1,
                        metric2=metric2,
                        correlation=correlation,
                        trade_off_strength=strength,
                        description=description
                    )
                    
                    trade_off_relations.append(trade_off)
            
            logger.info(f"权衡关系识别完成，发现{len(trade_off_relations)}个关系")
            return trade_off_relations
            
        except Exception as e:
            logger.error(f"权衡关系识别失败: {e}")
            return []
    
    def _generate_trade_off_description(self, metric1: str, metric2: str,
                                      correlation: float, strength: str) -> str:
        """生成权衡关系描述"""
        metric_names = {
            'energy_consumption': '能耗',
            'thermal_comfort_hours': '不舒适小时数',
            'overall_u_value': '传热系数',
            'estimated_cost': '成本'
        }
        
        name1 = metric_names.get(metric1, metric1)
        name2 = metric_names.get(metric2, metric2)
        
        if correlation > 0:
            relation = "正相关"
            description = f"{name1}与{name2}呈{strength}{relation}，改善一个可能导致另一个恶化"
        else:
            relation = "负相关"
            description = f"{name1}与{name2}呈{strength}{relation}，可以同时改善"
        
        return description
    
    def learn_user_preferences(self, user_id: str, selected_solutions: List[int],
                             all_solutions: List[Any], performance_results: List[Any]):
        """
        学习用户偏好
        
        Args:
            user_id: 用户ID
            selected_solutions: 用户选择的方案索引
            all_solutions: 所有方案
            performance_results: 性能评估结果
        """
        try:
            logger.info(f"开始学习用户{user_id}的偏好")
            
            if not selected_solutions:
                return
            
            # 获取或创建用户偏好
            if user_id not in self.user_preferences:
                self.user_preferences[user_id] = UserPreference(
                    preference_id=user_id,
                    metric_weights=self.config['default_weights'].copy(),
                    constraint_preferences={},
                    historical_selections=[],
                    preference_strength=0.0
                )
            
            user_pref = self.user_preferences[user_id]
            
            # 更新历史选择
            user_pref.historical_selections.extend(selected_solutions)
            
            # 分析选择模式
            if len(user_pref.historical_selections) >= self.config['min_historical_data']:
                updated_weights = self._analyze_selection_patterns(
                    user_pref.historical_selections, performance_results
                )
                
                # 更新权重（使用学习率）
                learning_rate = self.config['learning_rate']
                for metric, new_weight in updated_weights.items():
                    current_weight = user_pref.metric_weights.get(metric, 0.25)
                    user_pref.metric_weights[metric] = (
                        current_weight * (1 - learning_rate) + new_weight * learning_rate
                    )
                
                # 更新偏好强度
                user_pref.preference_strength = min(1.0, len(user_pref.historical_selections) / 10.0)
            
            logger.info(f"用户{user_id}偏好学习完成")
            
        except Exception as e:
            logger.error(f"用户偏好学习失败: {e}")
    
    def _analyze_selection_patterns(self, selected_indices: List[int],
                                  performance_results: List[Any]) -> Dict[str, float]:
        """分析选择模式"""
        try:
            # 提取选择的方案的性能数据
            selected_performance = [performance_results[i] for i in selected_indices]
            
            # 计算选择方案的性能特征
            selected_energies = [p.energy_consumption for p in selected_performance]
            selected_comforts = [p.thermal_comfort_hours for p in selected_performance]
            selected_thermals = [p.overall_u_value for p in selected_performance]
            
            # 计算所有方案的性能特征
            all_energies = [p.energy_consumption for p in performance_results]
            all_comforts = [p.thermal_comfort_hours for p in performance_results]
            all_thermals = [p.overall_u_value for p in performance_results]
            
            # 分析偏好（基于选择方案相对于平均值的偏差）
            energy_preference = self._calculate_preference_strength(selected_energies, all_energies, minimize=True)
            comfort_preference = self._calculate_preference_strength(selected_comforts, all_comforts, minimize=True)
            thermal_preference = self._calculate_preference_strength(selected_thermals, all_thermals, minimize=True)
            
            # 标准化权重
            total_preference = energy_preference + comfort_preference + thermal_preference
            if total_preference > 0:
                weights = {
                    'energy_consumption': energy_preference / total_preference,
                    'thermal_comfort_hours': comfort_preference / total_preference,
                    'overall_u_value': thermal_preference / total_preference,
                    'estimated_cost': 0.1  # 默认成本权重
                }
            else:
                weights = self.config['default_weights'].copy()
            
            return weights
            
        except Exception as e:
            logger.warning(f"选择模式分析失败: {e}")
            return self.config['default_weights'].copy()
    
    def _calculate_preference_strength(self, selected_values: List[float],
                                     all_values: List[float], minimize: bool = True) -> float:
        """计算偏好强度"""
        try:
            if not selected_values or not all_values:
                return 0.25  # 默认权重
            
            selected_mean = np.mean(selected_values)
            all_mean = np.mean(all_values)
            all_std = np.std(all_values)
            
            if all_std == 0:
                return 0.25
            
            # 计算标准化差异
            normalized_diff = (all_mean - selected_mean) / all_std
            
            if minimize:
                # 对于最小化目标，选择值越小偏好强度越高
                preference_strength = max(0, normalized_diff)
            else:
                # 对于最大化目标，选择值越大偏好强度越高
                preference_strength = max(0, -normalized_diff)
            
            return min(1.0, preference_strength)
            
        except Exception as e:
            logger.warning(f"偏好强度计算失败: {e}")
            return 0.25
    
    def generate_personalized_recommendations(self, user_id: str, solutions: List[Any],
                                            performance_results: List[Any]) -> List[RecommendationResult]:
        """
        生成个性化推荐
        
        Args:
            user_id: 用户ID
            solutions: 解决方案列表
            performance_results: 性能评估结果列表
            
        Returns:
            List[RecommendationResult]: 推荐结果列表
        """
        try:
            logger.info(f"为用户{user_id}生成个性化推荐")
            
            if not solutions or not performance_results:
                return []
            
            # 获取用户偏好
            user_pref = self.user_preferences.get(user_id)
            if not user_pref:
                # 使用默认偏好
                user_pref = UserPreference(
                    preference_id=user_id,
                    metric_weights=self.config['default_weights'].copy(),
                    constraint_preferences={},
                    historical_selections=[],
                    preference_strength=0.0
                )
            
            # 计算推荐得分
            recommendation_scores = self._calculate_recommendation_scores(
                solutions, performance_results, user_pref
            )
            
            # 生成推荐结果
            recommendations = []
            
            for i, (solution, score) in enumerate(recommendation_scores):
                if score >= self.config['min_confidence_threshold']:
                    reason = self._generate_recommendation_reason(
                        performance_results[i], user_pref
                    )
                    
                    # 计算置信度
                    confidence = min(1.0, score * (1.0 + user_pref.preference_strength * 0.5))
                    
                    recommendation = RecommendationResult(
                        solution=solution,
                        recommendation_score=score,
                        recommendation_reason=reason,
                        confidence=confidence,
                        alternative_solutions=[]
                    )
                    
                    recommendations.append(recommendation)
            
            # 按得分排序
            recommendations.sort(key=lambda x: x.recommendation_score, reverse=True)
            
            # 限制推荐数量
            recommendations = recommendations[:self.config['max_recommendations']]
            
            # 添加备选方案
            for rec in recommendations:
                rec.alternative_solutions = self._find_alternative_solutions(
                    rec.solution, solutions, performance_results, user_pref
                )
            
            logger.info(f"为用户{user_id}生成了{len(recommendations)}个推荐")
            return recommendations
            
        except Exception as e:
            logger.error(f"个性化推荐生成失败: {e}")
            return []
    
    def _calculate_recommendation_scores(self, solutions: List[Any],
                                       performance_results: List[Any],
                                       user_pref: UserPreference) -> List[Tuple[Any, float]]:
        """计算推荐得分"""
        try:
            # 提取性能数据
            performance_data = self._extract_performance_data(performance_results)
            
            # 标准化性能数据
            normalized_data = {}
            for metric, values in performance_data.items():
                values_array = np.array(values)
                min_val, max_val = np.min(values_array), np.max(values_array)
                if max_val > min_val:
                    # 对于最小化目标，标准化后取反
                    normalized_values = (values_array - min_val) / (max_val - min_val)
                    if metric in ['energy_consumption', 'thermal_comfort_hours', 'overall_u_value', 'estimated_cost']:
                        normalized_values = 1.0 - normalized_values  # 越小越好
                    normalized_data[metric] = normalized_values
                else:
                    normalized_data[metric] = np.ones_like(values_array) * 0.5
            
            # 计算加权得分
            scores = []
            for i in range(len(solutions)):
                weighted_score = 0.0
                
                for metric, weight in user_pref.metric_weights.items():
                    if metric in normalized_data:
                        weighted_score += normalized_data[metric][i] * weight
                
                scores.append((solutions[i], weighted_score))
            
            return scores
            
        except Exception as e:
            logger.warning(f"推荐得分计算失败: {e}")
            return [(sol, 0.5) for sol in solutions]
    
    def _generate_recommendation_reason(self, performance_result: Any,
                                      user_pref: UserPreference) -> str:
        """生成推荐理由"""
        try:
            # 找出用户最关注的指标
            max_weight_metric = max(user_pref.metric_weights.items(), key=lambda x: x[1])
            
            metric_names = {
                'energy_consumption': '能耗',
                'thermal_comfort_hours': '舒适性',
                'overall_u_value': '热力性能',
                'estimated_cost': '成本'
            }
            
            primary_metric = metric_names.get(max_weight_metric[0], max_weight_metric[0])
            
            # 生成基本推荐理由
            reason = f"该方案在您最关注的{primary_metric}方面表现优秀"
            
            # 添加具体数值
            if max_weight_metric[0] == 'energy_consumption':
                reason += f"，年度能耗仅为{performance_result.energy_consumption:.1f} kWh/m²"
            elif max_weight_metric[0] == 'thermal_comfort_hours':
                reason += f"，不舒适小时数仅为{performance_result.thermal_comfort_hours:.0f}小时"
            elif max_weight_metric[0] == 'overall_u_value':
                reason += f"，传热系数为{performance_result.overall_u_value:.2f} W/m²·K"
            
            # 添加综合评价
            if user_pref.preference_strength > 0.5:
                reason += "，符合您的历史选择偏好"
            
            return reason
            
        except Exception as e:
            logger.warning(f"推荐理由生成失败: {e}")
            return "该方案综合性能优秀，推荐选择"
    
    def _find_alternative_solutions(self, target_solution: Any, all_solutions: List[Any],
                                  performance_results: List[Any],
                                  user_pref: UserPreference) -> List[Any]:
        """寻找备选方案"""
        try:
            # 简化的备选方案查找
            target_index = all_solutions.index(target_solution)
            target_performance = performance_results[target_index]
            
            alternatives = []
            
            # 寻找性能相似但不同的方案
            for i, (solution, performance) in enumerate(zip(all_solutions, performance_results)):
                if i == target_index:
                    continue
                
                # 计算性能相似度
                similarity = self._calculate_performance_similarity(
                    target_performance, performance
                )
                
                # 选择相似度适中的方案作为备选
                if 0.3 < similarity < 0.8:
                    alternatives.append(solution)
                
                if len(alternatives) >= 2:  # 最多2个备选方案
                    break
            
            return alternatives
            
        except Exception as e:
            logger.warning(f"备选方案查找失败: {e}")
            return []
    
    def _calculate_performance_similarity(self, perf1: Any, perf2: Any) -> float:
        """计算性能相似度"""
        try:
            metrics1 = np.array([
                perf1.energy_consumption,
                perf1.thermal_comfort_hours,
                perf1.overall_u_value
            ])
            
            metrics2 = np.array([
                perf2.energy_consumption,
                perf2.thermal_comfort_hours,
                perf2.overall_u_value
            ])
            
            # 标准化
            combined = np.vstack([metrics1, metrics2])
            ranges = np.max(combined, axis=0) - np.min(combined, axis=0)
            ranges[ranges == 0] = 1.0
            
            normalized1 = (metrics1 - np.min(combined, axis=0)) / ranges
            normalized2 = (metrics2 - np.min(combined, axis=0)) / ranges
            
            # 计算相似度
            distance = np.sqrt(np.sum((normalized1 - normalized2) ** 2))
            max_distance = np.sqrt(len(metrics1))
            similarity = 1.0 - (distance / max_distance)
            
            return similarity
            
        except Exception as e:
            logger.warning(f"性能相似度计算失败: {e}")
            return 0.0
    
    def cluster_solutions(self, solutions: List[Any], 
                        performance_results: List[Any]) -> Dict[str, List[int]]:
        """
        对解决方案进行聚类
        
        Args:
            solutions: 解决方案列表
            performance_results: 性能评估结果列表
            
        Returns:
            Dict[str, List[int]]: 聚类结果
        """
        try:
            if not self.config['enable_clustering'] or len(solutions) < self.config['n_clusters']:
                return {'cluster_0': list(range(len(solutions)))}
            
            logger.info(f"开始对{len(solutions)}个方案进行聚类")
            
            # 提取性能数据
            performance_data = self._extract_performance_data(performance_results)
            
            # 准备聚类数据
            clustering_data = []
            for i in range(len(solutions)):
                row = [
                    performance_data['energy_consumption'][i],
                    performance_data['thermal_comfort_hours'][i],
                    performance_data['overall_u_value'][i],
                    performance_data['estimated_cost'][i]
                ]
                clustering_data.append(row)
            
            # 标准化数据
            clustering_array = np.array(clustering_data)
            
            # 检查数据多样性，避免聚类警告
            unique_rows = len(np.unique(clustering_array, axis=0))
            effective_clusters = min(self.config['n_clusters'], unique_rows)
            
            if unique_rows < 2:
                # 数据完全相同，无法聚类
                logger.warning("所有解决方案数据相同，无法进行聚类")
                return {'cluster_0': list(range(len(solutions)))}
            
            if effective_clusters < self.config['n_clusters']:
                logger.warning(f"数据唯一性不足，将聚类数从{self.config['n_clusters']}调整为{effective_clusters}")
            
            normalized_data = self.scaler.fit_transform(clustering_array)
            
            # 执行K-means聚类，使用调整后的聚类数
            kmeans = KMeans(n_clusters=effective_clusters, random_state=42, n_init=10)
            cluster_labels = kmeans.fit_predict(normalized_data)
            
            # 组织聚类结果
            clusters = {}
            for i, label in enumerate(cluster_labels):
                cluster_key = f'cluster_{label}'
                if cluster_key not in clusters:
                    clusters[cluster_key] = []
                clusters[cluster_key].append(i)
            
            logger.info(f"聚类完成，生成{len(clusters)}个聚类")
            return clusters
            
        except Exception as e:
            logger.error(f"解决方案聚类失败: {e}")
            return {'cluster_0': list(range(len(solutions)))}
    
    def export_recommendation_results(self, recommendations: List[RecommendationResult],
                                    trade_offs: List[TradeOffRelation],
                                    output_path: str) -> bool:
        """
        导出推荐结果
        
        Args:
            recommendations: 推荐结果
            trade_offs: 权衡关系
            output_path: 输出路径
            
        Returns:
            bool: 导出是否成功
        """
        try:
            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            # 准备导出数据
            export_data = {
                'recommendation_summary': {
                    'total_recommendations': len(recommendations),
                    'average_confidence': np.mean([r.confidence for r in recommendations]) if recommendations else 0.0
                },
                'recommendations': [
                    {
                        'recommendation_score': rec.recommendation_score,
                        'recommendation_reason': rec.recommendation_reason,
                        'confidence': rec.confidence,
                        'alternative_count': len(rec.alternative_solutions)
                    }
                    for rec in recommendations
                ],
                'trade_off_relations': [
                    {
                        'metric1': tr.metric1,
                        'metric2': tr.metric2,
                        'correlation': tr.correlation,
                        'trade_off_strength': tr.trade_off_strength,
                        'description': tr.description
                    }
                    for tr in trade_offs
                ]
            }
            
            # 保存到文件
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
            
            logger.info(f"推荐结果已导出到: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"推荐结果导出失败: {e}")
            return False


# 便捷函数
def generate_solution_recommendations(user_id: str, solutions: List[Any],
                                    performance_results: List[Any],
                                    config: Optional[Dict] = None) -> List[RecommendationResult]:
    """
    便捷函数：生成解决方案推荐
    """
    recommender = SolutionRecommender(config)
    return recommender.generate_personalized_recommendations(user_id, solutions, performance_results)


def analyze_solution_trade_offs(performance_results: List[Any],
                               config: Optional[Dict] = None) -> List[TradeOffRelation]:
    """
    便捷函数：分析解决方案权衡关系
    """
    recommender = SolutionRecommender(config)
    return recommender.identify_trade_off_relations(performance_results)
