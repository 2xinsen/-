
"""
动态帕累托解生成器模块

该模块实现建筑立面优化的动态帕累托解生成功能，包括：
- 用户指定数量的帕累托解生成
- 多次运行和解集合并功能
- 解质量评估和筛选机制
- 自适应优化参数调整

作者: Kiro AI Assistant
日期: 2025-01-25
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any, Union, Callable
import logging
from dataclasses import dataclass
import json
from pathlib import Path
import copy
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class GenerationRun:
    """生成运行数据类"""
    run_id: int                         # 运行ID
    solutions: List[Any]                # 生成的解
    performance_results: List[Any]      # 性能结果
    execution_time: float               # 执行时间
    convergence_metrics: Dict[str, float]  # 收敛指标
    parameters: Dict[str, Any]          # 运行参数


@dataclass
class QualityMetrics:
    """质量指标数据类"""
    hypervolume: float                  # 超体积
    spread: float                       # 分布性
    convergence: float                  # 收敛性
    diversity: float                    # 多样性
    overall_quality: float              # 整体质量


@dataclass
class AdaptiveParameters:
    """自适应参数数据类"""
    population_size: int                # 种群大小
    max_generations: int                # 最大代数
    mutation_rate: float                # 变异率
    crossover_rate: float               # 交叉率
    selection_pressure: float           # 选择压力


class DynamicParetoGenerator:
    """
    动态帕累托解生成器
    
    实现用户指定数量的帕累托解生成和自适应参数调整
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """
        初始化动态帕累托解生成器
        
        Args:
            config: 配置参数字典
        """
        self.config = config or self._get_default_config()
        self.generation_history = []
        self.best_parameters = None
        
        logger.info("动态帕累托解生成器初始化完成")
    
    def _get_default_config(self) -> Dict:
        """获取默认配置"""
        return {
            # 生成参数
            'target_solution_count': 100,      # 目标解数量
            'max_runs': 5,                     # 最大运行次数
            'min_quality_threshold': 0.5,     # 最小质量阈值
            'convergence_threshold': 1e-4,    # 收敛阈值
            
            # 自适应参数范围
            'population_size_range': (20, 100),    # 种群大小范围
            'generations_range': (50, 200),        # 代数范围
            'mutation_rate_range': (0.01, 0.3),    # 变异率范围
            'crossover_rate_range': (0.6, 0.9),    # 交叉率范围
            
            # 质量评估权重
            'hypervolume_weight': 0.3,         # 超体积权重
            'spread_weight': 0.25,             # 分布性权重
            'convergence_weight': 0.25,        # 收敛性权重
            'diversity_weight': 0.2,           # 多样性权重
            
            # 合并参数
            'merge_similarity_threshold': 0.05, # 合并相似性阈值
            'enable_parallel_runs': False,     # 启用并行运行
            'max_workers': 2,                  # 最大工作线程数
            
            # 自适应学习参数
            'learning_rate': 0.1,              # 学习率
            'exploration_rate': 0.2,           # 探索率
            'enable_adaptive_learning': True,  # 启用自适应学习
        }
    
    def generate_pareto_solutions(self, target_count: int,
                                facade_data: Dict[str, Any],
                                climate_data: List[Dict],
                                optimization_function: Callable) -> Dict[str, Any]:
        """
        生成指定数量的帕累托解
        
        Args:
            target_count: 目标解数量
            facade_data: 立面数据
            climate_data: 气候数据
            optimization_function: 优化函数
            
        Returns:
            Dict[str, Any]: 生成结果
        """
        try:
            logger.info(f"开始生成{target_count}个帕累托解")
            
            # 1. 初始化参数
            self.config['target_solution_count'] = target_count
            current_solutions = []
            current_performance = []
            
            # 2. 多次运行生成
            for run_id in range(self.config['max_runs']):
                logger.info(f"执行第{run_id + 1}次运行")
                
                # 获取当前运行参数
                run_parameters = self._get_adaptive_parameters(run_id)
                
                # 执行优化运行
                run_result = self._execute_optimization_run(
                    run_id, run_parameters, facade_data, climate_data, optimization_function
                )
                
                if run_result:
                    self.generation_history.append(run_result)
                    
                    # 合并解集
                    merged_result = self._merge_solution_sets(
                        current_solutions, current_performance,
                        run_result.solutions, run_result.performance_results
                    )
                    
                    current_solutions = merged_result['solutions']
                    current_performance = merged_result['performance_results']
                    
                    # 检查是否达到目标
                    if len(current_solutions) >= target_count:
                        quality_metrics = self._evaluate_solution_quality(
                            current_solutions, current_performance
                        )
                        
                        if quality_metrics.overall_quality >= self.config['min_quality_threshold']:
                            logger.info(f"达到目标质量，提前结束生成")
                            break
                
                # 自适应参数调整
                if self.config['enable_adaptive_learning']:
                    self._update_adaptive_parameters(run_result)
            
            # 3. 最终筛选
            final_solutions, final_performance = self._final_solution_selection(
                current_solutions, current_performance, target_count
            )
            
            # 4. 生成结果报告
            generation_report = self._generate_generation_report(
                final_solutions, final_performance, target_count
            )
            
            logger.info(f"帕累托解生成完成，共生成{len(final_solutions)}个解")
            
            return {
                'solutions': final_solutions,
                'performance_results': final_performance,
                'generation_report': generation_report,
                'generation_history': self.generation_history,
                'success': len(final_solutions) > 0
            }
            
        except Exception as e:
            logger.error(f"帕累托解生成失败: {e}")
            return {
                'solutions': [],
                'performance_results': [],
                'generation_report': {'error': str(e)},
                'generation_history': [],
                'success': False
            }
    
    def _get_adaptive_parameters(self, run_id: int) -> AdaptiveParameters:
        """获取自适应参数"""
        if run_id == 0 or not self.best_parameters:
            # 第一次运行使用默认参数
            return AdaptiveParameters(
                population_size=50,
                max_generations=100,
                mutation_rate=0.1,
                crossover_rate=0.8,
                selection_pressure=1.0
            )
        
        # 基于历史表现调整参数
        if self.config['enable_adaptive_learning']:
            return self._adaptive_parameter_adjustment(run_id)
        else:
            return self.best_parameters
    
    def _adaptive_parameter_adjustment(self, run_id: int) -> AdaptiveParameters:
        """自适应参数调整"""
        try:
            # 分析历史运行表现
            if not self.generation_history:
                return self._get_adaptive_parameters(0)
            
            # 找到表现最好的运行
            best_run = max(self.generation_history, 
                          key=lambda x: x.convergence_metrics.get('overall_quality', 0))
            
            # 基于最佳运行调整参数
            base_params = best_run.parameters
            
            # 添加探索性变化
            exploration_factor = self.config['exploration_rate']
            learning_rate = self.config['learning_rate']
            
            new_params = AdaptiveParameters(
                population_size=self._adjust_parameter(
                    base_params.get('population_size', 50),
                    self.config['population_size_range'],
                    exploration_factor, learning_rate
                ),
                max_generations=self._adjust_parameter(
                    base_params.get('max_generations', 100),
                    self.config['generations_range'],
                    exploration_factor, learning_rate
                ),
                mutation_rate=self._adjust_parameter(
                    base_params.get('mutation_rate', 0.1),
                    self.config['mutation_rate_range'],
                    exploration_factor, learning_rate
                ),
                crossover_rate=self._adjust_parameter(
                    base_params.get('crossover_rate', 0.8),
                    self.config['crossover_rate_range'],
                    exploration_factor, learning_rate
                ),
                selection_pressure=1.0
            )
            
            return new_params
            
        except Exception as e:
            logger.warning(f"自适应参数调整失败: {e}")
            return self._get_adaptive_parameters(0)
    
    def _adjust_parameter(self, base_value: float, value_range: Tuple[float, float],
                        exploration_factor: float, learning_rate: float) -> int:
        """调整单个参数"""
        min_val, max_val = value_range
        
        # 添加探索性噪声
        noise = np.random.normal(0, exploration_factor * (max_val - min_val))
        adjusted_value = base_value + learning_rate * noise
        
        # 确保在范围内
        adjusted_value = max(min_val, min(max_val, adjusted_value))
        
        return int(adjusted_value) if isinstance(base_value, int) else adjusted_value
    
    def _execute_optimization_run(self, run_id: int, parameters: AdaptiveParameters,
                                facade_data: Dict[str, Any], climate_data: List[Dict],
                                optimization_function: Callable) -> Optional[GenerationRun]:
        """执行优化运行"""
        try:
            start_time = time.time()
            
            # 准备优化参数
            optimization_config = {
                'population_size': parameters.population_size,
                'max_generations': parameters.max_generations,
                'mutation_rate': parameters.mutation_rate,
                'crossover_rate': parameters.crossover_rate,
                'enable_detailed_analysis': False  # 简化分析以提高速度
            }
            
            # 执行优化
            result = optimization_function(facade_data, climate_data, optimization_config)
            
            execution_time = time.time() - start_time
            
            if result and result.get('success', False):
                # 评估收敛指标
                convergence_metrics = self._calculate_convergence_metrics(
                    result.get('solutions', []),
                    result.get('performance_results', [])
                )
                
                return GenerationRun(
                    run_id=run_id,
                    solutions=result.get('solutions', []),
                    performance_results=result.get('performance_results', []),
                    execution_time=execution_time,
                    convergence_metrics=convergence_metrics,
                    parameters={
                        'population_size': parameters.population_size,
                        'max_generations': parameters.max_generations,
                        'mutation_rate': parameters.mutation_rate,
                        'crossover_rate': parameters.crossover_rate
                    }
                )
            else:
                logger.warning(f"运行{run_id}失败")
                return None
                
        except Exception as e:
            logger.error(f"优化运行{run_id}执行失败: {e}")
            return None
    
    def _calculate_convergence_metrics(self, solutions: List[Any],
                                     performance_results: List[Any]) -> Dict[str, float]:
        """计算收敛指标"""
        try:
            if not solutions or not performance_results:
                return {'overall_quality': 0.0}
            
            # 简化的收敛指标计算
            energies = [p.energy_consumption for p in performance_results]
            comforts = [p.thermal_comfort_hours for p in performance_results]
            thermals = [p.overall_u_value for p in performance_results]
            
            # 计算各指标的分布性
            energy_std = np.std(energies) / (np.mean(energies) + 1e-10)
            comfort_std = np.std(comforts) / (np.mean(comforts) + 1e-10)
            thermal_std = np.std(thermals) / (np.mean(thermals) + 1e-10)
            
            # 整体质量评估
            diversity_score = (energy_std + comfort_std + thermal_std) / 3.0
            convergence_score = 1.0 / (1.0 + diversity_score)  # 多样性越高，收敛性越低
            
            # 性能质量评估
            avg_energy = np.mean(energies)
            avg_comfort = np.mean(comforts)
            avg_thermal = np.mean(thermals)
            
            # 标准化性能得分（假设理想值）
            energy_score = max(0, 1.0 - (avg_energy - 30) / 50)  # 30-80范围
            comfort_score = max(0, 1.0 - (avg_comfort - 80) / 120)  # 80-200范围
            thermal_score = max(0, 1.0 - (avg_thermal - 1.5) / 2.5)  # 1.5-4.0范围
            
            performance_score = (energy_score + comfort_score + thermal_score) / 3.0
            
            overall_quality = 0.6 * performance_score + 0.4 * diversity_score
            
            return {
                'diversity_score': diversity_score,
                'convergence_score': convergence_score,
                'performance_score': performance_score,
                'overall_quality': overall_quality,
                'solution_count': len(solutions)
            }
            
        except Exception as e:
            logger.warning(f"收敛指标计算失败: {e}")
            return {'overall_quality': 0.0}
    
    def _merge_solution_sets(self, solutions1: List[Any], performance1: List[Any],
                           solutions2: List[Any], performance2: List[Any]) -> Dict[str, List[Any]]:
        """合并解集"""
        try:
            # 简单合并
            merged_solutions = solutions1 + solutions2
            merged_performance = performance1 + performance2
            
            # 去重（基于性能相似性）
            unique_solutions = []
            unique_performance = []
            
            for i, (sol, perf) in enumerate(zip(merged_solutions, merged_performance)):
                is_duplicate = False
                
                for j, existing_perf in enumerate(unique_performance):
                    # 检查性能相似性
                    similarity = self._calculate_performance_similarity(perf, existing_perf)
                    if similarity > (1.0 - self.config['merge_similarity_threshold']):
                        is_duplicate = True
                        break
                
                if not is_duplicate:
                    unique_solutions.append(sol)
                    unique_performance.append(perf)
            
            logger.info(f"解集合并完成，从{len(merged_solutions)}个解中保留{len(unique_solutions)}个")
            
            return {
                'solutions': unique_solutions,
                'performance_results': unique_performance
            }
            
        except Exception as e:
            logger.error(f"解集合并失败: {e}")
            return {
                'solutions': solutions1 + solutions2,
                'performance_results': performance1 + performance2
            }
    
    def _calculate_performance_similarity(self, perf1: Any, perf2: Any) -> float:
        """计算性能相似性"""
        try:
            # 提取关键性能指标
            metrics1 = np.array([
                perf1.energy_consumption,
                perf1.thermal_comfort_hours,
                perf1.overall_u_value
            ])
            
            metrics2 = np.array([
                perf2.energy_consumption,
                perf2.thermal_comfort_hours,
                perf2.overall_u_value
            ])
            
            # 标准化
            combined = np.vstack([metrics1, metrics2])
            ranges = np.max(combined, axis=0) - np.min(combined, axis=0)
            ranges[ranges == 0] = 1.0  # 避免除零
            
            normalized1 = (metrics1 - np.min(combined, axis=0)) / ranges
            normalized2 = (metrics2 - np.min(combined, axis=0)) / ranges
            
            # 计算相似性
            distance = np.sqrt(np.sum((normalized1 - normalized2) ** 2))
            max_distance = np.sqrt(len(metrics1))
            similarity = 1.0 - (distance / max_distance)
            
            return similarity
            
        except Exception as e:
            logger.warning(f"性能相似性计算失败: {e}")
            return 0.0
    
    def _evaluate_solution_quality(self, solutions: List[Any],
                                 performance_results: List[Any]) -> QualityMetrics:
        """评估解质量"""
        try:
            if not solutions or not performance_results:
                return QualityMetrics(0, 0, 0, 0, 0)
            
            # 简化的质量评估
            energies = [p.energy_consumption for p in performance_results]
            comforts = [p.thermal_comfort_hours for p in performance_results]
            thermals = [p.overall_u_value for p in performance_results]
            
            # 超体积（简化计算）
            hypervolume = self._calculate_simple_hypervolume(energies, comforts, thermals)
            
            # 分布性
            spread = self._calculate_spread_metric(energies, comforts, thermals)
            
            # 收敛性
            convergence = self._calculate_convergence_metric(energies, comforts, thermals)
            
            # 多样性
            diversity = self._calculate_diversity_metric(energies, comforts, thermals)
            
            # 整体质量
            overall_quality = (
                hypervolume * self.config['hypervolume_weight'] +
                spread * self.config['spread_weight'] +
                convergence * self.config['convergence_weight'] +
                diversity * self.config['diversity_weight']
            )
            
            return QualityMetrics(
                hypervolume=hypervolume,
                spread=spread,
                convergence=convergence,
                diversity=diversity,
                overall_quality=overall_quality
            )
            
        except Exception as e:
            logger.warning(f"解质量评估失败: {e}")
            return QualityMetrics(0, 0, 0, 0, 0)
    
    def _calculate_simple_hypervolume(self, energies: List[float],
                                    comforts: List[float], thermals: List[float]) -> float:
        """计算简化超体积"""
        try:
            # 使用参考点计算简化超体积
            ref_energy = 100.0
            ref_comfort = 300.0
            ref_thermal = 4.0
            
            total_volume = 0.0
            for e, c, t in zip(energies, comforts, thermals):
                volume = max(0, ref_energy - e) * max(0, ref_comfort - c) * max(0, ref_thermal - t)
                total_volume += volume
            
            # 标准化
            max_volume = ref_energy * ref_comfort * ref_thermal
            normalized_volume = total_volume / (len(energies) * max_volume)
            
            return min(1.0, normalized_volume)
            
        except Exception as e:
            logger.warning(f"超体积计算失败: {e}")
            return 0.0
    
    def _calculate_spread_metric(self, energies: List[float],
                               comforts: List[float], thermals: List[float]) -> float:
        """计算分布性指标"""
        try:
            if len(energies) < 2:
                return 0.0
            
            # 计算各维度的分布性
            energy_range = max(energies) - min(energies)
            comfort_range = max(comforts) - min(comforts)
            thermal_range = max(thermals) - min(thermals)
            
            # 标准化范围
            energy_spread = energy_range / 100.0  # 假设最大范围100
            comfort_spread = comfort_range / 300.0  # 假设最大范围300
            thermal_spread = thermal_range / 4.0   # 假设最大范围4
            
            avg_spread = (energy_spread + comfort_spread + thermal_spread) / 3.0
            return min(1.0, avg_spread)
            
        except Exception as e:
            logger.warning(f"分布性计算失败: {e}")
            return 0.0
    
    def _calculate_convergence_metric(self, energies: List[float],
                                    comforts: List[float], thermals: List[float]) -> float:
        """计算收敛性指标"""
        try:
            if len(energies) < 2:
                return 1.0
            
            # 基于变异系数计算收敛性
            energy_cv = np.std(energies) / (np.mean(energies) + 1e-10)
            comfort_cv = np.std(comforts) / (np.mean(comforts) + 1e-10)
            thermal_cv = np.std(thermals) / (np.mean(thermals) + 1e-10)
            
            avg_cv = (energy_cv + comfort_cv + thermal_cv) / 3.0
            
            # 收敛性与变异系数成反比
            convergence = 1.0 / (1.0 + avg_cv)
            return convergence
            
        except Exception as e:
            logger.warning(f"收敛性计算失败: {e}")
            return 0.5
    
    def _calculate_diversity_metric(self, energies: List[float],
                                  comforts: List[float], thermals: List[float]) -> float:
        """计算多样性指标"""
        try:
            if len(energies) < 2:
                return 0.0
            
            # 计算解之间的平均距离
            solutions = list(zip(energies, comforts, thermals))
            total_distance = 0.0
            count = 0
            
            for i in range(len(solutions)):
                for j in range(i + 1, len(solutions)):
                    # 标准化距离
                    distance = np.sqrt(
                        ((solutions[i][0] - solutions[j][0]) / 100.0) ** 2 +
                        ((solutions[i][1] - solutions[j][1]) / 300.0) ** 2 +
                        ((solutions[i][2] - solutions[j][2]) / 4.0) ** 2
                    )
                    total_distance += distance
                    count += 1
            
            avg_distance = total_distance / count if count > 0 else 0.0
            max_distance = np.sqrt(3)  # 最大可能距离
            
            diversity = avg_distance / max_distance
            return min(1.0, diversity)
            
        except Exception as e:
            logger.warning(f"多样性计算失败: {e}")
            return 0.0
    
    def _final_solution_selection(self, solutions: List[Any], performance_results: List[Any],
                                target_count: int) -> Tuple[List[Any], List[Any]]:
        """最终解选择"""
        try:
            if len(solutions) <= target_count:
                return solutions, performance_results
            
            # 基于质量评估选择最佳解
            solution_scores = []
            
            for i, (sol, perf) in enumerate(zip(solutions, performance_results)):
                # 简化的质量评分
                energy_score = max(0, 1.0 - (perf.energy_consumption - 30) / 50)
                comfort_score = max(0, 1.0 - (perf.thermal_comfort_hours - 80) / 120)
                thermal_score = max(0, 1.0 - (perf.overall_u_value - 1.5) / 2.5)
                
                overall_score = (energy_score + comfort_score + thermal_score) / 3.0
                solution_scores.append((i, overall_score))
            
            # 按得分排序
            solution_scores.sort(key=lambda x: x[1], reverse=True)
            
            # 选择前target_count个解
            selected_indices = [idx for idx, _ in solution_scores[:target_count]]
            
            selected_solutions = [solutions[i] for i in selected_indices]
            selected_performance = [performance_results[i] for i in selected_indices]
            
            logger.info(f"最终选择了{len(selected_solutions)}个解")
            return selected_solutions, selected_performance
            
        except Exception as e:
            logger.error(f"最终解选择失败: {e}")
            return solutions[:target_count], performance_results[:target_count]
    
    def _update_adaptive_parameters(self, run_result: Optional[GenerationRun]):
        """更新自适应参数"""
        try:
            if not run_result or not self.config['enable_adaptive_learning']:
                return
            
            # 评估当前运行的表现
            current_quality = run_result.convergence_metrics.get('overall_quality', 0.0)
            
            # 更新最佳参数
            if not self.best_parameters or current_quality > getattr(self, '_best_quality', 0.0):
                self.best_parameters = AdaptiveParameters(
                    population_size=run_result.parameters['population_size'],
                    max_generations=run_result.parameters['max_generations'],
                    mutation_rate=run_result.parameters['mutation_rate'],
                    crossover_rate=run_result.parameters['crossover_rate'],
                    selection_pressure=1.0
                )
                self._best_quality = current_quality
                logger.info(f"更新最佳参数，质量得分: {current_quality:.4f}")
            
        except Exception as e:
            logger.warning(f"自适应参数更新失败: {e}")
    
    def _generate_generation_report(self, solutions: List[Any], performance_results: List[Any],
                                  target_count: int) -> Dict[str, Any]:
        """生成生成报告"""
        try:
            quality_metrics = self._evaluate_solution_quality(solutions, performance_results)
            
            report = {
                'generation_summary': {
                    'target_count': target_count,
                    'actual_count': len(solutions),
                    'success_rate': len(solutions) / target_count if target_count > 0 else 0.0,
                    'total_runs': len(self.generation_history)
                },
                'quality_metrics': {
                    'hypervolume': quality_metrics.hypervolume,
                    'spread': quality_metrics.spread,
                    'convergence': quality_metrics.convergence,
                    'diversity': quality_metrics.diversity,
                    'overall_quality': quality_metrics.overall_quality
                },
                'performance_statistics': {},
                'adaptive_learning': {
                    'enabled': self.config['enable_adaptive_learning'],
                    'best_parameters': self._format_parameters(self.best_parameters) if self.best_parameters else None
                }
            }
            
            # 性能统计
            if performance_results:
                energies = [p.energy_consumption for p in performance_results]
                comforts = [p.thermal_comfort_hours for p in performance_results]
                thermals = [p.overall_u_value for p in performance_results]
                
                report['performance_statistics'] = {
                    'energy_consumption': {
                        'mean': np.mean(energies),
                        'std': np.std(energies),
                        'min': np.min(energies),
                        'max': np.max(energies)
                    },
                    'thermal_comfort_hours': {
                        'mean': np.mean(comforts),
                        'std': np.std(comforts),
                        'min': np.min(comforts),
                        'max': np.max(comforts)
                    },
                    'overall_u_value': {
                        'mean': np.mean(thermals),
                        'std': np.std(thermals),
                        'min': np.min(thermals),
                        'max': np.max(thermals)
                    }
                }
            
            return report
            
        except Exception as e:
            logger.error(f"生成报告创建失败: {e}")
            return {'error': str(e)}
    
    def _format_parameters(self, parameters: AdaptiveParameters) -> Dict[str, Any]:
        """格式化参数"""
        return {
            'population_size': parameters.population_size,
            'max_generations': parameters.max_generations,
            'mutation_rate': parameters.mutation_rate,
            'crossover_rate': parameters.crossover_rate,
            'selection_pressure': parameters.selection_pressure
        }
    
    def export_generation_results(self, generation_result: Dict[str, Any],
                                output_path: str) -> bool:
        """
        导出生成结果
        
        Args:
            generation_result: 生成结果
            output_path: 输出路径
            
        Returns:
            bool: 导出是否成功
        """
        try:
            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            # 准备导出数据（不包含解对象，只包含统计信息）
            export_data = {
                'generation_report': generation_result.get('generation_report', {}),
                'generation_history': [
                    {
                        'run_id': run.run_id,
                        'solution_count': len(run.solutions),
                        'execution_time': run.execution_time,
                        'convergence_metrics': run.convergence_metrics,
                        'parameters': run.parameters
                    }
                    for run in generation_result.get('generation_history', [])
                ],
                'success': generation_result.get('success', False)
            }
            
            # 保存到文件
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
            
            logger.info(f"生成结果已导出到: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"生成结果导出失败: {e}")
            return False


# 便捷函数
def generate_dynamic_pareto_solutions(target_count: int,
                                    facade_data: Dict[str, Any],
                                    climate_data: List[Dict],
                                    optimization_function: Callable,
                                    config: Optional[Dict] = None) -> Dict[str, Any]:
    """
    便捷函数：生成动态帕累托解
    """
    generator = DynamicParetoGenerator(config)
    return generator.generate_pareto_solutions(
        target_count, facade_data, climate_data, optimization_function
    )
