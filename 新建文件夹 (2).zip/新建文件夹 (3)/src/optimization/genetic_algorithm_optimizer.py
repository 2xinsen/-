"""
专门的遗传算法优化器
包含自动测试、详细日志记录和基于日志分析的自动优化循环
"""

import numpy as np
import json
import time
import os
from typing import List, Dict, Tuple, Optional, Any, Callable
from dataclasses import dataclass, asdict
from datetime import datetime
import threading
import queue
import copy

from ..core.config import config_manager
from ..core.logging_config import get_logger
from ..core.exceptions import OptimizationError
from ..core.data_structures import Individual, OptimizationResults, FacadeData, ClimateData
from .nsga3_optimizer import NSGA3Optimizer, NSGA3Config
from .genetic_operators import GeneticOperatorManager, GeneticOperatorConfig
from .convergence_control import OptimizationMonitor, ConvergenceConfig
from .objective_functions import ObjectiveWeights, BuildingParameters, EnergyCalculator

logger = get_logger(__name__)


@dataclass
class GAOptimizationConfig:
    """遗传算法优化配置"""
    # 基础参数
    population_size: int = 200
    max_generations: int = 300
    max_iterations: int = 10  # 最大优化循环次数
    
    # 性能阈值
    target_pareto_solutions: int = 50  # 目标帕累托解数量
    min_diversity_threshold: float = 0.15  # 最小多样性阈值
    convergence_patience: int = 30  # 收敛耐心值
    
    # 自动调整参数
    auto_adjustment_enabled: bool = True
    adjustment_frequency: int = 5  # 每5代检查一次
    performance_window: int = 10  # 性能评估窗口
    
    # 日志配置
    detailed_logging: bool = True
    log_frequency: int = 1  # 每代记录
    save_intermediate_results: bool = True


@dataclass
class PerformanceMetrics:
    """性能指标"""
    generation: int
    timestamp: float
    pareto_front_size: int
    population_diversity: float
    convergence_rate: float
    hypervolume: float
    energy_range: Tuple[float, float]
    thermal_range: Tuple[float, float]
    best_energy: float
    best_thermal: float
    execution_time: float
    memory_usage: float


@dataclass
class OptimizationIteration:
    """优化迭代记录"""
    iteration_id: int
    start_time: float
    end_time: float
    config_used: GAOptimizationConfig
    final_results: OptimizationResults
    performance_history: List[PerformanceMetrics]
    adjustments_made: List[Dict[str, Any]]
    success_metrics: Dict[str, float]


class PerformanceAnalyzer:
    """性能分析器"""
    
    def __init__(self):
        self.metrics_history: List[PerformanceMetrics] = []
        self.analysis_cache: Dict[str, Any] = {}
    
    def analyze_performance(self, metrics: List[PerformanceMetrics]) -> Dict[str, Any]:
        """分析性能指标"""
        try:
            if len(metrics) < 5:
                return {"status": "insufficient_data"}
            
            # 计算趋势
            generations = [m.generation for m in metrics]
            pareto_sizes = [m.pareto_front_size for m in metrics]
            diversities = [m.population_diversity for m in metrics]
            convergence_rates = [m.convergence_rate for m in metrics]
            
            # 帕累托前沿增长趋势
            pareto_trend = np.polyfit(generations, pareto_sizes, 1)[0]
            
            # 多样性趋势
            diversity_trend = np.polyfit(generations, diversities, 1)[0]
            
            # 收敛速度趋势
            convergence_trend = np.polyfit(generations, convergence_rates, 1)[0]
            
            # 性能稳定性
            pareto_stability = 1.0 / (1.0 + np.std(pareto_sizes[-10:]))
            diversity_stability = 1.0 / (1.0 + np.std(diversities[-10:]))
            
            # 当前性能状态
            current_metrics = metrics[-1]
            
            analysis = {
                "pareto_trend": pareto_trend,
                "diversity_trend": diversity_trend,
                "convergence_trend": convergence_trend,
                "pareto_stability": pareto_stability,
                "diversity_stability": diversity_stability,
                "current_pareto_size": current_metrics.pareto_front_size,
                "current_diversity": current_metrics.population_diversity,
                "current_convergence_rate": current_metrics.convergence_rate,
                "performance_score": self._calculate_performance_score(metrics),
                "recommendations": self._generate_recommendations(metrics)
            }
            
            return analysis
            
        except Exception as e:
            logger.error(f"性能分析失败: {str(e)}")
            return {"status": "analysis_failed", "error": str(e)}
    
    def _calculate_performance_score(self, metrics: List[PerformanceMetrics]) -> float:
        """计算综合性能得分"""
        try:
            if not metrics:
                return 0.0
            
            latest = metrics[-1]
            
            # 帕累托解数量得分 (0-40分)
            pareto_score = min(40, latest.pareto_front_size * 0.8)
            
            # 多样性得分 (0-30分)
            diversity_score = min(30, latest.population_diversity * 100)
            
            # 收敛速度得分 (0-20分)
            convergence_score = min(20, (1.0 - latest.convergence_rate) * 20)
            
            # 稳定性得分 (0-10分)
            if len(metrics) >= 10:
                recent_pareto = [m.pareto_front_size for m in metrics[-10:]]
                stability_score = min(10, 10 / (1 + np.std(recent_pareto)))
            else:
                stability_score = 5
            
            total_score = pareto_score + diversity_score + convergence_score + stability_score
            return min(100, total_score)
            
        except Exception:
            return 0.0
    
    def _generate_recommendations(self, metrics: List[PerformanceMetrics]) -> List[str]:
        """生成优化建议"""
        recommendations = []
        
        try:
            if len(metrics) < 5:
                return ["需要更多数据进行分析"]
            
            latest = metrics[-1]
            
            # 帕累托解数量建议
            if latest.pareto_front_size < 20:
                recommendations.append("增加种群大小或变异概率以获得更多帕累托解")
            
            # 多样性建议
            if latest.population_diversity < 0.1:
                recommendations.append("多样性过低，建议增加变异强度或注入多样化个体")
            elif latest.population_diversity > 0.5:
                recommendations.append("多样性过高，建议增加选择压力或交叉概率")
            
            # 收敛建议
            if latest.convergence_rate > 0.8:
                recommendations.append("收敛过快，建议降低选择压力或增加探索")
            elif latest.convergence_rate < 0.2:
                recommendations.append("收敛过慢，建议增加选择压力或精英保留")
            
            # 趋势建议
            if len(metrics) >= 10:
                recent_pareto = [m.pareto_front_size for m in metrics[-10:]]
                if np.polyfit(range(len(recent_pareto)), recent_pareto, 1)[0] < 0:
                    recommendations.append("帕累托前沿在缩小，建议重启或增加多样性")
            
            return recommendations if recommendations else ["当前性能良好，继续优化"]
            
        except Exception as e:
            logger.warning(f"建议生成失败: {str(e)}")
            return ["分析失败，使用默认参数继续"]


class ConfigurationAdjuster:
    """配置自动调整器"""
    
    def __init__(self):
        self.adjustment_history: List[Dict[str, Any]] = []
    
    def adjust_configuration(self, config: GAOptimizationConfig, 
                           analysis: Dict[str, Any]) -> Tuple[GAOptimizationConfig, List[str]]:
        """根据分析结果调整配置"""
        try:
            new_config = copy.deepcopy(config)
            adjustments = []
            
            # 获取分析结果
            pareto_trend = analysis.get("pareto_trend", 0)
            diversity_trend = analysis.get("diversity_trend", 0)
            current_diversity = analysis.get("current_diversity", 0.2)
            current_pareto_size = analysis.get("current_pareto_size", 0)
            performance_score = analysis.get("performance_score", 50)
            
            # 调整策略1: 帕累托解数量优化
            if current_pareto_size < config.target_pareto_solutions:
                if pareto_trend < 0:  # 帕累托解在减少
                    new_config.population_size = min(400, int(config.population_size * 1.2))
                    adjustments.append(f"增加种群大小至{new_config.population_size}")
                else:  # 帕累托解增长缓慢
                    new_config.max_generations = min(500, int(config.max_generations * 1.1))
                    adjustments.append(f"增加最大代数至{new_config.max_generations}")
            
            # 调整策略2: 多样性控制
            if current_diversity < config.min_diversity_threshold:
                # 多样性过低
                if diversity_trend < -0.001:  # 多样性快速下降
                    new_config.convergence_patience = min(50, config.convergence_patience + 10)
                    adjustments.append(f"增加收敛耐心至{new_config.convergence_patience}")
                else:  # 多样性稳定但低
                    new_config.adjustment_frequency = max(3, config.adjustment_frequency - 1)
                    adjustments.append(f"增加调整频率至每{new_config.adjustment_frequency}代")
            
            elif current_diversity > 0.4:
                # 多样性过高，可能收敛太慢
                new_config.convergence_patience = max(15, config.convergence_patience - 5)
                adjustments.append(f"减少收敛耐心至{new_config.convergence_patience}")
            
            # 调整策略3: 性能得分优化
            if performance_score < 60:
                # 整体性能较差
                new_config.target_pareto_solutions = max(30, config.target_pareto_solutions - 10)
                new_config.min_diversity_threshold = max(0.1, config.min_diversity_threshold - 0.02)
                adjustments.append("降低性能目标以适应当前状况")
            
            elif performance_score > 85:
                # 性能很好，可以提高目标
                new_config.target_pareto_solutions = min(80, config.target_pareto_solutions + 10)
                new_config.min_diversity_threshold = min(0.25, config.min_diversity_threshold + 0.02)
                adjustments.append("提高性能目标以获得更好结果")
            
            # 记录调整历史
            adjustment_record = {
                "timestamp": time.time(),
                "analysis_input": analysis,
                "adjustments": adjustments,
                "old_config": asdict(config),
                "new_config": asdict(new_config)
            }
            self.adjustment_history.append(adjustment_record)
            
            return new_config, adjustments
            
        except Exception as e:
            logger.error(f"配置调整失败: {str(e)}")
            return config, ["配置调整失败，使用原配置"]


class GeneticAlgorithmOptimizer:
    """专门的遗传算法优化器"""
    
    def __init__(self, config: Optional[GAOptimizationConfig] = None):
        self.config = config or GAOptimizationConfig()
        self.performance_analyzer = PerformanceAnalyzer()
        self.config_adjuster = ConfigurationAdjuster()
        
        # 优化历史
        self.optimization_history: List[OptimizationIteration] = []
        self.current_iteration = 0
        
        # 日志系统
        self.detailed_logs: List[Dict[str, Any]] = []
        self.log_file_path = f"logs/ga_optimization_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        # 确保日志目录存在
        os.makedirs("logs", exist_ok=True)
        
        logger.info("遗传算法优化器初始化完成")
    
    def optimize_with_auto_adjustment(self, facade_data: FacadeData, 
                                    climate_data: ClimateData,
                                    objective_function: Callable) -> OptimizationResults:
        """
        带自动调整的优化循环
        
        Args:
            facade_data: 立面数据
            climate_data: 气候数据
            objective_function: 目标函数
            
        Returns:
            最终优化结果
        """
        try:
            logger.info("开始自动调整优化循环")
            
            best_results = None
            best_score = 0.0
            
            for iteration in range(self.config.max_iterations):
                self.current_iteration = iteration
                logger.info(f"开始第{iteration + 1}次优化迭代")
                
                # 记录迭代开始
                iteration_start = time.time()
                
                # 执行单次优化
                results = self._run_single_optimization(
                    facade_data, climate_data, objective_function, iteration
                )
                
                # 分析性能
                performance_metrics = self._extract_performance_metrics(results)
                analysis = self.performance_analyzer.analyze_performance(performance_metrics)
                
                # 计算当前得分
                current_score = analysis.get("performance_score", 0)
                
                # 更新最佳结果
                if current_score > best_score:
                    best_results = results
                    best_score = current_score
                    logger.info(f"发现更好结果，得分: {current_score:.2f}")
                
                # 记录迭代结果
                iteration_record = OptimizationIteration(
                    iteration_id=iteration,
                    start_time=iteration_start,
                    end_time=time.time(),
                    config_used=copy.deepcopy(self.config),
                    final_results=results,
                    performance_history=performance_metrics,
                    adjustments_made=self.config_adjuster.adjustment_history[-10:],
                    success_metrics=analysis
                )
                self.optimization_history.append(iteration_record)
                
                # 保存详细日志
                self._save_iteration_log(iteration_record)
                
                # 检查是否达到目标
                if self._check_optimization_target(analysis):
                    logger.info(f"达到优化目标，在第{iteration + 1}次迭代后结束")
                    break
                
                # 调整配置（除了最后一次迭代）
                if iteration < self.config.max_iterations - 1:
                    new_config, adjustments = self.config_adjuster.adjust_configuration(
                        self.config, analysis
                    )
                    
                    if adjustments:
                        logger.info(f"配置调整: {'; '.join(adjustments)}")
                        self.config = new_config
                    else:
                        logger.info("配置无需调整")
            
            # 生成最终报告
            final_report = self._generate_final_report()
            logger.info("优化循环完成")
            logger.info(f"最终得分: {best_score:.2f}")
            logger.info(f"总迭代次数: {len(self.optimization_history)}")
            
            return best_results or OptimizationResults()
            
        except Exception as e:
            logger.error(f"自动调整优化失败: {str(e)}")
            raise OptimizationError(f"自动调整优化失败: {str(e)}") from e
    
    def _run_single_optimization(self, facade_data: FacadeData, 
                               climate_data: ClimateData,
                               objective_function: Callable,
                               iteration: int) -> OptimizationResults:
        """运行单次优化"""
        try:
            logger.info(f"执行第{iteration + 1}次优化")
            
            # 创建NSGA3配置
            nsga3_config = NSGA3Config(
                population_size=self.config.population_size,
                max_generations=self.config.max_generations,
                max_stagnation_generations=self.config.convergence_patience
            )
            
            # 创建优化器
            optimizer = NSGA3Optimizer(nsga3_config)
            optimizer.set_objective_function(objective_function)
            
            # 执行优化
            results = optimizer.optimize(facade_data, climate_data, n_objectives=2)
            
            logger.info(f"第{iteration + 1}次优化完成")
            logger.info(f"帕累托解数量: {len(results.pareto_solutions)}")
            logger.info(f"实际代数: {results.actual_generations}")
            
            return results
            
        except Exception as e:
            logger.error(f"单次优化失败: {str(e)}")
            raise
    
    def _extract_performance_metrics(self, results: OptimizationResults) -> List[PerformanceMetrics]:
        """从优化结果中提取性能指标"""
        try:
            metrics = []
            
            if not results.evolution_history:
                return metrics
            
            for i, gen_stats in enumerate(results.evolution_history):
                # 计算能耗和热力性能范围
                if results.pareto_solutions:
                    energies = [sol.objectives[0] for sol in results.pareto_solutions if sol.objectives]
                    thermals = [sol.objectives[1] for sol in results.pareto_solutions if sol.objectives]
                    
                    energy_range = (min(energies), max(energies)) if energies else (0, 0)
                    thermal_range = (min(thermals), max(thermals)) if thermals else (0, 0)
                    best_energy = min(energies) if energies else 0
                    best_thermal = min(thermals) if thermals else 0
                else:
                    energy_range = (0, 0)
                    thermal_range = (0, 0)
                    best_energy = 0
                    best_thermal = 0
                
                # 计算超体积（简化版本）
                hypervolume = self._calculate_hypervolume(results.pareto_solutions)
                
                metric = PerformanceMetrics(
                    generation=i,
                    timestamp=time.time(),
                    pareto_front_size=gen_stats.pareto_front_size,
                    population_diversity=gen_stats.objective_diversity,
                    convergence_rate=gen_stats.convergence_metric,
                    hypervolume=hypervolume,
                    energy_range=energy_range,
                    thermal_range=thermal_range,
                    best_energy=best_energy,
                    best_thermal=best_thermal,
                    execution_time=0.0,  # 简化
                    memory_usage=0.0     # 简化
                )
                
                metrics.append(metric)
            
            return metrics
            
        except Exception as e:
            logger.warning(f"性能指标提取失败: {str(e)}")
            return []
    
    def _calculate_hypervolume(self, pareto_solutions: List[Individual]) -> float:
        """计算超体积（简化版本）"""
        try:
            if not pareto_solutions:
                return 0.0
            
            # 获取目标函数值
            objectives = []
            for sol in pareto_solutions:
                if sol.objectives and len(sol.objectives) >= 2:
                    objectives.append(sol.objectives[:2])
            
            if not objectives:
                return 0.0
            
            # 简化的超体积计算
            objectives = np.array(objectives)
            
            # 使用参考点 (最大值 + 10%)
            ref_point = np.max(objectives, axis=0) * 1.1
            
            # 计算每个解的贡献
            total_volume = 0.0
            for obj in objectives:
                volume = np.prod(ref_point - obj)
                if volume > 0:
                    total_volume += volume
            
            return total_volume
            
        except Exception:
            return 0.0
    
    def _check_optimization_target(self, analysis: Dict[str, Any]) -> bool:
        """检查是否达到优化目标"""
        try:
            current_pareto_size = analysis.get("current_pareto_size", 0)
            current_diversity = analysis.get("current_diversity", 0)
            performance_score = analysis.get("performance_score", 0)
            
            # 目标条件
            pareto_target_met = current_pareto_size >= self.config.target_pareto_solutions
            diversity_target_met = current_diversity >= self.config.min_diversity_threshold
            performance_target_met = performance_score >= 80
            
            return pareto_target_met and diversity_target_met and performance_target_met
            
        except Exception:
            return False
    
    def _save_iteration_log(self, iteration_record: OptimizationIteration):
        """保存迭代日志"""
        try:
            log_entry = {
                "iteration_id": iteration_record.iteration_id,
                "timestamp": datetime.now().isoformat(),
                "duration": iteration_record.end_time - iteration_record.start_time,
                "config": asdict(iteration_record.config_used),
                "results_summary": {
                    "pareto_solutions_count": len(iteration_record.final_results.pareto_solutions),
                    "actual_generations": iteration_record.final_results.actual_generations,
                    "total_evaluations": iteration_record.final_results.total_evaluations
                },
                "performance_metrics": [asdict(m) for m in iteration_record.performance_history[-5:]],
                "success_metrics": iteration_record.success_metrics,
                "adjustments_made": iteration_record.adjustments_made
            }
            
            self.detailed_logs.append(log_entry)
            
            # 保存到文件
            with open(self.log_file_path, 'w', encoding='utf-8') as f:
                json.dump(self.detailed_logs, f, indent=2, ensure_ascii=False)
            
        except Exception as e:
            logger.warning(f"日志保存失败: {str(e)}")
    
    def _generate_final_report(self) -> Dict[str, Any]:
        """生成最终报告"""
        try:
            if not self.optimization_history:
                return {"error": "无优化历史"}
            
            # 统计信息
            total_iterations = len(self.optimization_history)
            total_time = sum(record.end_time - record.start_time 
                           for record in self.optimization_history)
            
            # 最佳结果
            best_iteration = max(self.optimization_history, 
                               key=lambda x: x.success_metrics.get("performance_score", 0))
            
            # 性能趋势
            performance_scores = [record.success_metrics.get("performance_score", 0) 
                                for record in self.optimization_history]
            
            # 配置调整统计
            total_adjustments = sum(len(record.adjustments_made) 
                                  for record in self.optimization_history)
            
            report = {
                "summary": {
                    "total_iterations": total_iterations,
                    "total_time": total_time,
                    "average_time_per_iteration": total_time / total_iterations,
                    "total_adjustments": total_adjustments,
                    "final_score": performance_scores[-1] if performance_scores else 0,
                    "best_score": max(performance_scores) if performance_scores else 0,
                    "score_improvement": (performance_scores[-1] - performance_scores[0]) 
                                       if len(performance_scores) > 1 else 0
                },
                "best_iteration": {
                    "iteration_id": best_iteration.iteration_id,
                    "performance_score": best_iteration.success_metrics.get("performance_score", 0),
                    "pareto_solutions": len(best_iteration.final_results.pareto_solutions),
                    "generations": best_iteration.final_results.actual_generations
                },
                "performance_trend": performance_scores,
                "recommendations": self._generate_final_recommendations()
            }
            
            # 保存报告
            report_path = f"logs/ga_optimization_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(report_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
            
            logger.info(f"最终报告已保存至: {report_path}")
            return report
            
        except Exception as e:
            logger.error(f"最终报告生成失败: {str(e)}")
            return {"error": str(e)}
    
    def _generate_final_recommendations(self) -> List[str]:
        """生成最终建议"""
        recommendations = []
        
        try:
            if not self.optimization_history:
                return ["无足够数据生成建议"]
            
            # 分析整体趋势
            performance_scores = [record.success_metrics.get("performance_score", 0) 
                                for record in self.optimization_history]
            
            if len(performance_scores) > 1:
                improvement = performance_scores[-1] - performance_scores[0]
                
                if improvement > 20:
                    recommendations.append("优化效果显著，建议继续使用当前策略")
                elif improvement > 5:
                    recommendations.append("优化有一定效果，可考虑进一步调整参数")
                else:
                    recommendations.append("优化效果有限，建议尝试不同的算法或参数")
            
            # 分析最佳配置
            best_iteration = max(self.optimization_history, 
                               key=lambda x: x.success_metrics.get("performance_score", 0))
            
            recommendations.append(f"最佳配置：种群大小{best_iteration.config_used.population_size}，"
                                 f"最大代数{best_iteration.config_used.max_generations}")
            
            # 分析调整效果
            total_adjustments = sum(len(record.adjustments_made) 
                                  for record in self.optimization_history)
            
            if total_adjustments > 10:
                recommendations.append("参数调整频繁，建议使用更稳定的初始配置")
            elif total_adjustments < 3:
                recommendations.append("参数调整较少，可考虑更积极的自适应策略")
            
            return recommendations
            
        except Exception:
            return ["建议生成失败"]


def create_test_objective_function() -> Callable:
    """创建测试用目标函数"""
    
    # 初始化计算器
    building_params = BuildingParameters()
    energy_calculator = EnergyCalculator(building_params)
    
    def test_objective_function(individual: Individual, 
                              facade_data: FacadeData, 
                              climate_data: ClimateData) -> List[float]:
        """测试目标函数"""
        try:
            # 计算能耗目标
            energy_consumption = energy_calculator.calculate_annual_energy_consumption(
                individual, facade_data, climate_data
            )
            
            # 计算热力性能目标（简化版本）
            thermal_performance = 0.0
            for i, window in enumerate(facade_data.windows):
                if len(individual.window_width_scales) > i:
                    width_scale = individual.window_width_scales[i]
                    thermal_performance += width_scale * 10.0  # 简化计算
            
            return [energy_consumption, thermal_performance]
            
        except Exception as e:
            logger.warning(f"目标函数计算失败: {str(e)}")
            return [1000.0, 100.0]  # 默认较差值
    
    return test_objective_function


# 测试和演示函数
def run_optimization_test():
    """运行优化测试"""
    try:
        logger.info("开始遗传算法优化测试")
        
        # 创建测试数据（简化版本）
        from ..core.data_structures import Window, FacadeData, ClimateData, ClimateDataPoint
        
        # 创建测试立面数据
        windows = [
            Window(id=f"window_{i}", x=i*2, y=1, width=1.5, height=1.2, area=1.8)
            for i in range(3)
        ]
        
        facade_data = FacadeData(
            windows=windows,
            total_facade_area=20.0,
            total_window_area=5.4,
            total_wall_area=14.6
        )
        
        # 创建测试气候数据（简化版本）
        hourly_data = [
            ClimateDataPoint(
                hour=i,
                dry_bulb_temp=20 + 5 * np.sin(i * np.pi / 12),
                relative_humidity=60,
                global_radiation=max(0, 500 * np.sin(i * np.pi / 12))
            )
            for i in range(24)
        ]
        
        climate_data = ClimateData(
            location="测试地点",
            hourly_data=hourly_data
        )
        
        # 创建目标函数
        objective_function = create_test_objective_function()
        
        # 创建优化器配置
        config = GAOptimizationConfig(
            population_size=50,  # 测试用较小值
            max_generations=20,  # 测试用较小值
            max_iterations=3,    # 测试用较小值
            target_pareto_solutions=10,
            detailed_logging=True
        )
        
        # 创建优化器
        optimizer = GeneticAlgorithmOptimizer(config)
        
        # 执行优化
        results = optimizer.optimize_with_auto_adjustment(
            facade_data, climate_data, objective_function
        )
        
        logger.info("遗传算法优化测试完成")
        logger.info(f"最终帕累托解数量: {len(results.pareto_solutions)}")
        
        return results
        
    except Exception as e:
        logger.error(f"优化测试失败: {str(e)}")
        raise


if __name__ == "__main__":
    # 运行测试
    run_optimization_test()