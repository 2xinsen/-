
"""
算法验证器
用于评估优化算法的性能和质量
"""

import numpy as np
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import json
import os
from datetime import datetime

from ..core.logging_config import get_logger
from ..core.data_structures import Individual

logger = get_logger(__name__)


@dataclass
class ValidationConfig:
    """验证配置数据类"""
    test_runs: int = 3
    max_generations: int = 50
    population_size: int = 30
    enable_hypervolume: bool = True
    enable_diversity: bool = True
    enable_convergence: bool = True
    save_plots: bool = True
    output_dir: str = "validation_results"


@dataclass
class ValidationMetrics:
    """验证指标数据类"""
    convergence_rate: float = 0.0
    diversity_index: float = 0.0
    hypervolume: float = 0.0
    spread_metric: float = 0.0
    solution_quality: float = 0.0
    computational_efficiency: float = 0.0


class AlgorithmValidator:
    """算法验证器"""
    
    def __init__(self):
        """初始化算法验证器"""
        self.logger = get_logger(__name__)
        self.validation_history = []
        
    def validate_optimization_results(self, solutions: List[Individual], 
                                    evolution_data: Dict[str, Any],
                                    pareto_solutions: List[Individual] = None) -> Dict[str, Any]:
        """
        验证优化结果
        
        Args:
            solutions: 所有解
            evolution_data: 进化数据
            pareto_solutions: 帕累托解
            
        Returns:
            验证结果字典
        """
        try:
            validation_results = {
                'timestamp': datetime.now().isoformat(),
                'solution_count': len(solutions),
                'pareto_count': len(pareto_solutions) if pareto_solutions else 0,
                'metrics': {},
                'quality_assessment': {},
                'recommendations': []
            }
            
            # 计算各种验证指标
            validation_results['metrics'] = self._calculate_validation_metrics(
                solutions, evolution_data, pareto_solutions
            )
            
            # 质量评估
            validation_results['quality_assessment'] = self._assess_solution_quality(
                solutions, pareto_solutions
            )
            
            # 生成改进建议
            validation_results['recommendations'] = self._generate_recommendations(
                validation_results['metrics'], validation_results['quality_assessment']
            )
            
            # 保存验证历史
            self.validation_history.append(validation_results)
            
            return validation_results
            
        except Exception as e:
            logger.error(f"算法验证失败: {str(e)}")
            return {'error': str(e)}
    
    def _calculate_validation_metrics(self, solutions: List[Individual], 
                                    evolution_data: Dict[str, Any],
                                    pareto_solutions: List[Individual] = None) -> Dict[str, float]:
        """计算验证指标"""
        try:
            metrics = {}
            
            # 收敛性指标
            metrics['convergence_rate'] = self._calculate_convergence_rate(evolution_data)
            
            # 多样性指标
            metrics['diversity_index'] = self._calculate_diversity_index(solutions)
            
            # 超体积指标
            if pareto_solutions:
                metrics['hypervolume'] = self._calculate_hypervolume(pareto_solutions)
            
            # 分布指标
            metrics['spread_metric'] = self._calculate_spread_metric(solutions)
            
            # 解质量指标
            metrics['solution_quality'] = self._calculate_solution_quality(solutions)
            
            # 计算效率指标
            metrics['computational_efficiency'] = self._calculate_computational_efficiency(evolution_data)
            
            return metrics
            
        except Exception as e:
            logger.error(f"验证指标计算失败: {str(e)}")
            return {}
    
    def _calculate_convergence_rate(self, evolution_data: Dict[str, Any]) -> float:
        """计算收敛率 - 修复收敛性分析问题"""
        try:
            fitness_history = evolution_data.get('best_fitness_history', [])
            if len(fitness_history) < 2:
                # 如果没有足够的历史数据，检查是否有解
                total_evaluations = evolution_data.get('total_evaluations', 0)
                if total_evaluations > 0:
                    return 0.5  # 有评估但缺少历史，给予中等评分
                return 0.0
            
            # 计算改进率
            initial_fitness = fitness_history[0]
            final_fitness = fitness_history[-1]
            
            # 处理初始适应度为0的情况
            if abs(initial_fitness) < 1e-6:
                if abs(final_fitness) < 1e-6:
                    improvement_rate = 0.0  # 没有改进
                else:
                    improvement_rate = 1.0  # 从0开始有改进
            else:
                improvement_rate = abs(final_fitness - initial_fitness) / abs(initial_fitness)
                improvement_rate = min(1.0, improvement_rate)  # 限制在1.0以内
            
            # 计算收敛稳定性
            if len(fitness_history) >= 10:
                last_10_percent = max(1, len(fitness_history) // 10)
                recent_fitness = fitness_history[-last_10_percent:]
                mean_recent = np.mean(recent_fitness)
                if abs(mean_recent) > 1e-6:
                    stability = 1.0 - (np.std(recent_fitness) / abs(mean_recent))
                    stability = max(0.0, min(1.0, stability))
                else:
                    stability = 1.0  # 如果均值接近0，认为已稳定
            else:
                stability = 0.5  # 数据不足，给予中等稳定性评分
            
            # 综合收敛率
            convergence_rate = (improvement_rate * 0.7 + stability * 0.3)
            return min(1.0, max(0.0, convergence_rate))
            
        except Exception as e:
            logger.warning(f"收敛率计算失败: {str(e)}")
            return 0.0
    
    def _calculate_diversity_index(self, solutions: List[Individual]) -> float:
        """计算多样性指数"""
        try:
            if len(solutions) < 2:
                return 0.0
            
            # 提取决策变量
            decision_vectors = []
            for solution in solutions:
                if hasattr(solution, 'window_width_scales'):
                    vector = list(solution.window_width_scales)
                    if hasattr(solution, 'shading_depths'):
                        vector.extend(solution.shading_depths)
                    if hasattr(solution, 'shading_types'):
                        vector.extend(solution.shading_types)
                    decision_vectors.append(vector)
            
            if not decision_vectors:
                return 0.0
            
            decision_vectors = np.array(decision_vectors)
            
            # 计算平均距离
            total_distance = 0.0
            count = 0
            
            for i in range(len(decision_vectors)):
                for j in range(i + 1, len(decision_vectors)):
                    distance = np.linalg.norm(decision_vectors[i] - decision_vectors[j])
                    total_distance += distance
                    count += 1
            
            if count > 0:
                avg_distance = total_distance / count
                # 归一化到0-1范围
                max_possible_distance = np.sqrt(len(decision_vectors[0]))
                diversity_index = min(1.0, avg_distance / max_possible_distance)
                return diversity_index
            
            return 0.0
            
        except Exception as e:
            logger.warning(f"多样性指数计算失败: {str(e)}")
            return 0.0
    
    def _calculate_hypervolume(self, pareto_solutions: List[Individual]) -> float:
        """计算超体积指标"""
        try:
            if not pareto_solutions:
                return 0.0
            
            # 提取目标函数值
            objectives = []
            for solution in pareto_solutions:
                if hasattr(solution, 'objectives') and solution.objectives:
                    objectives.append(solution.objectives)
            
            if not objectives:
                return 0.0
            
            objectives = np.array(objectives)
            
            # 简化的超体积计算（2D情况）
            if objectives.shape[1] == 2:
                # 排序
                sorted_indices = np.argsort(objectives[:, 0])
                sorted_objectives = objectives[sorted_indices]
                
                # 计算超体积
                hypervolume = 0.0
                for i in range(len(sorted_objectives)):
                    if i == 0:
                        width = sorted_objectives[i, 0]
                    else:
                        width = sorted_objectives[i, 0] - sorted_objectives[i-1, 0]
                    
                    height = sorted_objectives[i, 1]
                    hypervolume += width * height
                
                return hypervolume
            
            # 多维情况的简化计算
            normalized_objectives = objectives / (np.max(objectives, axis=0) + 1e-6)
            return np.prod(np.max(normalized_objectives, axis=0))
            
        except Exception as e:
            logger.warning(f"超体积计算失败: {str(e)}")
            return 0.0
    
    def _calculate_spread_metric(self, solutions: List[Individual]) -> float:
        """计算分布指标"""
        try:
            if len(solutions) < 3:
                return 0.0
            
            # 提取目标函数值
            objectives = []
            for solution in solutions:
                if hasattr(solution, 'objectives') and solution.objectives:
                    objectives.append(solution.objectives)
            
            if not objectives:
                return 0.0
            
            objectives = np.array(objectives)
            
            # 计算相邻解之间的距离
            distances = []
            for i in range(len(objectives) - 1):
                dist = np.linalg.norm(objectives[i+1] - objectives[i])
                distances.append(dist)
            
            if not distances:
                return 0.0
            
            # 计算分布均匀性
            mean_distance = np.mean(distances)
            std_distance = np.std(distances)
            
            if mean_distance > 0:
                spread_metric = 1.0 - (std_distance / mean_distance)
                return max(0.0, spread_metric)
            
            return 0.0
            
        except Exception as e:
            logger.warning(f"分布指标计算失败: {str(e)}")
            return 0.0
    
    def _calculate_solution_quality(self, solutions: List[Individual]) -> float:
        """计算解质量指标"""
        try:
            if not solutions:
                return 0.0
            
            quality_scores = []
            
            for solution in solutions:
                if hasattr(solution, 'objectives') and solution.objectives:
                    # 简化的质量评估：基于目标函数值
                    energy_score = 1.0 / (1.0 + solution.objectives[0])  # 能耗越低越好
                    if len(solution.objectives) > 1:
                        thermal_score = 1.0 / (1.0 + solution.objectives[1])  # 热性能越低越好
                        quality_score = (energy_score + thermal_score) / 2.0
                    else:
                        quality_score = energy_score
                    
                    quality_scores.append(quality_score)
            
            if quality_scores:
                return np.mean(quality_scores)
            
            return 0.0
            
        except Exception as e:
            logger.warning(f"解质量计算失败: {str(e)}")
            return 0.0
    
    def _calculate_computational_efficiency(self, evolution_data: Dict[str, Any]) -> float:
        """计算计算效率"""
        try:
            total_evaluations = evolution_data.get('total_evaluations', 0)
            total_generations = evolution_data.get('total_generations', 1)
            
            if total_generations > 0 and total_evaluations > 0:
                evaluations_per_generation = total_evaluations / total_generations
                # 假设理想的每代评估次数为100
                efficiency = min(1.0, 100.0 / evaluations_per_generation)
                return efficiency
            
            return 0.0
            
        except Exception as e:
            logger.warning(f"计算效率计算失败: {str(e)}")
            return 0.0
    
    def _assess_solution_quality(self, solutions: List[Individual], 
                               pareto_solutions: List[Individual] = None) -> Dict[str, Any]:
        """评估解质量"""
        try:
            assessment = {
                'overall_quality': 'unknown',
                'strengths': [],
                'weaknesses': [],
                'quality_score': 0.0
            }
            
            if not solutions:
                assessment['overall_quality'] = 'poor'
                assessment['weaknesses'].append('没有找到有效解')
                return assessment
            
            # 评估解的数量
            if len(solutions) >= 50:
                assessment['strengths'].append('解的数量充足')
            elif len(solutions) >= 20:
                assessment['strengths'].append('解的数量适中')
            else:
                assessment['weaknesses'].append('解的数量较少')
            
            # 评估帕累托解
            if pareto_solutions:
                pareto_ratio = len(pareto_solutions) / len(solutions)
                if pareto_ratio >= 0.3:
                    assessment['strengths'].append('帕累托解比例良好')
                else:
                    assessment['weaknesses'].append('帕累托解比例偏低')
            
            # 评估目标函数值分布
            energy_values = []
            thermal_values = []
            
            for solution in solutions:
                if hasattr(solution, 'objectives') and solution.objectives:
                    energy_values.append(solution.objectives[0])
                    if len(solution.objectives) > 1:
                        thermal_values.append(solution.objectives[1])
            
            if energy_values:
                energy_cv = np.std(energy_values) / (np.mean(energy_values) + 1e-6)
                if energy_cv > 0.1:
                    assessment['strengths'].append('能耗解分布多样')
                else:
                    assessment['weaknesses'].append('能耗解分布单一')
            
            if thermal_values:
                thermal_cv = np.std(thermal_values) / (np.mean(thermal_values) + 1e-6)
                if thermal_cv > 0.1:
                    assessment['strengths'].append('热性能解分布多样')
                else:
                    assessment['weaknesses'].append('热性能解分布单一')
            
            # 综合质量评分
            strength_score = len(assessment['strengths']) * 0.2
            weakness_penalty = len(assessment['weaknesses']) * 0.1
            assessment['quality_score'] = max(0.0, min(1.0, strength_score - weakness_penalty))
            
            # 确定整体质量等级
            if assessment['quality_score'] >= 0.8:
                assessment['overall_quality'] = 'excellent'
            elif assessment['quality_score'] >= 0.6:
                assessment['overall_quality'] = 'good'
            elif assessment['quality_score'] >= 0.4:
                assessment['overall_quality'] = 'fair'
            else:
                assessment['overall_quality'] = 'poor'
            
            return assessment
            
        except Exception as e:
            logger.error(f"解质量评估失败: {str(e)}")
            return {'overall_quality': 'error', 'error': str(e)}
    
    def _generate_recommendations(self, metrics: Dict[str, float], 
                                quality_assessment: Dict[str, Any]) -> List[str]:
        """生成改进建议"""
        try:
            recommendations = []
            
            # 基于收敛性的建议
            convergence_rate = metrics.get('convergence_rate', 0.0)
            if convergence_rate < 0.3:
                recommendations.append("建议增加迭代代数以改善收敛性")
            elif convergence_rate < 0.5:
                recommendations.append("考虑调整变异率以平衡探索和开发")
            
            # 基于多样性的建议
            diversity_index = metrics.get('diversity_index', 0.0)
            if diversity_index < 0.3:
                recommendations.append("建议增加种群大小以提高解的多样性")
            elif diversity_index < 0.5:
                recommendations.append("考虑调整选择压力以保持种群多样性")
            
            # 基于解质量的建议
            solution_quality = metrics.get('solution_quality', 0.0)
            if solution_quality < 0.4:
                recommendations.append("建议检查目标函数定义和约束条件")
            elif solution_quality < 0.6:
                recommendations.append("考虑优化参数编码方案")
            
            # 基于计算效率的建议
            computational_efficiency = metrics.get('computational_efficiency', 0.0)
            if computational_efficiency < 0.3:
                recommendations.append("建议优化目标函数计算以提高效率")
            elif computational_efficiency < 0.5:
                recommendations.append("考虑并行化计算以加速优化过程")
            
            # 基于质量评估的建议
            overall_quality = quality_assessment.get('overall_quality', 'unknown')
            if overall_quality == 'poor':
                recommendations.append("建议重新检查问题建模和算法参数设置")
            elif overall_quality == 'fair':
                recommendations.append("建议微调算法参数以提升解质量")
            
            # 如果没有具体建议，给出通用建议
            if not recommendations:
                recommendations.append("当前优化结果良好，可考虑进一步精细化参数调整")
            
            return recommendations
            
        except Exception as e:
            logger.error(f"建议生成失败: {str(e)}")
            return ["建议生成失败，请检查算法实现"]
    
    def save_validation_report(self, validation_results: Dict[str, Any], 
                             output_path: str = "output/validation_report.json"):
        """保存验证报告"""
        try:
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(validation_results, f, indent=2, ensure_ascii=False, default=str)
            
            logger.info(f"验证报告已保存到: {output_path}")
            
        except Exception as e:
            logger.error(f"保存验证报告失败: {str(e)}")
    
    def get_validation_summary(self, validation_results: Dict[str, Any]) -> str:
        """获取验证摘要"""
        try:
            if 'error' in validation_results:
                return f"验证失败: {validation_results['error']}"
            
            metrics = validation_results.get('metrics', {})
            quality = validation_results.get('quality_assessment', {})
            
            summary = f"""
算法验证摘要:
====================
解的数量: {validation_results.get('solution_count', 0)}
帕累托解数量: {validation_results.get('pareto_count', 0)}

性能指标:
- 收敛率: {metrics.get('convergence_rate', 0.0):.3f}
- 多样性指数: {metrics.get('diversity_index', 0.0):.3f}
- 解质量: {metrics.get('solution_quality', 0.0):.3f}
- 计算效率: {metrics.get('computational_efficiency', 0.0):.3f}

质量评估: {quality.get('overall_quality', 'unknown')}
质量得分: {quality.get('quality_score', 0.0):.3f}

主要建议:
"""
            
            recommendations = validation_results.get('recommendations', [])
            for i, rec in enumerate(recommendations[:3], 1):  # 只显示前3个建议
                summary += f"{i}. {rec}\n"
            
            return summary
            
        except Exception as e:
            return f"生成验证摘要失败: {str(e)}"
