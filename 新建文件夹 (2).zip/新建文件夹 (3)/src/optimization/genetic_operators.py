
"""
遗传算子模块
实现高级的交叉、变异、选择等遗传算子
"""

import numpy as np
from typing import List, Dict, Tuple, Optional, Any
import random
import math
from dataclasses import dataclass
from abc import ABC, abstractmethod

from ..core.config import config_manager
from ..core.logging_config import get_logger
from ..core.exceptions import OptimizationError
from ..core.data_structures import Individual, FacadeData
from .constraint_handler import ConstraintHandler

logger = get_logger(__name__)


@dataclass
class GeneticOperatorConfig:
    """遗传算子配置 - 大幅优化以获得更多帕累托解并延缓收敛"""
    # 交叉算子配置
    crossover_type: str = "simulated_binary"  # 交叉类型
    crossover_eta: float = 5.0                # 进一步降低SBX分布指数以大幅增加探索性
    crossover_probability: float = 0.70       # 进一步降低交叉概率以增加多样性
    
    # 变异算子配置
    mutation_type: str = "adaptive"           # 变异类型 - 默认使用自适应变异
    mutation_eta: float = 5.0                 # 进一步降低多项式变异分布指数以大幅增加变异强度
    mutation_probability: float = 0.50        # 大幅提高变异概率以增加随机度
    
    # 选择算子配置
    selection_type: str = "tournament"        # 选择类型
    tournament_size: int = 2                  # 保持较小的锦标赛大小以减少选择压力
    
    # 自适应参数
    adaptive_enabled: bool = True             # 是否启用自适应
    adaptation_frequency: int = 1             # 每代都进行自适应调整
    performance_window: int = 5               # 进一步缩短性能评估窗口以更快响应


class CrossoverOperator(ABC):
    """交叉算子基类"""
    
    @abstractmethod
    def crossover(self, parent1: Individual, parent2: Individual, 
                 facade_data: FacadeData) -> Tuple[Individual, Individual]:
        """执行交叉操作"""
        pass


class SimulatedBinaryCrossover(CrossoverOperator):
    """模拟二进制交叉（SBX）- 强制原图比例和窗户位置"""
    
    def __init__(self, eta: float = 20.0, force_original_proportions: bool = True):
        """
        初始化SBX交叉算子
        
        Args:
            eta: 分布指数，控制交叉的探索性
            force_original_proportions: 是否强制原图比例和窗户位置
        """
        self.eta = eta
        self.force_original_proportions = force_original_proportions
    
    def crossover(self, parent1: Individual, parent2: Individual, 
                 facade_data: FacadeData) -> Tuple[Individual, Individual]:
        """执行SBX交叉 - 强制原图比例和窗户位置"""
        try:
            child1 = parent1.copy()
            child2 = parent2.copy()
            
            if self.force_original_proportions and facade_data:
                # 强制保持原图窗户位置不变
                child1.window_positions_x = np.zeros_like(parent1.window_positions_x)
                child1.window_positions_y = np.zeros_like(parent1.window_positions_y)
                child2.window_positions_x = np.zeros_like(parent2.window_positions_x)
                child2.window_positions_y = np.zeros_like(parent2.window_positions_y)
                
                # 强制保持原图窗户高度不变（高度缩放因子=1.0）
                child1.window_height_scales = np.ones_like(parent1.window_height_scales)
                child2.window_height_scales = np.ones_like(parent2.window_height_scales)
            
            # 对窗户宽度缩放因子进行交叉（允许宽度调整）
            child1.window_width_scales, child2.window_width_scales = self._sbx_crossover(
                parent1.window_width_scales, parent2.window_width_scales, 0.7, 1.5
            )
            
            # 对遮阳深度进行交叉
            child1.shading_depths, child2.shading_depths = self._sbx_crossover(
                parent1.shading_depths, parent2.shading_depths, 0.2, 0.8
            )
            
            # 强制使用窗框或遮阳（不能两者都没有）
            for i in range(len(parent1.shading_types)):
                if random.random() < 0.5:
                    child1.shading_types[i] = parent2.shading_types[i]
                    child2.shading_types[i] = parent1.shading_types[i]
                
                # 强制约束：每个窗户必须有窗框或遮阳
                if child1.shading_types[i] == 0:  # 如果没有遮阳
                    # 确保有窗框（通过设置合理的窗框深度）
                    pass  # 窗框深度在后续处理中设置
                
                if child2.shading_types[i] == 0:  # 如果没有遮阳
                    # 确保有窗框
                    pass
            
            return child1, child2
            
        except Exception as e:
            logger.error(f"SBX交叉失败: {str(e)}")
            return parent1.copy(), parent2.copy()
    
    def _sbx_crossover(self, p1_values: np.ndarray, p2_values: np.ndarray,
                      lower_bound: float, upper_bound: float) -> Tuple[np.ndarray, np.ndarray]:
        """执行SBX交叉的核心算法"""
        c1_values = p1_values.copy()
        c2_values = p2_values.copy()
        
        for i in range(len(p1_values)):
            if random.random() <= 0.5:  # 交叉概率
                if abs(p1_values[i] - p2_values[i]) > 1e-14:
                    # 计算beta值
                    u = random.random()
                    
                    if u <= 0.5:
                        beta = (2.0 * u) ** (1.0 / (self.eta + 1.0))
                    else:
                        beta = (1.0 / (2.0 * (1.0 - u))) ** (1.0 / (self.eta + 1.0))
                    
                    # 生成子代
                    c1_values[i] = 0.5 * ((1.0 + beta) * p1_values[i] + (1.0 - beta) * p2_values[i])
                    c2_values[i] = 0.5 * ((1.0 - beta) * p1_values[i] + (1.0 + beta) * p2_values[i])
                    
                    # 边界检查
                    c1_values[i] = np.clip(c1_values[i], lower_bound, upper_bound)
                    c2_values[i] = np.clip(c2_values[i], lower_bound, upper_bound)
        
        return c1_values, c2_values


class UniformCrossover(CrossoverOperator):
    """均匀交叉"""
    
    def __init__(self, crossover_rate: float = 0.5):
        """
        初始化均匀交叉算子
        
        Args:
            crossover_rate: 基因交叉概率
        """
        self.crossover_rate = crossover_rate
    
    def crossover(self, parent1: Individual, parent2: Individual, 
                 facade_data: FacadeData) -> Tuple[Individual, Individual]:
        """执行均匀交叉"""
        try:
            child1 = parent1.copy()
            child2 = parent2.copy()
            
            # 窗户宽度缩放因子交叉
            for i in range(len(parent1.window_width_scales)):
                if random.random() < self.crossover_rate:
                    child1.window_width_scales[i] = parent2.window_width_scales[i]
                    child2.window_width_scales[i] = parent1.window_width_scales[i]
            
            # 遮阳深度交叉
            for i in range(len(parent1.shading_depths)):
                if random.random() < self.crossover_rate:
                    child1.shading_depths[i] = parent2.shading_depths[i]
                    child2.shading_depths[i] = parent1.shading_depths[i]
            
            # 遮阳类型交叉
            for i in range(len(parent1.shading_types)):
                if random.random() < self.crossover_rate:
                    child1.shading_types[i] = parent2.shading_types[i]
                    child2.shading_types[i] = parent1.shading_types[i]
            
            return child1, child2
            
        except Exception as e:
            logger.error(f"均匀交叉失败: {str(e)}")
            return parent1.copy(), parent2.copy()


class MutationOperator(ABC):
    """变异算子基类"""
    
    @abstractmethod
    def mutate(self, individual: Individual, facade_data: FacadeData) -> Individual:
        """执行变异操作"""
        pass


class PolynomialMutation(MutationOperator):
    """多项式变异 - 强制原图比例和窗户位置"""
    
    def __init__(self, eta: float = 20.0, mutation_probability: float = 0.1, 
                 force_original_proportions: bool = True):
        """
        初始化多项式变异算子
        
        Args:
            eta: 分布指数
            mutation_probability: 变异概率
            force_original_proportions: 是否强制原图比例和窗户位置
        """
        self.eta = eta
        self.mutation_probability = mutation_probability
        self.force_original_proportions = force_original_proportions
    
    def mutate(self, individual: Individual, facade_data: FacadeData) -> Individual:
        """执行多项式变异 - 强制原图比例和窗户位置"""
        try:
            mutated = individual.copy()
            
            if self.force_original_proportions:
                # 强制保持原图窗户位置不变
                mutated.window_positions_x = np.zeros_like(individual.window_positions_x)
                mutated.window_positions_y = np.zeros_like(individual.window_positions_y)
                
                # 强制保持原图窗户高度不变
                mutated.window_height_scales = np.ones_like(individual.window_height_scales)
            
            # 窗户宽度缩放因子变异（允许宽度调整）
            mutated.window_width_scales = self._polynomial_mutation(
                mutated.window_width_scales, 0.7, 1.5
            )
            
            # 遮阳深度变异
            mutated.shading_depths = self._polynomial_mutation(
                mutated.shading_depths, 0.2, 0.8
            )
            
            # 遮阳类型变异（离散变异）- 强制使用窗框或遮阳
            for i in range(len(mutated.shading_types)):
                if random.random() < self.mutation_probability:
                    # 随机选择遮阳或窗框（不能两者都没有）
                    mutated.shading_types[i] = random.choice([0, 1])
            
            # 确保每个窗户都有窗框或遮阳
            self._enforce_frame_or_shading_constraint(mutated)
            
            return mutated
            
        except Exception as e:
            logger.error(f"多项式变异失败: {str(e)}")
            return individual
    
    def _enforce_frame_or_shading_constraint(self, individual: Individual):
        """强制每个窗户都有窗框或遮阳的约束"""
        for i in range(len(individual.shading_types)):
            # 如果没有遮阳，确保有合理的窗框深度
            if individual.shading_types[i] == 0:
                # 窗框深度将在窗户提取时设置为0.1
                pass
            else:
                # 如果有遮阳，确保遮阳深度合理
                if individual.shading_depths[i] < 0.2:
                    individual.shading_depths[i] = 0.2
    
    def _polynomial_mutation(self, values: np.ndarray, lower_bound: float, 
                           upper_bound: float) -> np.ndarray:
        """执行多项式变异的核心算法"""
        mutated_values = values.copy()
        
        for i in range(len(values)):
            if random.random() < self.mutation_probability:
                u = random.random()
                
                if u < 0.5:
                    delta = (2.0 * u) ** (1.0 / (self.eta + 1.0)) - 1.0
                else:
                    delta = 1.0 - (2.0 * (1.0 - u)) ** (1.0 / (self.eta + 1.0))
                
                # 应用变异
                mutated_values[i] += delta * (upper_bound - lower_bound)
                mutated_values[i] = np.clip(mutated_values[i], lower_bound, upper_bound)
        
        return mutated_values


class GaussianMutation(MutationOperator):
    """高斯变异"""
    
    def __init__(self, sigma: float = 0.1, mutation_probability: float = 0.1):
        """
        初始化高斯变异算子
        
        Args:
            sigma: 高斯分布标准差
            mutation_probability: 变异概率
        """
        self.sigma = sigma
        self.mutation_probability = mutation_probability
    
    def mutate(self, individual: Individual, facade_data: FacadeData) -> Individual:
        """执行高斯变异"""
        try:
            mutated = individual.copy()
            
            # 窗户宽度缩放因子变异
            for i in range(len(mutated.window_width_scales)):
                if random.random() < self.mutation_probability:
                    noise = random.gauss(0, self.sigma)
                    mutated.window_width_scales[i] += noise
                    mutated.window_width_scales[i] = np.clip(mutated.window_width_scales[i], 0.5, 2.0)
            
            # 遮阳深度变异
            for i in range(len(mutated.shading_depths)):
                if random.random() < self.mutation_probability:
                    noise = random.gauss(0, self.sigma)
                    mutated.shading_depths[i] += noise
                    mutated.shading_depths[i] = np.clip(mutated.shading_depths[i], 0.1, 1.0)
            
            # 遮阳类型变异
            for i in range(len(mutated.shading_types)):
                if random.random() < self.mutation_probability * 0.5:  # 降低离散变异概率
                    mutated.shading_types[i] = 1 - mutated.shading_types[i]
            
            return mutated
            
        except Exception as e:
            logger.error(f"高斯变异失败: {str(e)}")
            return individual


class AdaptiveMutation(MutationOperator):
    """自适应变异 - 结合多种变异策略"""
    
    def __init__(self, mutation_probability: float = 0.1):
        """
        初始化自适应变异算子
        
        Args:
            mutation_probability: 基础变异概率
        """
        self.mutation_probability = mutation_probability
        self.generation = 0
        self.max_generations = 200
        
        # 初始化多种变异算子
        self.polynomial_mutator = PolynomialMutation(20.0, mutation_probability)
        self.gaussian_mutator = GaussianMutation(0.1, mutation_probability)
    
    def set_generation_info(self, generation: int, max_generations: int):
        """设置代数信息用于自适应"""
        self.generation = generation
        self.max_generations = max_generations
    
    def mutate(self, individual: Individual, facade_data: FacadeData) -> Individual:
        """执行自适应变异 - 增强随机度版本"""
        try:
            # 计算自适应变异强度 - 更高的基础强度
            progress = self.generation / max(self.max_generations, 1)
            adaptive_strength = 0.5 * (1 - progress * 0.6) + 0.1  # 0.5->0.2，保持更高的变异强度
            
            # 选择变异策略 - 更多样化的策略选择
            strategy_choice = random.random()
            
            if strategy_choice < 0.3:
                # 30% 概率使用多项式变异
                self.polynomial_mutator.mutation_probability = adaptive_strength
                return self.polynomial_mutator.mutate(individual, facade_data)
            elif strategy_choice < 0.5:
                # 20% 概率使用高斯变异
                self.gaussian_mutator.mutation_probability = adaptive_strength
                self.gaussian_mutator.sigma = adaptive_strength * 0.6  # 增加高斯变异强度
                return self.gaussian_mutator.mutate(individual, facade_data)
            elif strategy_choice < 0.8:
                # 30% 概率使用混合变异
                return self._mixed_mutation(individual, facade_data, adaptive_strength)
            else:
                # 20% 概率使用强变异（新增）
                return self._strong_mutation(individual, facade_data, adaptive_strength)
            
        except Exception as e:
            logger.error(f"自适应变异失败: {str(e)}")
            return individual
    
    def _strong_mutation(self, individual: Individual, facade_data: FacadeData, 
                        strength: float) -> Individual:
        """强变异策略 - 大幅度参数变化"""
        try:
            mutated = individual.copy()
            
            # 窗户宽度强变异 - 更大的变化范围
            for i in range(len(mutated.window_width_scales)):
                if random.random() < strength * 0.8:  # 更高的变异概率
                    if random.random() < 0.5:
                        # 大幅度随机重置
                        mutated.window_width_scales[i] = random.uniform(0.3, 2.5)
                    else:
                        # 大幅度增减
                        change = random.uniform(-0.8, 0.8)
                        mutated.window_width_scales[i] += change
                    
                    mutated.window_width_scales[i] = np.clip(mutated.window_width_scales[i], 0.3, 2.5)
            
            # 遮阳深度强变异
            for i in range(len(mutated.shading_depths)):
                if random.random() < strength * 0.7:
                    if random.random() < 0.4:
                        # 随机重置
                        mutated.shading_depths[i] = random.uniform(0.05, 1.5)
                    else:
                        # 大幅度变化
                        change = random.uniform(-0.6, 0.6)
                        mutated.shading_depths[i] += change
                    
                    mutated.shading_depths[i] = np.clip(mutated.shading_depths[i], 0.05, 1.5)
            
            # 遮阳类型强变异 - 更高的切换概率
            for i in range(len(mutated.shading_types)):
                if random.random() < strength * 0.6:
                    mutated.shading_types[i] = 1 - mutated.shading_types[i]
            
            # 角度强变异（如果存在）
            if hasattr(mutated, 'shading_angles'):
                for i in range(len(mutated.shading_angles)):
                    if random.random() < strength * 0.5:
                        if random.random() < 0.3:
                            # 随机重置角度
                            mutated.shading_angles[i] = random.uniform(10, 80)
                        else:
                            # 大幅度角度变化
                            change = random.uniform(-30, 30)
                            mutated.shading_angles[i] += change
                            mutated.shading_angles[i] = np.clip(mutated.shading_angles[i], 10, 80)
            
            return mutated
            
        except Exception as e:
            logger.error(f"强变异失败: {str(e)}")
            return individual
    
    def _mixed_mutation(self, individual: Individual, facade_data: FacadeData, 
                       strength: float) -> Individual:
        """混合变异策略"""
        try:
            mutated = individual.copy()
            
            # 对不同参数使用不同的变异策略
            for i in range(len(mutated.window_width_scales)):
                if random.random() < strength:
                    if random.random() < 0.5:
                        # 高斯变异
                        noise = random.gauss(0, strength * 0.3)
                        mutated.window_width_scales[i] += noise
                    else:
                        # 均匀变异
                        delta = random.uniform(-strength * 0.5, strength * 0.5)
                        mutated.window_width_scales[i] += delta
                    
                    mutated.window_width_scales[i] = np.clip(mutated.window_width_scales[i], 0.5, 2.0)
            
            # 遮阳深度使用多项式变异
            for i in range(len(mutated.shading_depths)):
                if random.random() < strength:
                    u = random.random()
                    eta = 20.0
                    
                    if u < 0.5:
                        delta = (2.0 * u) ** (1.0 / (eta + 1.0)) - 1.0
                    else:
                        delta = 1.0 - (2.0 * (1.0 - u)) ** (1.0 / (eta + 1.0))
                    
                    mutated.shading_depths[i] += delta * 0.3
                    mutated.shading_depths[i] = np.clip(mutated.shading_depths[i], 0.1, 1.0)
            
            # 遮阳类型变异
            for i in range(len(mutated.shading_types)):
                if random.random() < strength * 0.3:  # 降低离散变异概率
                    mutated.shading_types[i] = 1 - mutated.shading_types[i]
            
            return mutated
            
        except Exception as e:
            logger.error(f"混合变异失败: {str(e)}")
            return individual


class SelectionOperator(ABC):
    """选择算子基类"""
    
    @abstractmethod
    def select(self, population: List[Individual], num_parents: int) -> List[Individual]:
        """执行选择操作"""
        pass


class TournamentSelection(SelectionOperator):
    """锦标赛选择"""
    
    def __init__(self, tournament_size: int = 2):
        """
        初始化锦标赛选择算子
        
        Args:
            tournament_size: 锦标赛大小
        """
        self.tournament_size = tournament_size
    
    def select(self, population: List[Individual], num_parents: int) -> List[Individual]:
        """执行锦标赛选择"""
        try:
            selected = []
            
            for _ in range(num_parents):
                # 随机选择锦标赛参与者
                tournament = random.sample(population, 
                                         min(self.tournament_size, len(population)))
                
                # 选择最优个体（基于rank和crowding distance）
                winner = min(tournament, key=lambda x: (x.rank, -x.crowding_distance))
                selected.append(winner)
            
            return selected
            
        except Exception as e:
            logger.error(f"锦标赛选择失败: {str(e)}")
            return random.sample(population, num_parents)


class RouletteWheelSelection(SelectionOperator):
    """轮盘赌选择"""
    
    def select(self, population: List[Individual], num_parents: int) -> List[Individual]:
        """执行轮盘赌选择"""
        try:
            # 计算适应度（基于rank的倒数）
            fitness_values = []
            for individual in population:
                # rank越小越好，所以使用倒数
                fitness = 1.0 / (individual.rank + 1.0)
                fitness_values.append(fitness)
            
            total_fitness = sum(fitness_values)
            if total_fitness == 0:
                return random.sample(population, num_parents)
            
            # 计算选择概率
            probabilities = [f / total_fitness for f in fitness_values]
            
            # 执行选择
            selected = []
            for _ in range(num_parents):
                r = random.random()
                cumulative_prob = 0.0
                
                for i, prob in enumerate(probabilities):
                    cumulative_prob += prob
                    if r <= cumulative_prob:
                        selected.append(population[i])
                        break
                else:
                    selected.append(population[-1])  # 备选方案
            
            return selected
            
        except Exception as e:
            logger.error(f"轮盘赌选择失败: {str(e)}")
            return random.sample(population, num_parents)


class AdaptiveParameterController:
    """自适应参数控制器"""
    
    def __init__(self, config: GeneticOperatorConfig):
        """
        初始化自适应参数控制器
        
        Args:
            config: 遗传算子配置
        """
        self.config = config
        self.performance_history = []
        self.current_crossover_prob = config.crossover_probability
        self.current_mutation_prob = config.mutation_probability
        self.last_adaptation_generation = 0
    
    def update_parameters(self, generation: int, population: List[Individual]):
        """
        更新自适应参数
        
        Args:
            generation: 当前代数
            population: 当前种群
        """
        try:
            if not self.config.adaptive_enabled:
                return
            
            # 计算当前性能指标
            current_performance = self._calculate_performance(population)
            self.performance_history.append(current_performance)
            
            # 检查是否需要调整参数
            if (generation - self.last_adaptation_generation >= self.config.adaptation_frequency and
                len(self.performance_history) >= self.config.performance_window):
                
                self._adapt_parameters()
                self.last_adaptation_generation = generation
                
                logger.info(f"第{generation}代自适应参数调整: "
                          f"交叉概率={self.current_crossover_prob:.3f}, "
                          f"变异概率={self.current_mutation_prob:.3f}")
        
        except Exception as e:
            logger.warning(f"自适应参数更新失败: {str(e)}")
    
    def _calculate_performance(self, population: List[Individual]) -> Dict[str, float]:
        """计算种群性能指标"""
        try:
            # 计算帕累托前沿大小
            pareto_front_size = len([ind for ind in population if ind.rank == 0])
            
            # 计算目标函数的多样性
            objectives = [ind.objectives for ind in population if ind.objectives]
            if objectives:
                objectives_array = np.array(objectives)
                diversity = np.mean(np.std(objectives_array, axis=0))
            else:
                diversity = 0.0
            
            # 计算平均拥挤距离
            avg_crowding_distance = np.mean([ind.crowding_distance for ind in population])
            
            return {
                'pareto_front_size': pareto_front_size,
                'diversity': diversity,
                'avg_crowding_distance': avg_crowding_distance
            }
            
        except Exception as e:
            logger.warning(f"性能指标计算失败: {str(e)}")
            return {'pareto_front_size': 0, 'diversity': 0.0, 'avg_crowding_distance': 0.0}
    
    def _adapt_parameters(self):
        """
        自适应调整参数 - 超级增强版本，极致的多样性保持和收敛优化
        
        这个方法通过分析种群的多种性能指标来动态调整遗传算子参数：
        1. 多样性趋势分析 - 防止过早收敛
        2. 收敛速度监控 - 确保算法进展
        3. 帕累托前沿质量评估 - 提升解的数量和质量
        4. 停滞检测和响应 - 跳出局部最优
        """
        try:
            if len(self.performance_history) < 2:
                return
            
            # 获取性能历史数据
            recent_performance = self.performance_history[-self.config.performance_window:]
            
            # === 多样性趋势分析 ===
            diversity_values = [p['diversity'] for p in recent_performance if p['diversity'] > 0]
            if len(diversity_values) >= 3:
                # 计算多样性变化趋势
                recent_diversity = np.mean(diversity_values[-3:])
                baseline_diversity = np.mean(diversity_values[:3]) if len(diversity_values) >= 6 else recent_diversity
                diversity_ratio = recent_diversity / (baseline_diversity + 1e-8)
                
                # 计算多样性变化率
                diversity_slope = np.polyfit(range(len(diversity_values)), diversity_values, 1)[0]
            else:
                diversity_ratio = 1.0
                diversity_slope = 0.0
            
            # === 收敛趋势分析 ===
            pareto_sizes = [p['pareto_front_size'] for p in recent_performance]
            if len(pareto_sizes) >= 3:
                recent_pareto_size = np.mean(pareto_sizes[-3:])
                baseline_pareto_size = np.mean(pareto_sizes[:3]) if len(pareto_sizes) >= 6 else recent_pareto_size
                pareto_growth = recent_pareto_size - baseline_pareto_size
                
                # 计算帕累托前沿增长率
                pareto_slope = np.polyfit(range(len(pareto_sizes)), pareto_sizes, 1)[0]
            else:
                pareto_growth = 0.0
                pareto_slope = 0.0
            
            # === 拥挤距离分析 ===
            crowding_distances = [p['avg_crowding_distance'] for p in recent_performance 
                                 if p['avg_crowding_distance'] > 0]
            if crowding_distances:
                avg_crowding = np.mean(crowding_distances)
                crowding_trend = np.polyfit(range(len(crowding_distances)), crowding_distances, 1)[0]
            else:
                avg_crowding = 0.0
                crowding_trend = 0.0
            
            # === 智能参数调整策略 ===
            
            # 策略1：多样性危机响应
            if diversity_ratio < 0.7 or diversity_slope < -0.001:
                # 多样性急剧下降，启动紧急多样性保护
                self.current_mutation_prob = min(0.6, self.current_mutation_prob * 1.5)
                self.current_crossover_prob = max(0.3, self.current_crossover_prob * 0.7)
                logger.info(f"🚨 多样性危机响应：变异概率提升至{self.current_mutation_prob:.3f}")
                
            elif diversity_ratio < 0.85:
                # 多样性下降，增强探索
                self.current_mutation_prob = min(0.45, self.current_mutation_prob * 1.25)
                self.current_crossover_prob = max(0.5, self.current_crossover_prob * 0.85)
                logger.debug(f"多样性下降，增强探索：变异={self.current_mutation_prob:.3f}")
                
            # 策略2：收敛停滞响应
            elif pareto_growth <= 0 and pareto_slope <= 0:
                # 帕累托前沿停止增长，可能陷入局部最优
                self.current_mutation_prob = min(0.5, self.current_mutation_prob * 1.3)
                self.current_crossover_prob = max(0.4, self.current_crossover_prob * 0.8)
                logger.info(f"🔄 收敛停滞响应：增加变异强度至{self.current_mutation_prob:.3f}")
                
            # 策略3：拥挤距离优化
            elif avg_crowding < 0.1 or crowding_trend < 0:
                # 个体过于拥挤，需要增加分散性
                self.current_mutation_prob = min(0.4, self.current_mutation_prob * 1.2)
                logger.debug(f"拥挤距离优化：变异概率调整至{self.current_mutation_prob:.3f}")
                
            # 策略4：平衡调整
            elif diversity_ratio > 1.3 and pareto_growth > 2:
                # 多样性和收敛都很好，可以适度减少变异
                self.current_mutation_prob = max(0.12, self.current_mutation_prob * 0.95)
                self.current_crossover_prob = min(0.95, self.current_crossover_prob * 1.02)
                logger.debug(f"平衡调整：变异={self.current_mutation_prob:.3f}, 交叉={self.current_crossover_prob:.3f}")
            
            # === 动态边界控制 ===
            # 根据算法进展动态调整参数边界
            progress_ratio = len(self.performance_history) / 200  # 假设最大200代
            
            # 早期：高变异，低交叉（探索为主）
            if progress_ratio < 0.3:
                min_mutation = 0.15
                max_mutation = 0.6
                min_crossover = 0.3
                max_crossover = 0.8
            # 中期：平衡探索和开发
            elif progress_ratio < 0.7:
                min_mutation = 0.1
                max_mutation = 0.45
                min_crossover = 0.5
                max_crossover = 0.9
            # 后期：精细调整（开发为主）
            else:
                min_mutation = 0.08
                max_mutation = 0.3
                min_crossover = 0.6
                max_crossover = 0.95
            
            # 应用边界约束
            self.current_mutation_prob = np.clip(self.current_mutation_prob, min_mutation, max_mutation)
            self.current_crossover_prob = np.clip(self.current_crossover_prob, min_crossover, max_crossover)
            
            # === 特殊情况处理 ===
            # 如果连续多代无改进，启动激进模式
            if len(recent_performance) >= 5:
                recent_improvements = []
                for i in range(1, min(6, len(recent_performance))):
                    current_size = recent_performance[-i]['pareto_front_size']
                    previous_size = recent_performance[-i-1]['pareto_front_size'] if i < len(recent_performance) else current_size
                    improvement = current_size - previous_size
                    recent_improvements.append(improvement)
                
                if all(imp <= 0 for imp in recent_improvements):
                    # 连续无改进，启动激进探索模式
                    self.current_mutation_prob = min(0.7, self.current_mutation_prob * 1.8)
                    self.current_crossover_prob = max(0.2, self.current_crossover_prob * 0.6)
                    logger.warning(f"🔥 激进探索模式：变异概率={self.current_mutation_prob:.3f}")
            
            # 记录调整信息
            logger.debug(f"参数自适应调整完成 - 多样性比率:{diversity_ratio:.3f}, "
                        f"帕累托增长:{pareto_growth:.1f}, 变异概率:{self.current_mutation_prob:.3f}, "
                        f"交叉概率:{self.current_crossover_prob:.3f}")
            
        except Exception as e:
            logger.warning(f"参数自适应调整失败: {str(e)}")
            # 失败时使用保守的默认值
            self.current_mutation_prob = max(0.15, self.current_mutation_prob)
            self.current_crossover_prob = min(0.85, self.current_crossover_prob)
    
    def get_current_parameters(self) -> Dict[str, float]:
        """获取当前参数"""
        return {
            'crossover_probability': self.current_crossover_prob,
            'mutation_probability': self.current_mutation_prob
        }


class GeneticOperatorManager:
    """遗传算子管理器"""
    
    def __init__(self, config: Optional[GeneticOperatorConfig] = None):
        """
        初始化遗传算子管理器
        
        Args:
            config: 遗传算子配置
        """
        self.config = config or GeneticOperatorConfig()
        
        # 初始化算子
        self.crossover_operator = self._create_crossover_operator()
        self.mutation_operator = self._create_mutation_operator()
        self.selection_operator = self._create_selection_operator()
        
        # 初始化自适应控制器
        self.adaptive_controller = AdaptiveParameterController(self.config)
        
        logger.info(f"遗传算子管理器初始化完成: "
                   f"交叉={self.config.crossover_type}, "
                   f"变异={self.config.mutation_type}, "
                   f"选择={self.config.selection_type}")
    
    def _create_crossover_operator(self) -> CrossoverOperator:
        """创建交叉算子"""
        if self.config.crossover_type == "simulated_binary":
            return SimulatedBinaryCrossover(self.config.crossover_eta)
        elif self.config.crossover_type == "uniform":
            return UniformCrossover()
        else:
            logger.warning(f"未知交叉类型: {self.config.crossover_type}，使用默认SBX")
            return SimulatedBinaryCrossover(self.config.crossover_eta)
    
    def _create_mutation_operator(self) -> MutationOperator:
        """创建变异算子"""
        if self.config.mutation_type == "polynomial":
            return PolynomialMutation(self.config.mutation_eta, self.config.mutation_probability)
        elif self.config.mutation_type == "gaussian":
            return GaussianMutation(mutation_probability=self.config.mutation_probability)
        elif self.config.mutation_type == "adaptive":
            return AdaptiveMutation(self.config.mutation_probability)
        else:
            logger.warning(f"未知变异类型: {self.config.mutation_type}，使用自适应变异")
            return AdaptiveMutation(self.config.mutation_probability)
    
    def _create_selection_operator(self) -> SelectionOperator:
        """创建选择算子"""
        if self.config.selection_type == "tournament":
            return TournamentSelection(self.config.tournament_size)
        elif self.config.selection_type == "roulette":
            return RouletteWheelSelection()
        else:
            logger.warning(f"未知选择类型: {self.config.selection_type}，使用默认锦标赛选择")
            return TournamentSelection(self.config.tournament_size)
    
    def crossover(self, parent1: Individual, parent2: Individual, 
                 facade_data: FacadeData) -> Tuple[Individual, Individual]:
        """执行交叉操作"""
        current_params = self.adaptive_controller.get_current_parameters()
        
        if random.random() < current_params['crossover_probability']:
            return self.crossover_operator.crossover(parent1, parent2, facade_data)
        else:
            return parent1.copy(), parent2.copy()
    
    def mutate(self, individual: Individual, facade_data: FacadeData) -> Individual:
        """执行变异操作"""
        current_params = self.adaptive_controller.get_current_parameters()
        
        # 临时更新变异算子的概率
        if hasattr(self.mutation_operator, 'mutation_probability'):
            original_prob = self.mutation_operator.mutation_probability
            self.mutation_operator.mutation_probability = current_params['mutation_probability']
            
            result = self.mutation_operator.mutate(individual, facade_data)
            
            # 恢复原始概率
            self.mutation_operator.mutation_probability = original_prob
            return result
        else:
            return self.mutation_operator.mutate(individual, facade_data)
    
    def select(self, population: List[Individual], num_parents: int) -> List[Individual]:
        """执行选择操作"""
        return self.selection_operator.select(population, num_parents)
    
    def update_adaptive_parameters(self, generation: int, population: List[Individual]):
        """更新自适应参数"""
        self.adaptive_controller.update_parameters(generation, population)
        
        # 如果使用自适应变异，更新代数信息
        if isinstance(self.mutation_operator, AdaptiveMutation):
            self.mutation_operator.set_generation_info(generation, 200)  # 假设最大代数为200
    
    def get_operator_statistics(self) -> Dict[str, Any]:
        """获取算子统计信息"""
        current_params = self.adaptive_controller.get_current_parameters()
        
        return {
            'crossover_type': self.config.crossover_type,
            'mutation_type': self.config.mutation_type,
            'selection_type': self.config.selection_type,
            'current_crossover_prob': current_params['crossover_probability'],
            'current_mutation_prob': current_params['mutation_probability'],
            'adaptive_enabled': self.config.adaptive_enabled,
            'performance_history_length': len(self.adaptive_controller.performance_history)
        }


def create_genetic_operator_manager(config: Optional[GeneticOperatorConfig] = None) -> GeneticOperatorManager:
    """
    创建遗传算子管理器实例
    
    Args:
        config: 遗传算子配置
        
    Returns:
        遗传算子管理器实例
    """
    return GeneticOperatorManager(config)
