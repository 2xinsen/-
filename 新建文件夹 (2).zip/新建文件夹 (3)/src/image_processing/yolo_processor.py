
"""
YOLO分割结果处理器
负责解析YOLO分割后的色块图片，识别不同颜色区域对应的建筑元素
"""

import cv2
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from pathlib import Path

from ..core.config import config_manager
from ..core.logging_config import get_logger, LogContext
from ..core.exceptions import YOLOSegmentationError, ImageProcessingError
from ..core.data_structures import BuildingElement
from ..core.utils import FileUtils, ValidationUtils

# 获取日志记录器
logger = get_logger(__name__)


class YOLOSegmentationProcessor:
    """
    YOLO分割结果处理器
    
    功能：
    1. 解析YOLO分割后的色块图片
    2. 识别不同颜色区域对应的建筑元素
    3. 提取像素区域数据
    4. 进行图像预处理和噪声过滤
    """
    
    def __init__(self):
        """初始化YOLO分割处理器"""
        # 获取配置
        self.config = config_manager.get_image_processing_config()
        
        # 颜色映射配置
        self.color_mapping = self.config.color_mapping
        
        # 颜色匹配策略配置 - 从config_manager直接获取
        color_matching_config = config_manager.get('image_processing.color_matching', {})
        self.matching_strategy = color_matching_config.get('strategy', 'exact')
        self.color_tolerance = color_matching_config.get('tolerance', 15)
        self.use_hsv = color_matching_config.get('use_hsv', False)
        
        # 预处理参数
        self.preprocessing_config = self.config.preprocessing
        self.noise_filter_kernel = self.preprocessing_config.get('noise_filter_kernel', 3)
        self.min_contour_area = self.preprocessing_config.get('min_contour_area', 100)
        self.max_contour_area = self.preprocessing_config.get('max_contour_area', 50000)
        
        logger.info("YOLO分割处理器初始化完成")
    
    def process_image(self, image_path: str) -> Dict[str, List[Dict[str, Any]]]:
        """
        处理YOLO分割图像
        
        Args:
            image_path: 图像文件路径
            
        Returns:
            按元素类型分组的像素区域数据
            
        Raises:
            YOLOSegmentationError: 图像处理失败时抛出
        """
        with LogContext("YOLO分割图像处理", logger):
            try:
                # 验证输入
                if not ValidationUtils.validate_file_exists(image_path):
                    raise YOLOSegmentationError(f"图像文件不存在: {image_path}")
                
                if not FileUtils.is_image_file(image_path):
                    raise YOLOSegmentationError(f"不支持的图像格式: {image_path}")
                
                # 加载图像
                image = self._load_image(image_path)
                logger.info(f"成功加载图像: {image_path}, 尺寸: {image.shape}")
                
                # 图像预处理
                processed_image = self._preprocess_image(image)
                
                # 颜色区域识别
                color_regions = self._identify_color_regions(processed_image)
                
                # 提取建筑元素
                building_elements = self._extract_building_elements(color_regions, image.shape)
                
                logger.info(f"成功处理图像，提取到 {sum(len(elements) for elements in building_elements.values())} 个建筑元素")
                
                return building_elements
                
            except Exception as e:
                error_msg = f"YOLO分割图像处理失败: {str(e)}"
                logger.error(error_msg)
                raise YOLOSegmentationError(error_msg) from e
    
    def _load_image(self, image_path: str) -> np.ndarray:
        """
        加载图像文件
        
        Args:
            image_path: 图像文件路径
            
        Returns:
            图像数组 (BGR格式)
        """
        try:
            # 支持中文路径的图像加载方法
            # 使用numpy读取文件，然后用cv2解码
            with open(image_path, 'rb') as f:
                image_data = f.read()
            
            # 将字节数据转换为numpy数组
            nparr = np.frombuffer(image_data, np.uint8)
            
            # 使用cv2解码图像
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if image is None:
                raise YOLOSegmentationError(f"无法解码图像文件: {image_path}")
            
            return image
            
        except FileNotFoundError:
            raise YOLOSegmentationError(f"图像文件不存在: {image_path}")
        except PermissionError:
            raise YOLOSegmentationError(f"没有权限访问图像文件: {image_path}")
        except Exception as e:
            raise YOLOSegmentationError(f"图像加载失败: {str(e)}") from e
    
    def _preprocess_image(self, image: np.ndarray) -> np.ndarray:
        """
        图像预处理
        
        Args:
            image: 原始图像
            
        Returns:
            预处理后的图像
        """
        try:
            # 复制图像以避免修改原始数据
            processed = image.copy()
            
            # 噪声过滤 - 使用中值滤波去除椒盐噪声
            if self.noise_filter_kernel > 1:
                processed = cv2.medianBlur(processed, self.noise_filter_kernel)
                logger.debug(f"应用中值滤波，核大小: {self.noise_filter_kernel}")
            
            # 可选：高斯模糊进一步平滑
            # processed = cv2.GaussianBlur(processed, (3, 3), 0)
            
            return processed
            
        except Exception as e:
            raise YOLOSegmentationError(f"图像预处理失败: {str(e)}") from e
    
    def _identify_color_regions(self, image: np.ndarray) -> Dict[str, np.ndarray]:
        """
        识别不同颜色区域（改进墙体检测）
        
        Args:
            image: 预处理后的图像
            
        Returns:
            按元素类型分组的二值掩码
        """
        try:
            color_regions = {}
            
            logger.info(f"开始识别颜色区域，图像形状: {image.shape}")
            
            # 遍历每种建筑元素类型
            for element_type, color_config in self.color_mapping.items():
                if element_type == 'background':
                    logger.debug("跳过背景颜色检测")
                    continue  # 跳过背景
                
                logger.info(f"处理元素类型: {element_type}, 颜色配置: {color_config}")
                
                # 创建颜色掩码
                mask = self._create_color_mask_with_strategy(image, color_config, element_type)
                
                mask_sum = np.sum(mask > 0)
                logger.info(f"{element_type} 掩码非零像素数: {mask_sum}")
                
                if mask_sum > 0:
                    color_regions[element_type] = mask
                    logger.debug(f"检测到 {element_type}: {mask_sum} 个像素")
                else:
                    logger.debug(f"未检测到 {element_type}")
            
            # 特殊处理：如果没有检测到墙体，尝试智能墙体检测
            if 'walls' not in color_regions:
                logger.warning("未检测到墙体，尝试智能墙体检测")
                wall_mask = self._intelligent_wall_detection(image, color_regions)
                if wall_mask is not None and np.sum(wall_mask > 0) > 0:
                    color_regions['walls'] = wall_mask
                    logger.info(f"智能墙体检测成功，检测到 {np.sum(wall_mask > 0)} 个墙体像素")
            
            logger.info(f"总共识别到 {len(color_regions)} 种元素类型")
            return color_regions
            
        except Exception as e:
            raise YOLOSegmentationError(f"颜色区域识别失败: {str(e)}") from e
    
    def _create_color_mask_with_strategy(self, image: np.ndarray, color_config: Any, 
                                       element_type: str) -> np.ndarray:
        """
        根据配置策略创建颜色掩码
        
        Args:
            image: 输入图像
            color_config: 颜色配置（可能是精确值或范围）
            element_type: 元素类型
            
        Returns:
            二值掩码
        """
        try:
            if self.matching_strategy == 'range' and isinstance(color_config, dict):
                # 范围匹配策略
                mask = self._create_range_color_mask(image, color_config)
                logger.debug(f"{element_type} 掩码非零像素数: {np.sum(mask > 0)}")
                return mask
            else:
                # 兼容旧的精确匹配策略
                if isinstance(color_config, list) and len(color_config) == 3:
                    # 转换颜色格式 (RGB -> BGR for OpenCV)
                    bgr_color = [color_config[2], color_config[1], color_config[0]]
                    mask = self._create_exact_color_mask(image, bgr_color, self.color_tolerance)
                    logger.debug(f"{element_type} 掩码非零像素数: {np.sum(mask > 0)}")
                    return mask
                else:
                    logger.warning(f"无效的颜色配置格式: {element_type}")
                    return np.zeros(image.shape[:2], dtype=np.uint8)
            
        except Exception as e:
            raise YOLOSegmentationError(f"颜色掩码创建失败: {str(e)}") from e
    
    def _create_range_color_mask(self, image: np.ndarray, color_config: Dict) -> np.ndarray:
        """
        创建范围颜色掩码
        
        Args:
            image: 输入图像
            color_config: 包含min和max的颜色范围配置
            
        Returns:
            二值掩码
        """
        try:
            min_rgb = color_config.get('min', [0, 0, 0])
            max_rgb = color_config.get('max', [255, 255, 255])
            
            # 转换为BGR格式（输入配置是RGB，图像处理需要BGR）
            lower_bound = np.array([min_rgb[2], min_rgb[1], min_rgb[0]], dtype=np.uint8)
            upper_bound = np.array([max_rgb[2], max_rgb[1], max_rgb[0]], dtype=np.uint8)
            
            logger.debug(f"创建颜色掩码: 类型=range, 下限={lower_bound}, 上限={upper_bound}")
            
            # 创建掩码
            mask = cv2.inRange(image, lower_bound, upper_bound)
            
            # 如果掩码为空，尝试更宽松的匹配
            if np.sum(mask) == 0:
                # 扩大颜色范围尝试检测
                expanded_min = np.maximum(lower_bound - 10, [0, 0, 0])
                expanded_max = np.minimum(upper_bound + 10, [255, 255, 255])
                mask = cv2.inRange(image, expanded_min, expanded_max)
                if np.sum(mask) > 0:
                    logger.debug(f"使用扩展范围检测到元素: {expanded_min} - {expanded_max}")
            
            logger.debug(f"掩码非零像素数: {np.sum(mask > 0)}")
            
            # 形态学操作去除小噪声
            kernel = np.ones((3, 3), np.uint8)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)  # 开运算去除噪声
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)  # 闭运算填充空洞
            
            return mask
            
        except Exception as e:
            raise YOLOSegmentationError(f"范围颜色掩码创建失败: {str(e)}") from e
    
    def _create_exact_color_mask(self, image: np.ndarray, target_color: List[int], 
                                tolerance: int = 10) -> np.ndarray:
        """
        创建精确颜色掩码（兼容旧配置）
        
        Args:
            image: 输入图像
            target_color: 目标颜色 [B, G, R]
            tolerance: 颜色容差
            
        Returns:
            二值掩码
        """
        try:
            # 定义颜色范围
            lower_bound = np.array([max(0, c - tolerance) for c in target_color])
            upper_bound = np.array([min(255, c + tolerance) for c in target_color])
            
            # 创建掩码
            mask = cv2.inRange(image, lower_bound, upper_bound)
            
            # 形态学操作去除小噪声
            kernel = np.ones((3, 3), np.uint8)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)  # 开运算去除噪声
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)  # 闭运算填充空洞
            
            return mask
            
        except Exception as e:
            raise YOLOSegmentationError(f"精确颜色掩码创建失败: {str(e)}") from e
    
    def _extract_building_elements(self, color_regions: Dict[str, np.ndarray], 
                                 image_shape: Tuple[int, int, int]) -> Dict[str, List[Dict[str, Any]]]:
        """
        从颜色区域提取建筑元素
        
        Args:
            color_regions: 颜色区域掩码字典
            image_shape: 图像形状 (height, width, channels)
            
        Returns:
            按元素类型分组的建筑元素数据
        """
        try:
            building_elements = {}
            
            for element_type, mask in color_regions.items():
                elements = self._extract_elements_from_mask(mask, element_type)
                
                if elements:
                    building_elements[element_type] = elements
                    logger.debug(f"从 {element_type} 掩码中提取到 {len(elements)} 个元素")
            
            return building_elements
            
        except Exception as e:
            raise YOLOSegmentationError(f"建筑元素提取失败: {str(e)}") from e
    
    def _extract_elements_from_mask(self, mask: np.ndarray, element_type: str) -> List[Dict[str, Any]]:
        """
        从单个掩码中提取元素
        
        Args:
            mask: 二值掩码
            element_type: 元素类型
            
        Returns:
            元素数据列表
        """
        try:
            elements = []
            
            # 查找轮廓
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            for i, contour in enumerate(contours):
                # 计算轮廓面积
                area = cv2.contourArea(contour)
                
                # 动态调整面积限制：墙体可以更大
                if element_type == 'walls':
                    min_area = max(self.min_contour_area, 1000)  # 墙体最小1000像素
                    max_area = self.max_contour_area * 10        # 墙体可以是其他元素的10倍大
                else:
                    min_area = self.min_contour_area
                    max_area = self.max_contour_area
                
                # 过滤太小或太大的轮廓
                if area < min_area or area > max_area:
                    logger.debug(f"跳过{element_type}轮廓: 面积{area}, 范围[{min_area}, {max_area}]")
                    continue
                
                # 计算边界框
                x, y, w, h = cv2.boundingRect(contour)
                
                # 计算轮廓的其他几何属性
                moments = cv2.moments(contour)
                if moments['m00'] != 0:
                    cx = int(moments['m10'] / moments['m00'])  # 质心x坐标
                    cy = int(moments['m01'] / moments['m00'])  # 质心y坐标
                else:
                    cx, cy = x + w // 2, y + h // 2
                
                # 计算周长
                perimeter = cv2.arcLength(contour, True)
                
                # 创建元素数据
                element_data = {
                    'element_id': f"{element_type}_{i}",
                    'element_type': element_type,
                    'bbox': (x, y, x + w, y + h),  # (x_min, y_min, x_max, y_max)
                    'center': (cx, cy),
                    'area': float(area),
                    'perimeter': float(perimeter),
                    'width': w,
                    'height': h,
                    'contour': contour.tolist(),  # 转换为列表以便序列化
                    'aspect_ratio': w / h if h > 0 else 0.0,
                    'extent': area / (w * h) if (w * h) > 0 else 0.0,  # 轮廓面积与边界框面积的比值
                    'solidity': area / cv2.contourArea(cv2.convexHull(contour)) if cv2.contourArea(cv2.convexHull(contour)) > 0 else 0.0
                }
                
                elements.append(element_data)
            
            return elements
            
        except Exception as e:
            raise YOLOSegmentationError(f"从掩码提取元素失败: {str(e)}") from e
    
    def validate_segmentation_result(self, elements: Dict[str, List[Dict[str, Any]]]) -> bool:
        """
        验证分割结果的合理性
        
        Args:
            elements: 提取的建筑元素
            
        Returns:
            True如果结果合理
        """
        try:
            # 检查是否至少有墙体或窗户
            has_walls = 'walls' in elements and len(elements['walls']) > 0
            has_windows = 'windows' in elements and len(elements['windows']) > 0
            
            if not (has_walls or has_windows):
                logger.warning("分割结果中既没有墙体也没有窗户，可能存在问题")
                return False
            
            # 检查元素数量是否合理
            total_elements = sum(len(element_list) for element_list in elements.values())
            if total_elements > 1000:  # 设置一个合理的上限
                logger.warning(f"检测到的元素数量过多: {total_elements}，可能存在过度分割")
                return False
            
            # 检查窗墙比是否合理（如果同时有窗户和墙体）
            if has_walls and has_windows:
                window_area = sum(elem['area'] for elem in elements['windows'])
                wall_area = sum(elem['area'] for elem in elements['walls'])
                
                if wall_area > 0:
                    window_wall_ratio = window_area / wall_area
                    if window_wall_ratio > 1.0:  # 窗墙比不应该超过1
                        logger.warning(f"窗墙比异常: {window_wall_ratio:.2f}")
                        return False
            
            logger.info("分割结果验证通过")
            return True
            
        except Exception as e:
            logger.error(f"分割结果验证失败: {str(e)}")
            return False
    
    def get_processing_statistics(self, elements: Dict[str, List[Dict[str, Any]]]) -> Dict[str, Any]:
        """
        获取处理统计信息
        
        Args:
            elements: 提取的建筑元素
            
        Returns:
            统计信息字典
        """
        try:
            stats = {
                'total_elements': sum(len(element_list) for element_list in elements.values()),
                'element_counts': {element_type: len(element_list) 
                                 for element_type, element_list in elements.items()},
                'total_areas': {},
                'average_areas': {},
                'size_ranges': {}
            }
            
            # 计算各类型元素的面积统计
            for element_type, element_list in elements.items():
                if element_list:
                    areas = [elem['area'] for elem in element_list]
                    stats['total_areas'][element_type] = sum(areas)
                    stats['average_areas'][element_type] = np.mean(areas)
                    stats['size_ranges'][element_type] = {
                        'min_area': min(areas),
                        'max_area': max(areas),
                        'std_area': np.std(areas)
                    }
            
            return stats
            
        except Exception as e:
            logger.error(f"统计信息计算失败: {str(e)}")
            return {}
    
    def save_debug_images(self, image_path: str, elements: Dict[str, List[Dict[str, Any]]], 
                         output_dir: str = "outputs/debug") -> None:
        """
        保存调试图像，用于可视化分割结果
        
        Args:
            image_path: 原始图像路径
            elements: 提取的建筑元素
            output_dir: 输出目录
        """
        try:
            # 确保输出目录存在
            output_path = Path(output_dir)
            FileUtils.ensure_directory(output_path)
            
            # 加载原始图像（支持中文路径）
            original_image = self._load_image(image_path)
            if original_image is None:
                return
            
            # 创建标注图像
            annotated_image = original_image.copy()
            
            # 定义颜色（BGR格式）
            colors = {
                'windows': (255, 0, 0),    # 蓝色
                'doors': (0, 255, 0),      # 绿色
                'shading': (0, 0, 255),    # 红色
                'walls': (128, 128, 128)   # 灰色
            }
            
            # 绘制检测到的元素
            for element_type, element_list in elements.items():
                color = colors.get(element_type, (255, 255, 255))
                
                for element in element_list:
                    # 绘制边界框
                    x1, y1, x2, y2 = element['bbox']
                    cv2.rectangle(annotated_image, (x1, y1), (x2, y2), color, 2)
                    
                    # 绘制中心点
                    cx, cy = element['center']
                    cv2.circle(annotated_image, (cx, cy), 3, color, -1)
                    
                    # 添加标签
                    label = f"{element_type}_{element['element_id'].split('_')[-1]}"
                    cv2.putText(annotated_image, label, (x1, y1 - 10), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
            
            # 保存标注图像（支持中文路径）
            output_file = output_path / f"annotated_{Path(image_path).name}"
            
            # 使用cv2.imencode来支持中文路径
            success, encoded_img = cv2.imencode('.png', annotated_image)
            if success:
                with open(str(output_file), 'wb') as f:
                    f.write(encoded_img.tobytes())
            else:
                logger.error(f"图像编码失败: {output_file}")
            
            logger.info(f"调试图像已保存: {output_file}")
            
        except Exception as e:
            logger.error(f"保存调试图像失败: {str(e)}")
    
    def _intelligent_wall_detection(self, image: np.ndarray, 
                                   existing_regions: Dict[str, np.ndarray]) -> Optional[np.ndarray]:
        """
        智能墙体检测：当常规颜色检测失败时的备用方案
        
        Args:
            image: 输入图像
            existing_regions: 已检测到的其他区域
            
        Returns:
            墙体掩码或None
        """
        try:
            logger.info("开始智能墙体检测")
            
            # 策略1：基于非窗户区域检测墙体
            wall_mask = np.ones(image.shape[:2], dtype=np.uint8) * 255
            
            # 排除已检测到的窗户、门等区域
            for region_type, mask in existing_regions.items():
                if region_type in ['windows', 'doors', 'shading']:
                    wall_mask = cv2.bitwise_and(wall_mask, cv2.bitwise_not(mask))
            
            # 策略2：扩大墙体颜色检测范围
            expanded_wall_ranges = [
                # 原始灰色范围
                {'min': [100, 100, 100], 'max': [150, 150, 150]},
                # 扩大的灰色范围
                {'min': [80, 80, 80], 'max': [180, 180, 180]},
                # 更宽的灰色范围
                {'min': [60, 60, 60], 'max': [200, 200, 200]},
                # 白色到浅灰色
                {'min': [180, 180, 180], 'max': [255, 255, 255]},
                # 深灰色到中灰色
                {'min': [40, 40, 40], 'max': [120, 120, 120]}
            ]
            
            combined_wall_mask = np.zeros(image.shape[:2], dtype=np.uint8)
            
            for color_range in expanded_wall_ranges:
                range_mask = self._create_range_color_mask(image, color_range)
                combined_wall_mask = cv2.bitwise_or(combined_wall_mask, range_mask)
            
            # 策略3：基于边缘检测的墙体识别
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            edges = cv2.Canny(gray, 50, 150)
            
            # 膨胀边缘以形成区域
            kernel = np.ones((5, 5), np.uint8)
            edge_regions = cv2.dilate(edges, kernel, iterations=2)
            
            # 结合颜色和边缘信息
            wall_mask = cv2.bitwise_and(wall_mask, combined_wall_mask)
            wall_mask = cv2.bitwise_or(wall_mask, edge_regions)
            
            # 策略4：形态学操作优化
            # 去除小噪声
            kernel = np.ones((3, 3), np.uint8)
            wall_mask = cv2.morphologyEx(wall_mask, cv2.MORPH_OPEN, kernel)
            
            # 填充空洞
            kernel = np.ones((7, 7), np.uint8)
            wall_mask = cv2.morphologyEx(wall_mask, cv2.MORPH_CLOSE, kernel)
            
            # 策略5：基于图像统计的墙体检测
            # 如果仍然没有足够的墙体像素，使用统计方法
            wall_pixels = np.sum(wall_mask > 0)
            total_pixels = image.shape[0] * image.shape[1]
            wall_ratio = wall_pixels / total_pixels
            
            if wall_ratio < 0.1:  # 如果墙体像素太少
                logger.warning(f"墙体像素比例过低 ({wall_ratio:.3f})，使用统计方法")
                
                # 计算图像的主要颜色
                pixels = image.reshape(-1, 3)
                
                # 排除已知的窗户区域像素
                mask_combined = np.zeros(image.shape[:2], dtype=np.uint8)
                for region_type, mask in existing_regions.items():
                    if region_type in ['windows', 'doors']:
                        mask_combined = cv2.bitwise_or(mask_combined, mask)
                
                # 获取非窗户区域的像素
                non_window_mask = cv2.bitwise_not(mask_combined)
                non_window_pixels = image[non_window_mask > 0]
                
                if len(non_window_pixels) > 0:
                    # 使用K-means聚类找到主要颜色
                    from sklearn.cluster import KMeans
                    
                    # 简化像素数据以提高速度
                    sample_size = min(10000, len(non_window_pixels))
                    sample_pixels = non_window_pixels[np.random.choice(len(non_window_pixels), sample_size, replace=False)]
                    
                    kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
                    kmeans.fit(sample_pixels)
                    
                    # 找到最大的聚类作为墙体颜色
                    labels = kmeans.predict(pixels)
                    cluster_counts = np.bincount(labels)
                    main_cluster = np.argmax(cluster_counts)
                    main_color = kmeans.cluster_centers_[main_cluster]
                    
                    # 基于主要颜色创建墙体掩码
                    color_diff = np.linalg.norm(pixels - main_color, axis=1)
                    wall_pixels_mask = color_diff < 50  # 颜色距离阈值
                    
                    wall_mask = wall_pixels_mask.reshape(image.shape[:2]).astype(np.uint8) * 255
                    
                    logger.info(f"基于统计方法检测到墙体，主要颜色: {main_color}")
            
            # 最终验证
            final_wall_pixels = np.sum(wall_mask > 0)
            if final_wall_pixels > 1000:  # 至少要有1000个像素
                logger.info(f"智能墙体检测成功，检测到 {final_wall_pixels} 个墙体像素")
                return wall_mask
            else:
                logger.warning("智能墙体检测失败，墙体像素数量不足")
                return None
                
        except Exception as e:
            logger.error(f"智能墙体检测失败: {str(e)}")
            return None


def create_yolo_processor() -> YOLOSegmentationProcessor:
    """
    创建YOLO分割处理器实例
    
    Returns:
        配置好的处理器实例
    """
    return YOLOSegmentationProcessor()
