
"""
建筑元素提取器
负责从像素数据中提取建筑元素的几何信息
"""

import cv2
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from scipy import ndimage
from sklearn.cluster import DBSCAN

from ..core.config import config_manager
from ..core.logging_config import get_logger, LogContext
from ..core.exceptions import BuildingElementExtractionError, ImageProcessingError
from ..core.data_structures import BuildingElement
from ..core.utils import GeometryUtils, ValidationUtils

# 获取日志记录器
logger = get_logger(__name__)


class BuildingElementExtractor:
    """
    建筑元素提取器
    
    功能：
    1. 使用连通域分析提取独立建筑元素
    2. 实现轮廓检测和形状拟合算法
    3. 添加元素分类和属性计算功能
    4. 处理复杂形状和重叠元素
    """
    
    def __init__(self):
        """初始化建筑元素提取器"""
        # 获取配置
        self.config = config_manager.get_image_processing_config()
        self.constraints = self.config.constraints
        
        # 提取参数
        self.min_element_area = 50  # 最小元素面积（像素）
        self.max_element_area = 100000  # 最大元素面积（像素）
        self.shape_approximation_epsilon = 0.02  # 形状近似精度
        self.clustering_eps = 10  # 聚类距离阈值
        self.clustering_min_samples = 2  # 聚类最小样本数
        
        logger.info("建筑元素提取器初始化完成")
    
    def extract_elements(self, yolo_results: Dict[str, List[Dict[str, Any]]], 
                        image_shape: Tuple[int, int]) -> List[BuildingElement]:
        """
        从YOLO分割结果中提取建筑元素
        
        Args:
            yolo_results: YOLO处理器的输出结果
            image_shape: 图像形状 (height, width)
            
        Returns:
            建筑元素列表
            
        Raises:
            BuildingElementExtractionError: 提取失败时抛出
        """
        with LogContext("建筑元素提取", logger):
            try:
                building_elements = []
                
                # 处理每种类型的元素
                for element_type, element_data_list in yolo_results.items():
                    logger.info(f"处理 {element_type} 类型元素，数量: {len(element_data_list)}")
                    
                    # 提取该类型的所有元素
                    type_elements = self._extract_elements_by_type(
                        element_data_list, element_type, image_shape
                    )
                    
                    building_elements.extend(type_elements)
                    logger.debug(f"成功提取 {len(type_elements)} 个 {element_type} 元素")
                
                # 后处理：合并相似元素、过滤异常元素
                building_elements = self._post_process_elements(building_elements)
                
                logger.info(f"建筑元素提取完成，总计: {len(building_elements)} 个元素")
                return building_elements
                
            except Exception as e:
                error_msg = f"建筑元素提取失败: {str(e)}"
                logger.error(error_msg)
                raise BuildingElementExtractionError(error_msg) from e
    
    def _extract_elements_by_type(self, element_data_list: List[Dict[str, Any]], 
                                 element_type: str, image_shape: Tuple[int, int]) -> List[BuildingElement]:
        """
        提取特定类型的建筑元素
        
        Args:
            element_data_list: 元素数据列表
            element_type: 元素类型
            image_shape: 图像形状
            
        Returns:
            该类型的建筑元素列表
        """
        try:
            elements = []
            
            for i, element_data in enumerate(element_data_list):
                try:
                    # 创建建筑元素
                    building_element = self._create_building_element(
                        element_data, element_type, i, image_shape
                    )
                    
                    # 验证元素有效性
                    if self._validate_element(building_element, element_type):
                        elements.append(building_element)
                    else:
                        logger.debug(f"元素验证失败，跳过: {element_type}_{i}")
                        
                except Exception as e:
                    logger.warning(f"创建 {element_type} 元素 {i} 失败: {str(e)}")
                    continue
            
            return elements
            
        except Exception as e:
            raise BuildingElementExtractionError(f"提取 {element_type} 元素失败: {str(e)}") from e
    
    def _create_building_element(self, element_data: Dict[str, Any], element_type: str, 
                               index: int, image_shape: Tuple[int, int]) -> BuildingElement:
        """
        创建建筑元素对象
        
        Args:
            element_data: 元素数据
            element_type: 元素类型
            index: 元素索引
            image_shape: 图像形状
            
        Returns:
            建筑元素对象
        """
        try:
            # 提取基本几何信息
            bbox = element_data['bbox']  # (x_min, y_min, x_max, y_max)
            x, y = bbox[0], bbox[1]
            width = bbox[2] - bbox[0]
            height = bbox[3] - bbox[1]
            area = element_data['area']
            
            # 转换轮廓数据
            contour_data = element_data.get('contour')
            contour = np.array(contour_data, dtype=np.int32) if contour_data else None
            
            # 计算额外的几何属性
            properties = self._calculate_element_properties(element_data, element_type, image_shape)
            
            # 创建建筑元素
            building_element = BuildingElement(
                element_type=element_type,
                x=float(x),
                y=float(y),
                width=float(width),
                height=float(height),
                area=float(area),
                bbox=(float(bbox[0]), float(bbox[1]), float(bbox[2]), float(bbox[3])),
                contour=contour,
                properties=properties
            )
            
            return building_element
            
        except Exception as e:
            raise BuildingElementExtractionError(f"创建建筑元素失败: {str(e)}") from e
    
    def _calculate_element_properties(self, element_data: Dict[str, Any], 
                                    element_type: str, image_shape: Tuple[int, int]) -> Dict[str, Any]:
        """
        计算元素的额外属性
        
        Args:
            element_data: 元素数据
            element_type: 元素类型
            image_shape: 图像形状
            
        Returns:
            属性字典
        """
        try:
            properties = {}
            
            # 基本几何属性
            properties['aspect_ratio'] = element_data.get('aspect_ratio', 0.0)
            properties['extent'] = element_data.get('extent', 0.0)
            properties['solidity'] = element_data.get('solidity', 0.0)
            properties['perimeter'] = element_data.get('perimeter', 0.0)
            
            # 位置属性
            center = element_data.get('center', (0, 0))
            properties['center_x'] = center[0]
            properties['center_y'] = center[1]
            
            # 相对位置（归一化到[0,1]）
            height, width = image_shape
            properties['relative_x'] = center[0] / width if width > 0 else 0.0
            properties['relative_y'] = center[1] / height if height > 0 else 0.0
            
            # 形状分类
            properties['shape_category'] = self._classify_shape(element_data)
            
            # 元素特定属性
            if element_type == 'windows':
                properties.update(self._calculate_window_properties(element_data))
            elif element_type == 'doors':
                properties.update(self._calculate_door_properties(element_data))
            elif element_type == 'shading':
                properties.update(self._calculate_shading_properties(element_data))
            elif element_type == 'walls':
                properties.update(self._calculate_wall_properties(element_data))
            
            return properties
            
        except Exception as e:
            logger.warning(f"计算元素属性失败: {str(e)}")
            return {}
    
    def _classify_shape(self, element_data: Dict[str, Any]) -> str:
        """
        分类元素形状
        
        Args:
            element_data: 元素数据
            
        Returns:
            形状类别字符串
        """
        try:
            aspect_ratio = element_data.get('aspect_ratio', 1.0)
            extent = element_data.get('extent', 0.0)
            solidity = element_data.get('solidity', 0.0)
            
            # 基于几何特征分类形状
            if aspect_ratio > 2.0:
                return 'elongated'  # 细长形
            elif aspect_ratio < 0.5:
                return 'wide'  # 宽扁形
            elif 0.8 <= aspect_ratio <= 1.2 and solidity > 0.9:
                return 'square'  # 正方形
            elif 0.6 <= aspect_ratio <= 1.4 and extent > 0.8:
                return 'rectangular'  # 矩形
            elif solidity < 0.7:
                return 'irregular'  # 不规则形
            else:
                return 'regular'  # 规则形
                
        except Exception:
            return 'unknown'
    
    def _calculate_window_properties(self, element_data: Dict[str, Any]) -> Dict[str, Any]:
        """计算窗户特定属性"""
        properties = {}
        
        # 窗户类型推断（基于尺寸比例）
        aspect_ratio = element_data.get('aspect_ratio', 1.0)
        if aspect_ratio > 1.5:
            properties['window_type'] = 'vertical'
        elif aspect_ratio < 0.7:
            properties['window_type'] = 'horizontal'
        else:
            properties['window_type'] = 'square'
        
        # 估算开启方式（基于形状特征）
        solidity = element_data.get('solidity', 1.0)
        if solidity > 0.95:
            properties['opening_type'] = 'fixed'  # 固定窗
        else:
            properties['opening_type'] = 'operable'  # 可开启窗
        
        # 默认材料属性
        properties['material'] = 'glass'
        properties['frame_material'] = 'aluminum'
        properties['u_value'] = 2.5  # W/m²·K，默认传热系数
        
        return properties
    
    def _calculate_door_properties(self, element_data: Dict[str, Any]) -> Dict[str, Any]:
        """计算门特定属性"""
        properties = {}
        
        # 门类型推断
        aspect_ratio = element_data.get('aspect_ratio', 1.0)
        if aspect_ratio > 2.0:
            properties['door_type'] = 'single'
        elif aspect_ratio > 1.0:
            properties['door_type'] = 'standard'
        else:
            properties['door_type'] = 'wide'
        
        # 默认材料属性
        properties['material'] = 'wood'
        properties['u_value'] = 3.0  # W/m²·K
        
        return properties
    
    def _calculate_shading_properties(self, element_data: Dict[str, Any]) -> Dict[str, Any]:
        """计算遮阳特定属性"""
        properties = {}
        
        # 遮阳类型推断
        aspect_ratio = element_data.get('aspect_ratio', 1.0)
        if aspect_ratio > 3.0:
            properties['shading_type'] = 'horizontal_overhang'
        elif aspect_ratio < 0.3:
            properties['shading_type'] = 'vertical_fin'
        else:
            properties['shading_type'] = 'awning'
        
        # 估算遮阳深度（基于面积）
        area = element_data.get('area', 0)
        bbox = element_data.get('bbox', (0, 0, 0, 0))
        width = bbox[2] - bbox[0]
        
        if width > 0:
            estimated_depth = area / width * 0.1  # 简单估算
            properties['estimated_depth'] = max(0.1, min(1.0, estimated_depth))
        else:
            properties['estimated_depth'] = 0.3
        
        # 默认材料属性
        properties['material'] = 'metal'
        properties['solar_transmittance'] = 0.1
        
        return properties
    
    def _calculate_wall_properties(self, element_data: Dict[str, Any]) -> Dict[str, Any]:
        """计算墙体特定属性"""
        properties = {}
        
        # 墙体类型推断
        area = element_data.get('area', 0)
        if area > 10000:  # 大面积
            properties['wall_type'] = 'main_wall'
        elif area > 1000:
            properties['wall_type'] = 'secondary_wall'
        else:
            properties['wall_type'] = 'partition'
        
        # 默认材料属性
        properties['material'] = 'concrete'
        properties['thickness'] = 0.2  # 米
        properties['u_value'] = 0.4  # W/m²·K
        
        return properties
    
    def _validate_element(self, element: BuildingElement, element_type: str) -> bool:
        """
        验证建筑元素的有效性
        
        Args:
            element: 建筑元素
            element_type: 元素类型
            
        Returns:
            是否有效
        """
        try:
            # 检查基本属性
            if element.width <= 0 or element.height <= 0:
                logger.debug(f"元素尺寸无效: {element_type}, 宽度={element.width}, 高度={element.height}")
                return False
                
            if element.area <= 0:
                logger.debug(f"元素面积无效: {element_type}, 面积={element.area}")
                return False
                
            # 对墙体元素使用不同的验证标准
            if element_type == 'walls':
                # 墙体可以较大，放宽面积限制
                if element.area < 100:  # 最小面积可以更小
                    logger.debug(f"墙体面积过小: {element.area}")
                    return False
                return True
            else:
                # 其他元素使用原有验证逻辑
                if element.area < self.min_element_area:
                    logger.debug(f"元素面积过小: {element_type}, 面积={element.area}")
                    return False
                    
                if element.area > self.max_element_area:
                    logger.debug(f"元素面积过大: {element_type}, 面积={element.area}")
                    return False
            
            # 检查宽高比
            aspect_ratio = element.width / element.height if element.height > 0 else float('inf')
            if not (0.01 <= aspect_ratio <= 100):  # 更宽松的宽高比限制
                logger.debug(f"元素宽高比异常: {element_type}, 宽高比={aspect_ratio}")
                # 对墙体放宽宽高比限制
                if element_type != 'walls':
                    return False
            
            return True
            
        except Exception as e:
            logger.warning(f"元素验证出错: {str(e)}")
            return False
    
    def _validate_window(self, element: BuildingElement) -> bool:
        """验证窗户元素"""
        # 检查最小尺寸约束
        min_width = self.constraints.get('min_window_width', 0.5) * 100  # 转换为像素（假设1m=100px）
        min_height = self.constraints.get('min_window_height', 0.8) * 100
        
        return element.width >= min_width and element.height >= min_height
    
    def _validate_door(self, element: BuildingElement) -> bool:
        """验证门元素"""
        # 门通常比窗户高
        return element.height > element.width and element.height > 100  # 至少1米高
    
    def _validate_shading(self, element: BuildingElement) -> bool:
        """验证遮阳元素"""
        # 遮阳元素通常比较细长
        aspect_ratio = element.width / element.height if element.height > 0 else 0
        return aspect_ratio > 0.5  # 不能太窄
    
    def _validate_wall(self, element: BuildingElement) -> bool:
        """验证墙体元素"""
        # 墙体通常面积较大
        return element.area > 1000  # 至少10平方米（假设1m²=100px²）
    
    def _post_process_elements(self, elements: List[BuildingElement]) -> List[BuildingElement]:
        """
        后处理建筑元素
        
        Args:
            elements: 原始元素列表
            
        Returns:
            处理后的元素列表
        """
        try:
            # 按类型分组
            elements_by_type = {}
            for element in elements:
                if element.element_type not in elements_by_type:
                    elements_by_type[element.element_type] = []
                elements_by_type[element.element_type].append(element)
            
            processed_elements = []
            
            # 对每种类型的元素进行后处理
            for element_type, type_elements in elements_by_type.items():
                # 合并重叠或相邻的元素
                merged_elements = self._merge_overlapping_elements(type_elements)
                
                # 过滤异常元素
                filtered_elements = self._filter_outlier_elements(merged_elements)
                
                processed_elements.extend(filtered_elements)
            
            logger.info(f"后处理完成，从 {len(elements)} 个元素处理为 {len(processed_elements)} 个元素")
            return processed_elements
            
        except Exception as e:
            logger.warning(f"元素后处理失败: {str(e)}")
            return elements  # 返回原始元素列表
    
    def _merge_overlapping_elements(self, elements: List[BuildingElement]) -> List[BuildingElement]:
        """
        合并重叠或相邻的元素
        
        Args:
            elements: 同类型元素列表
            
        Returns:
            合并后的元素列表
        """
        try:
            if len(elements) <= 1:
                return elements
            
            merged_elements = []
            used_indices = set()
            
            for i, element1 in enumerate(elements):
                if i in used_indices:
                    continue
                
                # 查找与当前元素重叠的其他元素
                overlapping_elements = [element1]
                used_indices.add(i)
                
                for j, element2 in enumerate(elements[i+1:], i+1):
                    if j in used_indices:
                        continue
                    
                    if self._elements_overlap(element1, element2):
                        overlapping_elements.append(element2)
                        used_indices.add(j)
                
                # 如果有重叠元素，合并它们
                if len(overlapping_elements) > 1:
                    merged_element = self._merge_elements(overlapping_elements)
                    merged_elements.append(merged_element)
                else:
                    merged_elements.append(element1)
            
            return merged_elements
            
        except Exception as e:
            logger.warning(f"合并重叠元素失败: {str(e)}")
            return elements
    
    def _elements_overlap(self, element1: BuildingElement, element2: BuildingElement, 
                         threshold: float = 0.3) -> bool:
        """
        检查两个元素是否重叠
        
        Args:
            element1: 第一个元素
            element2: 第二个元素
            threshold: 重叠阈值
            
        Returns:
            True如果重叠
        """
        try:
            # 计算重叠区域
            x1_min, y1_min, x1_max, y1_max = element1.bbox
            x2_min, y2_min, x2_max, y2_max = element2.bbox
            
            # 计算交集
            x_overlap = max(0, min(x1_max, x2_max) - max(x1_min, x2_min))
            y_overlap = max(0, min(y1_max, y2_max) - max(y1_min, y2_min))
            overlap_area = x_overlap * y_overlap
            
            # 计算重叠比例
            min_area = min(element1.area, element2.area)
            overlap_ratio = overlap_area / min_area if min_area > 0 else 0
            
            return overlap_ratio > threshold
            
        except Exception:
            return False
    
    def _merge_elements(self, elements: List[BuildingElement]) -> BuildingElement:
        """
        合并多个元素为一个元素
        
        Args:
            elements: 要合并的元素列表
            
        Returns:
            合并后的元素
        """
        try:
            if len(elements) == 1:
                return elements[0]
            
            # 计算合并后的边界框
            x_mins = [elem.bbox[0] for elem in elements]
            y_mins = [elem.bbox[1] for elem in elements]
            x_maxs = [elem.bbox[2] for elem in elements]
            y_maxs = [elem.bbox[3] for elem in elements]
            
            merged_bbox = (min(x_mins), min(y_mins), max(x_maxs), max(y_maxs))
            
            # 计算合并后的基本属性
            merged_x = merged_bbox[0]
            merged_y = merged_bbox[1]
            merged_width = merged_bbox[2] - merged_bbox[0]
            merged_height = merged_bbox[3] - merged_bbox[1]
            merged_area = sum(elem.area for elem in elements)
            
            # 合并属性
            merged_properties = {}
            for elem in elements:
                merged_properties.update(elem.properties)
            
            # 创建合并后的元素
            merged_element = BuildingElement(
                element_type=elements[0].element_type,
                x=merged_x,
                y=merged_y,
                width=merged_width,
                height=merged_height,
                area=merged_area,
                bbox=merged_bbox,
                properties=merged_properties
            )
            
            return merged_element
            
        except Exception as e:
            logger.warning(f"合并元素失败: {str(e)}")
            return elements[0]  # 返回第一个元素
    
    def _filter_outlier_elements(self, elements: List[BuildingElement]) -> List[BuildingElement]:
        """
        过滤异常元素
        
        Args:
            elements: 元素列表
            
        Returns:
            过滤后的元素列表
        """
        try:
            if len(elements) <= 2:
                return elements
            
            # 基于面积过滤异常值
            areas = [elem.area for elem in elements]
            q1 = np.percentile(areas, 25)
            q3 = np.percentile(areas, 75)
            iqr = q3 - q1
            
            # 定义异常值范围
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            
            # 过滤异常元素
            filtered_elements = []
            for element in elements:
                if lower_bound <= element.area <= upper_bound:
                    filtered_elements.append(element)
                else:
                    logger.debug(f"过滤异常元素: 面积={element.area}, 类型={element.element_type}")
            
            return filtered_elements if filtered_elements else elements
            
        except Exception as e:
            logger.warning(f"过滤异常元素失败: {str(e)}")
            return elements


def create_element_extractor() -> BuildingElementExtractor:
    """
    创建建筑元素提取器实例
    
    Returns:
        配置好的提取器实例
    """
    return BuildingElementExtractor()
