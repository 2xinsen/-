
"""
几何参数计算器

该模块实现窗墙比、开口率、立面密度等指标计算。
"""

import numpy as np
import math
from typing import Dict, List, Tuple, Any, Union
import logging

class GeometryCalculator:
    """几何参数计算器"""
    
    def __init__(self):
        """初始化计算器"""
        self.logger = logging.getLogger(__name__)
        self.pixel_to_meter_ratio = 0.01  # 1像素 = 0.01米
        
    def calculate_parameters(self, elements: Union[Dict[str, List[Dict[str, Any]]], List[Dict[str, Any]]], 
                           image_size: Tuple[int, int] = None) -> Dict[str, Any]:
        """计算几何参数"""
        try:
            # 处理不同的输入格式
            if isinstance(elements, list):
                # 如果输入是列表，按类型分组
                grouped_elements = {}
                for element in elements:
                    element_type = element.get('type') or element.get('element_type', 'unknown')
                    if element_type not in grouped_elements:
                        grouped_elements[element_type] = []
                    grouped_elements[element_type].append(element)
                elements = grouped_elements
            
            # 分离窗户和墙体元素 - 支持单复数形式
            windows = elements.get('windows', []) + elements.get('window', [])
            walls = elements.get('walls', []) + elements.get('wall', [])
            
            # 计算窗墙比
            window_wall_ratio = self._calculate_window_wall_ratio(windows, walls)
            
            # 计算开口率
            opening_ratio = self._calculate_opening_ratio(windows, image_size)
            
            # 整合参数
            geometry_params = {
                'window_wall_ratio': window_wall_ratio,
                'opening_ratio': opening_ratio,
                'window_count': len(windows),
                'wall_count': len(walls),
                'total_elements': len(windows) + len(walls)
            }
            
            self.logger.info(f"几何参数计算完成，窗墙比: {window_wall_ratio:.3f}")
            
            return geometry_params
            
        except Exception as e:
            self.logger.error(f"几何参数计算失败: {str(e)}")
            raise
            
    def _calculate_window_wall_ratio(self, windows: List[Dict[str, Any]], 
                                   walls: List[Dict[str, Any]]) -> float:
        """计算窗墙比"""
        # 计算总窗户面积
        total_window_area = 0
        for w in windows:
            if 'area' in w:
                # 如果已经有面积信息，直接使用
                total_window_area += w['area'] * (self.pixel_to_meter_ratio ** 2)
            else:
                # 从bbox计算面积 (x_min, y_min, x_max, y_max)
                bbox = w['bbox']
                width = bbox[2] - bbox[0]
                height = bbox[3] - bbox[1]
                total_window_area += width * height * (self.pixel_to_meter_ratio ** 2)
        
        # 计算总墙体面积
        total_wall_area = 0
        for w in walls:
            if 'area' in w:
                # 如果已经有面积信息，直接使用
                total_wall_area += w['area'] * (self.pixel_to_meter_ratio ** 2)
            else:
                # 从bbox计算面积 (x_min, y_min, x_max, y_max)
                bbox = w['bbox']
                width = bbox[2] - bbox[0]
                height = bbox[3] - bbox[1]
                total_wall_area += width * height * (self.pixel_to_meter_ratio ** 2)
        
        # 改进的墙体面积计算逻辑
        if total_wall_area == 0 and len(windows) > 0:
            # 策略1：基于窗户分布的智能立面面积估算
            if windows:
                # 找到所有窗户的边界
                min_x = min(w['bbox'][0] for w in windows)
                min_y = min(w['bbox'][1] for w in windows)
                max_x = max(w['bbox'][2] for w in windows)
                max_y = max(w['bbox'][3] for w in windows)
                
                # 智能边距计算：基于窗户尺寸
                avg_window_width = np.mean([w['bbox'][2] - w['bbox'][0] for w in windows])
                avg_window_height = np.mean([w['bbox'][3] - w['bbox'][1] for w in windows])
                
                # 边距设置为平均窗户尺寸的一定比例
                horizontal_margin = max(avg_window_width * 0.5, 100)  # 至少100像素
                vertical_margin = max(avg_window_height * 0.3, 50)    # 至少50像素
                
                # 计算立面尺寸
                facade_width = max_x - min_x + 2 * horizontal_margin
                facade_height = max_y - min_y + 2 * vertical_margin
                
                # 立面总面积
                facade_total_area = facade_width * facade_height * (self.pixel_to_meter_ratio ** 2)
                
                # 墙体面积 = 立面总面积 - 窗户面积
                total_wall_area = facade_total_area - total_window_area
                
                # 确保墙体面积合理
                if total_wall_area < total_window_area:
                    # 如果墙体面积小于窗户面积，说明估算有问题，使用经验比例
                    total_wall_area = total_window_area * 4  # 假设窗墙比为0.25
                    self.logger.warning(f"墙体面积估算异常，使用经验比例调整: {total_wall_area:.2f} m²")
                
                self.logger.info(f"智能墙体面积估算: 立面总面积{facade_total_area:.2f}m², 墙体面积{total_wall_area:.2f}m²")
                
        elif total_wall_area == 0 and len(windows) == 0:
            # 策略2：没有窗户时的默认处理
            # 假设一个标准的建筑立面尺寸
            default_facade_area = 50.0  # 50平方米的默认立面
            total_wall_area = default_facade_area
            self.logger.warning(f"无窗户和墙体数据，使用默认立面面积: {total_wall_area:.2f} m²")
        
        # 计算窗墙比
        if total_wall_area > 0:
            ratio = total_window_area / total_wall_area
            self.logger.info(f"窗户面积: {total_window_area:.2f} m², 墙体面积: {total_wall_area:.2f} m², 窗墙比: {ratio:.3f}")
            return ratio
        else:
            self.logger.warning("墙体面积为0，无法计算窗墙比")
            return 0.0
            
    def _calculate_opening_ratio(self, windows: List[Dict[str, Any]], 
                               image_size: Tuple[int, int] = None) -> float:
        """计算开口率"""
        if not windows:
            return 0.0
            
        # 计算总窗户面积
        total_window_area = sum(w.get('area', 0) for w in windows)
        
        # 如果有图像尺寸，计算整个立面面积
        if image_size:
            image_width, image_height = image_size
            facade_area = image_width * image_height * (self.pixel_to_meter_ratio ** 2)
            if facade_area > 0:
                ratio = total_window_area * (self.pixel_to_meter_ratio ** 2) / facade_area
                self.logger.info(f"基于图像尺寸计算开口率: {ratio:.3f}")
                return ratio
        
        # 否则使用窗户边界估算
        min_x = min(w['bbox'][0] for w in windows)
        min_y = min(w['bbox'][1] for w in windows)
        max_x = max(w['bbox'][2] for w in windows)
        max_y = max(w['bbox'][3] for w in windows)
        
        facade_area = (max_x - min_x) * (max_y - min_y)
        if facade_area > 0:
            ratio = total_window_area / facade_area
            self.logger.info(f"基于窗户边界估算开口率: {ratio:.3f}")
            return ratio
            
        return 0.0

def create_geometry_calculator():
    """创建几何计算器实例"""
    return GeometryCalculator()
