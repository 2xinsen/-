
"""
图像质量验证器
负责进行输入验证，确保图像质量和数据完整性
"""

import cv2
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from pathlib import Path
import json

from ..core.config import config_manager
from ..core.logging_config import get_logger, LogContext
from ..core.exceptions import DataValidationError, ImageProcessingError
from ..core.data_structures import BuildingElement, FacadeData
from ..core.utils import FileUtils, ValidationUtils

# 获取日志记录器
logger = get_logger(__name__)


class ImageQualityMetrics:
    """图像质量指标类"""
    
    def __init__(self):
        self.resolution: Tuple[int, int] = (0, 0)      # 图像分辨率
        self.aspect_ratio: float = 0.0                  # 宽高比
        self.brightness_mean: float = 0.0               # 平均亮度
        self.brightness_std: float = 0.0                # 亮度标准差
        self.contrast_score: float = 0.0                # 对比度得分
        self.sharpness_score: float = 0.0               # 清晰度得分
        self.noise_level: float = 0.0                   # 噪声水平
        self.color_distribution: Dict[str, float] = {}  # 颜色分布
        self.segmentation_quality: float = 0.0          # 分割质量得分
        self.overall_quality: float = 0.0               # 总体质量得分


class QualityValidator:
    """
    图像质量验证器
    
    功能：
    1. 进行输入验证，检查图像格式和质量
    2. 验证YOLO分割结果的合理性
    3. 检查建筑元素数据的完整性和一致性
    4. 提供质量改进建议
    """
    
    def __init__(self):
        """初始化质量验证器"""
        # 获取配置
        self.config = config_manager.get_image_processing_config()
        
        # 质量阈值设置
        self.min_resolution = (200, 200)        # 最小分辨率
        self.max_resolution = (4000, 4000)      # 最大分辨率
        self.min_brightness = 30                # 最小平均亮度
        self.max_brightness = 225               # 最大平均亮度
        self.min_contrast = 20                  # 最小对比度
        self.min_sharpness = 100                # 最小清晰度
        self.max_noise_level = 50               # 最大噪声水平
        self.min_segmentation_quality = 0.6    # 最小分割质量
        
        # 颜色映射
        self.color_mapping = self.config.color_mapping
        
        logger.info("图像质量验证器初始化完成")
    
    def validate_input_image(self, image_path: str) -> Tuple[bool, ImageQualityMetrics, List[str]]:
        """
        验证输入图像质量
        
        Args:
            image_path: 图像文件路径
            
        Returns:
            (是否通过验证, 质量指标, 问题列表)
        """
        with LogContext("输入图像质量验证", logger):
            try:
                issues = []
                metrics = ImageQualityMetrics()
                
                # 基本文件检查
                if not self._validate_file_basic(image_path, issues):
                    return False, metrics, issues
                
                # 加载图像
                image = cv2.imread(image_path, cv2.IMREAD_COLOR)
                if image is None:
                    issues.append("无法加载图像文件")
                    return False, metrics, issues
                
                # 计算质量指标
                self._calculate_quality_metrics(image, metrics)
                
                # 验证各项质量指标
                self._validate_resolution(metrics, issues)
                self._validate_brightness_contrast(metrics, issues)
                self._validate_sharpness_noise(metrics, issues)
                self._validate_color_distribution(metrics, issues)
                
                # 计算总体质量得分
                metrics.overall_quality = self._calculate_overall_quality(metrics)
                
                # 判断是否通过验证
                is_valid = len(issues) == 0 and metrics.overall_quality >= 0.6
                
                if is_valid:
                    logger.info(f"图像质量验证通过，总体得分: {metrics.overall_quality:.2f}")
                else:
                    logger.warning(f"图像质量验证失败，发现 {len(issues)} 个问题")
                
                return is_valid, metrics, issues
                
            except Exception as e:
                error_msg = f"图像质量验证失败: {str(e)}"
                logger.error(error_msg)
                return False, ImageQualityMetrics(), [error_msg]
    
    def validate_segmentation_result(self, segmentation_data: Dict[str, List[Dict[str, Any]]], 
                                   image_shape: Tuple[int, int]) -> Tuple[bool, List[str]]:
        """
        验证YOLO分割结果
        
        Args:
            segmentation_data: 分割结果数据
            image_shape: 图像形状 (height, width)
            
        Returns:
            (是否通过验证, 问题列表)
        """
        with LogContext("分割结果验证", logger):
            try:
                issues = []
                
                # 基本结构检查
                if not self._validate_segmentation_structure(segmentation_data, issues):
                    return False, issues
                
                # 元素数量合理性检查
                self._validate_element_counts(segmentation_data, issues)
                
                # 元素尺寸合理性检查
                self._validate_element_sizes(segmentation_data, image_shape, issues)
                
                # 元素位置合理性检查
                self._validate_element_positions(segmentation_data, image_shape, issues)
                
                # 元素关系合理性检查
                self._validate_element_relationships(segmentation_data, issues)
                
                # 分割质量评估
                segmentation_quality = self._assess_segmentation_quality(segmentation_data)
                if segmentation_quality < self.min_segmentation_quality:
                    issues.append(f"分割质量过低: {segmentation_quality:.2f} < {self.min_segmentation_quality}")
                
                is_valid = len(issues) == 0
                
                if is_valid:
                    logger.info("分割结果验证通过")
                else:
                    logger.warning(f"分割结果验证失败，发现 {len(issues)} 个问题")
                
                return is_valid, issues
                
            except Exception as e:
                error_msg = f"分割结果验证失败: {str(e)}"
                logger.error(error_msg)
                return False, [error_msg]
    
    def validate_building_elements(self, building_elements: List[BuildingElement]) -> Tuple[bool, List[str]]:
        """
        验证建筑元素数据
        
        Args:
            building_elements: 建筑元素列表
            
        Returns:
            (是否通过验证, 问题列表)
        """
        with LogContext("建筑元素验证", logger):
            try:
                issues = []
                
                if not building_elements:
                    issues.append("建筑元素列表为空")
                    return False, issues
                
                # 验证每个元素
                for i, element in enumerate(building_elements):
                    element_issues = self._validate_single_element(element, i)
                    issues.extend(element_issues)
                
                # 验证元素间关系
                relationship_issues = self._validate_elements_relationships(building_elements)
                issues.extend(relationship_issues)
                
                is_valid = len(issues) == 0
                
                if is_valid:
                    logger.info(f"建筑元素验证通过，共 {len(building_elements)} 个元素")
                else:
                    logger.warning(f"建筑元素验证失败，发现 {len(issues)} 个问题")
                
                return is_valid, issues
                
            except Exception as e:
                error_msg = f"建筑元素验证失败: {str(e)}"
                logger.error(error_msg)
                return False, [error_msg]
    
    def _validate_file_basic(self, image_path: str, issues: List[str]) -> bool:
        """基本文件验证"""
        try:
            # 检查文件是否存在
            if not ValidationUtils.validate_file_exists(image_path):
                issues.append(f"图像文件不存在: {image_path}")
                return False
            
            # 检查文件格式
            if not FileUtils.is_image_file(image_path):
                issues.append(f"不支持的图像格式: {Path(image_path).suffix}")
                return False
            
            # 检查文件大小
            file_size = Path(image_path).stat().st_size
            if file_size == 0:
                issues.append("图像文件为空")
                return False
            elif file_size > 50 * 1024 * 1024:  # 50MB
                issues.append(f"图像文件过大: {file_size / (1024*1024):.1f}MB")
            
            return True
            
        except Exception as e:
            issues.append(f"文件基本验证失败: {str(e)}")
            return False
    
    def _calculate_quality_metrics(self, image: np.ndarray, metrics: ImageQualityMetrics) -> None:
        """计算图像质量指标"""
        try:
            # 分辨率和宽高比
            height, width = image.shape[:2]
            metrics.resolution = (width, height)
            metrics.aspect_ratio = width / height if height > 0 else 0.0
            
            # 转换为灰度图像用于亮度和对比度计算
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # 亮度指标
            metrics.brightness_mean = float(np.mean(gray))
            metrics.brightness_std = float(np.std(gray))
            
            # 对比度指标（使用标准差作为对比度的简单度量）
            metrics.contrast_score = metrics.brightness_std
            
            # 清晰度指标（使用拉普拉斯算子的方差）
            laplacian = cv2.Laplacian(gray, cv2.CV_64F)
            metrics.sharpness_score = float(laplacian.var())
            
            # 噪声水平估计（使用高频成分）
            blur = cv2.GaussianBlur(gray, (5, 5), 0)
            noise = cv2.absdiff(gray, blur)
            metrics.noise_level = float(np.mean(noise))
            
            # 颜色分布分析
            self._analyze_color_distribution(image, metrics)
            
        except Exception as e:
            logger.warning(f"质量指标计算失败: {str(e)}")
    
    def _analyze_color_distribution(self, image: np.ndarray, metrics: ImageQualityMetrics) -> None:
        """分析颜色分布"""
        try:
            total_pixels = image.shape[0] * image.shape[1]
            color_counts = {}
            
            # 统计各种目标颜色的像素数量
            for element_type, target_color in self.color_mapping.items():
                if element_type == 'background':
                    continue
                
                # 转换颜色格式 (RGB -> BGR)
                bgr_color = np.array([target_color[2], target_color[1], target_color[0]])
                
                # 创建颜色掩码（允许一定容差）
                lower = np.maximum(bgr_color - 10, 0)
                upper = np.minimum(bgr_color + 10, 255)
                mask = cv2.inRange(image, lower, upper)
                
                # 计算像素比例
                pixel_count = np.sum(mask > 0)
                color_counts[element_type] = pixel_count / total_pixels
            
            metrics.color_distribution = color_counts
            
        except Exception as e:
            logger.warning(f"颜色分布分析失败: {str(e)}")
            metrics.color_distribution = {}
    
    def _validate_resolution(self, metrics: ImageQualityMetrics, issues: List[str]) -> None:
        """验证分辨率"""
        width, height = metrics.resolution
        
        if width < self.min_resolution[0] or height < self.min_resolution[1]:
            issues.append(f"图像分辨率过低: {width}x{height} < {self.min_resolution[0]}x{self.min_resolution[1]}")
        
        if width > self.max_resolution[0] or height > self.max_resolution[1]:
            issues.append(f"图像分辨率过高: {width}x{height} > {self.max_resolution[0]}x{self.max_resolution[1]}")
        
        # 检查宽高比是否合理（建筑立面通常不会太极端）
        if metrics.aspect_ratio < 0.2 or metrics.aspect_ratio > 5.0:
            issues.append(f"图像宽高比异常: {metrics.aspect_ratio:.2f}")
    
    def _validate_brightness_contrast(self, metrics: ImageQualityMetrics, issues: List[str]) -> None:
        """验证亮度和对比度"""
        if metrics.brightness_mean < self.min_brightness:
            issues.append(f"图像过暗: 平均亮度 {metrics.brightness_mean:.1f} < {self.min_brightness}")
        
        if metrics.brightness_mean > self.max_brightness:
            issues.append(f"图像过亮: 平均亮度 {metrics.brightness_mean:.1f} > {self.max_brightness}")
        
        if metrics.contrast_score < self.min_contrast:
            issues.append(f"图像对比度过低: {metrics.contrast_score:.1f} < {self.min_contrast}")
    
    def _validate_sharpness_noise(self, metrics: ImageQualityMetrics, issues: List[str]) -> None:
        """验证清晰度和噪声"""
        if metrics.sharpness_score < self.min_sharpness:
            issues.append(f"图像清晰度不足: {metrics.sharpness_score:.1f} < {self.min_sharpness}")
        
        if metrics.noise_level > self.max_noise_level:
            issues.append(f"图像噪声过高: {metrics.noise_level:.1f} > {self.max_noise_level}")
    
    def _validate_color_distribution(self, metrics: ImageQualityMetrics, issues: List[str]) -> None:
        """验证颜色分布"""
        color_dist = metrics.color_distribution
        
        # 检查是否包含必要的颜色
        required_colors = ['windows', 'walls']  # 至少需要窗户和墙体
        missing_colors = []
        
        for color_type in required_colors:
            if color_type not in color_dist or color_dist[color_type] < 0.01:  # 至少1%的像素
                missing_colors.append(color_type)
        
        if missing_colors:
            issues.append(f"缺少必要的建筑元素颜色: {', '.join(missing_colors)}")
        
        # 检查颜色分布是否合理
        total_colored_pixels = sum(color_dist.values())
        if total_colored_pixels < 0.5:  # 至少50%的像素应该是有意义的颜色
            issues.append(f"有效颜色像素比例过低: {total_colored_pixels:.1%}")
    
    def _calculate_overall_quality(self, metrics: ImageQualityMetrics) -> float:
        """计算总体质量得分"""
        try:
            scores = []
            
            # 分辨率得分
            width, height = metrics.resolution
            res_score = min(1.0, (width * height) / (800 * 600))  # 以800x600为基准
            scores.append(res_score * 0.15)
            
            # 亮度得分
            brightness_score = 1.0 - abs(metrics.brightness_mean - 127.5) / 127.5
            scores.append(max(0, brightness_score) * 0.2)
            
            # 对比度得分
            contrast_score = min(1.0, metrics.contrast_score / 50.0)
            scores.append(contrast_score * 0.2)
            
            # 清晰度得分
            sharpness_score = min(1.0, metrics.sharpness_score / 500.0)
            scores.append(sharpness_score * 0.2)
            
            # 噪声得分（噪声越低得分越高）
            noise_score = max(0, 1.0 - metrics.noise_level / 50.0)
            scores.append(noise_score * 0.15)
            
            # 颜色分布得分
            color_score = min(1.0, sum(metrics.color_distribution.values()))
            scores.append(color_score * 0.1)
            
            return sum(scores)
            
        except Exception as e:
            logger.warning(f"总体质量得分计算失败: {str(e)}")
            return 0.0
    
    def _validate_segmentation_structure(self, data: Dict[str, List[Dict[str, Any]]], 
                                       issues: List[str]) -> bool:
        """验证分割结果数据结构"""
        try:
            if not isinstance(data, dict):
                issues.append("分割结果不是字典格式")
                return False
            
            # 检查必要的字段
            required_fields = ['element_type', 'bbox', 'area', 'width', 'height']
            
            for element_type, elements in data.items():
                if not isinstance(elements, list):
                    issues.append(f"{element_type} 不是列表格式")
                    continue
                
                for i, element in enumerate(elements):
                    if not isinstance(element, dict):
                        issues.append(f"{element_type}[{i}] 不是字典格式")
                        continue
                    
                    # 检查必要字段
                    missing_fields = [field for field in required_fields 
                                    if field not in element]
                    if missing_fields:
                        issues.append(f"{element_type}[{i}] 缺少字段: {', '.join(missing_fields)}")
            
            return len(issues) == 0
            
        except Exception as e:
            issues.append(f"结构验证失败: {str(e)}")
            return False
    
    def _validate_element_counts(self, data: Dict[str, List[Dict[str, Any]]], 
                               issues: List[str]) -> None:
        """验证元素数量合理性"""
        try:
            total_elements = sum(len(elements) for elements in data.values())
            
            if total_elements == 0:
                issues.append("未检测到任何建筑元素")
                return
            
            if total_elements > 500:  # 设置合理上限
                issues.append(f"检测到的元素数量过多: {total_elements}")
            
            # 检查各类型元素数量
            for element_type, elements in data.items():
                count = len(elements)
                
                if element_type == 'windows' and count > 100:
                    issues.append(f"窗户数量过多: {count}")
                elif element_type == 'doors' and count > 20:
                    issues.append(f"门数量过多: {count}")
                elif element_type == 'walls' and count > 50:
                    issues.append(f"墙体数量过多: {count}")
                elif element_type == 'shading' and count > 100:
                    issues.append(f"遮阳数量过多: {count}")
            
        except Exception as e:
            issues.append(f"元素数量验证失败: {str(e)}")
    
    def _validate_element_sizes(self, data: Dict[str, List[Dict[str, Any]]], 
                              image_shape: Tuple[int, int], issues: List[str]) -> None:
        """验证元素尺寸合理性"""
        try:
            height, width = image_shape
            total_area = width * height
            
            for element_type, elements in data.items():
                for i, element in enumerate(elements):
                    area = element.get('area', 0)
                    elem_width = element.get('width', 0)
                    elem_height = element.get('height', 0)
                    
                    # 检查面积是否合理
                    if area <= 0:
                        issues.append(f"{element_type}[{i}] 面积无效: {area}")
                        continue
                    
                    if area > total_area * 0.8:  # 单个元素不应超过图像80%
                        issues.append(f"{element_type}[{i}] 面积过大: {area} > {total_area * 0.8:.0f}")
                    
                    # 检查宽高是否合理
                    if elem_width <= 0 or elem_height <= 0:
                        issues.append(f"{element_type}[{i}] 尺寸无效: {elem_width}x{elem_height}")
                        continue
                    
                    # 检查宽高比是否合理
                    aspect_ratio = elem_width / elem_height
                    if aspect_ratio > 20 or aspect_ratio < 0.05:
                        issues.append(f"{element_type}[{i}] 宽高比异常: {aspect_ratio:.2f}")
            
        except Exception as e:
            issues.append(f"元素尺寸验证失败: {str(e)}")
    
    def _validate_element_positions(self, data: Dict[str, List[Dict[str, Any]]], 
                                  image_shape: Tuple[int, int], issues: List[str]) -> None:
        """验证元素位置合理性"""
        try:
            height, width = image_shape
            
            for element_type, elements in data.items():
                for i, element in enumerate(elements):
                    bbox = element.get('bbox', (0, 0, 0, 0))
                    
                    if len(bbox) != 4:
                        issues.append(f"{element_type}[{i}] 边界框格式错误")
                        continue
                    
                    x1, y1, x2, y2 = bbox
                    
                    # 检查边界框是否在图像范围内
                    if x1 < 0 or y1 < 0 or x2 > width or y2 > height:
                        issues.append(f"{element_type}[{i}] 位置超出图像边界: {bbox}")
                    
                    # 检查边界框是否有效
                    if x2 <= x1 or y2 <= y1:
                        issues.append(f"{element_type}[{i}] 边界框无效: {bbox}")
            
        except Exception as e:
            issues.append(f"元素位置验证失败: {str(e)}")
    
    def _validate_element_relationships(self, data: Dict[str, List[Dict[str, Any]]], 
                                      issues: List[str]) -> None:
        """验证元素关系合理性"""
        try:
            # 检查窗墙比是否合理
            windows = data.get('windows', [])
            walls = data.get('walls', [])
            
            if windows and walls:
                window_area = sum(w.get('area', 0) for w in windows)
                wall_area = sum(w.get('area', 0) for w in walls)
                
                if wall_area > 0:
                    window_wall_ratio = window_area / wall_area
                    if window_wall_ratio > 1.0:  # 窗墙比不应超过1
                        issues.append(f"窗墙比异常: {window_wall_ratio:.2f}")
            
            # 检查门的合理性
            doors = data.get('doors', [])
            for i, door in enumerate(doors):
                door_width = door.get('width', 0)
                door_height = door.get('height', 0)
                
                # 门通常比较高
                if door_height > 0 and door_width / door_height > 2.0:
                    issues.append(f"门[{i}] 宽高比异常: {door_width / door_height:.2f}")
            
        except Exception as e:
            issues.append(f"元素关系验证失败: {str(e)}")
    
    def _assess_segmentation_quality(self, data: Dict[str, List[Dict[str, Any]]]) -> float:
        """评估分割质量"""
        try:
            scores = []
            
            # 元素数量得分
            total_elements = sum(len(elements) for elements in data.values())
            count_score = min(1.0, total_elements / 20.0)  # 20个元素为满分
            scores.append(count_score * 0.3)
            
            # 元素多样性得分
            diversity_score = len(data) / 4.0  # 4种类型为满分
            scores.append(min(1.0, diversity_score) * 0.2)
            
            # 元素尺寸合理性得分
            size_scores = []
            for elements in data.values():
                for element in elements:
                    area = element.get('area', 0)
                    if 100 <= area <= 50000:  # 合理的面积范围
                        size_scores.append(1.0)
                    else:
                        size_scores.append(0.5)
            
            if size_scores:
                avg_size_score = np.mean(size_scores)
                scores.append(avg_size_score * 0.3)
            
            # 形状合理性得分
            shape_scores = []
            for elements in data.values():
                for element in elements:
                    width = element.get('width', 0)
                    height = element.get('height', 0)
                    if height > 0:
                        aspect_ratio = width / height
                        if 0.1 <= aspect_ratio <= 10.0:  # 合理的宽高比
                            shape_scores.append(1.0)
                        else:
                            shape_scores.append(0.3)
            
            if shape_scores:
                avg_shape_score = np.mean(shape_scores)
                scores.append(avg_shape_score * 0.2)
            
            return sum(scores)
            
        except Exception as e:
            logger.warning(f"分割质量评估失败: {str(e)}")
            return 0.0
    
    def _validate_single_element(self, element: BuildingElement, index: int) -> List[str]:
        """验证单个建筑元素"""
        issues = []
        
        try:
            # 基本属性检查
            if element.width <= 0 or element.height <= 0:
                issues.append(f"元素[{index}] 尺寸无效: {element.width}x{element.height}")
            
            if element.area <= 0:
                issues.append(f"元素[{index}] 面积无效: {element.area}")
            
            # 边界框检查
            if len(element.bbox) != 4:
                issues.append(f"元素[{index}] 边界框格式错误")
            else:
                x1, y1, x2, y2 = element.bbox
                if x2 <= x1 or y2 <= y1:
                    issues.append(f"元素[{index}] 边界框无效: {element.bbox}")
            
            # 类型检查
            valid_types = ['windows', 'doors', 'walls', 'shading']
            if element.element_type not in valid_types:
                issues.append(f"元素[{index}] 类型无效: {element.element_type}")
            
        except Exception as e:
            issues.append(f"元素[{index}] 验证失败: {str(e)}")
        
        return issues
    
    def _validate_elements_relationships(self, elements: List[BuildingElement]) -> List[str]:
        """验证元素间关系"""
        issues = []
        
        try:
            # 按类型分组
            by_type = {}
            for element in elements:
                if element.element_type not in by_type:
                    by_type[element.element_type] = []
                by_type[element.element_type].append(element)
            
            # 检查窗墙关系
            windows = by_type.get('windows', [])
            walls = by_type.get('walls', [])
            
            if windows and walls:
                window_area = sum(w.area for w in windows)
                wall_area = sum(w.area for w in walls)
                
                if wall_area > 0:
                    ratio = window_area / wall_area
                    if ratio > 0.8:  # 窗墙比过高
                        issues.append(f"窗墙比过高: {ratio:.2f}")
            
        except Exception as e:
            issues.append(f"元素关系验证失败: {str(e)}")
        
        return issues
    
    def generate_quality_report(self, metrics: ImageQualityMetrics, 
                              validation_issues: List[str]) -> str:
        """生成质量验证报告"""
        try:
            report_lines = [
                "=" * 60,
                "图像质量验证报告",
                "=" * 60,
                "",
                "基本信息:",
                f"  分辨率: {metrics.resolution[0]}x{metrics.resolution[1]}",
                f"  宽高比: {metrics.aspect_ratio:.2f}",
                f"  总体质量得分: {metrics.overall_quality:.2f}",
                "",
                "质量指标:",
                f"  平均亮度: {metrics.brightness_mean:.1f}",
                f"  亮度标准差: {metrics.brightness_std:.1f}",
                f"  对比度得分: {metrics.contrast_score:.1f}",
                f"  清晰度得分: {metrics.sharpness_score:.1f}",
                f"  噪声水平: {metrics.noise_level:.1f}",
                "",
                "颜色分布:"
            ]
            
            for color_type, ratio in metrics.color_distribution.items():
                report_lines.append(f"  {color_type}: {ratio:.1%}")
            
            report_lines.append("")
            
            if validation_issues:
                report_lines.extend([
                    "发现的问题:",
                    *[f"  ⚠️ {issue}" for issue in validation_issues],
                    ""
                ])
            else:
                report_lines.extend([
                    "验证结果:",
                    "  ✅ 所有检查通过",
                    ""
                ])
            
            report_lines.append("=" * 60)
            
            return "\n".join(report_lines)
            
        except Exception as e:
            logger.error(f"质量报告生成失败: {str(e)}")
            return f"质量报告生成失败: {str(e)}"


def create_quality_validator() -> QualityValidator:
    """
    创建图像质量验证器实例
    
    Returns:
        配置好的验证器实例
    """
    return QualityValidator()
