
"""
立面图像对比器

该模块实现立面识别结果与原始图片的对比功能，生成对比图片方便查看识别效果。
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from typing import Dict, List, Any, Tuple, Optional
from pathlib import Path
import os

from ..core.logging_config import get_logger
from ..core.exceptions import ImageProcessingError

logger = get_logger(__name__)


class FacadeComparisonGenerator:
    """立面对比图生成器"""
    
    def __init__(self):
        """初始化对比图生成器"""
        self.colors = {
            'windows': (0, 255, 0),      # 绿色
            'walls': (128, 128, 128),    # 灰色
            'doors': (255, 0, 0),        # 红色
            'shadings': (0, 0, 255),     # 蓝色
        }
        
    def create_comparison_image(self, 
                              original_image_path: str,
                              detected_elements: Dict[str, List[Dict[str, Any]]],
                              output_path: str = "outputs/facade_comparison.png") -> str:
        """
        创建原始图片与识别结果的对比图
        
        Args:
            original_image_path: 原始图片路径
            detected_elements: 检测到的建筑元素
            output_path: 输出路径
            
        Returns:
            生成的对比图路径
        """
        try:
            logger.info("开始生成立面对比图")
            
            # 确保输出目录存在
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            # 加载原始图像
            original_image = self._load_image_safe(original_image_path)
            if original_image is None:
                raise ImageProcessingError(f"无法加载原始图像: {original_image_path}")
            
            # 创建标注图像
            annotated_image = self._create_annotated_image(original_image, detected_elements)
            
            # 创建对比图
            comparison_fig = self._create_comparison_figure(original_image, annotated_image, detected_elements)
            
            # 保存对比图
            comparison_fig.savefig(output_path, dpi=300, bbox_inches='tight', 
                                 facecolor='white', edgecolor='none')
            plt.close(comparison_fig)
            
            logger.info(f"立面对比图已保存: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"生成立面对比图失败: {str(e)}")
            raise ImageProcessingError(f"立面对比图生成失败: {str(e)}")
    
    def _load_image_safe(self, image_path: str) -> Optional[np.ndarray]:
        """安全加载图像（支持中文路径）"""
        try:
            with open(image_path, 'rb') as f:
                image_data = f.read()
            
            nparr = np.frombuffer(image_data, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if image is not None:
                # 转换为RGB格式用于matplotlib显示
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
            return image
            
        except Exception as e:
            logger.error(f"图像加载失败: {str(e)}")
            return None
    
    def _create_annotated_image(self, 
                               original_image: np.ndarray,
                               detected_elements: Dict[str, List[Dict[str, Any]]]) -> np.ndarray:
        """创建标注图像"""
        try:
            # 复制原始图像
            annotated = original_image.copy()
            
            # 为每种元素类型绘制标注
            for element_type, elements in detected_elements.items():
                color = self.colors.get(element_type, (255, 255, 255))
                
                for i, element in enumerate(elements):
                    # 获取边界框
                    bbox = element.get('bbox', [0, 0, 100, 100])
                    if len(bbox) == 4:
                        x1, y1, x2, y2 = bbox
                        
                        # 绘制边界框
                        cv2.rectangle(annotated, (int(x1), int(y1)), (int(x2), int(y2)), color, 2)
                        
                        # 添加标签
                        label = f"{element_type}_{i+1}"
                        label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]
                        
                        # 绘制标签背景
                        cv2.rectangle(annotated, 
                                    (int(x1), int(y1) - label_size[1] - 10),
                                    (int(x1) + label_size[0] + 10, int(y1)),
                                    color, -1)
                        
                        # 绘制标签文字
                        cv2.putText(annotated, label, 
                                  (int(x1) + 5, int(y1) - 5),
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            
            return annotated
            
        except Exception as e:
            logger.error(f"创建标注图像失败: {str(e)}")
            return original_image.copy()
    
    def _create_comparison_figure(self, 
                                 original_image: np.ndarray,
                                 annotated_image: np.ndarray,
                                 detected_elements: Dict[str, List[Dict[str, Any]]]) -> plt.Figure:
        """创建对比图表"""
        try:
            # 创建图表
            fig = plt.figure(figsize=(16, 10))
            
            # 左侧：原始图像
            ax1 = plt.subplot(2, 2, 1)
            ax1.imshow(original_image)
            ax1.set_title('原始立面图像', fontsize=14, fontweight='bold', pad=20)
            ax1.axis('off')
            
            # 右侧：标注图像
            ax2 = plt.subplot(2, 2, 2)
            ax2.imshow(annotated_image)
            ax2.set_title('识别结果标注', fontsize=14, fontweight='bold', pad=20)
            ax2.axis('off')
            
            # 下方：统计信息
            ax3 = plt.subplot(2, 1, 2)
            self._add_statistics_table(ax3, detected_elements)
            
            # 添加图例
            self._add_legend(fig)
            
            plt.tight_layout()
            return fig
            
        except Exception as e:
            logger.error(f"创建对比图表失败: {str(e)}")
            # 返回简单的对比图
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))
            ax1.imshow(original_image)
            ax1.set_title('原始图像')
            ax1.axis('off')
            ax2.imshow(annotated_image)
            ax2.set_title('识别结果')
            ax2.axis('off')
            return fig
    
    def _add_statistics_table(self, ax, detected_elements: Dict[str, List[Dict[str, Any]]]):
        """添加统计信息表格"""
        try:
            ax.axis('off')
            
            # 准备表格数据
            table_data = []
            headers = ['元素类型', '数量', '总面积(像素)', '平均面积(像素)', '最大面积(像素)', '最小面积(像素)']
            
            for element_type, elements in detected_elements.items():
                if not elements:
                    continue
                
                count = len(elements)
                areas = [elem.get('area', 0) for elem in elements]
                total_area = sum(areas)
                avg_area = total_area / count if count > 0 else 0
                max_area = max(areas) if areas else 0
                min_area = min(areas) if areas else 0
                
                # 中文元素类型名称
                type_names = {
                    'windows': '窗户',
                    'walls': '墙体', 
                    'doors': '门',
                    'shadings': '遮阳设施'
                }
                
                table_data.append([
                    type_names.get(element_type, element_type),
                    str(count),
                    f"{total_area:.0f}",
                    f"{avg_area:.0f}",
                    f"{max_area:.0f}",
                    f"{min_area:.0f}"
                ])
            
            if table_data:
                # 创建表格
                table = ax.table(cellText=table_data,
                               colLabels=headers,
                               cellLoc='center',
                               loc='center',
                               bbox=[0, 0, 1, 1])
                
                # 设置表格样式
                table.auto_set_font_size(False)
                table.set_fontsize(10)
                table.scale(1, 2)
                
                # 设置表头样式
                for i in range(len(headers)):
                    table[(0, i)].set_facecolor('#4CAF50')
                    table[(0, i)].set_text_props(weight='bold', color='white')
                
                # 设置数据行样式
                for i in range(1, len(table_data) + 1):
                    for j in range(len(headers)):
                        if i % 2 == 0:
                            table[(i, j)].set_facecolor('#f0f0f0')
                        else:
                            table[(i, j)].set_facecolor('white')
            
            ax.set_title('识别结果统计', fontsize=12, fontweight='bold', pad=20)
            
        except Exception as e:
            logger.error(f"添加统计表格失败: {str(e)}")
            ax.text(0.5, 0.5, '统计信息生成失败', ha='center', va='center', transform=ax.transAxes)
    
    def _add_legend(self, fig):
        """添加图例"""
        try:
            # 创建图例元素
            legend_elements = []
            type_names = {
                'windows': '窗户',
                'walls': '墙体',
                'doors': '门',
                'shadings': '遮阳设施'
            }
            
            for element_type, color in self.colors.items():
                # 将BGR转换为RGB并归一化
                rgb_color = (color[0]/255, color[1]/255, color[2]/255)
                legend_elements.append(
                    patches.Patch(color=rgb_color, label=type_names.get(element_type, element_type))
                )
            
            # 添加图例
            fig.legend(handles=legend_elements, 
                      loc='upper right', 
                      bbox_to_anchor=(0.98, 0.98),
                      fontsize=10)
            
        except Exception as e:
            logger.error(f"添加图例失败: {str(e)}")
    
    def create_detailed_comparison(self,
                                 original_image_path: str,
                                 detected_elements: Dict[str, List[Dict[str, Any]]],
                                 output_dir: str = "outputs") -> List[str]:
        """
        创建详细的对比图（包括单独的元素类型图）
        
        Args:
            original_image_path: 原始图片路径
            detected_elements: 检测到的建筑元素
            output_dir: 输出目录
            
        Returns:
            生成的图片路径列表
        """
        try:
            logger.info("开始生成详细立面对比图")
            
            # 确保输出目录存在
            os.makedirs(output_dir, exist_ok=True)
            
            generated_files = []
            
            # 1. 生成总体对比图
            main_comparison = self.create_comparison_image(
                original_image_path, detected_elements, 
                os.path.join(output_dir, "facade_comparison_main.png")
            )
            generated_files.append(main_comparison)
            
            # 2. 为每种元素类型生成单独的对比图
            original_image = self._load_image_safe(original_image_path)
            if original_image is not None:
                for element_type, elements in detected_elements.items():
                    if elements:
                        single_type_path = os.path.join(output_dir, f"facade_comparison_{element_type}.png")
                        single_type_file = self._create_single_type_comparison(
                            original_image, {element_type: elements}, single_type_path
                        )
                        if single_type_file:
                            generated_files.append(single_type_file)
            
            logger.info(f"详细立面对比图生成完成，共生成 {len(generated_files)} 个文件")
            return generated_files
            
        except Exception as e:
            logger.error(f"生成详细立面对比图失败: {str(e)}")
            return []
    
    def _create_single_type_comparison(self,
                                     original_image: np.ndarray,
                                     single_type_elements: Dict[str, List[Dict[str, Any]]],
                                     output_path: str) -> Optional[str]:
        """创建单一元素类型的对比图"""
        try:
            annotated_image = self._create_annotated_image(original_image, single_type_elements)
            
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))
            
            # 原始图像
            ax1.imshow(original_image)
            ax1.set_title('原始图像', fontsize=12, fontweight='bold')
            ax1.axis('off')
            
            # 标注图像
            ax2.imshow(annotated_image)
            element_type = list(single_type_elements.keys())[0]
            type_names = {'windows': '窗户', 'walls': '墙体', 'doors': '门', 'shadings': '遮阳设施'}
            ax2.set_title(f'{type_names.get(element_type, element_type)}识别结果', 
                         fontsize=12, fontweight='bold')
            ax2.axis('off')
            
            plt.tight_layout()
            fig.savefig(output_path, dpi=300, bbox_inches='tight', 
                       facecolor='white', edgecolor='none')
            plt.close(fig)
            
            return output_path
            
        except Exception as e:
            logger.error(f"创建单一类型对比图失败: {str(e)}")
            return None


def create_facade_comparison_generator() -> FacadeComparisonGenerator:
    """创建立面对比图生成器实例"""
    return FacadeComparisonGenerator()
