
"""
数据结构转换器
负责转换为优化算法所需格式，提供数据格式转换功能
"""

import numpy as np
from typing import Dict, List, Tuple, Optional, Any, Union
import json
from pathlib import Path

from ..core.config import config_manager
from ..core.logging_config import get_logger, LogContext
from ..core.exceptions import DataSerializationError, ImageProcessingError
from ..core.data_structures import BuildingElement, FacadeData
from ..core.utils import FileUtils, ValidationUtils

# 获取日志记录器
logger = get_logger(__name__)


class DataStructureConverter:
    """
    数据结构转换器
    
    功能：
    1. 转换为优化算法所需格式
    2. 提供多种数据格式转换（JSON、NumPy、字典等）
    3. 处理数据序列化和反序列化
    4. 支持数据格式验证和修复
    """
    
    def __init__(self):
        """初始化数据结构转换器"""
        self.config = config_manager.get_image_processing_config()
        logger.info("数据结构转换器初始化完成")
    
    def convert_to_optimization_format(self, facade_data: FacadeData) -> Dict[str, Any]:
        """
        转换为优化算法所需的格式
        
        Args:
            facade_data: 立面数据对象
            
        Returns:
            优化算法格式的数据字典
            
        Raises:
            DataSerializationError: 转换失败时抛出
        """
        with LogContext("转换为优化格式", logger):
            try:
                optimization_data = {
                    # 基本信息
                    'metadata': {
                        'image_path': facade_data.image_path,
                        'image_dimensions': (facade_data.image_width, facade_data.image_height),
                        'total_facade_area': facade_data.total_facade_area,
                        'processing_timestamp': facade_data.metadata.get('processing_timestamp', ''),
                        'pixel_to_meter_scale': facade_data.metadata.get('pixel_to_meter_scale', 0.01)
                    },
                    
                    # 几何参数
                    'geometry': {
                        'total_window_area': facade_data.total_window_area,
                        'total_wall_area': facade_data.total_wall_area,
                        'window_wall_ratio': facade_data.window_wall_ratio,
                        'facade_dimensions': {
                            'width': facade_data.image_width * facade_data.metadata.get('pixel_to_meter_scale', 0.01),
                            'height': facade_data.image_height * facade_data.metadata.get('pixel_to_meter_scale', 0.01)
                        }
                    },
                    
                    # 建筑元素数据
                    'elements': {
                        'windows': self._convert_elements_to_optimization(facade_data.windows),
                        'doors': self._convert_elements_to_optimization(facade_data.doors),
                        'shadings': self._convert_elements_to_optimization(facade_data.shadings),
                        'walls': self._convert_elements_to_optimization(facade_data.walls)
                    },
                    
                    # 约束信息
                    'constraints': facade_data.constraints,
                    
                    # 优化参数边界
                    'parameter_bounds': self._generate_parameter_bounds(facade_data),
                    
                    # 初始设计向量
                    'initial_design': self._generate_initial_design_vector(facade_data)
                }
                
                logger.info("成功转换为优化算法格式")
                return optimization_data
                
            except Exception as e:
                error_msg = f"转换为优化格式失败: {str(e)}"
                logger.error(error_msg)
                raise DataSerializationError(error_msg) from e
    
    def _convert_elements_to_optimization(self, elements: List[BuildingElement]) -> List[Dict[str, Any]]:
        """将建筑元素转换为优化格式"""
        try:
            converted_elements = []
            
            for i, element in enumerate(elements):
                element_data = {
                    'id': i,
                    'type': element.element_type,
                    'geometry': {
                        'position': {'x': element.x, 'y': element.y},
                        'dimensions': {'width': element.width, 'height': element.height},
                        'area': element.area,
                        'bbox': element.bbox,
                        'center': {'x': element.center_x, 'y': element.center_y}
                    },
                    'properties': element.properties,
                    'optimization_params': self._extract_optimization_parameters(element)
                }
                
                converted_elements.append(element_data)
            
            return converted_elements
            
        except Exception as e:
            raise DataSerializationError(f"元素转换失败: {str(e)}") from e
    
    def _extract_optimization_parameters(self, element: BuildingElement) -> Dict[str, Any]:
        """提取元素的优化参数"""
        try:
            params = {
                'can_resize': True,  # 是否可以调整尺寸
                'can_move': True,    # 是否可以移动位置
                'min_size': {'width': element.width * 0.5, 'height': element.height * 0.5},
                'max_size': {'width': element.width * 2.0, 'height': element.height * 2.0},
                'move_range': {'x': element.width * 0.3, 'y': element.height * 0.2}
            }
            
            # 根据元素类型设置特定参数
            if element.element_type == 'windows':
                params.update({
                    'glazing_ratio': element.properties.get('glazing_ratio', 0.8),
                    'frame_width': element.properties.get('frame_width', 0.05),
                    'u_value': element.properties.get('u_value', 2.5),
                    'shgc': element.properties.get('shgc', 0.7)  # 太阳得热系数
                })
            elif element.element_type == 'shading':
                params.update({
                    'depth_range': {'min': 0.1, 'max': 1.0},
                    'angle_range': {'min': 0, 'max': 90},
                    'solar_transmittance': element.properties.get('solar_transmittance', 0.1)
                })
            elif element.element_type == 'walls':
                params.update({
                    'can_resize': False,  # 墙体通常不能调整尺寸
                    'can_move': False,    # 墙体不能移动
                    'u_value': element.properties.get('u_value', 0.4),
                    'thermal_mass': element.properties.get('thermal_mass', 'medium')
                })
            
            return params
            
        except Exception as e:
            logger.warning(f"提取优化参数失败: {str(e)}")
            return {}
    
    def _generate_parameter_bounds(self, facade_data: FacadeData) -> Dict[str, Dict[str, float]]:
        """生成优化参数边界"""
        try:
            bounds = {
                'window_width_scale': {'min': 0.5, 'max': 2.0},
                'window_height_scale': {'min': 0.5, 'max': 2.0},
                'window_position_x': {'min': -0.3, 'max': 0.3},
                'window_position_y': {'min': -0.2, 'max': 0.2},
                'shading_width': {'min': 0.5, 'max': 3.0},
                'shading_depth': {'min': 0.1, 'max': 1.0},
                'shading_angle': {'min': 0, 'max': 90},
                'shading_type': {'min': 0, 'max': 3}
            }
            
            # 根据实际立面尺寸调整边界
            facade_width = facade_data.image_width * facade_data.metadata.get('pixel_to_meter_scale', 0.01)
            facade_height = facade_data.image_height * facade_data.metadata.get('pixel_to_meter_scale', 0.01)
            
            # 调整位置移动范围
            max_x_move = min(0.3, facade_width * 0.1)  # 最多移动立面宽度的10%
            max_y_move = min(0.2, facade_height * 0.1)  # 最多移动立面高度的10%
            
            bounds['window_position_x'] = {'min': -max_x_move, 'max': max_x_move}
            bounds['window_position_y'] = {'min': -max_y_move, 'max': max_y_move}
            
            return bounds
            
        except Exception as e:
            logger.warning(f"生成参数边界失败: {str(e)}")
            return {}
    
    def _generate_initial_design_vector(self, facade_data: FacadeData) -> Dict[str, np.ndarray]:
        """生成初始设计向量"""
        try:
            num_windows = len(facade_data.windows)
            num_shadings = len(facade_data.shadings)
            
            # 为每个窗户生成初始参数
            initial_design = {
                'window_width_scales': np.ones(num_windows),      # 初始缩放为1.0（不变）
                'window_height_scales': np.ones(num_windows),     # 初始缩放为1.0（不变）
                'window_positions_x': np.zeros(num_windows),      # 初始位置偏移为0
                'window_positions_y': np.zeros(num_windows),      # 初始位置偏移为0
                'shading_widths': np.ones(num_shadings) * 1.0,   # 初始遮阳宽度1米
                'shading_depths': np.ones(num_shadings) * 0.3,   # 初始遮阳深度0.3米
                'shading_angles': np.zeros(num_shadings),         # 初始遮阳角度0度
                'shading_types': np.zeros(num_shadings)           # 初始遮阳类型0
            }
            
            # 转换为列表以便JSON序列化
            for key, value in initial_design.items():
                initial_design[key] = value.tolist()
            
            return initial_design
            
        except Exception as e:
            logger.warning(f"生成初始设计向量失败: {str(e)}")
            return {}
    
    def convert_to_json_format(self, data: Any, ensure_serializable: bool = True) -> Dict[str, Any]:
        """
        转换为JSON格式
        
        Args:
            data: 要转换的数据
            ensure_serializable: 是否确保可序列化
            
        Returns:
            JSON格式的数据字典
        """
        with LogContext("转换为JSON格式", logger):
            try:
                if isinstance(data, FacadeData):
                    json_data = self._facade_data_to_json(data)
                elif isinstance(data, BuildingElement):
                    json_data = self._building_element_to_json(data)
                elif isinstance(data, list) and all(isinstance(item, BuildingElement) for item in data):
                    json_data = [self._building_element_to_json(element) for element in data]
                else:
                    json_data = data
                
                if ensure_serializable:
                    json_data = self._ensure_json_serializable(json_data)
                
                logger.debug("成功转换为JSON格式")
                return json_data
                
            except Exception as e:
                error_msg = f"JSON格式转换失败: {str(e)}"
                logger.error(error_msg)
                raise DataSerializationError(error_msg) from e
    
    def _facade_data_to_json(self, facade_data: FacadeData) -> Dict[str, Any]:
        """将立面数据转换为JSON格式"""
        return {
            'image_path': facade_data.image_path,
            'image_width': facade_data.image_width,
            'image_height': facade_data.image_height,
            'windows': [self._building_element_to_json(w) for w in facade_data.windows],
            'doors': [self._building_element_to_json(d) for d in facade_data.doors],
            'shadings': [self._building_element_to_json(s) for s in facade_data.shadings],
            'walls': [self._building_element_to_json(w) for w in facade_data.walls],
            'total_facade_area': facade_data.total_facade_area,
            'total_window_area': facade_data.total_window_area,
            'total_wall_area': facade_data.total_wall_area,
            'window_wall_ratio': facade_data.window_wall_ratio,
            'constraints': facade_data.constraints,
            'metadata': facade_data.metadata
        }
    
    def _building_element_to_json(self, element: BuildingElement) -> Dict[str, Any]:
        """将建筑元素转换为JSON格式"""
        return {
            'element_type': element.element_type,
            'x': element.x,
            'y': element.y,
            'width': element.width,
            'height': element.height,
            'area': element.area,
            'bbox': element.bbox,
            'center_x': element.center_x,
            'center_y': element.center_y,
            'contour': element.contour.tolist() if element.contour is not None else None,
            'properties': element.properties
        }
    
    def _ensure_json_serializable(self, data: Any) -> Any:
        """确保数据可以JSON序列化"""
        try:
            if isinstance(data, np.ndarray):
                return data.tolist()
            elif isinstance(data, np.integer):
                return int(data)
            elif isinstance(data, np.floating):
                return float(data)
            elif isinstance(data, dict):
                return {key: self._ensure_json_serializable(value) for key, value in data.items()}
            elif isinstance(data, list):
                return [self._ensure_json_serializable(item) for item in data]
            elif isinstance(data, tuple):
                return [self._ensure_json_serializable(item) for item in data]
            else:
                return data
        except Exception as e:
            logger.warning(f"序列化处理失败: {str(e)}")
            return str(data)  # 转换为字符串作为备选方案
    
    def convert_from_json_format(self, json_data: Dict[str, Any]) -> Union[FacadeData, List[BuildingElement]]:
        """
        从JSON格式转换回对象
        
        Args:
            json_data: JSON格式的数据
            
        Returns:
            转换后的对象
        """
        with LogContext("从JSON格式转换", logger):
            try:
                if 'image_path' in json_data and 'image_width' in json_data:
                    # 转换为FacadeData
                    return self._json_to_facade_data(json_data)
                elif isinstance(json_data, list):
                    # 转换为BuildingElement列表
                    return [self._json_to_building_element(item) for item in json_data]
                else:
                    raise ValueError("无法识别的JSON数据格式")
                
            except Exception as e:
                error_msg = f"从JSON格式转换失败: {str(e)}"
                logger.error(error_msg)
                raise DataSerializationError(error_msg) from e
    
    def _json_to_facade_data(self, json_data: Dict[str, Any]) -> FacadeData:
        """从JSON转换为立面数据"""
        facade_data = FacadeData(
            image_path=json_data['image_path'],
            image_width=json_data['image_width'],
            image_height=json_data['image_height'],
            windows=[self._json_to_building_element(w) for w in json_data.get('windows', [])],
            doors=[self._json_to_building_element(d) for d in json_data.get('doors', [])],
            shadings=[self._json_to_building_element(s) for s in json_data.get('shadings', [])],
            walls=[self._json_to_building_element(w) for w in json_data.get('walls', [])]
        )
        
        # 设置其他属性
        facade_data.total_facade_area = json_data.get('total_facade_area', 0.0)
        facade_data.total_window_area = json_data.get('total_window_area', 0.0)
        facade_data.total_wall_area = json_data.get('total_wall_area', 0.0)
        facade_data.window_wall_ratio = json_data.get('window_wall_ratio', 0.0)
        facade_data.constraints = json_data.get('constraints', {})
        facade_data.metadata = json_data.get('metadata', {})
        
        return facade_data
    
    def _json_to_building_element(self, json_data: Dict[str, Any]) -> BuildingElement:
        """从JSON转换为建筑元素"""
        contour = None
        if json_data.get('contour') is not None:
            contour = np.array(json_data['contour'])
        
        return BuildingElement(
            element_type=json_data['element_type'],
            x=json_data['x'],
            y=json_data['y'],
            width=json_data['width'],
            height=json_data['height'],
            area=json_data['area'],
            bbox=tuple(json_data['bbox']),
            contour=contour,
            properties=json_data.get('properties', {})
        )
    
    def convert_to_numpy_format(self, facade_data: FacadeData) -> Dict[str, np.ndarray]:
        """
        转换为NumPy数组格式（用于数值计算）
        
        Args:
            facade_data: 立面数据
            
        Returns:
            NumPy格式的数据字典
        """
        with LogContext("转换为NumPy格式", logger):
            try:
                numpy_data = {}
                
                # 转换各类型元素
                for element_type in ['windows', 'doors', 'shadings', 'walls']:
                    elements = getattr(facade_data, element_type, [])
                    if elements:
                        # 提取几何信息
                        positions = np.array([[elem.x, elem.y] for elem in elements])
                        dimensions = np.array([[elem.width, elem.height] for elem in elements])
                        areas = np.array([elem.area for elem in elements])
                        
                        numpy_data[f'{element_type}_positions'] = positions
                        numpy_data[f'{element_type}_dimensions'] = dimensions
                        numpy_data[f'{element_type}_areas'] = areas
                
                # 添加全局信息
                numpy_data['facade_dimensions'] = np.array([facade_data.image_width, facade_data.image_height])
                numpy_data['facade_areas'] = np.array([
                    facade_data.total_facade_area,
                    facade_data.total_window_area,
                    facade_data.total_wall_area
                ])
                
                logger.debug("成功转换为NumPy格式")
                return numpy_data
                
            except Exception as e:
                error_msg = f"NumPy格式转换失败: {str(e)}"
                logger.error(error_msg)
                raise DataSerializationError(error_msg) from e
    
    def save_to_file(self, data: Any, file_path: str, format_type: str = 'json') -> None:
        """
        保存数据到文件
        
        Args:
            data: 要保存的数据
            file_path: 文件路径
            format_type: 文件格式 ('json', 'pickle', 'numpy')
        """
        with LogContext(f"保存数据到文件 ({format_type})", logger):
            try:
                file_path = Path(file_path)
                FileUtils.ensure_directory(file_path.parent)
                
                if format_type == 'json':
                    json_data = self.convert_to_json_format(data)
                    FileUtils.save_json(json_data, file_path)
                elif format_type == 'pickle':
                    FileUtils.save_pickle(data, file_path)
                elif format_type == 'numpy' and isinstance(data, FacadeData):
                    numpy_data = self.convert_to_numpy_format(data)
                    np.savez_compressed(file_path, **numpy_data)
                else:
                    raise ValueError(f"不支持的文件格式: {format_type}")
                
                logger.info(f"数据已保存到: {file_path}")
                
            except Exception as e:
                error_msg = f"保存数据失败: {str(e)}"
                logger.error(error_msg)
                raise DataSerializationError(error_msg) from e
    
    def load_from_file(self, file_path: str, format_type: str = 'json') -> Any:
        """
        从文件加载数据
        
        Args:
            file_path: 文件路径
            format_type: 文件格式 ('json', 'pickle', 'numpy')
            
        Returns:
            加载的数据
        """
        with LogContext(f"从文件加载数据 ({format_type})", logger):
            try:
                if not ValidationUtils.validate_file_exists(file_path):
                    raise FileNotFoundError(f"文件不存在: {file_path}")
                
                if format_type == 'json':
                    json_data = FileUtils.load_json(file_path)
                    return self.convert_from_json_format(json_data)
                elif format_type == 'pickle':
                    return FileUtils.load_pickle(file_path)
                elif format_type == 'numpy':
                    return np.load(file_path)
                else:
                    raise ValueError(f"不支持的文件格式: {format_type}")
                
            except Exception as e:
                error_msg = f"加载数据失败: {str(e)}"
                logger.error(error_msg)
                raise DataSerializationError(error_msg) from e
    
    def validate_data_integrity(self, data: Any) -> Tuple[bool, List[str]]:
        """
        验证数据完整性
        
        Args:
            data: 要验证的数据
            
        Returns:
            (是否完整, 问题列表)
        """
        try:
            issues = []
            
            if isinstance(data, FacadeData):
                # 验证立面数据完整性
                if not data.image_path:
                    issues.append("缺少图像路径")
                
                if data.image_width <= 0 or data.image_height <= 0:
                    issues.append("图像尺寸无效")
                
                if not any([data.windows, data.doors, data.walls]):
                    issues.append("缺少建筑元素")
                
                # 验证几何一致性
                calculated_window_area = sum(w.area for w in data.windows)
                if abs(calculated_window_area - data.total_window_area) > 1.0:
                    issues.append("窗户面积计算不一致")
            
            elif isinstance(data, list) and all(isinstance(item, BuildingElement) for item in data):
                # 验证建筑元素列表
                for i, element in enumerate(data):
                    if element.width <= 0 or element.height <= 0:
                        issues.append(f"元素[{i}]尺寸无效")
                    
                    if element.area <= 0:
                        issues.append(f"元素[{i}]面积无效")
            
            is_valid = len(issues) == 0
            
            if is_valid:
                logger.debug("数据完整性验证通过")
            else:
                logger.warning(f"数据完整性验证失败，发现 {len(issues)} 个问题")
            
            return is_valid, issues
            
        except Exception as e:
            error_msg = f"数据完整性验证失败: {str(e)}"
            logger.error(error_msg)
            return False, [error_msg]


def create_data_converter() -> DataStructureConverter:
    """
    创建数据结构转换器实例
    
    Returns:
        配置好的转换器实例
    """
    return DataStructureConverter()
