
"""
建筑元素提取器

该模块使用连通域分析提取独立建筑元素，实现轮廓检测和形状拟合算法。
"""

import numpy as np
import cv2
from typing import Dict, List, Tuple, Any
from scipy import ndimage
from sklearn.cluster import DBSCAN
import logging

class BuildingElementExtractor:
    """
    建筑元素提取器
    
    功能：
    1. 连通域分析提取独立建筑元素
    2. 轮廓检测和形状拟合算法
    3. 元素分类和属性计算
    4. 几何特征提取
    """
    
    def __init__(self):
        """初始化提取器"""
        self.logger = logging.getLogger(__name__)
        
        # 提取参数
        self.min_element_area = 100  # 最小元素面积
        self.max_element_area = 50000  # 最大元素面积
        self.connectivity = 8  # 连通性（4或8）
        
    def extract_elements(self, segmentation_result: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        从分割结果中提取建筑元素
        
        Args:
            segmentation_result: YOLO分割结果
            
        Returns:
            提取的建筑元素列表
        """
        try:
            mask = segmentation_result['segmentation_mask']
            detected_regions = segmentation_result['detected_regions']
            
            elements = []
            
            # 处理每个检测到的区域
            for region in detected_regions:
                # 提取区域掩码
                region_mask = self._extract_region_mask(mask, region)
                
                # 连通域分析
                connected_components = self._analyze_connected_components(region_mask)
                
                # 处理每个连通域
                for component in connected_components:
                    element = self._process_connected_component(component, region)
                    if element:
                        elements.append(element)
            
            # 元素后处理
            elements = self._post_process_elements(elements)
            
            self.logger.info(f"提取了 {len(elements)} 个建筑元素")
            
            return elements
            
        except Exception as e:
            self.logger.error(f"建筑元素提取失败: {str(e)}")
            raise
            
    def _extract_region_mask(self, mask: np.ndarray, region: Dict[str, Any]) -> np.ndarray:
        """提取区域掩码"""
        region_id = region['id']
        return (mask == region_id).astype(np.uint8)
        
    def _analyze_connected_components(self, mask: np.ndarray) -> List[Dict[str, Any]]:
        """分析连通域"""
        # 标记连通域
        labeled_mask, num_components = ndimage.label(mask, structure=np.ones((3, 3)))
        
        components = []
        
        for i in range(1, num_components + 1):
            component_mask = (labeled_mask == i)
            
            # 计算基本属性
            area = np.sum(component_mask)
            
            # 过滤太小或太大的组件
            if area < self.min_element_area or area > self.max_element_area:
                continue
                
            # 计算边界框
            coords = np.where(component_mask)
            y_min, y_max = np.min(coords[0]), np.max(coords[0])
            x_min, x_max = np.min(coords[1]), np.max(coords[1])
            
            # 计算质心
            centroid_y = np.mean(coords[0])
            centroid_x = np.mean(coords[1])
            
            component_info = {
                'mask': component_mask,
                'area': area,
                'bbox': (x_min, y_min, x_max - x_min, y_max - y_min),
                'centroid': (centroid_x, centroid_y),
                'coords': coords
            }
            
            components.append(component_info)
            
        return components
        
    def _process_connected_component(self, component: Dict[str, Any], 
                                   parent_region: Dict[str, Any]) -> Dict[str, Any]:
        """处理单个连通域"""
        try:
            # 基本信息
            element = {
                'id': f"{parent_region['id']}_{len(component['coords'][0])}",
                'type': parent_region['type'],
                'parent_region_id': parent_region['id'],
                'area': component['area'],
                'bbox': component['bbox'],
                'centroid': component['centroid']
            }
            
            # 几何特征提取
            geometric_features = self._extract_geometric_features(component)
            element.update(geometric_features)
            
            # 形状拟合
            shape_features = self._fit_shape(component)
            element.update(shape_features)
            
            # 元素分类
            classification = self._classify_element(element)
            element.update(classification)
            
            return element
            
        except Exception as e:
            self.logger.warning(f"处理连通域时出错: {str(e)}")
            return None
            
    def _extract_geometric_features(self, component: Dict[str, Any]) -> Dict[str, Any]:
        """提取几何特征"""
        mask = component['mask']
        
        # 计算周长
        contours, _ = cv2.findContours(mask.astype(np.uint8), 
                                     cv2.RETR_EXTERNAL, 
                                     cv2.CHAIN_APPROX_SIMPLE)
        
        if len(contours) == 0:
            return {}
            
        main_contour = max(contours, key=cv2.contourArea)
        perimeter = cv2.arcLength(main_contour, True)
        
        # 计算形状特征
        area = component['area']
        
        # 紧凑性（圆形度）
        compactness = (4 * np.pi * area) / (perimeter ** 2) if perimeter > 0 else 0
        
        # 长宽比
        x, y, w, h = component['bbox']
        aspect_ratio = w / h if h > 0 else 0
        
        # 填充率
        bbox_area = w * h
        fill_ratio = area / bbox_area if bbox_area > 0 else 0
        
        # 计算方向
        if len(main_contour) >= 5:
            ellipse = cv2.fitEllipse(main_contour)
            orientation = ellipse[2]  # 角度
        else:
            orientation = 0
            
        return {
            'perimeter': perimeter,
            'compactness': compactness,
            'aspect_ratio': aspect_ratio,
            'fill_ratio': fill_ratio,
            'orientation': orientation,
            'contour': main_contour
        }
        
    def _fit_shape(self, component: Dict[str, Any]) -> Dict[str, Any]:
        """形状拟合"""
        if 'contour' not in component or len(component['contour']) < 5:
            return {'shape_type': 'unknown'}
            
        contour = component['contour']
        
        # 多边形拟合
        epsilon = 0.02 * cv2.arcLength(contour, True)
        approx_poly = cv2.approxPolyDP(contour, epsilon, True)
        
        # 根据顶点数判断形状
        vertex_count = len(approx_poly)
        
        if vertex_count == 4:
            # 检查是否为矩形
            if self._is_rectangle(approx_poly):
                shape_type = 'rectangle'
            else:
                shape_type = 'quadrilateral'
        elif vertex_count == 3:
            shape_type = 'triangle'
        elif vertex_count > 6:
            shape_type = 'circle'
        else:
            shape_type = 'polygon'
            
        # 拟合椭圆
        ellipse = cv2.fitEllipse(contour)
        
        # 拟合最小外接矩形
        min_rect = cv2.minAreaRect(contour)
        
        return {
            'shape_type': shape_type,
            'vertex_count': vertex_count,
            'approx_polygon': approx_poly,
            'fitted_ellipse': ellipse,
            'min_area_rect': min_rect
        }
        
    def _is_rectangle(self, polygon: np.ndarray) -> bool:
        """检查多边形是否为矩形"""
        if len(polygon) != 4:
            return False
            
        # 计算角度
        angles = []
        for i in range(4):
            p1 = polygon[i][0]
            p2 = polygon[(i + 1) % 4][0]
            p3 = polygon[(i + 2) % 4][0]
            
            v1 = p1 - p2
            v2 = p3 - p2
            
            angle = np.arccos(np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2)))
            angles.append(np.degrees(angle))
            
        # 检查是否接近90度
        return all(abs(angle - 90) < 15 for angle in angles)
        
    def _classify_element(self, element: Dict[str, Any]) -> Dict[str, Any]:
        """元素分类"""
        element_type = element['type']
        
        if element_type == 'window':
            return self._classify_window(element)
        elif element_type == 'wall':
            return self._classify_wall(element)
        else:
            return {'classification': 'unknown'}
            
    def _classify_window(self, element: Dict[str, Any]) -> Dict[str, Any]:
        """窗户分类"""
        aspect_ratio = element.get('aspect_ratio', 1.0)
        area = element.get('area', 0)
        shape_type = element.get('shape_type', 'unknown')
        
        # 根据长宽比分类
        if aspect_ratio > 1.5:
            window_type = 'horizontal_window'
        elif aspect_ratio < 0.7:
            window_type = 'vertical_window'
        else:
            window_type = 'square_window'
            
        # 根据面积分类大小
        if area < 500:
            size_category = 'small'
        elif area < 2000:
            size_category = 'medium'
        else:
            size_category = 'large'
            
        return {
            'classification': 'window',
            'window_type': window_type,
            'size_category': size_category,
            'is_regular': shape_type == 'rectangle'
        }
        
    def _classify_wall(self, element: Dict[str, Any]) -> Dict[str, Any]:
        """墙体分类"""
        aspect_ratio = element.get('aspect_ratio', 1.0)
        area = element.get('area', 0)
        
        # 根据长宽比判断墙体类型
        if aspect_ratio > 3:
            wall_type = 'horizontal_wall'
        elif aspect_ratio < 0.3:
            wall_type = 'vertical_wall'
        else:
            wall_type = 'wall_section'
            
        return {
            'classification': 'wall',
            'wall_type': wall_type,
            'area_category': 'large' if area > 5000 else 'medium'
        }
        
    def _post_process_elements(self, elements: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """元素后处理"""
        # 去除重复元素
        elements = self._remove_duplicate_elements(elements)
        
        # 合并相邻元素
        elements = self._merge_adjacent_elements(elements)
        
        # 排序元素
        elements = sorted(elements, key=lambda x: (x['centroid'][1], x['centroid'][0]))
        
        # 重新分配ID
        for i, element in enumerate(elements):
            element['final_id'] = i + 1
            
        return elements
        
    def _remove_duplicate_elements(self, elements: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """去除重复元素"""
        if len(elements) <= 1:
            return elements
            
        # 基于质心位置聚类
        centroids = np.array([elem['centroid'] for elem in elements])
        
        # 使用DBSCAN聚类
        clustering = DBSCAN(eps=50, min_samples=1).fit(centroids)
        labels = clustering.labels_
        
        # 每个聚类保留面积最大的元素
        unique_elements = []
        for cluster_id in set(labels):
            cluster_elements = [elem for i, elem in enumerate(elements) if labels[i] == cluster_id]
            best_element = max(cluster_elements, key=lambda x: x['area'])
            unique_elements.append(best_element)
            
        return unique_elements
        
    def _merge_adjacent_elements(self, elements: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """合并相邻元素"""
        # 简化实现：如果两个同类型元素距离很近且大小相似，则合并
        merged_elements = []
        used_indices = set()
        
        for i, elem1 in enumerate(elements):
            if i in used_indices:
                continue
                
            merged_elem = elem1.copy()
            
            for j, elem2 in enumerate(elements[i+1:], i+1):
                if j in used_indices:
                    continue
                    
                # 检查是否应该合并
                if self._should_merge_elements(elem1, elem2):
                    merged_elem = self._merge_two_elements(merged_elem, elem2)
                    used_indices.add(j)
                    
            merged_elements.append(merged_elem)
            used_indices.add(i)
            
        return merged_elements
        
    def _should_merge_elements(self, elem1: Dict[str, Any], elem2: Dict[str, Any]) -> bool:
        """判断是否应该合并两个元素"""
        # 类型必须相同
        if elem1['type'] != elem2['type']:
            return False
            
        # 计算距离
        c1 = elem1['centroid']
        c2 = elem2['centroid']
        distance = np.sqrt((c1[0] - c2[0])**2 + (c1[1] - c2[1])**2)
        
        # 距离阈值
        avg_size = np.sqrt((elem1['area'] + elem2['area']) / 2)
        distance_threshold = avg_size * 0.5
        
        return distance < distance_threshold
        
    def _merge_two_elements(self, elem1: Dict[str, Any], elem2: Dict[str, Any]) -> Dict[str, Any]:
        """合并两个元素"""
        merged = elem1.copy()
        
        # 合并面积
        merged['area'] = elem1['area'] + elem2['area']
        
        # 重新计算质心
        total_area = merged['area']
        new_centroid_x = (elem1['centroid'][0] * elem1['area'] + 
                         elem2['centroid'][0] * elem2['area']) / total_area
        new_centroid_y = (elem1['centroid'][1] * elem1['area'] + 
                         elem2['centroid'][1] * elem2['area']) / total_area
        merged['centroid'] = (new_centroid_x, new_centroid_y)
        
        # 合并边界框
        bbox1 = elem1['bbox']
        bbox2 = elem2['bbox']
        
        x_min = min(bbox1[0], bbox2[0])
        y_min = min(bbox1[1], bbox2[1])
        x_max = max(bbox1[0] + bbox1[2], bbox2[0] + bbox2[2])
        y_max = max(bbox1[1] + bbox1[3], bbox2[1] + bbox2[3])
        
        merged['bbox'] = (x_min, y_min, x_max - x_min, y_max - y_min)
        
        return merged
