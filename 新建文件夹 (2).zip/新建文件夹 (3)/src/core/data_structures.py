
"""
核心数据结构定义
定义了系统中使用的所有核心数据类和结构
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Tuple
import numpy as np
from datetime import datetime


@dataclass
class BuildingElement:
    """
    建筑元素基础数据类
    用于存储从图像中提取的建筑元素信息
    """
    # 元素类型（window, door, shading, wall）
    element_type: str
    
    # 几何信息
    x: float  # X坐标（像素或米）
    y: float  # Y坐标（像素或米）
    width: float  # 宽度
    height: float  # 高度
    area: float  # 面积
    
    # 边界框信息
    bbox: Tuple[float, float, float, float]  # (x_min, y_min, x_max, y_max)
    
    # 轮廓信息
    contour: Optional[np.ndarray] = None  # 轮廓点坐标
    
    # 元素属性
    properties: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """初始化后处理，计算派生属性"""
        if self.area == 0:
            self.area = self.width * self.height
        
        # 计算中心点
        self.center_x = self.x + self.width / 2
        self.center_y = self.y + self.height / 2


@dataclass
class FacadeData:
    """
    立面数据类
    存储从图像处理模块提取的完整立面信息
    """
    # 原始图像信息
    image_path: str  # 图像文件路径
    image_width: int  # 图像宽度（像素）
    image_height: int  # 图像高度（像素）
    
    # 建筑元素列表
    windows: List[BuildingElement] = field(default_factory=list)  # 窗户列表
    doors: List[BuildingElement] = field(default_factory=list)    # 门列表
    shadings: List[BuildingElement] = field(default_factory=list) # 遮阳列表
    walls: List[BuildingElement] = field(default_factory=list)    # 墙体列表
    
    # 几何参数
    total_facade_area: float = 0.0      # 总立面面积
    total_window_area: float = 0.0      # 总窗户面积
    total_wall_area: float = 0.0        # 总墙体面积
    window_wall_ratio: float = 0.0      # 窗墙比
    
    # 约束信息
    constraints: Dict[str, Any] = field(default_factory=dict)
    
    # 元数据
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """计算派生的几何参数"""
        self.calculate_geometry_parameters()
    
    def calculate_geometry_parameters(self):
        """计算几何参数"""
        # 计算总窗户面积
        self.total_window_area = sum(window.area for window in self.windows)
        
        # 计算总墙体面积
        self.total_wall_area = sum(wall.area for wall in self.walls)
        
        # 计算总立面面积
        self.total_facade_area = self.total_window_area + self.total_wall_area
        
        # 计算窗墙比
        if self.total_wall_area > 0:
            self.window_wall_ratio = self.total_window_area / self.total_wall_area
        else:
            self.window_wall_ratio = 0.0
    
    def get_elements_by_type(self, element_type: str) -> List[BuildingElement]:
        """
        根据类型获取建筑元素
        
        Args:
            element_type: 元素类型 ('window', 'door', 'shading', 'wall')
            
        Returns:
            对应类型的建筑元素列表
        """
        type_mapping = {
            'window': self.windows,
            'door': self.doors,
            'shading': self.shadings,
            'wall': self.walls
        }
        return type_mapping.get(element_type, [])


@dataclass
class ClimateDataPoint:
    """
    单个时刻的气候数据点
    存储一小时的气候数据
    """
    # 时间信息
    month: int          # 月份 (1-12)
    day: int           # 日期 (1-31)
    hour: int          # 小时 (0-23)
    
    # 温度数据
    dry_bulb_temp: float        # 干球温度 (°C)
    wet_bulb_temp: float        # 湿球温度 (°C)
    dew_point_temp: float       # 露点温度 (°C)
    
    # 湿度数据
    relative_humidity: float    # 相对湿度 (%)
    
    # 辐射数据
    global_radiation: float     # 全球辐射 (Wh/m²)
    direct_radiation: float     # 直射辐射 (Wh/m²)
    diffuse_radiation: float    # 散射辐射 (Wh/m²)
    
    # 风数据
    wind_speed: float          # 风速 (m/s)
    wind_direction: float      # 风向 (度)
    
    # 大气数据
    atmospheric_pressure: float # 大气压力 (Pa)
    
    # 其他数据
    cloud_cover: float = 0.0   # 云量 (0-10)
    visibility: float = 0.0    # 能见度 (km)


@dataclass
class ClimateData:
    """
    完整的气候数据类
    存储全年8760小时的气候数据和相关信息
    """
    # 基本信息
    location_name: str          # 地点名称
    latitude: float            # 纬度
    longitude: float           # 经度
    elevation: float           # 海拔 (m)
    time_zone: float           # 时区
    
    # 小时数据（8760个数据点）
    hourly_data: List[ClimateDataPoint] = field(default_factory=list)
    
    # 设计工况
    design_conditions: Dict[str, Any] = field(default_factory=dict)
    
    # 季节模式
    seasonal_patterns: Dict[str, Any] = field(default_factory=dict)
    
    # 极端事件
    extreme_events: List[Dict[str, Any]] = field(default_factory=list)
    
    # 数据质量信息
    data_quality: Dict[str, Any] = field(default_factory=dict)
    
    # 建筑朝向调整系数
    orientation_factors: Dict[str, float] = field(default_factory=dict)
    
    def get_monthly_averages(self) -> Dict[int, Dict[str, float]]:
        """
        计算月平均值
        
        Returns:
            每月的平均气候数据
        """
        monthly_data = {}
        
        for month in range(1, 13):
            month_points = [point for point in self.hourly_data if point.month == month]
            
            if month_points:
                monthly_data[month] = {
                    'avg_temp': np.mean([p.dry_bulb_temp for p in month_points]),
                    'avg_humidity': np.mean([p.relative_humidity for p in month_points]),
                    'avg_radiation': np.mean([p.global_radiation for p in month_points]),
                    'avg_wind_speed': np.mean([p.wind_speed for p in month_points])
                }
        
        return monthly_data
    
    def get_seasonal_data(self, season: str) -> List[ClimateDataPoint]:
        """
        获取季节数据
        
        Args:
            season: 季节名称 ('spring', 'summer', 'autumn', 'winter')
            
        Returns:
            对应季节的气候数据点列表
        """
        season_months = {
            'spring': [3, 4, 5],      # 春季：3-5月
            'summer': [6, 7, 8],      # 夏季：6-8月
            'autumn': [9, 10, 11],    # 秋季：9-11月
            'winter': [12, 1, 2]      # 冬季：12-2月
        }
        
        target_months = season_months.get(season, [])
        return [point for point in self.hourly_data if point.month in target_months]


@dataclass
class Individual:
    """
    优化算法中的个体类
    表示一个优化解，包含所有可调参数
    """
    # 个体ID
    individual_id: str = ""
    
    # 窗户参数
    window_width_scales: np.ndarray = field(default_factory=lambda: np.array([]))   # 窗户宽度缩放因子
    window_height_scales: np.ndarray = field(default_factory=lambda: np.array([]))  # 窗户高度缩放因子
    window_positions_x: np.ndarray = field(default_factory=lambda: np.array([]))    # 窗户X位置偏移
    window_positions_y: np.ndarray = field(default_factory=lambda: np.array([]))    # 窗户Y位置偏移
    
    # 遮阳参数
    shading_widths: np.ndarray = field(default_factory=lambda: np.array([]))        # 遮阳宽度
    shading_depths: np.ndarray = field(default_factory=lambda: np.array([]))        # 遮阳深度
    shading_angles: np.ndarray = field(default_factory=lambda: np.array([]))        # 遮阳角度
    shading_types: np.ndarray = field(default_factory=lambda: np.array([]))         # 遮阳类型
    
    # 目标函数值
    objectives: Optional[List[float]] = None  # [能耗, 热舒适性, 热力性能]
    
    # 约束违反度
    constraint_violations: Optional[List[float]] = None
    
    # 适应度相关
    rank: int = 0                    # 非支配排序等级
    crowding_distance: float = 0.0   # 拥挤距离
    
    # 元数据
    generation: int = 0              # 所属代数
    parent_ids: List[str] = field(default_factory=list)  # 父代ID
    
    def __post_init__(self):
        """初始化后处理"""
        if not self.individual_id:
            # 生成唯一ID
            import uuid
            self.individual_id = str(uuid.uuid4())[:8]
    
    def copy(self) -> 'Individual':
        """创建个体的深拷贝"""
        import copy
        return copy.deepcopy(self)
    
    def is_feasible(self) -> bool:
        """检查个体是否满足所有约束"""
        if self.constraint_violations is None:
            return True
        return all(violation <= 0 for violation in self.constraint_violations)


@dataclass
class OptimizationResults:
    """
    优化结果数据类
    存储优化算法的完整结果
    """
    # 基本信息
    algorithm_name: str = "NSGA-III"     # 算法名称
    start_time: datetime = field(default_factory=datetime.now)  # 开始时间
    end_time: Optional[datetime] = None   # 结束时间
    
    # 优化参数
    population_size: int = 100           # 种群大小
    max_generations: int = 200           # 最大代数
    actual_generations: int = 0          # 实际运行代数
    
    # 结果数据
    pareto_solutions: List[Individual] = field(default_factory=list)      # 帕累托解
    best_5_solutions: List[Individual] = field(default_factory=list)      # 最佳5方案
    evolution_history: List[Dict[str, Any]] = field(default_factory=list) # 进化历史
    
    # 性能指标
    hypervolume: float = 0.0             # 超体积指标
    convergence_metric: float = 0.0      # 收敛性指标
    diversity_metric: float = 0.0        # 多样性指标
    
    # 统计信息
    total_evaluations: int = 0           # 总评估次数
    convergence_generation: int = 0      # 收敛代数
    
    # 元数据
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def get_execution_time(self) -> float:
        """
        获取执行时间（秒）
        
        Returns:
            执行时间，如果未结束则返回当前经过时间
        """
        end = self.end_time or datetime.now()
        return (end - self.start_time).total_seconds()
    
    def get_best_solution_by_objective(self, objective_index: int) -> Optional[Individual]:
        """
        根据目标函数获取最佳解
        
        Args:
            objective_index: 目标函数索引 (0:能耗, 1:热舒适性, 2:热力性能)
            
        Returns:
            对应目标的最佳个体
        """
        if not self.pareto_solutions:
            return None
        
        return min(self.pareto_solutions, 
                  key=lambda x: x.objectives[objective_index] if x.objectives else float('inf'))


@dataclass
class PerformanceMetrics:
    """
    性能评估指标数据类
    存储建筑性能评估的各项指标
    """
    # 能耗指标
    annual_energy_consumption: float = 0.0    # 年度总能耗 (kWh/m²)
    heating_energy: float = 0.0               # 供暖能耗 (kWh/m²)
    cooling_energy: float = 0.0               # 制冷能耗 (kWh/m²)
    lighting_energy: float = 0.0              # 照明能耗 (kWh/m²)
    
    # 热舒适性指标
    discomfort_hours: float = 0.0             # 不舒适小时数 (hours/year)
    pmv_deviation: float = 0.0                # PMV偏差
    ppd_average: float = 0.0                  # 平均PPD值
    
    # 热力性能指标
    overall_u_value: float = 0.0              # 整体传热系数 (W/m²·K)
    thermal_bridge_effect: float = 0.0        # 热桥效应
    thermal_inertia: float = 0.0              # 热惰性
    
    # 经济指标
    initial_cost: float = 0.0                 # 初始成本
    lifecycle_cost: float = 0.0               # 生命周期成本
    payback_period: float = 0.0               # 投资回收期 (年)
    
    # 环境指标
    co2_emissions: float = 0.0                # CO2排放量 (kg/m²·year)
    
    # 置信度和不确定性
    confidence_intervals: Dict[str, Tuple[float, float]] = field(default_factory=dict)
    uncertainty_factors: Dict[str, float] = field(default_factory=dict)
    
    def get_weighted_score(self, weights: Dict[str, float]) -> float:
        """
        计算加权综合得分
        
        Args:
            weights: 各指标权重字典
            
        Returns:
            加权综合得分
        """
        score = 0.0
        
        # 能耗得分（越低越好，需要归一化）
        if 'energy' in weights:
            score += weights['energy'] * (1.0 / (1.0 + self.annual_energy_consumption))
        
        # 舒适性得分（不舒适小时数越少越好）
        if 'comfort' in weights:
            score += weights['comfort'] * (1.0 / (1.0 + self.discomfort_hours / 8760))
        
        # 热力性能得分（传热系数越低越好）
        if 'thermal' in weights:
            score += weights['thermal'] * (1.0 / (1.0 + self.overall_u_value))
        
        return score


@dataclass
class ProjectData:
    """
    项目数据类
    存储完整项目的所有数据
    """
    # 项目基本信息
    project_name: str = ""               # 项目名称
    project_id: str = ""                 # 项目ID
    created_time: datetime = field(default_factory=datetime.now)  # 创建时间
    modified_time: datetime = field(default_factory=datetime.now) # 修改时间
    
    # 输入数据
    facade_data: Optional[FacadeData] = None      # 立面数据
    climate_data: Optional[ClimateData] = None    # 气候数据
    
    # 优化结果
    optimization_results: Optional[OptimizationResults] = None  # 优化结果
    
    # 性能评估结果
    performance_results: Dict[str, PerformanceMetrics] = field(default_factory=dict)
    
    # 可视化结果路径
    visualization_paths: Dict[str, str] = field(default_factory=dict)
    
    # 项目配置
    project_config: Dict[str, Any] = field(default_factory=dict)
    
    # 元数据
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """初始化后处理"""
        if not self.project_id:
            import uuid
            self.project_id = str(uuid.uuid4())
    
    def update_modified_time(self):
        """更新修改时间"""
        self.modified_time = datetime.now()
    
    def is_complete(self) -> bool:
        """检查项目是否完整（包含所有必要数据）"""
        return (self.facade_data is not None and 
                self.climate_data is not None and 
                self.optimization_results is not None)
