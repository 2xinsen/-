
"""
日志配置模块
提供统一的日志配置和管理功能
"""

import os
import sys
from pathlib import Path
from typing import Optional
from loguru import logger
from .config import config_manager


class LoggingManager:
    """日志管理器"""
    
    def __init__(self):
        """初始化日志管理器"""
        self._configured = False
        self.setup_logging()
    
    def setup_logging(self) -> None:
        """设置日志配置"""
        if self._configured:
            return
        
        # 移除默认的日志处理器
        logger.remove()
        
        # 获取日志配置
        log_config = config_manager.get('logging', {})
        log_level = log_config.get('level', 'INFO')
        log_format = log_config.get('format', 
            "{time:YYYY-MM-DD HH:mm:ss} | {level} | {name}:{function}:{line} | {message}")
        
        # 确保日志目录存在
        log_dir = Path("logs")
        log_dir.mkdir(exist_ok=True)
        
        # 控制台输出
        logger.add(
            sys.stdout,
            level=log_level,
            format=log_format,
            colorize=True,
            backtrace=True,
            diagnose=True
        )
        
        # 主日志文件
        main_log_file = log_config.get('files', {}).get('main', 'logs/main.log')
        logger.add(
            main_log_file,
            level=log_level,
            format=log_format,
            rotation=log_config.get('rotation', '1 day'),
            retention=log_config.get('retention', '30 days'),
            compression=log_config.get('compression', 'gz'),
            backtrace=True,
            diagnose=True
        )
        
        # 错误日志文件
        error_log_file = log_config.get('files', {}).get('error', 'logs/error.log')
        logger.add(
            error_log_file,
            level="ERROR",
            format=log_format,
            rotation=log_config.get('rotation', '1 day'),
            retention=log_config.get('retention', '30 days'),
            compression=log_config.get('compression', 'gz'),
            backtrace=True,
            diagnose=True
        )
        
        # 性能日志文件
        performance_log_file = log_config.get('files', {}).get('performance', 'logs/performance.log')
        logger.add(
            performance_log_file,
            level="INFO",
            format=log_format,
            rotation=log_config.get('rotation', '1 day'),
            retention=log_config.get('retention', '30 days'),
            compression=log_config.get('compression', 'gz'),
            filter=lambda record: "PERFORMANCE" in record["extra"]
        )
        
        self._configured = True
        logger.info("日志系统初始化完成")
    
    def get_logger(self, name: Optional[str] = None):
        """
        获取日志记录器
        
        Args:
            name: 日志记录器名称
            
        Returns:
            配置好的日志记录器
        """
        if name:
            return logger.bind(name=name)
        return logger
    
    def log_performance(self, operation: str, duration: float, **kwargs):
        """
        记录性能日志
        
        Args:
            operation: 操作名称
            duration: 执行时间（秒）
            **kwargs: 其他性能指标
        """
        performance_data = {
            "operation": operation,
            "duration": duration,
            **kwargs
        }
        
        logger.bind(PERFORMANCE=True).info(
            f"性能统计 - {operation}: {duration:.3f}s",
            extra={"performance_data": performance_data}
        )


# 全局日志管理器实例
logging_manager = LoggingManager()

# 便捷的日志记录器获取函数
def get_logger(name: Optional[str] = None):
    """获取日志记录器"""
    return logging_manager.get_logger(name)

# 性能日志记录函数
def log_performance(operation: str, duration: float, **kwargs):
    """记录性能日志"""
    logging_manager.log_performance(operation, duration, **kwargs)


# 性能监控装饰器
import time
import functools

def monitor_performance(operation_name: Optional[str] = None):
    """
    性能监控装饰器
    
    Args:
        operation_name: 操作名称，默认使用函数名
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            op_name = operation_name or f"{func.__module__}.{func.__name__}"
            
            try:
                result = func(*args, **kwargs)
                duration = time.time() - start_time
                log_performance(op_name, duration, status="success")
                return result
            except Exception as e:
                duration = time.time() - start_time
                log_performance(op_name, duration, status="error", error=str(e))
                raise
        
        return wrapper
    return decorator


# 日志上下文管理器
class LogContext:
    """日志上下文管理器"""
    
    def __init__(self, operation: str, logger_instance=None):
        """
        初始化日志上下文
        
        Args:
            operation: 操作名称
            logger_instance: 日志记录器实例
        """
        self.operation = operation
        self.logger = logger_instance or get_logger()
        self.start_time = None
    
    def __enter__(self):
        self.start_time = time.time()
        self.logger.info(f"开始执行: {self.operation}")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        duration = time.time() - self.start_time
        
        if exc_type is None:
            self.logger.info(f"完成执行: {self.operation} (耗时: {duration:.3f}s)")
            log_performance(self.operation, duration, status="success")
        else:
            self.logger.error(f"执行失败: {self.operation} (耗时: {duration:.3f}s) - {exc_val}")
            log_performance(self.operation, duration, status="error", error=str(exc_val))
        
        return False
