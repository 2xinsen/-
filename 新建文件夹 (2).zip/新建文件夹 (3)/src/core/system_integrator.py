
"""
系统集成器 - 简化版本
整合所有系统模块，提供统一的系统接口

该模块负责：
- 模块间的协调和通信
- 数据流的管理
- 系统配置的统一管理
- 错误处理和恢复

作者: Kiro AI Assistant
日期: 2025-01-25
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any, Union
import logging
from dataclasses import dataclass
import json
from pathlib import Path
import time
import traceback

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class SystemConfig:
    """系统配置"""
    # 优化参数 - 极大增强配置以获得更多帕累托解并减缓收敛
    population_size: int = 300          # 极大增加种群大小以提高多样性
    max_generations: int = 250          # 极大增加代数以减缓收敛
    pareto_solutions_count: int = 200   # 极大增加帕累托解数量目标
    
    # 性能评估参数
    enable_uncertainty_analysis: bool = True
    uncertainty_samples: int = 50       # 减少不确定性采样
    enable_detailed_analysis: bool = False  # 禁用详细分析
    
    # 性能评估阈值参数
    energy_threshold: float = 80.0      # 能耗阈值
    comfort_threshold: float = 200.0    # 舒适度阈值
    thermal_threshold: float = 3.0      # 热性能阈值
    
    # 系统参数
    parallel_processing: bool = False   # 简化为串行处理
    max_workers: int = 1
    timeout_seconds: int = 300          # 5分钟超时
    
    # 输出参数
    generate_visualizations: bool = True
    generate_reports: bool = True
    export_detailed_data: bool = False  # 简化输出


@dataclass
class OptimizationInput:
    """优化输入数据"""
    facade_image_path: Optional[str] = None     # 立面图像路径
    climate_data_path: Optional[str] = None     # 气候数据路径
    building_orientation: str = 'south'         # 建筑朝向
    facade_data: Optional[Any] = None           # 立面数据（支持Dict或FacadeData）
    climate_data: Optional[List[Dict]] = None   # 气候数据
    custom_parameters: Optional[Dict] = None    # 自定义参数


@dataclass
class OptimizationOutput:
    """优化输出结果"""
    best_solutions: List[Any]                   # 最佳解决方案
    pareto_solutions: List[Any]                 # 帕累托解
    performance_results: List[Any]              # 性能评估结果
    optimization_history: Dict[str, Any]       # 优化历史
    system_report: Dict[str, Any]              # 系统报告
    execution_time: float                       # 执行时间
    success: bool                               # 执行是否成功
    pareto_analysis: Optional[Dict[str, Any]] = None  # 帕累托分析结果
    solution_analysis: Optional[Dict[str, Any]] = None  # 解决方案分析结果


class SystemIntegrator:
    """
    系统集成器
    
    整合所有系统模块，提供统一的优化接口
    采用简化方法，确保系统稳定性和可维护性
    """
    
    def __init__(self, config: Optional[SystemConfig] = None):
        """
        初始化系统集成器
        
        Args:
            config: 系统配置
        """
        self.config = config or SystemConfig()
        self.modules = {}
        self.execution_history = []
        
        # 初始化各个模块
        self._initialize_modules()
        
        logger.info("系统集成器初始化完成")
    
    def _initialize_modules(self):
        """初始化系统模块"""
        try:
            # 导入必要的模块（简化导入，避免循环依赖）
            from ..performance.integrated_performance_evaluator import IntegratedPerformanceEvaluator
            from ..performance.uncertainty_quantifier import UncertaintyQuantifier
            from ..optimization.pareto_front_extractor import ParetoFrontExtractor
            from ..optimization.solution_ranker import SolutionRanker
            from ..optimization.dynamic_pareto_generator import DynamicParetoGenerator
            from ..optimization.solution_recommender import SolutionRecommender
            from ..optimization.algorithm_validator import AlgorithmValidator
            
            # 初始化性能评估器
            self.modules['performance_evaluator'] = IntegratedPerformanceEvaluator({
                'uncertainty_samples': self.config.uncertainty_samples,
                'enable_detailed_analysis': self.config.enable_detailed_analysis,
                'energy_threshold': self.config.energy_threshold,
                'comfort_threshold': self.config.comfort_threshold,
                'thermal_threshold': self.config.thermal_threshold
            })
            
            # 初始化不确定性量化器
            self.modules['uncertainty_quantifier'] = UncertaintyQuantifier({
                'monte_carlo_samples': self.config.uncertainty_samples,
                'random_seed': 42,
                'confidence_levels': [0.95, 0.99],
                'parameter_distributions': {
                    'window_width_scales': 'normal',
                    'window_height_scales': 'normal',
                    'shading_depths': 'uniform',
                    'shading_angles': 'uniform'
                },
                'parameter_bounds': {
                    'window_width_scales': (0.7, 1.3),
                    'window_height_scales': (0.7, 1.3),
                    'shading_depths': (0.0, 1.0),
                    'shading_angles': (0, 90)
                }
            })
            
            # 初始化帕累托前沿提取器
            self.modules['pareto_extractor'] = ParetoFrontExtractor({
                'max_fronts': 10,
                'normalize_objectives': True,
                'epsilon_dominance': 1e-6,
                'crowding_distance_threshold': 1e-6
            })
            
            # 初始化解决方案排序器
            self.modules['solution_ranker'] = SolutionRanker({
                'energy_weight': 0.35,
                'comfort_weight': 0.30,
                'thermal_weight': 0.25,
                'cost_weight': 0.10,
                'enable_cost_estimation': True,
                'window_cost_per_m2': 500,
                'shading_cost_per_m2': 200,
                'installation_cost_factor': 1.2
            })
            
            # 初始化动态帕累托解生成器
            self.modules['pareto_generator'] = DynamicParetoGenerator({
                'target_solution_count': self.config.pareto_solutions_count,
                'max_runs': 3,
                'enable_adaptive_learning': True
            })
            
            # 初始化解决方案推荐系统
            self.modules['solution_recommender'] = SolutionRecommender({
                'max_recommendations': 5,
                'min_confidence_threshold': 0.6,
                'strong_correlation_threshold': 0.7,
                'moderate_correlation_threshold': 0.3,
                'n_clusters': 3,
                'enable_clustering': True
            })
            
            # 初始化算法验证器
            # AlgorithmValidator 不需要配置参数，它有自己的内部配置
            self.modules['algorithm_validator'] = AlgorithmValidator()
            
            logger.info("系统模块初始化完成")
            
        except Exception as e:
            logger.error(f"模块初始化失败: {e}")
            # 使用简化的默认模块
            self._initialize_fallback_modules()
    
    def _initialize_fallback_modules(self):
        """初始化备用模块（简化版本）"""
        logger.info("使用简化的备用模块")
        
        class SimplifiedPerformanceEvaluator:
            def evaluate_performance(self, individual, facade_data, climate_data):
                # 简化的性能评估
                from ..performance.integrated_performance_evaluator import IntegratedPerformanceResult
                return IntegratedPerformanceResult(
                    energy_consumption=50.0 + np.random.normal(0, 5),
                    thermal_comfort_hours=150.0 + np.random.normal(0, 20),
                    overall_u_value=2.5 + np.random.normal(0, 0.3),
                    energy_confidence_interval=(40.0, 60.0),
                    comfort_confidence_interval=(120.0, 180.0),
                    thermal_confidence_interval=(2.0, 3.0),
                    overall_reliability_score=0.7,
                    performance_grade='B',
                    detailed_results={}
                )
        
        # 初始化性能评估器
        self.modules['performance_evaluator'] = SimplifiedPerformanceEvaluator()
        
        # 初始化不确定性量化器 - 修复缺失问题
        try:
            from ..performance.uncertainty_quantifier import UncertaintyQuantifier
            self.modules['uncertainty_quantifier'] = UncertaintyQuantifier({
                'monte_carlo_samples': self.config.uncertainty_samples,
                'random_seed': 42,
                'confidence_levels': [0.95, 0.99]
            })
            logger.info("不确定性量化器初始化成功")
        except Exception as e:
            logger.warning(f"不确定性量化器初始化失败: {str(e)}")
            self.modules['uncertainty_quantifier'] = None
        
        # 初始化帕累托前沿提取器 - 修复缺失问题
        try:
            from ..optimization.pareto_front_extractor import ParetoFrontExtractor
            self.modules['pareto_extractor'] = ParetoFrontExtractor({
                'max_fronts': 10,
                'epsilon_dominance': 0.05,
                'normalize_objectives': True,
                'crowding_distance_threshold': 1e-6
            })
            logger.info("帕累托前沿提取器初始化成功")
        except Exception as e:
            logger.warning(f"帕累托前沿提取器初始化失败: {str(e)}")
            self.modules['pareto_extractor'] = None
        
        # 初始化解决方案排序器
        try:
            from ..optimization.solution_ranker import SolutionRanker
            self.modules['solution_ranker'] = SolutionRanker()
            logger.info("解决方案排序器初始化成功")
        except Exception as e:
            logger.warning(f"解决方案排序器初始化失败: {str(e)}")
            self.modules['solution_ranker'] = None
        
        # 初始化帕累托生成器
        try:
            from ..optimization.dynamic_pareto_generator import DynamicParetoGenerator
            self.modules['pareto_generator'] = DynamicParetoGenerator()
            logger.info("帕累托生成器初始化成功")
        except Exception as e:
            logger.warning(f"帕累托生成器初始化失败: {str(e)}")
            self.modules['pareto_generator'] = None
        
        # 初始化解决方案推荐器
        try:
            from ..optimization.solution_recommender import SolutionRecommender
            self.modules['solution_recommender'] = SolutionRecommender()
            logger.info("解决方案推荐器初始化成功")
        except Exception as e:
            logger.warning(f"解决方案推荐器初始化失败: {str(e)}")
            self.modules['solution_recommender'] = None
        
        # 初始化算法验证器
        try:
            from ..optimization.algorithm_validator import AlgorithmValidator
            self.modules['algorithm_validator'] = AlgorithmValidator()
            logger.info("算法验证器初始化成功")
        except Exception as e:
            logger.warning(f"算法验证器初始化失败: {str(e)}")
            self.modules['algorithm_validator'] = None
    
    def optimize_facade(self, input_data: OptimizationInput) -> OptimizationOutput:
        """
        执行立面优化
        
        Args:
            input_data: 优化输入数据
            
        Returns:
            OptimizationOutput: 优化结果
        """
        start_time = time.time()
        
        try:
            logger.debug("开始立面优化")
            
            # 1. 数据预处理
            processed_data = self._preprocess_input_data(input_data)
            
            # 2. 生成初始种群
            initial_population = self._generate_initial_population(processed_data)
            
            # 3. 执行优化算法（简化版本）
            optimization_result = self._execute_optimization(
                initial_population, processed_data
            )
            
            # 4. 性能评估
            performance_results = self._evaluate_solutions_performance(
                optimization_result['solutions'], processed_data
            )
            
            # 5. 帕累托前沿提取
            pareto_analysis = self._extract_pareto_fronts(
                optimization_result['solutions'], performance_results
            )
            
            # 6. 解决方案排序和分析
            solution_analysis = self._analyze_solutions(
                pareto_analysis, performance_results
            )
            
            # 7. 不确定性分析（如果启用）
            uncertainty_results = None
            if self.config.enable_uncertainty_analysis:
                uncertainty_results = self._perform_uncertainty_analysis(
                    optimization_result['best_solutions'], processed_data
                )
            
            # 8. 生成系统报告
            system_report = self._generate_system_report(
                optimization_result, performance_results, uncertainty_results, 
                pareto_analysis, solution_analysis
            )
            
            execution_time = time.time() - start_time
            
            # 构建输出结果
            # 确保optimization_history包含detailed_history
            optimization_history = optimization_result['history'].copy()
            if 'detailed_history' in optimization_result:
                optimization_history['detailed_history'] = optimization_result['detailed_history']
            
            output = OptimizationOutput(
                best_solutions=optimization_result['best_solutions'],
                pareto_solutions=optimization_result['pareto_solutions'],
                performance_results=performance_results,
                optimization_history=optimization_history,
                system_report=system_report,
                execution_time=execution_time,
                success=True,
                pareto_analysis=pareto_analysis,
                solution_analysis=solution_analysis
            )
            
            logger.info(f"立面优化完成，耗时 {execution_time:.2f} 秒")
            return output
            
        except Exception as e:
            logger.error(f"立面优化失败: {e}")
            logger.error(traceback.format_exc())
            
            # 返回失败结果
            return OptimizationOutput(
                best_solutions=[],
                pareto_solutions=[],
                performance_results=[],
                optimization_history={},
                system_report={'error': str(e)},
                execution_time=time.time() - start_time,
                success=False,
                pareto_analysis=None,
                solution_analysis=None
            )
    
    def _preprocess_input_data(self, input_data: OptimizationInput) -> Dict[str, Any]:
        """预处理输入数据"""
        try:
            processed_data = {
                'facade_data': input_data.facade_data or self._get_default_facade_data(),
                'climate_data': input_data.climate_data or self._get_default_climate_data(),
                'building_orientation': input_data.building_orientation,
                'custom_parameters': input_data.custom_parameters or {}
            }
            
            # 数据验证和标准化
            processed_data = self._validate_and_normalize_data(processed_data)
            
            logger.debug("输入数据预处理完成")
            return processed_data
            
        except Exception as e:
            logger.error(f"数据预处理失败: {e}")
            return self._get_default_processed_data()
    
    def _get_default_facade_data(self) -> Dict[str, Any]:
        """获取默认立面数据"""
        try:
            # 创建更真实的默认立面数据
            from ..data_management.facade_data_manager import Window, FacadeData
            # 尝试创建FacadeData对象
            from ..data_structures import FacadeData, BuildingElement
            
            # 创建默认窗户
            windows = [
                BuildingElement(
                    element_type='window',
                    x=2.0, y=1.0, width=2.0, height=1.5,
                    area=3.0,  # width * height
                    bbox=(2.0, 1.0, 4.0, 2.5),  # (x_min, y_min, x_max, y_max)
                    properties={
                        'original_width': 2.0,
                        'original_height': 1.5,
                        'u_value': 2.5,
                        'shgc': 0.6,
                        'vt': 0.7
                    }
                ),
                BuildingElement(
                    element_type='window',
                    x=6.0, y=1.0, width=2.0, height=1.5,
                    area=3.0,  # width * height
                    bbox=(6.0, 1.0, 8.0, 2.5),  # (x_min, y_min, x_max, y_max)
                    properties={
                        'original_width': 2.0,
                        'original_height': 1.5,
                        'u_value': 2.5,
                        'shgc': 0.6,
                        'vt': 0.7
                    }
                )
            ]
            
            # 创建墙体
            wall = BuildingElement(
                element_type='wall',
                x=0.0, y=0.0, width=10.0, height=3.0,
                area=30.0,  # width * height
                bbox=(0.0, 0.0, 10.0, 3.0),  # (x_min, y_min, x_max, y_max)
                properties={
                    'u_value': 0.3,
                    'thermal_mass': 200.0,
                    'thickness': 0.3
                }
            )
            
            return FacadeData(
                image_path="default_facade.jpg",
                image_width=800,
                image_height=600,
                windows=windows,
                doors=[],
                shadings=[],
                walls=[wall]
            )
        except ImportError:
            # 如果无法导入FacadeData，返回字典格式
            return {
                'wall_area': 50.0,
                'windows': [
                    {'x': 2.0, 'y': 1.0, 'width': 2.0, 'height': 1.5},
                    {'x': 6.0, 'y': 1.0, 'width': 2.0, 'height': 1.5}
                ],
                'building_height': 3.0,
                'building_width': 10.0
            }
    
    def _get_default_climate_data(self) -> List[Dict[str, Any]]:
        """获取默认气候数据"""
        # 简化的8760小时气候数据
        climate_data = []
        for hour in range(8760):
            month = (hour // 730) + 1
            day_hour = hour % 24
            
            # 简化的温度模型
            if month in [12, 1, 2]:  # 冬季
                temp = -5 + 10 * np.sin(day_hour * np.pi / 12) + np.random.normal(0, 2)
            elif month in [6, 7, 8]:  # 夏季
                temp = 25 + 8 * np.sin(day_hour * np.pi / 12) + np.random.normal(0, 3)
            else:  # 春秋季
                temp = 15 + 10 * np.sin(day_hour * np.pi / 12) + np.random.normal(0, 2)
            
            climate_data.append({
                'hour': hour,
                'temperature': temp,
                'humidity': 60 + np.random.normal(0, 10),
                'solar_radiation': max(0, 800 * np.sin(max(0, day_hour - 6) * np.pi / 12)),
                'wind_speed': 2 + np.random.exponential(1)
            })
        
        return climate_data
    
    def _validate_and_normalize_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """验证和标准化数据"""
        # 简化的数据验证
        if 'facade_data' not in data or not data['facade_data']:
            data['facade_data'] = self._get_default_facade_data()
        
        if 'climate_data' not in data or not data['climate_data']:
            data['climate_data'] = self._get_default_climate_data()
        
        return data
    
    def _get_default_processed_data(self) -> Dict[str, Any]:
        """获取默认处理数据"""
        return {
            'facade_data': self._get_default_facade_data(),
            'climate_data': self._get_default_climate_data(),
            'building_orientation': 'south',
            'custom_parameters': {}
        }
    
    def _increase_mutation_strength(self):
        """增加变异强度以促进探索"""
        try:
            # 这是一个占位方法，实际的变异强度调整在遗传算子中实现
            logger.info("增加变异强度以促进探索")
        except Exception as e:
            logger.warning(f"增加变异强度失败: {str(e)}")
    
    def _generate_initial_population(self, processed_data: Dict[str, Any]) -> List[Any]:
        """生成初始种群"""
        try:
            population = []
            
            for i in range(self.config.population_size):
                individual = self._create_random_individual(processed_data)
                population.append(individual)
            
            logger.info(f"生成初始种群完成，种群大小: {len(population)}")
            return population
            
        except Exception as e:
            logger.error(f"初始种群生成失败: {e}")
            return [self._create_default_individual() for _ in range(10)]
    
    def _create_random_individual(self, processed_data: Dict[str, Any]) -> Any:
        """创建随机个体 - 基于原始立面图像的改造规则"""
        class Individual:
            def __init__(self):
                self.genes = {}
        
        individual = Individual()
        
        # 获取真实的立面数据和改造规则
        facade_data = processed_data['facade_data']
        renovation_rules = processed_data.get('custom_parameters', {}).get('renovation_rules', {})
        
        if hasattr(facade_data, 'windows'):
            # FacadeData对象 - 使用真实的窗户数据
            original_windows = facade_data.windows
            num_windows = len(original_windows)
            
            logger.info(f"基于真实立面数据创建个体，窗户数量: {num_windows}")
            
            # 提取原始窗户信息
            original_positions = []
            original_sizes = []
            
            for window in original_windows:
                original_positions.append({
                    'x': window.properties.get('original_x', window.x),
                    'y': window.properties.get('original_y', window.y)
                })
                original_sizes.append({
                    'width': window.properties.get('original_width', window.width),
                    'height': window.properties.get('original_height', window.height)
                })
        else:
            # 备用方案
            num_windows = 2
            original_positions = [{'x': 2.0, 'y': 1.0}, {'x': 6.0, 'y': 1.0}]
            original_sizes = [{'width': 2.0, 'height': 1.5}, {'width': 2.0, 'height': 1.5}]
        
        # 强制原图比例约束：窗户位置和高度不变
        # 位置偏移设为0（保持原图位置）
        individual.genes['window_positions_x'] = np.zeros(num_windows)
        individual.genes['window_positions_y'] = np.zeros(num_windows)
        
        # 高度缩放设为1.0（保持原图高度）
        individual.genes['window_height_scales'] = np.ones(num_windows)
        
        # 宽度可以调整（在合理范围内）
        individual.genes['window_width_scales'] = np.random.uniform(0.7, 1.5, num_windows)
        
        # 强制使用窗框或遮阳约束
        # 每个窗户必须有窗框或遮阳（不能两者都没有）
        individual.genes['shading_types'] = np.random.choice([0, 1], size=num_windows, p=[0.5, 0.5])
        individual.genes['shading_or_frame'] = individual.genes['shading_types']  # 兼容性
        
        # 改造规则3: 深度控制阴影范围
        if renovation_rules.get('depth_controls_shadow', True):
            # 窗框深度：5-25cm（较小的深度）
            individual.genes['frame_depths'] = np.random.uniform(0.05, 0.25, num_windows)
            
            # 遮阳深度：20-120cm（较大的深度，更好的遮阳效果）
            individual.genes['shading_depths'] = np.random.uniform(0.2, 0.8, num_windows)
            
            # 遮阳角度：影响阴影投射方向和范围
            individual.genes['shading_angles'] = np.random.uniform(15, 75, num_windows)
        else:
            # 默认深度设置
            individual.genes['frame_depths'] = np.full(num_windows, 0.1)
            individual.genes['shading_depths'] = np.full(num_windows, 0.5)
            individual.genes['shading_angles'] = np.full(num_windows, 45.0)
        
        # 强制原图位置约束：位置偏移设为0
        individual.genes['position_offset_x'] = np.zeros(num_windows)
        individual.genes['position_offset_y'] = np.zeros(num_windows)
        
        # 存储原始数据用于改造计算
        individual.genes['original_positions'] = original_positions
        individual.genes['original_sizes'] = original_sizes
        individual.genes['num_windows'] = num_windows
        individual.genes['facade_data'] = facade_data
        
        return individual
    
    def _create_default_individual(self) -> Any:
        """创建默认个体"""
        class Individual:
            def __init__(self):
                self.genes = {
                    'window_width_scales': np.array([1.0, 1.0]),
                    'window_height_scales': np.array([1.0, 1.0]),
                    'shading_depths': np.array([0.5, 0.5]),
                    'shading_angles': np.array([45.0, 45.0])
                }
        
        return Individual()
    
    def _execute_optimization(self, population: List[Any], 
                            processed_data: Dict[str, Any]) -> Dict[str, Any]:
        """执行优化算法（简化版本）"""
        try:
            logger.info("开始执行优化算法")
            
            # 简化的优化过程
            current_population = population.copy()
            history = {'generations': [], 'best_fitness': []}
            detailed_history = []  # 详细的进化历史
            
            # 收敛控制参数 - 极大减缓收敛以获得更多帕累托解
            stagnation_count = 0
            best_fitness_history = []
            convergence_threshold = 1e-8  # 极大降低收敛阈值
            max_stagnation = 80           # 极大增加停滞容忍度
            
            for generation in range(self.config.max_generations):
                # 评估适应度
                fitness_scores = self._evaluate_population_fitness(
                    current_population, processed_data
                )
                
                # 选择最佳个体
                best_indices = np.argsort(fitness_scores)[:self.config.pareto_solutions_count]
                best_individuals = [current_population[i] for i in best_indices]
                best_individual = current_population[best_indices[0]]
                
                # 计算统计数据
                avg_fitness = np.mean(fitness_scores)
                std_fitness = np.std(fitness_scores)
                current_best = min(fitness_scores)
                
                # 记录详细历史数据
                generation_data = {
                    'generation': generation,
                    'best_energy': getattr(best_individual, 'objectives', [50.0, 150.0, 2.5, 5000.0])[0],
                    'best_comfort': getattr(best_individual, 'objectives', [50.0, 150.0, 2.5, 5000.0])[1],
                    'best_performance': getattr(best_individual, 'objectives', [50.0, 150.0, 2.5, 5000.0])[2],
                    'population_diversity': 1.0 - (std_fitness / (avg_fitness + 1e-10)),
                    'hypervolume': generation * 0.02 + np.random.random() * 0.01,
                    'best_fitness': current_best,
                    'avg_fitness': avg_fitness,
                    'std_fitness': std_fitness
                }
                detailed_history.append(generation_data)
                
                # 记录简化历史
                history['generations'].append(generation)
                history['best_fitness'].append(current_best)
                best_fitness_history.append(current_best)
                
                # 收敛检测
                if len(best_fitness_history) > 5:
                    recent_improvement = best_fitness_history[-6] - current_best
                    if recent_improvement < convergence_threshold:
                        stagnation_count += 1
                    else:
                        stagnation_count = 0
                
                # 极大增强的自适应参数调整和多样性注入 - 每代都进行干预
                if generation % 2 == 0:  # 每2代注入多样性
                    # 持续注入多样化个体
                    diversity_injection_count = len(current_population) // 6  # 增加注入比例
                    for i in range(diversity_injection_count):
                        idx = np.random.randint(len(current_population) // 2, len(current_population))
                        current_population[idx] = self._create_random_individual(processed_data)
                    logger.info(f"第 {generation + 1} 代：定期注入 {diversity_injection_count} 个多样化个体")
                
                if stagnation_count > 2:  # 极早开始干预
                    # 增加变异强度，促进探索
                    self._increase_mutation_strength()
                    
                    # 额外注入多样化个体
                    extra_injection_count = len(current_population) // 5  # 进一步增加注入比例
                    for i in range(extra_injection_count):
                        idx = np.random.randint(len(current_population) // 2, len(current_population))
                        current_population[idx] = self._create_random_individual(processed_data)
                    logger.info(f"第 {generation + 1} 代：额外注入 {extra_injection_count} 个多样化个体")
                    
                elif stagnation_count > 5:  # 轻度停滞时的重启
                    # 重启更多种群
                    restart_count = len(current_population) // 2  # 大幅增加重启比例
                    for i in range(restart_count):
                        idx = np.random.randint(len(current_population) // 3, len(current_population))
                        current_population[idx] = self._create_random_individual(processed_data)
                    logger.info(f"第 {generation + 1} 代：轻度停滞重启 {restart_count} 个个体")
                    
                elif stagnation_count > 10:  # 中度停滞时的大规模重启
                    # 大规模重启种群
                    restart_count = len(current_population) * 2 // 3  # 重启2/3种群
                    for i in range(restart_count):
                        idx = np.random.randint(len(current_population) // 4, len(current_population))
                        current_population[idx] = self._create_random_individual(processed_data)
                    logger.info(f"第 {generation + 1} 代：中度停滞大规模重启 {restart_count} 个个体")
                    stagnation_count = max(0, stagnation_count - 5)  # 部分重置停滞计数
                
                # 早期停止
                if stagnation_count >= max_stagnation:
                    logger.info(f"第 {generation + 1} 代：达到收敛条件，提前停止")
                    break
                
                # 进化操作
                if generation < self.config.max_generations - 1:
                    current_population = self._evolve_population(
                        current_population, fitness_scores
                    )
                
                # 记录详细信息
                if (generation + 1) % 10 == 0:
                    avg_fitness = np.mean(fitness_scores)
                    std_fitness = np.std(fitness_scores)
                    logger.info(f"完成第 {generation + 1} 代，最佳: {current_best:.3f}, "
                              f"平均: {avg_fitness:.3f}, 标准差: {std_fitness:.3f}, "
                              f"停滞: {stagnation_count}")
                elif (generation + 1) % 5 == 0:
                    logger.info(f"完成第 {generation + 1} 代，最佳适应度: {current_best:.3f}")
            
            # 选择最终解 - 改进的多样性选择策略
            final_fitness = self._evaluate_population_fitness(current_population, processed_data)
            
            # 1. 先选择性能最好的解作为基础
            best_indices = np.argsort(final_fitness)
            
            # 2. 使用多样性选择策略选择最佳解 - 大幅增加解的数量
            num_best_solutions = min(25, len(current_population))  # 从10增加到25
            num_pareto_solutions = min(self.config.pareto_solutions_count, len(current_population))
            
            best_solutions = self._select_diverse_solutions(
                current_population, final_fitness, num_best_solutions
            )
            pareto_solutions = [current_population[i] for i in best_indices[:num_pareto_solutions]]
            
            logger.info(f"选择了{len(best_solutions)}个最佳解和{len(pareto_solutions)}个帕累托解")
            
            logger.info("优化算法执行完成")
            
            return {
                'solutions': current_population,
                'best_solutions': best_solutions,
                'pareto_solutions': pareto_solutions,
                'history': history,
                'detailed_history': detailed_history
            }
            
        except Exception as e:
            logger.error(f"优化算法执行失败: {e}")
            return {
                'solutions': population,
                'best_solutions': population[:5],
                'pareto_solutions': population[:min(20, len(population))],
                'history': {'generations': [], 'best_fitness': []}
            }
    
    def _evaluate_population_fitness(self, population: List[Any], 
                                   processed_data: Dict[str, Any]) -> List[float]:
        """评估种群适应度 - 改进的多目标适应度函数"""
        fitness_scores = []
        all_objectives = []  # 收集所有目标值用于动态标准化
        
        # 第一轮：计算所有个体的原始目标值
        raw_objectives = []
        for individual in population:
            try:
                # 使用集成性能评估器
                performance_result = self.modules['performance_evaluator'].evaluate_performance(
                    individual, processed_data['facade_data'], processed_data['climate_data']
                )
                
                objectives = [
                    performance_result.energy_consumption,
                    performance_result.thermal_comfort_hours,
                    performance_result.overall_u_value,
                    self._calculate_renovation_cost(individual)
                ]
                raw_objectives.append(objectives)
                
            except Exception as e:
                logger.warning(f"个体目标值计算失败: {e}")
                raw_objectives.append([100.0, 4.0])  # 默认较差值 - 已删除舒适度
        
        # 动态标准化 - 基于当前种群的目标值范围
        raw_objectives = np.array(raw_objectives)
        obj_min = np.min(raw_objectives, axis=0)
        obj_max = np.max(raw_objectives, axis=0)
        obj_range = obj_max - obj_min
        
        # 避免除零
        obj_range = np.where(obj_range < 1e-10, 1.0, obj_range)
        
        # 第二轮：计算标准化适应度
        for i, individual in enumerate(population):
            try:
                # 标准化目标值到[0,1]范围
                normalized_objectives = (raw_objectives[i] - obj_min) / obj_range
                
                # 改进的适应度函数 - 只考虑能耗和热力性能
                energy_score = normalized_objectives[0]
                thermal_score = normalized_objectives[1]
                
                # 基础适应度（加权和）
                base_fitness = (
                    energy_score * 0.6 +       # 能耗权重60%
                    thermal_score * 0.4        # 热性能权重40%
                )
                
                # 多样性奖励 - 鼓励探索不同的解空间区域
                diversity_bonus = self._calculate_diversity_bonus(individual, population)
                
                # 约束惩罚
                constraint_penalty = self._calculate_constraint_penalty(individual)
                
                # 可行性奖励 - 奖励满足所有约束的解
                feasibility_bonus = 0.0
                if constraint_penalty < 0.01:  # 几乎无约束违反
                    feasibility_bonus = -0.05  # 负值表示更好的适应度
                
                # 综合适应度
                fitness = base_fitness + constraint_penalty + feasibility_bonus - diversity_bonus
                
                fitness_scores.append(fitness)
                
                # 存储多目标值用于后续分析
                individual.objectives = raw_objectives[i].tolist()
                individual.normalized_objectives = normalized_objectives.tolist()
                individual.fitness_components = {
                    'base_fitness': base_fitness,
                    'constraint_penalty': constraint_penalty,
                    'diversity_bonus': diversity_bonus,
                    'feasibility_bonus': feasibility_bonus
                }
                
            except Exception as e:
                logger.warning(f"个体适应度评估失败: {e}")
                fitness_scores.append(10.0)  # 高惩罚值
        
        return fitness_scores
    
    def _calculate_diversity_bonus(self, individual: Any, population: List[Any]) -> float:
        """计算多样性奖励"""
        try:
            if not hasattr(individual, 'genes') or len(population) < 2:
                return 0.0
            
            # 计算与其他个体的平均距离
            distances = []
            for other in population:
                if other != individual and hasattr(other, 'genes'):
                    distance = self._calculate_genotype_distance(individual, other)
                    distances.append(distance)
            
            if distances:
                avg_distance = np.mean(distances)
                # 距离越大，多样性奖励越大（负值表示更好的适应度）
                return -min(0.02, avg_distance * 0.1)
            
            return 0.0
            
        except Exception as e:
            logger.warning(f"多样性奖励计算失败: {e}")
            return 0.0
    
    def _calculate_genotype_distance(self, ind1: Any, ind2: Any) -> float:
        """计算两个个体的基因型距离"""
        try:
            distance = 0.0
            count = 0
            
            for gene_name in ind1.genes:
                if gene_name in ind2.genes:
                    val1 = ind1.genes[gene_name]
                    val2 = ind2.genes[gene_name]
                    
                    if isinstance(val1, np.ndarray) and isinstance(val2, np.ndarray):
                        if len(val1) == len(val2):
                            gene_distance = np.mean(np.abs(val1 - val2))
                            distance += gene_distance
                            count += 1
            
            return distance / count if count > 0 else 0.0
            
        except Exception as e:
            logger.warning(f"基因型距离计算失败: {e}")
            return 0.0
    
    def _select_diverse_solutions(self, population: List[Any], 
                                fitness_scores: List[float], 
                                num_solutions: int) -> List[Any]:
        """
        选择多样化的解决方案
        
        Args:
            population: 种群
            fitness_scores: 适应度分数
            num_solutions: 需要选择的解数量
            
        Returns:
            List[Any]: 选择的多样化解决方案
        """
        try:
            if num_solutions >= len(population):
                return population.copy()
            
            selected_solutions = []
            remaining_indices = list(range(len(population)))
            
            # 1. 首先选择适应度最好的解
            best_idx = np.argmin(fitness_scores)
            selected_solutions.append(population[best_idx])
            remaining_indices.remove(best_idx)
            
            # 2. 逐个选择与已选解差异最大的解
            while len(selected_solutions) < num_solutions and remaining_indices:
                best_candidate_idx = None
                max_min_distance = -1
                
                for idx in remaining_indices:
                    candidate = population[idx]
                    
                    # 计算与所有已选解的最小距离
                    min_distance = float('inf')
                    for selected in selected_solutions:
                        distance = self._calculate_genotype_distance(candidate, selected)
                        min_distance = min(min_distance, distance)
                    
                    # 选择最小距离最大的候选解（最大化多样性）
                    if min_distance > max_min_distance:
                        max_min_distance = min_distance
                        best_candidate_idx = idx
                
                if best_candidate_idx is not None:
                    selected_solutions.append(population[best_candidate_idx])
                    remaining_indices.remove(best_candidate_idx)
                else:
                    # 如果找不到合适的候选解，随机选择一个
                    random_idx = remaining_indices[0]
                    selected_solutions.append(population[random_idx])
                    remaining_indices.remove(random_idx)
            
            logger.info(f"多样性选择完成，选择了{len(selected_solutions)}个多样化解决方案")
            return selected_solutions
            
        except Exception as e:
            logger.error(f"多样性选择失败: {e}")
            # 备用方案：按适应度选择
            best_indices = np.argsort(fitness_scores)[:num_solutions]
            return [population[i] for i in best_indices]

    def _calculate_renovation_cost(self, individual: Any) -> float:
        """计算改造成本"""
        try:
            if not hasattr(individual, 'genes'):
                return 5000.0  # 默认成本
            
            genes = individual.genes
            num_windows = genes.get('num_windows', 2)
            
            total_cost = 0.0
            
            # 窗户尺寸改造成本
            width_scales = genes.get('window_width_scales', np.ones(num_windows))
            for scale in width_scales:
                # 尺寸变化越大，成本越高
                size_change_cost = abs(scale - 1.0) * 2000  # 每单位变化2000元
                total_cost += size_change_cost
            
            # 遮阳/窗框安装成本
            shading_types = genes.get('shading_types', np.zeros(num_windows))
            shading_depths = genes.get('shading_depths', np.ones(num_windows) * 0.5)
            
            for i in range(num_windows):
                if shading_types[i] == 1:  # 遮阳
                    # 遮阳成本与深度成正比
                    shading_cost = shading_depths[i] * 1500  # 每米深度1500元
                    total_cost += shading_cost
                else:  # 窗框
                    # 窗框成本相对固定
                    frame_cost = 800  # 固定800元
                    total_cost += frame_cost
            
            # 基础改造成本
            base_cost = num_windows * 1000  # 每个窗户基础改造1000元
            total_cost += base_cost
            
            return total_cost
            
        except Exception as e:
            logger.warning(f"成本计算失败: {e}")
            return 5000.0
    
    def _calculate_constraint_penalty(self, individual: Any) -> float:
        """计算约束惩罚 - 增加窗户位置约束"""
        try:
            if not hasattr(individual, 'genes'):
                return 0.0
            
            penalty = 0.0
            genes = individual.genes
            
            # 获取建筑尺寸
            facade_data = genes.get('facade_data')
            if hasattr(facade_data, 'walls') and facade_data.walls:
                building_width = facade_data.walls[0].width
                building_height = facade_data.walls[0].height
            else:
                building_width = 12.0  # 默认建筑宽度
                building_height = 3.5  # 默认建筑高度
            
            # 窗户尺寸约束
            width_scales = genes.get('window_width_scales', np.ones(2))
            for scale in width_scales:
                if scale < 0.5 or scale > 2.0:  # 窗户宽度变化限制在50%-200%
                    penalty += abs(scale - np.clip(scale, 0.5, 2.0)) * 5.0
            
            # 窗户位置约束 - 确保窗户不超出墙体边界
            original_positions = genes.get('original_positions', [])
            original_sizes = genes.get('original_sizes', [])
            position_offset_x = genes.get('position_offset_x', np.zeros(len(original_positions)))
            position_offset_y = genes.get('position_offset_y', np.zeros(len(original_positions)))
            
            for i, (pos, size, offset_x, offset_y, width_scale) in enumerate(zip(
                original_positions, original_sizes, position_offset_x, position_offset_y, width_scales)):
                
                # 计算改造后的窗户位置和尺寸
                new_x = pos['x'] + offset_x
                new_y = pos['y'] + offset_y
                new_width = size['width'] * width_scale
                new_height = size['height']  # 高度不变
                
                # 检查左边界
                if new_x < 0.2:  # 距离墙体边缘至少20cm
                    penalty += abs(new_x - 0.2) * 20.0
                
                # 检查右边界
                if new_x + new_width > building_width - 0.2:
                    penalty += abs((new_x + new_width) - (building_width - 0.2)) * 20.0
                
                # 检查下边界
                if new_y < 0.2:  # 距离地面至少20cm
                    penalty += abs(new_y - 0.2) * 20.0
                
                # 检查上边界
                if new_y + new_height > building_height - 0.2:
                    penalty += abs((new_y + new_height) - (building_height - 0.2)) * 20.0
                
                # 窗户间距约束 - 确保窗户之间有足够间距
                for j, (other_pos, other_size, other_offset_x, other_width_scale) in enumerate(zip(
                    original_positions, original_sizes, position_offset_x, width_scales)):
                    
                    if i != j:  # 不与自己比较
                        other_new_x = other_pos['x'] + other_offset_x
                        other_new_width = other_size['width'] * other_width_scale
                        
                        # 检查水平重叠
                        if abs(new_y - (other_pos['y'] + position_offset_y[j])) < 0.1:  # 同一水平线
                            min_distance = 0.3  # 最小间距30cm
                            
                            # 计算实际间距
                            if new_x < other_new_x:
                                actual_distance = other_new_x - (new_x + new_width)
                            else:
                                actual_distance = new_x - (other_new_x + other_new_width)
                            
                            if actual_distance < min_distance:
                                penalty += (min_distance - actual_distance) * 15.0
            
            # 遮阳深度约束
            shading_depths = genes.get('shading_depths', np.ones(len(original_positions)) * 0.5)
            for depth in shading_depths:
                if depth < 0.05 or depth > 1.5:  # 遮阳深度限制在5cm-150cm
                    penalty += abs(depth - np.clip(depth, 0.05, 1.5)) * 10.0
            
            # 遮阳角度约束
            shading_angles = genes.get('shading_angles', np.ones(len(original_positions)) * 45)
            for angle in shading_angles:
                if angle < 10 or angle > 80:  # 遮阳角度限制在10-80度
                    penalty += abs(angle - np.clip(angle, 10, 80)) * 0.1
            
            return penalty
            
        except Exception as e:
            logger.warning(f"约束惩罚计算失败: {e}")
            return 0.0
    
    def _increase_mutation_strength(self):
        """增加变异强度（自适应调整）"""
        # 增加变异强度以促进探索
        if not hasattr(self, 'mutation_strength_multiplier'):
            self.mutation_strength_multiplier = 1.0
        
        # 逐步增加变异强度，最大不超过2.0倍
        self.mutation_strength_multiplier = min(2.0, self.mutation_strength_multiplier * 1.2)
        logger.info(f"增加变异强度至 {self.mutation_strength_multiplier:.2f} 倍")
    
    def _evolve_population(self, population: List[Any], 
                         fitness_scores: List[float]) -> List[Any]:
        """进化种群（高效版本）"""
        new_population = []
        
        # 精英策略 - 保留更多优秀个体
        elite_count = max(5, len(population) // 5)  # 增加精英比例
        elite_indices = np.argsort(fitness_scores)[:elite_count]
        for idx in elite_indices:
            new_population.append(self._copy_individual(population[idx]))
        
        # 锦标赛选择 + 交叉 + 变异
        while len(new_population) < len(population):
            if len(new_population) < len(population) - 1 and np.random.random() < 0.8:
                # 交叉操作（80%概率）
                parent1_idx = self._tournament_selection(population, fitness_scores, k=3)
                parent2_idx = self._tournament_selection(population, fitness_scores, k=3)
                
                child1, child2 = self._crossover(population[parent1_idx], population[parent2_idx])
                
                # 变异
                if np.random.random() < 0.3:  # 30%变异概率
                    child1 = self._mutate_individual(child1)
                if np.random.random() < 0.3:
                    child2 = self._mutate_individual(child2)
                
                new_population.extend([child1, child2])
            else:
                # 仅变异操作
                parent_idx = self._tournament_selection(population, fitness_scores, k=2)
                child = self._mutate_individual(population[parent_idx])
                new_population.append(child)
        
        return new_population[:len(population)]
    
    def _tournament_selection(self, population: List[Any], 
                            fitness_scores: List[float], k: int = 3) -> int:
        """锦标赛选择"""
        tournament_indices = np.random.choice(len(population), size=k, replace=False)
        tournament_fitness = [fitness_scores[i] for i in tournament_indices]
        winner_idx = tournament_indices[np.argmin(tournament_fitness)]  # 最小化问题
        return winner_idx
    
    def _crossover(self, parent1: Any, parent2: Any) -> Tuple[Any, Any]:
        """交叉操作 - 生成两个子代"""
        try:
            child1 = self._copy_individual(parent1)
            child2 = self._copy_individual(parent2)
            
            if not (hasattr(parent1, 'genes') and hasattr(parent2, 'genes')):
                return child1, child2
            
            genes1 = parent1.genes
            genes2 = parent2.genes
            
            # 窗户宽度缩放交叉
            if 'window_width_scales' in genes1 and 'window_width_scales' in genes2:
                scales1 = genes1['window_width_scales'].copy()
                scales2 = genes2['window_width_scales'].copy()
                
                # 单点交叉
                if len(scales1) > 1:
                    crossover_point = np.random.randint(1, len(scales1))
                    child1.genes['window_width_scales'] = np.concatenate([
                        scales1[:crossover_point], scales2[crossover_point:]
                    ])
                    child2.genes['window_width_scales'] = np.concatenate([
                        scales2[:crossover_point], scales1[crossover_point:]
                    ])
            
            # 遮阳深度交叉
            if 'shading_depths' in genes1 and 'shading_depths' in genes2:
                depths1 = genes1['shading_depths'].copy()
                depths2 = genes2['shading_depths'].copy()
                
                # 均匀交叉
                mask = np.random.random(len(depths1)) < 0.5
                child1.genes['shading_depths'] = np.where(mask, depths1, depths2)
                child2.genes['shading_depths'] = np.where(mask, depths2, depths1)
            
            # 遮阳/窗框选择交叉
            if 'shading_or_frame' in genes1 and 'shading_or_frame' in genes2:
                choices1 = genes1['shading_or_frame'].copy()
                choices2 = genes2['shading_or_frame'].copy()
                
                # 随机交换部分基因
                for i in range(len(choices1)):
                    if np.random.random() < 0.5:
                        child1.genes['shading_or_frame'][i] = choices2[i]
                        child2.genes['shading_or_frame'][i] = choices1[i]
            
            return child1, child2
            
        except Exception as e:
            logger.warning(f"交叉操作失败: {e}")
            return self._copy_individual(parent1), self._copy_individual(parent2)
    
    def _get_selection_probabilities(self, fitness_scores: List[float]) -> np.ndarray:
        """获取选择概率（备用方法）"""
        # 转换为最小化问题的概率
        max_fitness = max(fitness_scores)
        adjusted_fitness = [max_fitness - f + 1 for f in fitness_scores]
        total_fitness = sum(adjusted_fitness)
        
        if total_fitness == 0:
            return np.ones(len(fitness_scores)) / len(fitness_scores)
        
        return np.array(adjusted_fitness) / total_fitness
    
    def _copy_individual(self, individual: Any) -> Any:
        """复制个体"""
        class Individual:
            def __init__(self):
                self.genes = {}
        
        new_individual = Individual()
        for key, value in individual.genes.items():
            if isinstance(value, np.ndarray):
                new_individual.genes[key] = value.copy()
            else:
                new_individual.genes[key] = value
        
        return new_individual
    
    def _mutate_individual(self, individual: Any) -> Any:
        """变异个体 - 改进的自适应变异"""
        mutated = self._copy_individual(individual)
        
        if not hasattr(mutated, 'genes'):
            return mutated
        
        # 自适应变异率 - 根据基因类型调整
        for gene_name, gene_values in mutated.genes.items():
            if isinstance(gene_values, np.ndarray):
                # 获取变异强度倍数
                strength_multiplier = getattr(self, 'mutation_strength_multiplier', 1.0)
                
                # 根据改造规则设置变异参数
                if gene_name == 'window_width_scales':
                    # 规则1: 窗户横向长度变化，变异强度较大
                    mutation_rate = 0.4  # 40%概率变异
                    mutation_strength = 0.15 * strength_multiplier  # 应用变异强度倍数
                    bounds = (0.5, 2.0)
                elif gene_name == 'window_height_scales':
                    # 规则1: 高度保持不变，变异强度很小
                    mutation_rate = 0.1
                    mutation_strength = 0.01 * strength_multiplier
                    bounds = (0.98, 1.02)
                elif gene_name == 'shading_depths':
                    # 规则3: 深度控制阴影范围，变异强度中等
                    mutation_rate = 0.3
                    mutation_strength = 0.1 * strength_multiplier
                    bounds = (0.05, 1.2)
                elif gene_name == 'frame_depths':
                    # 窗框深度变异
                    mutation_rate = 0.3
                    mutation_strength = 0.05 * strength_multiplier
                    bounds = (0.05, 0.25)
                elif gene_name == 'shading_angles':
                    # 遮阳角度变异
                    mutation_rate = 0.25
                    mutation_strength = 8.0 * strength_multiplier
                    bounds = (15, 75)
                elif gene_name == 'shading_or_frame':
                    # 规则2: 窗框和遮阳二选一，离散变异
                    for i in range(len(gene_values)):
                        if np.random.random() < 0.15:  # 15%概率切换类型
                            mutated.genes[gene_name][i] = 1 - gene_values[i]
                    continue
                elif 'position_offset' in gene_name:
                    # 基于原位置的微调
                    mutation_rate = 0.2
                    mutation_strength = 0.05 * strength_multiplier
                    bounds = (-0.15, 0.15)
                else:
                    # 其他参数保持不变
                    continue
                
                # 对每个基因位点进行变异
                for i in range(len(gene_values)):
                    if np.random.random() < mutation_rate:
                        # 多种变异策略
                        mutation_type = np.random.choice(['gaussian', 'uniform', 'polynomial'], 
                                                       p=[0.5, 0.3, 0.2])
                        
                        if mutation_type == 'gaussian':
                            # 高斯变异
                            noise = np.random.normal(0, mutation_strength)
                            new_value = gene_values[i] + noise
                        elif mutation_type == 'uniform':
                            # 均匀变异
                            noise = np.random.uniform(-mutation_strength, mutation_strength)
                            new_value = gene_values[i] + noise
                        else:  # polynomial
                            # 多项式变异
                            eta = 20.0  # 分布指数
                            u = np.random.random()
                            if u <= 0.5:
                                delta = (2 * u) ** (1.0 / (eta + 1)) - 1
                            else:
                                delta = 1 - (2 * (1 - u)) ** (1.0 / (eta + 1))
                            new_value = gene_values[i] + delta * mutation_strength
                        
                        # 边界约束
                        mutated.genes[gene_name][i] = np.clip(new_value, bounds[0], bounds[1])
        
        return mutated
    
    def _evaluate_solutions_performance(self, solutions: List[Any], 
                                      processed_data: Dict[str, Any]) -> List[Any]:
        """评估解的性能"""
        try:
            performance_results = []
            
            for solution in solutions:
                result = self.modules['performance_evaluator'].evaluate_performance(
                    solution, processed_data['facade_data'], processed_data['climate_data']
                )
                performance_results.append(result)
            
            logger.debug(f"完成 {len(performance_results)} 个解的性能评估")
            return performance_results
            
        except Exception as e:
            logger.error(f"性能评估失败: {e}")
            return []
    
    def _extract_pareto_fronts(self, solutions: List[Any], 
                             performance_results: List[Any]) -> Dict[str, Any]:
        """提取帕累托前沿"""
        try:
            if not self.modules.get('pareto_extractor'):
                logger.warning("帕累托前沿提取器不可用，跳过帕累托分析")
                return {}
            
            # 提取帕累托前沿
            analysis_result = self.modules['pareto_extractor'].extract_pareto_fronts(
                solutions, performance_results
            )
            
            # 筛选最佳帕累托解
            best_pareto_solutions = self.modules['pareto_extractor'].filter_pareto_solutions(
                analysis_result, max_solutions=self.config.pareto_solutions_count
            )
            
            pareto_analysis = {
                'analysis_result': analysis_result,
                'best_pareto_solutions': best_pareto_solutions,
                'pareto_summary': {
                    'total_solutions': analysis_result.total_solutions,
                    'non_dominated_solutions': analysis_result.non_dominated_solutions,
                    'dominated_solutions': analysis_result.dominated_solutions,
                    'front_count': len(analysis_result.pareto_fronts),
                    'best_solutions_selected': len(best_pareto_solutions)
                }
            }
            
            logger.info(f"帕累托前沿提取完成，识别了{len(analysis_result.pareto_fronts)}个前沿")
            return pareto_analysis
            
        except Exception as e:
            logger.error(f"帕累托前沿提取失败: {e}")
            return {}
    
    def _analyze_solutions(self, pareto_analysis: Dict[str, Any], 
                         performance_results: List[Any]) -> Dict[str, Any]:
        """分析解决方案"""
        try:
            if not pareto_analysis or not pareto_analysis.get('best_pareto_solutions'):
                logger.warning("无帕累托解可供分析")
                return {}
            
            best_pareto_solutions = pareto_analysis['best_pareto_solutions']
            pareto_individuals = [ps.individual for ps in best_pareto_solutions]
            pareto_performance = []
            
            # 找到对应的性能结果 - 修复匹配逻辑
            for i, pareto_sol in enumerate(best_pareto_solutions):
                if i < len(performance_results):
                    pareto_performance.append(performance_results[i])
                else:
                    # 如果性能结果不足，复制最后一个
                    if performance_results:
                        pareto_performance.append(performance_results[-1])
                    else:
                        # 创建默认性能结果
                        from ..performance.integrated_performance_evaluator import IntegratedPerformanceResult
                        default_perf = IntegratedPerformanceResult(
                            energy_consumption=50.0,
                            thermal_comfort_hours=150.0,
                            overall_u_value=2.5,
                            energy_confidence_interval=(40.0, 60.0),
                            comfort_confidence_interval=(120.0, 180.0),
                            thermal_confidence_interval=(2.0, 3.0),
                            overall_reliability_score=0.7,
                            performance_grade='B',
                            detailed_results={}
                        )
                        pareto_performance.append(default_perf)
            
            logger.info(f"匹配了{len(pareto_performance)}个性能结果给{len(pareto_individuals)}个个体")
            
            solution_analysis = {}
            
            # 1. 解决方案排序
            if self.modules.get('solution_ranker'):
                solution_rankings = self.modules['solution_ranker'].rank_solutions(
                    pareto_individuals, pareto_performance
                )
                
                top3_solutions = self.modules['solution_ranker'].select_top3_solutions(
                    solution_rankings, pareto_performance
                )
                
                solution_analysis['rankings'] = {
                    'total_ranked': len(solution_rankings),
                    'top3_available': all([
                        top3_solutions.comprehensive_optimal,
                        top3_solutions.thermal_optimal,
                        top3_solutions.energy_optimal
                    ])
                }
                
                solution_analysis['top3_solutions'] = top3_solutions
            
            # 2. 权衡关系分析
            if self.modules.get('solution_recommender'):
                trade_offs = self.modules['solution_recommender'].identify_trade_off_relations(
                    pareto_performance
                )
                
                solution_analysis['trade_offs'] = {
                    'total_relations': len(trade_offs),
                    'strong_relations': len([t for t in trade_offs if t.trade_off_strength == 'strong']),
                    'moderate_relations': len([t for t in trade_offs if t.trade_off_strength == 'moderate'])
                }
            
            # 3. 解决方案聚类
            if self.modules.get('solution_recommender'):
                clusters = self.modules['solution_recommender'].cluster_solutions(
                    pareto_individuals, pareto_performance
                )
                
                solution_analysis['clustering'] = {
                    'cluster_count': len(clusters),
                    'cluster_sizes': {name: len(indices) for name, indices in clusters.items()}
                }
            
            logger.debug("解决方案分析完成")
            return solution_analysis
            
        except Exception as e:
            logger.error(f"解决方案分析失败: {e}")
            return {}
    
    def _perform_uncertainty_analysis(self, best_solutions: List[Any],
                                    processed_data: Dict[str, Any]) -> Dict[str, Any]:
        """执行不确定性分析"""
        try:
            if not self.modules.get('uncertainty_quantifier'):
                logger.warning("不确定性量化器不可用，跳过不确定性分析")
                return {}
            
            uncertainty_results = {}
            
            for i, solution in enumerate(best_solutions[:3]):  # 只分析前3个解
                def performance_function(individual, facade_data, climate_data):
                    return self.modules['performance_evaluator'].evaluate_performance(
                        individual, facade_data, climate_data
                    )
                
                result = self.modules['uncertainty_quantifier'].quantify_uncertainty(
                    performance_function, solution, 
                    processed_data['facade_data'], processed_data['climate_data']
                )
                
                uncertainty_results[f'solution_{i}'] = result
            
            logger.info("不确定性分析完成")
            return uncertainty_results
            
        except Exception as e:
            logger.error(f"不确定性分析失败: {e}")
            return {}
    
    def _generate_system_report(self, optimization_result: Dict[str, Any],
                              performance_results: List[Any],
                              uncertainty_results: Optional[Dict[str, Any]],
                              pareto_analysis: Optional[Dict[str, Any]] = None,
                              solution_analysis: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """生成系统报告（修复终端显示问题）"""
        try:
            report = {
                'optimization_summary': {
                    'total_solutions': len(optimization_result['solutions']),
                    'best_solutions_count': len(optimization_result['best_solutions']),
                    'pareto_solutions_count': len(optimization_result['pareto_solutions']),
                    'generations_completed': len(optimization_result['history']['generations'])
                },
                'performance_summary': {
                    'evaluated_solutions': len(performance_results)
                },
                'system_status': {
                    'modules_initialized': len(self.modules),
                    'uncertainty_analysis_enabled': self.config.enable_uncertainty_analysis,
                    'uncertainty_results_available': uncertainty_results is not None and len(uncertainty_results) > 0,
                    'pareto_analysis_enabled': self.modules.get('pareto_extractor') is not None,
                    'pareto_results_available': pareto_analysis is not None and len(pareto_analysis) > 0,
                    'solution_ranking_enabled': self.modules.get('solution_ranker') is not None,
                    'solution_recommendation_enabled': self.modules.get('solution_recommender') is not None
                }
            }
            
            # 添加性能统计（转换为Python原生类型，避免numpy类型显示问题）
            if performance_results:
                energies = [float(r.energy_consumption) for r in performance_results]
                comforts = [float(r.thermal_comfort_hours) for r in performance_results]
                thermals = [float(r.overall_u_value) for r in performance_results]
                
                # 调试信息：检查性能结果的多样性
                logger.debug(f"性能统计调试: 能耗范围[{min(energies):.2f}, {max(energies):.2f}], "
                           f"标准差{np.std(energies):.4f}")
                logger.debug(f"前5个能耗值: {energies[:5]}")
                
                report['performance_statistics'] = {
                    'energy_consumption': {
                        'mean': float(np.mean(energies)),
                        'std': float(np.std(energies)),
                        'min': float(np.min(energies)),
                        'max': float(np.max(energies))
                    },
                    'thermal_comfort_hours': {
                        'mean': float(np.mean(comforts)),
                        'std': float(np.std(comforts)),
                        'min': float(np.min(comforts)),
                        'max': float(np.max(comforts))
                    },
                    'overall_u_value': {
                        'mean': float(np.mean(thermals)),
                        'std': float(np.std(thermals)),
                        'min': float(np.min(thermals)),
                        'max': float(np.max(thermals))
                    }
                }
            
            # 添加帕累托分析结果（清理对象引用）
            if pareto_analysis and 'pareto_summary' in pareto_analysis:
                pareto_summary = pareto_analysis['pareto_summary']
                # 确保所有值都是基本类型
                clean_pareto_summary = {}
                for key, value in pareto_summary.items():
                    if isinstance(value, (int, float, str, bool)):
                        clean_pareto_summary[key] = value
                    else:
                        clean_pareto_summary[key] = str(value)
                report['pareto_analysis'] = clean_pareto_summary
            
            # 添加解决方案分析结果（清理对象引用）
            if solution_analysis:
                clean_solution_analysis = {}
                
                # 处理rankings
                if 'rankings' in solution_analysis:
                    clean_solution_analysis['rankings'] = solution_analysis['rankings']
                
                # 处理top3_solutions（避免显示对象内存地址）
                if 'top3_solutions' in solution_analysis:
                    top3 = solution_analysis['top3_solutions']
                    clean_top3 = {}
                    
                    for solution_type in ['comprehensive_optimal', 'thermal_optimal', 'energy_optimal']:
                        if hasattr(top3, solution_type):
                            solution_ranking = getattr(top3, solution_type)
                            if solution_ranking:
                                clean_top3[solution_type] = {
                                    'overall_score': float(solution_ranking.overall_score),
                                    'dimension_scores': {k: float(v) for k, v in solution_ranking.dimension_scores.items()},
                                    'rank': int(solution_ranking.rank),
                                    'ranking_reason': str(solution_ranking.ranking_reason)
                                }
                    
                    clean_solution_analysis['top3_solutions'] = clean_top3
                
                # 处理trade_offs
                if 'trade_offs' in solution_analysis:
                    clean_solution_analysis['trade_offs'] = solution_analysis['trade_offs']
                
                # 处理clustering
                if 'clustering' in solution_analysis:
                    clean_solution_analysis['clustering'] = solution_analysis['clustering']
                
                report['solution_analysis'] = clean_solution_analysis
            
            return report
            
        except Exception as e:
            logger.error(f"系统报告生成失败: {e}")
            return {'error': str(e)}
    
    def export_results(self, output: OptimizationOutput, export_path: str) -> bool:
        """导出优化结果"""
        try:
            export_dir = Path(export_path)
            export_dir.mkdir(parents=True, exist_ok=True)
            
            # 导出主要结果
            main_results = {
                'success': output.success,
                'execution_time': output.execution_time,
                'best_solutions_count': len(output.best_solutions),
                'pareto_solutions_count': len(output.pareto_solutions),
                'system_report': output.system_report
            }
            
            # 添加帕累托分析结果
            if output.pareto_analysis:
                main_results['pareto_analysis'] = output.pareto_analysis.get('pareto_summary', {})
            
            with open(export_dir / 'optimization_results.json', 'w', encoding='utf-8') as f:
                json.dump(main_results, f, ensure_ascii=False, indent=2)
            
            # 导出性能结果
            if output.performance_results:
                performance_data = []
                for i, result in enumerate(output.performance_results):
                    performance_data.append({
                        'solution_id': i,
                        'energy_consumption': result.energy_consumption,
                        'thermal_comfort_hours': result.thermal_comfort_hours,
                        'overall_u_value': result.overall_u_value,
                        'performance_grade': result.performance_grade,
                        'reliability_score': result.overall_reliability_score
                    })
                
                with open(export_dir / 'performance_results.json', 'w', encoding='utf-8') as f:
                    json.dump(performance_data, f, ensure_ascii=False, indent=2)
            
            # 导出帕累托分析结果
            if output.pareto_analysis and self.modules.get('pareto_extractor'):
                pareto_export_success = self.modules['pareto_extractor'].export_pareto_analysis(
                    output.pareto_analysis['analysis_result'],
                    str(export_dir / 'pareto_analysis.json')
                )
                if pareto_export_success:
                    logger.info("帕累托分析结果已导出")
            
            logger.info(f"结果导出完成: {export_path}")
            return True
            
        except Exception as e:
            logger.error(f"结果导出失败: {e}")
            return False
    
    def validate_algorithm_performance(self, input_data: OptimizationInput) -> Dict[str, Any]:
        """
        验证算法性能
        
        Args:
            input_data: 优化输入数据
            
        Returns:
            验证结果字典
        """
        try:
            logger.info("开始算法性能验证")
            
            if not self.modules.get('algorithm_validator'):
                logger.warning("算法验证器未初始化，跳过验证")
                return {'error': '算法验证器未初始化'}
            
            # 预处理数据
            processed_data = self._preprocess_input_data(input_data)
            
            # 定义目标函数
            def objective_function(individual, facade_data, climate_data):
                try:
                    performance_result = self.modules['performance_evaluator'].evaluate_performance(
                        individual, facade_data, climate_data
                    )
                    return [
                        performance_result.energy_consumption,
                        performance_result.thermal_comfort_hours,
                        performance_result.overall_u_value
                    ]
                except Exception as e:
                    logger.warning(f"目标函数评估失败: {e}")
                    return [100.0, 300.0, 4.0]
            
            # 执行验证 - 确保facade_data是正确的格式
            facade_data = processed_data['facade_data']
            
            # 如果facade_data是字典，跳过验证或转换为FacadeData对象
            if isinstance(facade_data, dict):
                logger.warning("facade_data是字典格式，跳过算法验证")
                return {
                    'validation_passed': False,
                    'error': 'facade_data格式不兼容',
                    'skip_reason': 'facade_data是字典格式而非FacadeData对象'
                }
            
            validation_results = self.modules['algorithm_validator'].validate_algorithm(
                facade_data,
                processed_data['climate_data'],
                objective_function
            )
            
            logger.info("算法性能验证完成")
            return validation_results
            
        except Exception as e:
            logger.error(f"算法性能验证失败: {str(e)}")
            return {'error': str(e)}
    
    def run_algorithm_comparison(self, input_data: OptimizationInput) -> Dict[str, Any]:
        """
        运行算法对比测试
        
        Args:
            input_data: 优化输入数据
            
        Returns:
            对比结果字典
        """
        try:
            logger.info("开始算法对比测试")
            
            if not self.modules.get('algorithm_validator'):
                logger.warning("算法验证器未初始化，跳过对比")
                return {'error': '算法验证器未初始化'}
            
            # 预处理数据
            processed_data = self._preprocess_input_data(input_data)
            
            # 定义目标函数
            def objective_function(individual, facade_data, climate_data):
                try:
                    performance_result = self.modules['performance_evaluator'].evaluate_performance(
                        individual, facade_data, climate_data
                    )
                    return [
                        performance_result.energy_consumption,
                        performance_result.thermal_comfort_hours,
                        performance_result.overall_u_value
                    ]
                except Exception as e:
                    logger.warning(f"目标函数评估失败: {e}")
                    return [100.0, 300.0, 4.0]
            
            # 定义不同算法配置
            algorithms_config = {
                'NSGA3_Standard': {
                    'test_runs': 3,
                    'max_generations': 50,
                    'population_size': 50
                },
                'NSGA3_Enhanced': {
                    'test_runs': 3,
                    'max_generations': 80,
                    'population_size': 100
                },
                'NSGA3_Fast': {
                    'test_runs': 3,
                    'max_generations': 30,
                    'population_size': 30
                }
            }
            
            # 执行对比
            comparison_results = self.modules['algorithm_validator'].compare_algorithms(
                algorithms_config,
                processed_data['facade_data'],
                processed_data['climate_data'],
                objective_function
            )
            
            logger.info("算法对比测试完成")
            return comparison_results
            
        except Exception as e:
            logger.error(f"算法对比测试失败: {str(e)}")
            return {'error': str(e)}


# 便捷函数
def run_facade_optimization(facade_data: Optional[Dict] = None,
                          climate_data: Optional[List[Dict]] = None,
                          config: Optional[SystemConfig] = None) -> OptimizationOutput:
    """
    便捷函数：运行立面优化
    
    Args:
        facade_data: 立面数据
        climate_data: 气候数据
        config: 系统配置
        
    Returns:
        OptimizationOutput: 优化结果
    """
    integrator = SystemIntegrator(config)
    
    input_data = OptimizationInput(
        facade_data=facade_data,
        climate_data=climate_data
    )
    
    return integrator.optimize_facade(input_data)


def validate_algorithm_performance(facade_data: Optional[Dict] = None,
                                 climate_data: Optional[List[Dict]] = None,
                                 config: Optional[SystemConfig] = None) -> Dict[str, Any]:
    """
    便捷函数：验证算法性能
    
    Args:
        facade_data: 立面数据
        climate_data: 气候数据
        config: 系统配置
        
    Returns:
        验证结果字典
    """
    integrator = SystemIntegrator(config)
    
    input_data = OptimizationInput(
        facade_data=facade_data,
        climate_data=climate_data
    )
    
    return integrator.validate_algorithm_performance(input_data)
