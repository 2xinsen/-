
"""
配置管理模块
负责加载和管理系统配置
"""

import os
import yaml
from pathlib import Path
from typing import Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class SystemConfig:
    """系统配置数据类"""
    name: str
    version: str
    debug: bool
    log_level: str
    max_workers: int


@dataclass
class ImageProcessingConfig:
    """图像处理配置数据类"""
    color_mapping: Dict[str, list]
    preprocessing: Dict[str, Any]
    constraints: Dict[str, float]


@dataclass
class OptimizationConfig:
    """优化算法配置数据类"""
    nsga3: Dict[str, Any]
    parameter_bounds: Dict[str, list]
    convergence: Dict[str, Any]


class ConfigManager:
    """配置管理器"""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化配置管理器
        
        Args:
            config_path: 配置文件路径，默认为项目根目录下的config.yaml
        """
        if config_path is None:
            # 获取项目根目录
            project_root = Path(__file__).parent.parent.parent
            config_path = project_root / "config.yaml"
        
        self.config_path = Path(config_path)
        self._config_data = None
        self.load_config()
    
    def load_config(self) -> None:
        """加载配置文件"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                self._config_data = yaml.safe_load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"配置文件未找到: {self.config_path}")
        except yaml.YAMLError as e:
            raise ValueError(f"配置文件格式错误: {e}")
    
    def get_system_config(self) -> SystemConfig:
        """获取系统配置"""
        system_data = self._config_data.get('system', {})
        return SystemConfig(
            name=system_data.get('name', '建筑立面优化系统'),
            version=system_data.get('version', '1.0.0'),
            debug=system_data.get('debug', False),
            log_level=system_data.get('log_level', 'INFO'),
            max_workers=system_data.get('max_workers', 4)
        )
    
    def get_image_processing_config(self) -> ImageProcessingConfig:
        """获取图像处理配置"""
        img_data = self._config_data.get('image_processing', {})
        return ImageProcessingConfig(
            color_mapping=img_data.get('color_mapping', {}),
            preprocessing=img_data.get('preprocessing', {}),
            constraints=img_data.get('constraints', {})
        )
    
    def get_optimization_config(self) -> OptimizationConfig:
        """获取优化算法配置"""
        opt_data = self._config_data.get('optimization', {})
        return OptimizationConfig(
            nsga3=opt_data.get('nsga3', {}),
            parameter_bounds=opt_data.get('parameter_bounds', {}),
            convergence=opt_data.get('convergence', {})
        )
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        获取配置值
        
        Args:
            key: 配置键，支持点号分隔的嵌套键，如 'system.debug'
            default: 默认值
            
        Returns:
            配置值
        """
        keys = key.split('.')
        value = self._config_data
        
        try:
            for k in keys:
                value = value[k]
            return value
        except (KeyError, TypeError):
            return default
    
    def set(self, key: str, value: Any) -> None:
        """
        设置配置值
        
        Args:
            key: 配置键，支持点号分隔的嵌套键
            value: 配置值
        """
        keys = key.split('.')
        config = self._config_data
        
        # 导航到目标位置
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        # 设置值
        config[keys[-1]] = value
    
    def save_config(self) -> None:
        """保存配置到文件"""
        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                yaml.dump(self._config_data, f, default_flow_style=False, 
                         allow_unicode=True, indent=2)
        except Exception as e:
            raise IOError(f"保存配置文件失败: {e}")


# 全局配置管理器实例
config_manager = ConfigManager()
