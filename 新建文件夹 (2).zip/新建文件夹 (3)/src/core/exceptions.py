
"""
系统异常类层次结构
定义了建筑立面优化系统中使用的所有异常类
"""

from typing import Optional, Any


class OptimizationSystemError(Exception):
    """系统基础异常类"""
    
    def __init__(self, message: str, error_code: Optional[str] = None, 
                 details: Optional[dict] = None):
        """
        初始化异常
        
        Args:
            message: 错误消息
            error_code: 错误代码
            details: 错误详细信息
        """
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.details = details or {}
    
    def __str__(self) -> str:
        error_str = self.message
        if self.error_code:
            error_str = f"[{self.error_code}] {error_str}"
        return error_str


class ImageProcessingError(OptimizationSystemError):
    """图像处理异常"""
    pass


class YOLOSegmentationError(ImageProcessingError):
    """YOLO分割处理异常"""
    pass


class BuildingElementExtractionError(ImageProcessingError):
    """建筑元素提取异常"""
    pass


class GeometryCalculationError(ImageProcessingError):
    """几何参数计算异常"""
    pass


class ClimateDataError(OptimizationSystemError):
    """气候数据异常"""
    pass


class EPWParsingError(ClimateDataError):
    """EPW文件解析异常"""
    pass


class ClimateDataQualityError(ClimateDataError):
    """气候数据质量异常"""
    pass


class OrientationAdjustmentError(ClimateDataError):
    """朝向调整异常"""
    pass


class OptimizationError(OptimizationSystemError):
    """优化算法异常"""
    pass


class NSGA3Error(OptimizationError):
    """NSGA-III算法异常"""
    pass


class ObjectiveFunctionError(OptimizationError):
    """目标函数计算异常"""
    pass


class ConstraintViolationError(OptimizationError):
    """约束违反异常"""
    pass


class ConvergenceError(OptimizationError):
    """收敛异常"""
    pass


class PerformanceEvaluationError(OptimizationSystemError):
    """性能评估异常"""
    pass


class EnergyCalculationError(PerformanceEvaluationError):
    """能耗计算异常"""
    pass


class ThermalComfortError(PerformanceEvaluationError):
    """热舒适性评估异常"""
    pass


class ThermalPerformanceError(PerformanceEvaluationError):
    """热力性能分析异常"""
    pass


class SolutionSelectionError(OptimizationSystemError):
    """解筛选异常"""
    pass


class ParetoFrontExtractionError(SolutionSelectionError):
    """帕累托前沿提取异常"""
    pass


class SolutionRankingError(SolutionSelectionError):
    """解排序异常"""
    pass


class VisualizationError(OptimizationSystemError):
    """可视化异常"""
    pass


class ChartGenerationError(VisualizationError):
    """图表生成异常"""
    pass


class ReportGenerationError(VisualizationError):
    """报告生成异常"""
    pass


class UIError(OptimizationSystemError):
    """用户界面异常"""
    pass


class FileUploadError(UIError):
    """文件上传异常"""
    pass


class DataValidationError(UIError):
    """数据验证异常"""
    pass


class DataManagementError(OptimizationSystemError):
    """数据管理异常"""
    pass


class ProjectManagementError(DataManagementError):
    """项目管理异常"""
    pass


class DataSerializationError(DataManagementError):
    """数据序列化异常"""
    pass


class BackupError(DataManagementError):
    """备份异常"""
    pass


class CacheError(DataManagementError):
    """缓存异常"""
    pass


# 异常处理装饰器
def handle_exceptions(exception_type: type = OptimizationSystemError, 
                     default_return: Any = None, 
                     log_error: bool = True):
    """
    异常处理装饰器
    
    Args:
        exception_type: 要捕获的异常类型
        default_return: 异常时的默认返回值
        log_error: 是否记录错误日志
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except exception_type as e:
                if log_error:
                    # 这里可以集成日志记录
                    print(f"异常捕获: {e}")
                return default_return
            except Exception as e:
                if log_error:
                    print(f"未预期异常: {e}")
                raise OptimizationSystemError(
                    f"函数 {func.__name__} 执行失败: {str(e)}"
                )
        return wrapper
    return decorator


# 异常上下文管理器
class ExceptionContext:
    """异常上下文管理器"""
    
    def __init__(self, operation_name: str, 
                 exception_type: type = OptimizationSystemError):
        """
        初始化异常上下文
        
        Args:
            operation_name: 操作名称
            exception_type: 异常类型
        """
        self.operation_name = operation_name
        self.exception_type = exception_type
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            # 将原始异常包装为系统异常
            if not isinstance(exc_val, OptimizationSystemError):
                raise self.exception_type(
                    f"{self.operation_name} 执行失败: {str(exc_val)}",
                    details={"original_exception": str(exc_val)}
                ) from exc_val
        return False
