
"""
工具函数库
提供几何计算、数据转换等通用功能
"""

import numpy as np
import math
from typing import List, Tuple, Dict, Any, Optional, Union
from pathlib import Path
import json
import pickle
import cv2
from PIL import Image


class GeometryUtils:
    """几何计算工具类"""
    
    @staticmethod
    def calculate_distance(point1: Tuple[float, float], point2: Tuple[float, float]) -> float:
        """
        计算两点间的欧几里得距离
        
        Args:
            point1: 第一个点的坐标 (x, y)
            point2: 第二个点的坐标 (x, y)
            
        Returns:
            两点间的距离
        """
        return math.sqrt((point1[0] - point2[0])**2 + (point1[1] - point2[1])**2)
    
    @staticmethod
    def calculate_area_from_contour(contour: np.ndarray) -> float:
        """
        从轮廓计算面积
        
        Args:
            contour: 轮廓点数组
            
        Returns:
            轮廓围成的面积
        """
        if contour is None or len(contour) < 3:
            return 0.0
        return cv2.contourArea(contour)
    
    @staticmethod
    def calculate_bounding_box(contour: np.ndarray) -> Tuple[float, float, float, float]:
        """
        计算轮廓的边界框
        
        Args:
            contour: 轮廓点数组
            
        Returns:
            边界框 (x_min, y_min, x_max, y_max)
        """
        if contour is None or len(contour) == 0:
            return (0, 0, 0, 0)
        
        x_coords = contour[:, 0, 0] if len(contour.shape) == 3 else contour[:, 0]
        y_coords = contour[:, 0, 1] if len(contour.shape) == 3 else contour[:, 1]
        
        return (float(np.min(x_coords)), float(np.min(y_coords)), 
                float(np.max(x_coords)), float(np.max(y_coords)))
    
    @staticmethod
    def calculate_centroid(contour: np.ndarray) -> Tuple[float, float]:
        """
        计算轮廓的质心
        
        Args:
            contour: 轮廓点数组
            
        Returns:
            质心坐标 (x, y)
        """
        if contour is None or len(contour) == 0:
            return (0.0, 0.0)
        
        moments = cv2.moments(contour)
        if moments['m00'] == 0:
            return (0.0, 0.0)
        
        cx = moments['m10'] / moments['m00']
        cy = moments['m01'] / moments['m00']
        return (float(cx), float(cy))
    
    @staticmethod
    def point_in_polygon(point: Tuple[float, float], polygon: List[Tuple[float, float]]) -> bool:
        """
        判断点是否在多边形内（射线法）
        
        Args:
            point: 测试点坐标
            polygon: 多边形顶点列表
            
        Returns:
            True如果点在多边形内，否则False
        """
        x, y = point
        n = len(polygon)
        inside = False
        
        p1x, p1y = polygon[0]
        for i in range(1, n + 1):
            p2x, p2y = polygon[i % n]
            if y > min(p1y, p2y):
                if y <= max(p1y, p2y):
                    if x <= max(p1x, p2x):
                        if p1y != p2y:
                            xinters = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x
                        if p1x == p2x or x <= xinters:
                            inside = not inside
            p1x, p1y = p2x, p2y
        
        return inside
    
    @staticmethod
    def calculate_window_wall_ratio(window_area: float, wall_area: float) -> float:
        """
        计算窗墙比
        
        Args:
            window_area: 窗户总面积
            wall_area: 墙体总面积
            
        Returns:
            窗墙比
        """
        if wall_area == 0:
            return 0.0
        return window_area / wall_area
    
    @staticmethod
    def pixel_to_meter(pixel_value: float, scale_factor: float) -> float:
        """
        像素坐标转换为实际尺寸（米）
        
        Args:
            pixel_value: 像素值
            scale_factor: 缩放因子（米/像素）
            
        Returns:
            实际尺寸（米）
        """
        return pixel_value * scale_factor
    
    @staticmethod
    def meter_to_pixel(meter_value: float, scale_factor: float) -> float:
        """
        实际尺寸（米）转换为像素坐标
        
        Args:
            meter_value: 实际尺寸（米）
            scale_factor: 缩放因子（米/像素）
            
        Returns:
            像素值
        """
        if scale_factor == 0:
            return 0.0
        return meter_value / scale_factor


class DataUtils:
    """数据处理工具类"""
    
    @staticmethod
    def normalize_array(arr: np.ndarray, min_val: float = 0.0, max_val: float = 1.0) -> np.ndarray:
        """
        数组归一化
        
        Args:
            arr: 输入数组
            min_val: 归一化后的最小值
            max_val: 归一化后的最大值
            
        Returns:
            归一化后的数组
        """
        if arr.size == 0:
            return arr
        
        arr_min, arr_max = np.min(arr), np.max(arr)
        if arr_max == arr_min:
            return np.full_like(arr, (min_val + max_val) / 2)
        
        normalized = (arr - arr_min) / (arr_max - arr_min)
        return normalized * (max_val - min_val) + min_val
    
    @staticmethod
    def clip_values(arr: np.ndarray, min_val: float, max_val: float) -> np.ndarray:
        """
        限制数组值在指定范围内
        
        Args:
            arr: 输入数组
            min_val: 最小值
            max_val: 最大值
            
        Returns:
            限制后的数组
        """
        return np.clip(arr, min_val, max_val)
    
    @staticmethod
    def calculate_statistics(data: List[float]) -> Dict[str, float]:
        """
        计算数据的统计信息
        
        Args:
            data: 数据列表
            
        Returns:
            统计信息字典
        """
        if not data:
            return {}
        
        arr = np.array(data)
        return {
            'mean': float(np.mean(arr)),
            'median': float(np.median(arr)),
            'std': float(np.std(arr)),
            'min': float(np.min(arr)),
            'max': float(np.max(arr)),
            'q25': float(np.percentile(arr, 25)),
            'q75': float(np.percentile(arr, 75))
        }
    
    @staticmethod
    def interpolate_missing_values(data: List[Optional[float]], method: str = 'linear') -> List[float]:
        """
        插值填补缺失值
        
        Args:
            data: 包含缺失值的数据列表
            method: 插值方法 ('linear', 'nearest', 'zero', 'slinear', 'quadratic', 'cubic')
            
        Returns:
            填补后的数据列表
        """
        from scipy import interpolate
        
        # 转换为numpy数组
        arr = np.array(data, dtype=float)
        
        # 找到非空值的索引
        valid_indices = ~np.isnan(arr)
        
        if not np.any(valid_indices):
            # 如果全部都是缺失值，返回零数组
            return [0.0] * len(data)
        
        if np.all(valid_indices):
            # 如果没有缺失值，直接返回
            return arr.tolist()
        
        # 创建插值函数
        x_valid = np.where(valid_indices)[0]
        y_valid = arr[valid_indices]
        
        if len(x_valid) == 1:
            # 只有一个有效值，用该值填充所有缺失值
            arr[~valid_indices] = y_valid[0]
        else:
            # 使用插值填充
            f = interpolate.interp1d(x_valid, y_valid, kind=method, 
                                   bounds_error=False, fill_value='extrapolate')
            x_all = np.arange(len(arr))
            arr = f(x_all)
        
        return arr.tolist()


class FileUtils:
    """文件处理工具类"""
    
    @staticmethod
    def ensure_directory(path: Union[str, Path]) -> Path:
        """
        确保目录存在，如果不存在则创建
        
        Args:
            path: 目录路径
            
        Returns:
            Path对象
        """
        path_obj = Path(path)
        path_obj.mkdir(parents=True, exist_ok=True)
        return path_obj
    
    @staticmethod
    def get_file_extension(filepath: Union[str, Path]) -> str:
        """
        获取文件扩展名
        
        Args:
            filepath: 文件路径
            
        Returns:
            文件扩展名（小写，不包含点）
        """
        return Path(filepath).suffix.lower().lstrip('.')
    
    @staticmethod
    def is_image_file(filepath: Union[str, Path]) -> bool:
        """
        判断是否为图像文件
        
        Args:
            filepath: 文件路径
            
        Returns:
            True如果是图像文件
        """
        image_extensions = {'png', 'jpg', 'jpeg', 'bmp', 'tiff', 'tif', 'gif'}
        return FileUtils.get_file_extension(filepath) in image_extensions
    
    @staticmethod
    def load_image(filepath: Union[str, Path], as_rgb: bool = True) -> np.ndarray:
        """
        加载图像文件
        
        Args:
            filepath: 图像文件路径
            as_rgb: 是否转换为RGB格式
            
        Returns:
            图像数组
        """
        if not Path(filepath).exists():
            raise FileNotFoundError(f"图像文件不存在: {filepath}")
        
        # 使用PIL加载图像
        image = Image.open(filepath)
        
        if as_rgb and image.mode != 'RGB':
            image = image.convert('RGB')
        
        return np.array(image)
    
    @staticmethod
    def save_json(data: Any, filepath: Union[str, Path], indent: int = 2) -> None:
        """
        保存数据为JSON文件
        
        Args:
            data: 要保存的数据
            filepath: 保存路径
            indent: 缩进空格数
        """
        filepath = Path(filepath)
        FileUtils.ensure_directory(filepath.parent)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=indent, default=str)
    
    @staticmethod
    def load_json(filepath: Union[str, Path]) -> Any:
        """
        从JSON文件加载数据
        
        Args:
            filepath: JSON文件路径
            
        Returns:
            加载的数据
        """
        if not Path(filepath).exists():
            raise FileNotFoundError(f"JSON文件不存在: {filepath}")
        
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    @staticmethod
    def save_pickle(data: Any, filepath: Union[str, Path]) -> None:
        """
        保存数据为pickle文件
        
        Args:
            data: 要保存的数据
            filepath: 保存路径
        """
        filepath = Path(filepath)
        FileUtils.ensure_directory(filepath.parent)
        
        with open(filepath, 'wb') as f:
            pickle.dump(data, f)
    
    @staticmethod
    def load_pickle(filepath: Union[str, Path]) -> Any:
        """
        从pickle文件加载数据
        
        Args:
            filepath: pickle文件路径
            
        Returns:
            加载的数据
        """
        if not Path(filepath).exists():
            raise FileNotFoundError(f"Pickle文件不存在: {filepath}")
        
        with open(filepath, 'rb') as f:
            return pickle.load(f)


class ValidationUtils:
    """数据验证工具类"""
    
    @staticmethod
    def validate_color_format(color: List[int]) -> bool:
        """
        验证颜色格式是否正确
        
        Args:
            color: RGB颜色值列表 [R, G, B]
            
        Returns:
            True如果格式正确
        """
        if not isinstance(color, (list, tuple)) or len(color) != 3:
            return False
        
        return all(isinstance(c, int) and 0 <= c <= 255 for c in color)
    
    @staticmethod
    def validate_coordinate(coord: Tuple[float, float]) -> bool:
        """
        验证坐标格式是否正确
        
        Args:
            coord: 坐标元组 (x, y)
            
        Returns:
            True如果格式正确
        """
        if not isinstance(coord, (list, tuple)) or len(coord) != 2:
            return False
        
        return all(isinstance(c, (int, float)) for c in coord)
    
    @staticmethod
    def validate_parameter_bounds(value: float, min_val: float, max_val: float) -> bool:
        """
        验证参数是否在指定范围内
        
        Args:
            value: 参数值
            min_val: 最小值
            max_val: 最大值
            
        Returns:
            True如果在范围内
        """
        return min_val <= value <= max_val
    
    @staticmethod
    def validate_array_shape(arr: np.ndarray, expected_shape: Tuple[int, ...]) -> bool:
        """
        验证数组形状是否符合预期
        
        Args:
            arr: 输入数组
            expected_shape: 期望的形状
            
        Returns:
            True如果形状正确
        """
        return arr.shape == expected_shape
    
    @staticmethod
    def validate_file_exists(filepath: Union[str, Path]) -> bool:
        """
        验证文件是否存在
        
        Args:
            filepath: 文件路径
            
        Returns:
            True如果文件存在
        """
        return Path(filepath).exists()


class InteractiveUtils:
    """交互式输入工具类"""
    
    @staticmethod
    def select_file(prompt: str = "请选择文件", 
                   file_types: Optional[List[str]] = None,
                   default_path: str = ".") -> Optional[str]:
        """
        交互式文件选择
        
        Args:
            prompt: 提示信息
            file_types: 允许的文件类型列表，如 ['.png', '.jpg']
            default_path: 默认路径
            
        Returns:
            选择的文件路径，如果取消则返回None
        """
        import os
        from pathlib import Path
        
        print(f"\n{prompt}")
        print(f"当前目录: {os.getcwd()}")
        
        # 列出当前目录的文件
        current_path = Path(default_path)
        if current_path.is_dir():
            files = []
            for file_path in current_path.iterdir():
                if file_path.is_file():
                    if file_types is None or file_path.suffix.lower() in file_types:
                        files.append(file_path)
            
            if files:
                print("\n可选文件:")
                for i, file_path in enumerate(files, 1):
                    print(f"{i}. {file_path.name}")
                
                while True:
                    try:
                        choice = input(f"\n请输入文件编号 (1-{len(files)}) 或直接输入文件路径 (回车取消): ").strip()
                        
                        if not choice:
                            return None
                        
                        # 尝试解析为数字
                        try:
                            index = int(choice) - 1
                            if 0 <= index < len(files):
                                return str(files[index])
                            else:
                                print(f"请输入1到{len(files)}之间的数字")
                                continue
                        except ValueError:
                            # 不是数字，当作文件路径处理
                            file_path = Path(choice)
                            if file_path.exists() and file_path.is_file():
                                if file_types is None or file_path.suffix.lower() in file_types:
                                    return str(file_path)
                                else:
                                    print(f"文件类型不支持，支持的类型: {file_types}")
                            else:
                                print("文件不存在，请重新输入")
                    
                    except KeyboardInterrupt:
                        print("\n操作已取消")
                        return None
            else:
                print("当前目录没有符合条件的文件")
        
        # 如果没有找到文件，让用户直接输入路径
        while True:
            try:
                file_path = input("请输入完整文件路径 (回车取消): ").strip()
                
                if not file_path:
                    return None
                
                path_obj = Path(file_path)
                if path_obj.exists() and path_obj.is_file():
                    if file_types is None or path_obj.suffix.lower() in file_types:
                        return str(path_obj)
                    else:
                        print(f"文件类型不支持，支持的类型: {file_types}")
                else:
                    print("文件不存在，请重新输入")
            
            except KeyboardInterrupt:
                print("\n操作已取消")
                return None
    
    @staticmethod
    def select_option(prompt: str, options: List[str], default_index: int = 0) -> str:
        """
        交互式选项选择
        
        Args:
            prompt: 提示信息
            options: 选项列表
            default_index: 默认选项索引
            
        Returns:
            选择的选项
        """
        print(f"\n{prompt}")
        for i, option in enumerate(options, 1):
            marker = " (默认)" if i - 1 == default_index else ""
            print(f"{i}. {option}{marker}")
        
        while True:
            try:
                choice = input(f"\n请选择 (1-{len(options)}, 回车选择默认): ").strip()
                
                if not choice:
                    return options[default_index]
                
                index = int(choice) - 1
                if 0 <= index < len(options):
                    return options[index]
                else:
                    print(f"请输入1到{len(options)}之间的数字")
            
            except ValueError:
                print("请输入有效的数字")
            except KeyboardInterrupt:
                print("\n使用默认选项")
                return options[default_index]
    
    @staticmethod
    def input_number(prompt: str, min_val: Optional[float] = None, 
                    max_val: Optional[float] = None, default: Optional[float] = None) -> float:
        """
        交互式数字输入
        
        Args:
            prompt: 提示信息
            min_val: 最小值
            max_val: 最大值
            default: 默认值
            
        Returns:
            输入的数字
        """
        range_info = ""
        if min_val is not None and max_val is not None:
            range_info = f" ({min_val}-{max_val})"
        elif min_val is not None:
            range_info = f" (>={min_val})"
        elif max_val is not None:
            range_info = f" (<={max_val})"
        
        default_info = f" (默认: {default})" if default is not None else ""
        
        while True:
            try:
                value_str = input(f"{prompt}{range_info}{default_info}: ").strip()
                
                if not value_str and default is not None:
                    return default
                
                value = float(value_str)
                
                if min_val is not None and value < min_val:
                    print(f"值不能小于 {min_val}")
                    continue
                
                if max_val is not None and value > max_val:
                    print(f"值不能大于 {max_val}")
                    continue
                
                return value
            
            except ValueError:
                print("请输入有效的数字")
            except KeyboardInterrupt:
                if default is not None:
                    print(f"\n使用默认值: {default}")
                    return default
                else:
                    raise
