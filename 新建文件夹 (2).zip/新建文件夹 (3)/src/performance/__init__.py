
# 性能评估与预测模块

from .thermal_performance_analyzer import (
    ThermalPerformanceAnalyzer,
    ThermalProperties,
    MaterialProperties,
    create_test_thermal_analyzer,
    validate_thermal_properties
)

# 尝试导入其他模块，如果失败则跳过
try:
    from .energy_calculator import EnergyCalculator
    _has_energy_calculator = True
except ImportError:
    _has_energy_calculator = False

try:
    from .thermal_comfort_evaluator import ThermalComfortEvaluator
    _has_thermal_comfort = True
except ImportError:
    _has_thermal_comfort = False

__all__ = [
    'ThermalPerformanceAnalyzer',
    'ThermalProperties',
    'MaterialProperties',
    'create_test_thermal_analyzer',
    'validate_thermal_properties'
]

if _has_energy_calculator:
    __all__.append('EnergyCalculator')

if _has_thermal_comfort:
    __all__.append('ThermalComfortEvaluator')
