
"""
热舒适性评估系统
实现PMV/PPD热舒适模型，室内温度和湿度预测算法，以及舒适度时间序列分析
"""

import numpy as np
import math
from typing import List, Dict, Tuple, Optional, Any
from dataclasses import dataclass, field
from enum import Enum

from ..core.config import config_manager
from ..core.logging_config import get_logger
from ..core.exceptions import OptimizationError
from ..core.data_structures import Individual, FacadeData, ClimateData, ClimateDataPoint

logger = get_logger(__name__)


class ComfortLevel(Enum):
    """热舒适等级"""
    VERY_COLD = -3
    COLD = -2
    COOL = -1
    NEUTRAL = 0
    WARM = 1
    HOT = 2
    VERY_HOT = 3


@dataclass
class ThermalComfortConfig:
    """热舒适性评估配置"""
    # PMV模型参数
    metabolic_rate: float = 1.2           # 代谢率 (met)
    clothing_insulation: float = 0.7      # 服装热阻 (clo)
    air_velocity: float = 0.1             # 空气流速 (m/s)
    
    # 舒适性标准
    pmv_comfort_range: Tuple[float, float] = (-0.5, 0.5)  # PMV舒适范围
    ppd_comfort_threshold: float = 10.0    # PPD舒适阈值 (%)
    
    # 室内环境参数
    indoor_temp_range: Tuple[float, float] = (18.0, 28.0)  # 室内温度范围 (°C)
    indoor_humidity_range: Tuple[float, float] = (30.0, 70.0)  # 室内湿度范围 (%)
    
    # 分析参数
    comfort_analysis_hours: int = 8760     # 分析小时数
    seasonal_analysis: bool = True         # 是否进行季节性分析


@dataclass
class ComfortMetrics:
    """热舒适性指标"""
    # PMV/PPD指标
    pmv_value: float = 0.0                # PMV值
    ppd_value: float = 0.0                # PPD值 (%)
    comfort_level: ComfortLevel = ComfortLevel.NEUTRAL  # 舒适等级
    
    # 环境参数
    indoor_temperature: float = 22.0      # 室内温度 (°C)
    indoor_humidity: float = 50.0         # 室内相对湿度 (%)
    mean_radiant_temp: float = 22.0       # 平均辐射温度 (°C)
    
    # 舒适性判断
    is_comfortable: bool = True           # 是否舒适
    discomfort_reason: str = ""           # 不舒适原因


@dataclass
class ComfortAnalysisResult:
    """热舒适性分析结果"""
    # 年度统计
    annual_comfort_hours: int = 0         # 年度舒适小时数
    annual_comfort_ratio: float = 0.0     # 年度舒适比例
    
    # 季节性统计
    seasonal_comfort: Dict[str, Dict[str, float]] = field(default_factory=dict)
    
    # PMV/PPD统计
    avg_pmv: float = 0.0                  # 平均PMV
    avg_ppd: float = 0.0                  # 平均PPD
    pmv_std: float = 0.0                  # PMV标准差
    
    # 不舒适时间分析
    too_cold_hours: int = 0               # 过冷小时数
    too_hot_hours: int = 0                # 过热小时数
    
    # 时间序列数据
    hourly_metrics: List[ComfortMetrics] = field(default_factory=list)


class ThermalComfortEvaluator:
    """热舒适性评估器主类"""
    
    def __init__(self, config: Optional[ThermalComfortConfig] = None):
        """
        初始化热舒适性评估器
        
        Args:
            config: 热舒适性评估配置
        """
        self.config = config or ThermalComfortConfig()
        
        # PMV模型常数
        self.pmv_constants = {
            'pa': 0.0,  # 水蒸气分压
            'icl': 0.0,  # 服装表面积系数
            'fcl': 0.0,  # 服装面积系数
            'hc': 0.0,   # 对流换热系数
            'tcl': 0.0,  # 服装表面温度
        }
        
        logger.info("热舒适性评估器初始化完成") 
   
    def calculate_pmv_ppd(self, indoor_temp: float, indoor_humidity: float,
                         mean_radiant_temp: Optional[float] = None,
                         air_velocity: Optional[float] = None,
                         metabolic_rate: Optional[float] = None,
                         clothing_insulation: Optional[float] = None) -> Tuple[float, float]:
        """
        计算PMV和PPD值（简化版本）
        
        Args:
            indoor_temp: 室内空气温度 (°C)
            indoor_humidity: 室内相对湿度 (%)
            mean_radiant_temp: 平均辐射温度 (°C)，默认等于空气温度
            air_velocity: 空气流速 (m/s)
            metabolic_rate: 代谢率 (met)
            clothing_insulation: 服装热阻 (clo)
            
        Returns:
            (PMV值, PPD值)
        """
        try:
            # 使用默认值或配置值
            mrt = mean_radiant_temp if mean_radiant_temp is not None else indoor_temp
            vel = air_velocity if air_velocity is not None else self.config.air_velocity
            met = metabolic_rate if metabolic_rate is not None else self.config.metabolic_rate
            clo = clothing_insulation if clothing_insulation is not None else self.config.clothing_insulation
            
            # 简化的PMV计算（基于经验公式）
            # 舒适温度基准
            comfort_temp = 22.0  # 舒适基准温度
            
            # 温度偏差影响
            temp_deviation = indoor_temp - comfort_temp
            
            # 湿度影响
            humidity_factor = 1.0
            if indoor_humidity > 60:
                humidity_factor = 1.0 + (indoor_humidity - 60) * 0.01
            elif indoor_humidity < 40:
                humidity_factor = 1.0 + (40 - indoor_humidity) * 0.01
            
            # 代谢率影响
            met_factor = met / 1.2  # 标准代谢率为1.2 met
            
            # 服装影响
            clo_factor = 1.0
            if clo > 0.7:
                clo_factor = 1.0 - (clo - 0.7) * 0.3
            elif clo < 0.5:
                clo_factor = 1.0 + (0.5 - clo) * 0.5
            
            # 风速影响
            vel_factor = 1.0 - vel * 0.5
            
            # 计算PMV
            pmv = temp_deviation * 0.3 * humidity_factor * met_factor * clo_factor * vel_factor
            
            # 限制PMV在合理范围内
            pmv = max(-3.0, min(3.0, pmv))
            
            # 计算PPD
            if abs(pmv) <= 0.5:
                ppd = 5.0 + abs(pmv) * 10.0
            else:
                ppd = 10.0 + (abs(pmv) - 0.5) * 30.0
            
            ppd = min(100.0, ppd)
            
            return pmv, ppd
            
        except Exception as e:
            logger.error(f"PMV/PPD计算失败: {str(e)}")
            return 0.0, 5.0  # 返回中性值
    
    def predict_indoor_temperature(self, facade_data: FacadeData, individual: Individual,
                                 outdoor_temp: float, solar_radiation: float,
                                 wind_speed: float = 2.0) -> float:
        """
        预测室内温度
        
        Args:
            facade_data: 立面数据
            individual: 个体参数
            outdoor_temp: 室外温度 (°C)
            solar_radiation: 太阳辐射 (W/m²)
            wind_speed: 风速 (m/s)
            
        Returns:
            预测的室内温度 (°C)
        """
        try:
            # 基础室内温度（基于室外温度）
            base_indoor_temp = outdoor_temp
            
            # 建筑热惰性影响
            thermal_mass_factor = 0.7  # 热惰性系数
            base_indoor_temp = outdoor_temp * (1 - thermal_mass_factor) + 22.0 * thermal_mass_factor
            
            # 太阳得热影响
            total_window_area = sum(
                window.width * individual.window_width_scales[i] * window.height
                for i, window in enumerate(facade_data.windows)
            )
            
            if total_window_area > 0:
                # 计算遮阳影响
                shading_factor = 1.0
                for i, window in enumerate(facade_data.windows):
                    if individual.shading_types[i] == 1:  # 有遮阳
                        depth = individual.shading_depths[i]
                        angle = individual.shading_angles[i]
                        window_shading = min(0.8, depth * 0.4 + abs(angle - 45) * 0.01)
                        shading_factor *= (1 - window_shading)
                
                # 太阳得热温升
                solar_gain_temp = (solar_radiation * total_window_area * shading_factor * 0.6) / (1200 * 1.2)
                base_indoor_temp += solar_gain_temp
            
            # 通风影响
            ventilation_cooling = max(0, (base_indoor_temp - outdoor_temp) * 0.3)
            base_indoor_temp -= ventilation_cooling
            
            # 限制在合理范围内
            indoor_temp = max(self.config.indoor_temp_range[0], 
                            min(self.config.indoor_temp_range[1], base_indoor_temp))
            
            # 确保室内温度与室外温度有合理的关系
            if outdoor_temp > 25.0:  # 夏季
                indoor_temp = max(indoor_temp, outdoor_temp - 5.0)
            elif outdoor_temp < 15.0:  # 冬季
                indoor_temp = min(indoor_temp, outdoor_temp + 10.0)
            
            return indoor_temp
            
        except Exception as e:
            logger.error(f"室内温度预测失败: {str(e)}")
            return 22.0  # 返回默认值
    
    def predict_indoor_humidity(self, outdoor_humidity: float, indoor_temp: float,
                              outdoor_temp: float) -> float:
        """
        预测室内湿度
        
        Args:
            outdoor_humidity: 室外相对湿度 (%)
            indoor_temp: 室内温度 (°C)
            outdoor_temp: 室外温度 (°C)
            
        Returns:
            预测的室内相对湿度 (%)
        """
        try:
            # 基于温度差异调整湿度
            temp_diff = indoor_temp - outdoor_temp
            
            # 温度升高时相对湿度降低
            humidity_adjustment = temp_diff * 2.0  # 每度温差约2%湿度变化
            
            indoor_humidity = outdoor_humidity - humidity_adjustment
            
            # 考虑室内湿度源（人员、设备等）
            indoor_humidity += 5.0  # 室内湿度源贡献
            
            # 限制在合理范围内
            indoor_humidity = max(self.config.indoor_humidity_range[0],
                                min(self.config.indoor_humidity_range[1], indoor_humidity))
            
            return indoor_humidity
            
        except Exception as e:
            logger.error(f"室内湿度预测失败: {str(e)}")
            return 50.0  # 返回默认值  
  
    def evaluate_comfort_metrics(self, indoor_temp: float, indoor_humidity: float,
                                mean_radiant_temp: Optional[float] = None) -> ComfortMetrics:
        """
        评估热舒适性指标
        
        Args:
            indoor_temp: 室内温度 (°C)
            indoor_humidity: 室内湿度 (%)
            mean_radiant_temp: 平均辐射温度 (°C)
            
        Returns:
            热舒适性指标
        """
        try:
            # 计算PMV和PPD
            pmv, ppd = self.calculate_pmv_ppd(indoor_temp, indoor_humidity, mean_radiant_temp)
            
            # 确定舒适等级
            if pmv <= -2.5:
                comfort_level = ComfortLevel.VERY_COLD
            elif pmv <= -1.5:
                comfort_level = ComfortLevel.COLD
            elif pmv <= -0.5:
                comfort_level = ComfortLevel.COOL
            elif pmv <= 0.5:
                comfort_level = ComfortLevel.NEUTRAL
            elif pmv <= 1.5:
                comfort_level = ComfortLevel.WARM
            elif pmv <= 2.5:
                comfort_level = ComfortLevel.HOT
            else:
                comfort_level = ComfortLevel.VERY_HOT
            
            # 判断是否舒适
            pmv_comfortable = (self.config.pmv_comfort_range[0] <= pmv <= 
                             self.config.pmv_comfort_range[1])
            ppd_comfortable = ppd <= self.config.ppd_comfort_threshold
            is_comfortable = pmv_comfortable and ppd_comfortable
            
            # 确定不舒适原因
            discomfort_reason = ""
            if not is_comfortable:
                if pmv < self.config.pmv_comfort_range[0]:
                    discomfort_reason = "过冷"
                elif pmv > self.config.pmv_comfort_range[1]:
                    discomfort_reason = "过热"
                elif ppd > self.config.ppd_comfort_threshold:
                    discomfort_reason = "PPD超标"
            
            return ComfortMetrics(
                pmv_value=pmv,
                ppd_value=ppd,
                comfort_level=comfort_level,
                indoor_temperature=indoor_temp,
                indoor_humidity=indoor_humidity,
                mean_radiant_temp=mean_radiant_temp or indoor_temp,
                is_comfortable=is_comfortable,
                discomfort_reason=discomfort_reason
            )
            
        except Exception as e:
            logger.error(f"舒适性指标评估失败: {str(e)}")
            return ComfortMetrics()
    
    def analyze_annual_comfort(self, facade_data: FacadeData, individual: Individual,
                             climate_data: ClimateData) -> ComfortAnalysisResult:
        """
        分析年度热舒适性
        
        Args:
            facade_data: 立面数据
            individual: 个体参数
            climate_data: 气候数据
            
        Returns:
            热舒适性分析结果
        """
        try:
            result = ComfortAnalysisResult()
            
            # 初始化季节性统计
            result.seasonal_comfort = {
                'spring': {'comfort_hours': 0, 'total_hours': 0, 'avg_pmv': 0, 'avg_ppd': 0},
                'summer': {'comfort_hours': 0, 'total_hours': 0, 'avg_pmv': 0, 'avg_ppd': 0},
                'autumn': {'comfort_hours': 0, 'total_hours': 0, 'avg_pmv': 0, 'avg_ppd': 0},
                'winter': {'comfort_hours': 0, 'total_hours': 0, 'avg_pmv': 0, 'avg_ppd': 0}
            }
            
            # 季节划分
            season_months = {
                'spring': [3, 4, 5],
                'summer': [6, 7, 8],
                'autumn': [9, 10, 11],
                'winter': [12, 1, 2]
            }
            
            pmv_values = []
            ppd_values = []
            comfort_hours = 0
            too_cold_hours = 0
            too_hot_hours = 0
            
            # 逐小时分析
            for hour_data in climate_data.hourly_data:
                # 预测室内环境
                indoor_temp = self.predict_indoor_temperature(
                    facade_data, individual, hour_data.dry_bulb_temp,
                    hour_data.global_radiation, hour_data.wind_speed
                )
                
                indoor_humidity = self.predict_indoor_humidity(
                    hour_data.relative_humidity, indoor_temp, hour_data.dry_bulb_temp
                )
                
                # 评估舒适性
                comfort_metrics = self.evaluate_comfort_metrics(indoor_temp, indoor_humidity)
                result.hourly_metrics.append(comfort_metrics)
                
                # 统计数据
                pmv_values.append(comfort_metrics.pmv_value)
                ppd_values.append(comfort_metrics.ppd_value)
                
                if comfort_metrics.is_comfortable:
                    comfort_hours += 1
                elif comfort_metrics.pmv_value < self.config.pmv_comfort_range[0]:
                    too_cold_hours += 1
                elif comfort_metrics.pmv_value > self.config.pmv_comfort_range[1]:
                    too_hot_hours += 1
                
                # 季节性统计
                if hasattr(hour_data, 'month'):
                    month = hour_data.month
                    for season, months in season_months.items():
                        if month in months:
                            result.seasonal_comfort[season]['total_hours'] += 1
                            if comfort_metrics.is_comfortable:
                                result.seasonal_comfort[season]['comfort_hours'] += 1
                            result.seasonal_comfort[season]['avg_pmv'] += comfort_metrics.pmv_value
                            result.seasonal_comfort[season]['avg_ppd'] += comfort_metrics.ppd_value
                            break
            
            # 计算年度统计
            total_hours = len(climate_data.hourly_data)
            result.annual_comfort_hours = comfort_hours
            result.annual_comfort_ratio = comfort_hours / total_hours if total_hours > 0 else 0
            result.too_cold_hours = too_cold_hours
            result.too_hot_hours = too_hot_hours
            
            # 计算PMV/PPD统计
            if pmv_values:
                result.avg_pmv = np.mean(pmv_values)
                result.avg_ppd = np.mean(ppd_values)
                result.pmv_std = np.std(pmv_values)
            
            # 计算季节性平均值
            for season in result.seasonal_comfort:
                total_hours = result.seasonal_comfort[season]['total_hours']
                if total_hours > 0:
                    result.seasonal_comfort[season]['comfort_ratio'] = (
                        result.seasonal_comfort[season]['comfort_hours'] / total_hours
                    )
                    result.seasonal_comfort[season]['avg_pmv'] /= total_hours
                    result.seasonal_comfort[season]['avg_ppd'] /= total_hours
                else:
                    result.seasonal_comfort[season]['comfort_ratio'] = 0
            
            logger.info(f"年度热舒适性分析完成: 舒适比例={result.annual_comfort_ratio:.3f}")
            return result
            
        except Exception as e:
            logger.error(f"年度热舒适性分析失败: {str(e)}")
            return ComfortAnalysisResult()
    
    def get_comfort_time_series(self, analysis_result: ComfortAnalysisResult,
                              time_step: str = 'hourly') -> Dict[str, List[float]]:
        """
        获取舒适度时间序列数据
        
        Args:
            analysis_result: 分析结果
            time_step: 时间步长 ('hourly', 'daily', 'monthly')
            
        Returns:
            时间序列数据字典
        """
        try:
            if time_step == 'hourly':
                return {
                    'pmv': [m.pmv_value for m in analysis_result.hourly_metrics],
                    'ppd': [m.ppd_value for m in analysis_result.hourly_metrics],
                    'indoor_temp': [m.indoor_temperature for m in analysis_result.hourly_metrics],
                    'indoor_humidity': [m.indoor_humidity for m in analysis_result.hourly_metrics],
                    'comfort_flag': [1 if m.is_comfortable else 0 for m in analysis_result.hourly_metrics]
                }
            
            elif time_step == 'daily':
                # 按天聚合数据
                daily_data = {'pmv': [], 'ppd': [], 'indoor_temp': [], 'indoor_humidity': [], 'comfort_ratio': []}
                
                for day in range(0, len(analysis_result.hourly_metrics), 24):
                    day_metrics = analysis_result.hourly_metrics[day:day+24]
                    if day_metrics:
                        daily_data['pmv'].append(np.mean([m.pmv_value for m in day_metrics]))
                        daily_data['ppd'].append(np.mean([m.ppd_value for m in day_metrics]))
                        daily_data['indoor_temp'].append(np.mean([m.indoor_temperature for m in day_metrics]))
                        daily_data['indoor_humidity'].append(np.mean([m.indoor_humidity for m in day_metrics]))
                        comfort_ratio = sum(1 for m in day_metrics if m.is_comfortable) / len(day_metrics)
                        daily_data['comfort_ratio'].append(comfort_ratio)
                
                return daily_data
            
            elif time_step == 'monthly':
                # 按月聚合数据
                monthly_data = {'pmv': [], 'ppd': [], 'indoor_temp': [], 'indoor_humidity': [], 'comfort_ratio': []}
                
                # 假设每月730小时（简化）
                hours_per_month = len(analysis_result.hourly_metrics) // 12
                
                for month in range(12):
                    start_hour = month * hours_per_month
                    end_hour = min((month + 1) * hours_per_month, len(analysis_result.hourly_metrics))
                    month_metrics = analysis_result.hourly_metrics[start_hour:end_hour]
                    
                    if month_metrics:
                        monthly_data['pmv'].append(np.mean([m.pmv_value for m in month_metrics]))
                        monthly_data['ppd'].append(np.mean([m.ppd_value for m in month_metrics]))
                        monthly_data['indoor_temp'].append(np.mean([m.indoor_temperature for m in month_metrics]))
                        monthly_data['indoor_humidity'].append(np.mean([m.indoor_humidity for m in month_metrics]))
                        comfort_ratio = sum(1 for m in month_metrics if m.is_comfortable) / len(month_metrics)
                        monthly_data['comfort_ratio'].append(comfort_ratio)
                
                return monthly_data
            
            else:
                logger.warning(f"不支持的时间步长: {time_step}")
                return {}
                
        except Exception as e:
            logger.error(f"时间序列数据获取失败: {str(e)}")
            return {}   
 
    def get_comfort_improvement_suggestions(self, analysis_result: ComfortAnalysisResult,
                                          facade_data: FacadeData,
                                          individual: Individual) -> List[Dict[str, Any]]:
        """
        获取舒适性改进建议
        
        Args:
            analysis_result: 分析结果
            facade_data: 立面数据
            individual: 个体参数
            
        Returns:
            改进建议列表
        """
        try:
            suggestions = []
            
            # 分析主要问题
            if analysis_result.too_cold_hours > analysis_result.too_hot_hours:
                # 主要问题是过冷
                suggestions.append({
                    'issue': '过冷问题',
                    'description': f'全年有{analysis_result.too_cold_hours}小时过冷',
                    'suggestions': [
                        '增加窗户面积以获得更多太阳得热',
                        '减少遮阳深度或调整遮阳角度',
                        '改善建筑保温性能',
                        '考虑增加内部热源'
                    ],
                    'priority': 'high' if analysis_result.too_cold_hours > 2000 else 'medium'
                })
                
            elif analysis_result.too_hot_hours > analysis_result.too_cold_hours:
                # 主要问题是过热
                suggestions.append({
                    'issue': '过热问题',
                    'description': f'全年有{analysis_result.too_hot_hours}小时过热',
                    'suggestions': [
                        '增加遮阳设施或调整遮阳参数',
                        '适当减少窗户面积',
                        '改善通风设计',
                        '考虑使用低辐射玻璃'
                    ],
                    'priority': 'high' if analysis_result.too_hot_hours > 2000 else 'medium'
                })
            
            # 分析季节性问题
            for season, data in analysis_result.seasonal_comfort.items():
                if data['comfort_ratio'] < 0.6:  # 舒适比例低于60%
                    season_name = {'spring': '春季', 'summer': '夏季', 'autumn': '秋季', 'winter': '冬季'}[season]
                    suggestions.append({
                        'issue': f'{season_name}舒适性问题',
                        'description': f'{season_name}舒适比例仅为{data["comfort_ratio"]:.1%}',
                        'suggestions': self._get_seasonal_suggestions(season, data),
                        'priority': 'medium'
                    })
            
            # 分析PMV变异性
            if analysis_result.pmv_std > 1.0:
                suggestions.append({
                    'issue': '热环境不稳定',
                    'description': f'PMV标准差为{analysis_result.pmv_std:.2f}，热环境变化较大',
                    'suggestions': [
                        '增加建筑热惰性',
                        '改善围护结构保温性能',
                        '优化遮阳控制策略',
                        '考虑增加热回收系统'
                    ],
                    'priority': 'medium'
                })
            
            # 分析窗墙比影响
            total_window_area = sum(
                window.width * individual.window_width_scales[i] * window.height
                for i, window in enumerate(facade_data.windows)
            )
            window_wall_ratio = total_window_area / max(facade_data.total_wall_area, 1.0)
            
            if window_wall_ratio > 0.6:
                suggestions.append({
                    'issue': '窗墙比过高',
                    'description': f'当前窗墙比为{window_wall_ratio:.2f}，可能导致热环境不稳定',
                    'suggestions': [
                        '适当减少窗户面积',
                        '增加高性能遮阳设施',
                        '使用高性能玻璃',
                        '优化窗户分布'
                    ],
                    'priority': 'medium'
                })
            elif window_wall_ratio < 0.2:
                suggestions.append({
                    'issue': '窗墙比过低',
                    'description': f'当前窗墙比为{window_wall_ratio:.2f}，可能影响自然采光和太阳得热',
                    'suggestions': [
                        '适当增加窗户面积',
                        '优化窗户位置和分布',
                        '考虑增加天窗或其他采光设施'
                    ],
                    'priority': 'low'
                })
            
            return suggestions
            
        except Exception as e:
            logger.error(f"舒适性改进建议生成失败: {str(e)}")
            return []
    
    def _get_seasonal_suggestions(self, season: str, season_data: Dict[str, float]) -> List[str]:
        """
        获取季节性改进建议
        
        Args:
            season: 季节名称
            season_data: 季节数据
            
        Returns:
            建议列表
        """
        suggestions = []
        avg_pmv = season_data.get('avg_pmv', 0)
        
        if season == 'summer':
            if avg_pmv > 0.5:
                suggestions.extend([
                    '增加夏季遮阳设施',
                    '改善自然通风',
                    '考虑使用遮阳玻璃',
                    '优化建筑朝向'
                ])
            else:
                suggestions.extend([
                    '调整遮阳角度',
                    '改善室内空气流动'
                ])
                
        elif season == 'winter':
            if avg_pmv < -0.5:
                suggestions.extend([
                    '减少冬季遮阳',
                    '增加太阳得热',
                    '改善建筑保温',
                    '优化供暖系统'
                ])
            else:
                suggestions.extend([
                    '调整供暖设定温度',
                    '改善气密性'
                ])
                
        elif season in ['spring', 'autumn']:
            if abs(avg_pmv) > 0.5:
                suggestions.extend([
                    '优化过渡季节控制策略',
                    '改善自然通风',
                    '调整遮阳控制'
                ])
        
        return suggestions
    
    def calculate_comfort_score(self, analysis_result: ComfortAnalysisResult) -> float:
        """
        计算综合舒适性评分
        
        Args:
            analysis_result: 分析结果
            
        Returns:
            舒适性评分 (0-100)
        """
        try:
            # 基础分数（基于舒适比例）
            base_score = analysis_result.annual_comfort_ratio * 100
            
            # PMV稳定性加分/减分
            pmv_stability_bonus = max(0, 10 - analysis_result.pmv_std * 5)
            
            # 季节性平衡加分/减分
            seasonal_scores = [data.get('comfort_ratio', 0) for data in analysis_result.seasonal_comfort.values()]
            seasonal_balance = 100 - np.std(seasonal_scores) * 100  # 季节间平衡性
            seasonal_bonus = max(0, (seasonal_balance - 80) / 4)  # 平衡性超过80%时加分
            
            # PPD惩罚
            ppd_penalty = max(0, (analysis_result.avg_ppd - 10) * 0.5)
            
            # 计算最终分数
            final_score = base_score + pmv_stability_bonus + seasonal_bonus - ppd_penalty
            
            # 限制在0-100范围内
            final_score = max(0.0, min(100.0, final_score))
            
            return float(final_score)
            
        except Exception as e:
            logger.error(f"舒适性评分计算失败: {str(e)}")
            return 50.0  # 返回中等分数


def create_thermal_comfort_evaluator(config: Optional[ThermalComfortConfig] = None) -> ThermalComfortEvaluator:
    """
    创建热舒适性评估器实例
    
    Args:
        config: 热舒适性评估配置
        
    Returns:
        热舒适性评估器实例
    """
    return ThermalComfortEvaluator(config)
