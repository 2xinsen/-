
"""
热力性能分析器模块

该模块实现建筑立面的热力性能分析，包括：
- 整体传热系数计算
- 热惰性分析
- 热桥效应分析
- 动态热力性能模拟

作者: Kiro AI Assistant
日期: 2025-01-25
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any
import logging
from dataclasses import dataclass
import json

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class ThermalProperties:
    """热力性能属性数据类"""
    overall_u_value: float  # 整体传热系数 (W/m²·K)
    thermal_mass: float     # 热惰性 (J/m²·K)
    thermal_bridge_factor: float  # 热桥系数
    dynamic_response: Dict[str, float]  # 动态响应特性
    heat_capacity: float    # 热容量 (J/K)
    thermal_lag: float      # 热滞后时间 (hours)


@dataclass
class MaterialProperties:
    """材料热力属性"""
    conductivity: float     # 导热系数 (W/m·K)
    density: float         # 密度 (kg/m³)
    specific_heat: float   # 比热容 (J/kg·K)
    thickness: float       # 厚度 (m)


class ThermalPerformanceAnalyzer:
    """
    热力性能分析器
    
    实现建筑立面的热力性能分析，包括传热系数计算、
    热惰性分析、热桥效应分析和动态热力性能模拟
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """
        初始化热力性能分析器
        
        Args:
            config: 配置参数字典
        """
        self.config = config or self._get_default_config()
        self.material_database = self._initialize_material_database()
        
        logger.info("热力性能分析器初始化完成")
    
    def _get_default_config(self) -> Dict:
        """获取默认配置"""
        return {
            'analysis_timestep': 1.0,  # 分析时间步长 (hours)
            'simulation_period': 8760,  # 模拟周期 (hours)
            'convergence_tolerance': 1e-6,
            'max_iterations': 1000,
            'thermal_bridge_factor': 0.1,  # 热桥影响系数
            'air_gap_resistance': 0.18,   # 空气间层热阻 (m²·K/W)
            'surface_resistance': {
                'internal': 0.13,  # 内表面热阻
                'external': 0.04   # 外表面热阻
            }
        }
    
    def _initialize_material_database(self) -> Dict[str, MaterialProperties]:
        """初始化材料数据库"""
        return {
            'concrete': MaterialProperties(
                conductivity=1.7, density=2400, specific_heat=880, thickness=0.2
            ),
            'brick': MaterialProperties(
                conductivity=0.8, density=1800, specific_heat=840, thickness=0.24
            ),
            'insulation': MaterialProperties(
                conductivity=0.04, density=30, specific_heat=1400, thickness=0.1
            ),
            'glass_single': MaterialProperties(
                conductivity=1.0, density=2500, specific_heat=750, thickness=0.006
            ),
            'glass_double': MaterialProperties(
                conductivity=0.5, density=2500, specific_heat=750, thickness=0.024
            ),
            'aluminum_frame': MaterialProperties(
                conductivity=160, density=2700, specific_heat=900, thickness=0.05
            ),
            'wood_frame': MaterialProperties(
                conductivity=0.13, density=500, specific_heat=1600, thickness=0.05
            )
        }
    
    def analyze_thermal_performance(self, individual: Any, facade_data: Dict, 
                                  climate_data: List[Dict]) -> ThermalProperties:
        """
        分析个体的热力性能
        
        Args:
            individual: 优化个体
            facade_data: 立面数据
            climate_data: 气候数据
            
        Returns:
            ThermalProperties: 热力性能分析结果
        """
        try:
            logger.info("开始热力性能分析")
            
            # 1. 计算整体传热系数
            overall_u_value = self.calculate_overall_u_value(individual, facade_data)
            
            # 2. 分析热惰性
            thermal_mass = self.calculate_thermal_mass(individual, facade_data)
            
            # 3. 分析热桥效应
            thermal_bridge_factor = self.analyze_thermal_bridges(individual, facade_data)
            
            # 4. 动态热力性能模拟
            dynamic_response = self.simulate_dynamic_thermal_response(
                individual, facade_data, climate_data
            )
            
            # 5. 计算热容量和热滞后
            heat_capacity = self.calculate_heat_capacity(individual, facade_data)
            thermal_lag = self.calculate_thermal_lag(individual, facade_data)
            
            result = ThermalProperties(
                overall_u_value=overall_u_value,
                thermal_mass=thermal_mass,
                thermal_bridge_factor=thermal_bridge_factor,
                dynamic_response=dynamic_response,
                heat_capacity=heat_capacity,
                thermal_lag=thermal_lag
            )
            
            logger.info(f"热力性能分析完成: U值={overall_u_value:.3f} W/m²·K")
            return result
            
        except Exception as e:
            logger.error(f"热力性能分析失败: {e}")
            return self._get_default_thermal_properties()
    
    def calculate_overall_u_value(self, individual: Any, facade_data: Dict) -> float:
        """
        计算整体传热系数
        
        Args:
            individual: 优化个体
            facade_data: 立面数据
            
        Returns:
            float: 整体传热系数 (W/m²·K)
        """
        try:
            # 获取立面总面积
            total_area = facade_data.get('total_area', 100.0)
            
            # 计算墙体面积和传热系数
            wall_area = self._calculate_wall_area(individual, facade_data)
            wall_u_value = self._calculate_wall_u_value(facade_data)
            
            # 计算窗户面积和传热系数
            window_areas, window_u_values = self._calculate_window_thermal_properties(
                individual, facade_data
            )
            
            # 计算加权平均传热系数
            total_heat_transfer = (
                wall_area * wall_u_value + 
                sum(area * u_val for area, u_val in zip(window_areas, window_u_values))
            )
            
            overall_u_value = total_heat_transfer / total_area
            
            # 考虑热桥效应的修正
            thermal_bridge_correction = 1 + self.config['thermal_bridge_factor']
            overall_u_value *= thermal_bridge_correction
            
            return max(0.1, min(overall_u_value, 10.0))  # 限制在合理范围内
            
        except Exception as e:
            logger.error(f"传热系数计算失败: {e}")
            return 2.5  # 返回默认值
    
    def _calculate_wall_area(self, individual: Any, facade_data: Dict) -> float:
        """计算墙体面积"""
        total_area = facade_data.get('total_area', 100.0)
        
        # 计算窗户总面积
        window_total_area = 0
        if hasattr(individual, 'genes') and 'window_width_scales' in individual.genes:
            windows = facade_data.get('windows', [])
            for i, window in enumerate(windows):
                if i < len(individual.genes['window_width_scales']):
                    original_area = window.get('width', 1.0) * window.get('height', 1.0)
                    width_scale = individual.genes['window_width_scales'][i]
                    height_scale = individual.genes.get('window_height_scales', [1.0] * len(windows))[i]
                    scaled_area = original_area * width_scale * height_scale
                    window_total_area += scaled_area
        else:
            # 简化计算：假设窗墙比为30%
            window_total_area = total_area * 0.3
        
        return max(0, total_area - window_total_area)
    
    def _calculate_wall_u_value(self, facade_data: Dict) -> float:
        """计算墙体传热系数"""
        # 典型墙体构造：外墙面层 + 保温层 + 结构层 + 内墙面层
        wall_layers = [
            ('concrete', 0.2),      # 混凝土结构层
            ('insulation', 0.1),    # 保温层
            ('brick', 0.05)         # 外墙面层
        ]
        
        total_resistance = (
            self.config['surface_resistance']['internal'] +
            self.config['surface_resistance']['external']
        )
        
        for material_name, thickness in wall_layers:
            material = self.material_database[material_name]
            resistance = thickness / material.conductivity
            total_resistance += resistance
        
        return 1.0 / total_resistance
    
    def _calculate_window_thermal_properties(self, individual: Any, 
                                           facade_data: Dict) -> Tuple[List[float], List[float]]:
        """计算窗户热力属性"""
        windows = facade_data.get('windows', [])
        window_areas = []
        window_u_values = []
        
        for i, window in enumerate(windows):
            # 计算窗户面积
            original_area = window.get('width', 1.0) * window.get('height', 1.0)
            
            if hasattr(individual, 'genes') and 'window_width_scales' in individual.genes:
                if i < len(individual.genes['window_width_scales']):
                    width_scale = individual.genes['window_width_scales'][i]
                    height_scale = individual.genes.get('window_height_scales', [1.0] * len(windows))[i]
                    scaled_area = original_area * width_scale * height_scale
                else:
                    scaled_area = original_area
            else:
                scaled_area = original_area
            
            window_areas.append(scaled_area)
            
            # 计算窗户传热系数
            base_u_value = self._get_window_base_u_value(window)
            
            # 考虑遮阳对传热系数的影响
            shading_thermal_factor = self._calculate_shading_thermal_effect(individual, i)
            effective_u_value = base_u_value * (1 - shading_thermal_factor * 0.05)
            
            window_u_values.append(effective_u_value)
        
        return window_areas, window_u_values
    
    def _get_window_base_u_value(self, window: Dict) -> float:
        """获取窗户基础传热系数"""
        window_type = window.get('type', 'double_glazed')
        
        u_values = {
            'single_glazed': 5.8,
            'double_glazed': 2.8,
            'triple_glazed': 1.6,
            'low_e_double': 2.0,
            'low_e_triple': 1.2
        }
        
        return u_values.get(window_type, 2.8)
    
    def _calculate_shading_thermal_effect(self, individual: Any, window_index: int) -> float:
        """计算遮阳对传热的影响"""
        if not hasattr(individual, 'genes') or 'shading_depths' not in individual.genes:
            return 0.0
        
        if window_index >= len(individual.genes['shading_depths']):
            return 0.0
        
        shading_depth = individual.genes['shading_depths'][window_index]
        shading_angle = individual.genes.get('shading_angles', [0] * len(individual.genes['shading_depths']))[window_index]
        
        # 遮阳深度和角度对传热系数的影响（简化模型）
        depth_factor = min(shading_depth / 1.0, 1.0)  # 标准化到[0,1]
        angle_factor = np.sin(np.radians(shading_angle)) if shading_angle > 0 else 0
        
        return depth_factor * angle_factor * 0.1  # 最大10%的改善
    
    def calculate_thermal_mass(self, individual: Any, facade_data: Dict) -> float:
        """
        计算热惰性（热质量）
        
        Args:
            individual: 优化个体
            facade_data: 立面数据
            
        Returns:
            float: 热惰性 (J/m²·K)
        """
        try:
            total_thermal_mass = 0.0
            total_area = facade_data.get('total_area', 100.0)
            
            # 墙体热质量
            wall_area = self._calculate_wall_area(individual, facade_data)
            wall_thermal_mass = self._calculate_wall_thermal_mass()
            total_thermal_mass += wall_area * wall_thermal_mass
            
            # 窗户热质量（相对较小）
            window_areas, _ = self._calculate_window_thermal_properties(individual, facade_data)
            window_thermal_mass = 15000  # J/m²·K (玻璃的热质量)
            total_thermal_mass += sum(window_areas) * window_thermal_mass
            
            # 遮阳构件热质量
            shading_thermal_mass = self._calculate_shading_thermal_mass(individual, facade_data)
            total_thermal_mass += shading_thermal_mass
            
            return total_thermal_mass / total_area
            
        except Exception as e:
            logger.error(f"热惰性计算失败: {e}")
            return 150000  # 返回典型值
    
    def _calculate_wall_thermal_mass(self) -> float:
        """计算墙体热质量"""
        thermal_mass = 0.0
        
        # 计算各层的热质量
        wall_layers = [
            ('concrete', 0.2),
            ('insulation', 0.1),
            ('brick', 0.05)
        ]
        
        for material_name, thickness in wall_layers:
            material = self.material_database[material_name]
            layer_thermal_mass = (
                material.density * material.specific_heat * thickness
            )
            thermal_mass += layer_thermal_mass
        
        return thermal_mass
    
    def _calculate_shading_thermal_mass(self, individual: Any, facade_data: Dict) -> float:
        """计算遮阳构件热质量"""
        if not hasattr(individual, 'genes') or 'shading_depths' not in individual.genes:
            return 0.0
        
        total_shading_mass = 0.0
        
        for i, depth in enumerate(individual.genes['shading_depths']):
            if depth > 0:
                # 假设遮阳构件为混凝土材质
                shading_volume = depth * 1.0 * 0.1  # 深度 × 宽度 × 厚度
                material = self.material_database['concrete']
                shading_mass = (
                    material.density * material.specific_heat * shading_volume
                )
                total_shading_mass += shading_mass
        
        return total_shading_mass
    
    def analyze_thermal_bridges(self, individual: Any, facade_data: Dict) -> float:
        """
        分析热桥效应
        
        Args:
            individual: 优化个体
            facade_data: 立面数据
            
        Returns:
            float: 热桥系数
        """
        try:
            thermal_bridge_factor = 0.0
            
            # 1. 窗框热桥
            window_frame_bridges = self._calculate_window_frame_bridges(individual, facade_data)
            thermal_bridge_factor += window_frame_bridges
            
            # 2. 结构热桥（梁、柱、楼板）
            structural_bridges = self._calculate_structural_bridges(facade_data)
            thermal_bridge_factor += structural_bridges
            
            # 3. 遮阳连接热桥
            shading_bridges = self._calculate_shading_bridges(individual, facade_data)
            thermal_bridge_factor += shading_bridges
            
            # 4. 几何热桥（转角、凹凸）
            geometric_bridges = self._calculate_geometric_bridges(facade_data)
            thermal_bridge_factor += geometric_bridges
            
            return min(thermal_bridge_factor, 0.5)  # 限制最大值
            
        except Exception as e:
            logger.error(f"热桥分析失败: {e}")
            return 0.1  # 返回默认值
    
    def _calculate_window_frame_bridges(self, individual: Any, facade_data: Dict) -> float:
        """计算窗框热桥"""
        windows = facade_data.get('windows', [])
        total_bridge_effect = 0.0
        
        for i, window in enumerate(windows):
            # 窗框周长
            if hasattr(individual, 'genes') and 'window_width_scales' in individual.genes:
                if i < len(individual.genes['window_width_scales']):
                    width = window.get('width', 1.0) * individual.genes['window_width_scales'][i]
                    height = window.get('height', 1.0) * individual.genes.get('window_height_scales', [1.0] * len(windows))[i]
                else:
                    width = window.get('width', 1.0)
                    height = window.get('height', 1.0)
            else:
                width = window.get('width', 1.0)
                height = window.get('height', 1.0)
            
            perimeter = 2 * (width + height)
            
            # 窗框材质影响
            frame_material = window.get('frame_material', 'aluminum')
            if frame_material == 'aluminum':
                bridge_coefficient = 0.8  # W/m·K
            elif frame_material == 'wood':
                bridge_coefficient = 0.2
            else:
                bridge_coefficient = 0.5
            
            bridge_effect = perimeter * bridge_coefficient * 0.001  # 转换为系数
            total_bridge_effect += bridge_effect
        
        return total_bridge_effect
    
    def _calculate_structural_bridges(self, facade_data: Dict) -> float:
        """计算结构热桥"""
        # 简化计算：基于立面面积估算结构热桥
        total_area = facade_data.get('total_area', 100.0)
        
        # 典型结构热桥密度
        bridge_density = 0.5  # 每平方米的热桥长度 (m/m²)
        bridge_coefficient = 0.3  # W/m·K
        
        structural_bridge_effect = total_area * bridge_density * bridge_coefficient * 0.001
        
        return structural_bridge_effect
    
    def _calculate_shading_bridges(self, individual: Any, facade_data: Dict) -> float:
        """计算遮阳连接热桥"""
        if not hasattr(individual, 'genes') or 'shading_depths' not in individual.genes:
            return 0.0
        
        total_bridge_effect = 0.0
        
        for depth in individual.genes['shading_depths']:
            if depth > 0:
                # 遮阳连接点热桥
                connection_length = 2.0  # 假设每个遮阳有2米的连接长度
                bridge_coefficient = 0.5  # W/m·K
                bridge_effect = connection_length * bridge_coefficient * 0.001
                total_bridge_effect += bridge_effect
        
        return total_bridge_effect
    
    def _calculate_geometric_bridges(self, facade_data: Dict) -> float:
        """计算几何热桥"""
        # 基于立面复杂度的简化计算
        complexity_factor = facade_data.get('complexity_factor', 1.0)
        base_geometric_bridge = 0.02
        
        return base_geometric_bridge * complexity_factor
    
    def simulate_dynamic_thermal_response(self, individual: Any, facade_data: Dict, 
                                        climate_data: List[Dict]) -> Dict[str, float]:
        """
        模拟动态热力性能响应
        
        Args:
            individual: 优化个体
            facade_data: 立面数据
            climate_data: 气候数据
            
        Returns:
            Dict[str, float]: 动态响应特性
        """
        try:
            logger.info("开始动态热力性能模拟")
            
            # 简化的动态模拟（使用前100小时数据进行快速分析）
            simulation_hours = min(100, len(climate_data))
            
            # 初始化温度数组
            indoor_temps = np.zeros(simulation_hours)
            heat_flows = np.zeros(simulation_hours)
            
            # 热力参数
            thermal_mass = self.calculate_thermal_mass(individual, facade_data)
            u_value = self.calculate_overall_u_value(individual, facade_data)
            
            # 动态模拟
            indoor_temp = 20.0  # 初始室内温度
            
            for hour in range(simulation_hours):
                outdoor_temp = climate_data[hour].get('dry_bulb_temp', 15.0)
                solar_radiation = climate_data[hour].get('global_radiation', 0.0)
                
                # 传热计算
                conduction_heat_flow = u_value * (outdoor_temp - indoor_temp)
                
                # 太阳得热
                solar_gain = self._calculate_solar_gain(individual, facade_data, solar_radiation)
                
                # 总热流
                total_heat_flow = conduction_heat_flow + solar_gain
                
                # 温度变化（考虑热惰性）
                temp_change = total_heat_flow / (thermal_mass / 3600)  # 每小时温度变化
                indoor_temp += temp_change * 0.1  # 阻尼系数
                
                indoor_temps[hour] = indoor_temp
                heat_flows[hour] = total_heat_flow
            
            # 计算动态响应特性
            response_characteristics = {
                'temperature_swing': float(np.max(indoor_temps) - np.min(indoor_temps)),
                'peak_heat_flow': float(np.max(np.abs(heat_flows))),
                'thermal_stability': float(1.0 / (np.std(indoor_temps) + 0.1)),
                'response_time': self._calculate_response_time(indoor_temps),
                'damping_factor': self._calculate_damping_factor(indoor_temps, climate_data[:simulation_hours])
            }
            
            logger.info("动态热力性能模拟完成")
            return response_characteristics
            
        except Exception as e:
            logger.error(f"动态热力性能模拟失败: {e}")
            return self._get_default_dynamic_response()
    
    def _calculate_solar_gain(self, individual: Any, facade_data: Dict, solar_radiation: float) -> float:
        """计算太阳得热"""
        total_solar_gain = 0.0
        windows = facade_data.get('windows', [])
        
        for i, window in enumerate(windows):
            # 窗户面积
            if hasattr(individual, 'genes') and 'window_width_scales' in individual.genes:
                if i < len(individual.genes['window_width_scales']):
                    area = (window.get('width', 1.0) * individual.genes['window_width_scales'][i] *
                           window.get('height', 1.0) * individual.genes.get('window_height_scales', [1.0] * len(windows))[i])
                else:
                    area = window.get('width', 1.0) * window.get('height', 1.0)
            else:
                area = window.get('width', 1.0) * window.get('height', 1.0)
            
            # 太阳得热系数
            shgc = 0.6  # 太阳得热系数
            
            # 遮阳影响
            shading_factor = self._calculate_shading_solar_factor(individual, i)
            
            # 窗户太阳得热
            window_solar_gain = area * solar_radiation * shgc * (1 - shading_factor) / 1000
            total_solar_gain += window_solar_gain
        
        return total_solar_gain
    
    def _calculate_shading_solar_factor(self, individual: Any, window_index: int) -> float:
        """计算遮阳对太阳辐射的遮挡系数"""
        if not hasattr(individual, 'genes') or 'shading_depths' not in individual.genes:
            return 0.0
        
        if window_index >= len(individual.genes['shading_depths']):
            return 0.0
        
        shading_depth = individual.genes['shading_depths'][window_index]
        shading_angle = individual.genes.get('shading_angles', [0] * len(individual.genes['shading_depths']))[window_index]
        
        # 简化的遮阳计算
        if shading_depth <= 0:
            return 0.0
        
        # 基于深度和角度的遮阳系数
        depth_factor = min(shading_depth / 1.0, 1.0)
        angle_factor = np.sin(np.radians(max(shading_angle, 30))) if shading_angle > 0 else 0.5
        
        return depth_factor * angle_factor * 0.7  # 最大70%的遮阳
    
    def _calculate_response_time(self, temperature_series: np.ndarray) -> float:
        """计算热响应时间"""
        # 简化计算：基于温度变化的时间常数
        if len(temperature_series) < 10:
            return 2.0
        
        # 计算温度变化率
        temp_changes = np.diff(temperature_series)
        avg_change_rate = np.mean(np.abs(temp_changes))
        
        # 响应时间与变化率成反比
        response_time = 1.0 / (avg_change_rate + 0.1)
        
        return min(max(response_time, 0.5), 8.0)  # 限制在0.5-8小时范围内
    
    def _calculate_damping_factor(self, indoor_temps: np.ndarray, climate_data: List[Dict]) -> float:
        """计算阻尼系数"""
        if len(indoor_temps) != len(climate_data):
            return 0.5
        
        # 提取室外温度
        outdoor_temps = np.array([data.get('dry_bulb_temp', 15.0) for data in climate_data])
        
        # 计算温度波动的阻尼效果
        outdoor_variation = np.std(outdoor_temps)
        indoor_variation = np.std(indoor_temps)
        
        if outdoor_variation > 0:
            damping_factor = 1.0 - (indoor_variation / outdoor_variation)
            return max(0.0, min(damping_factor, 1.0))
        else:
            return 0.5
    
    def calculate_heat_capacity(self, individual: Any, facade_data: Dict) -> float:
        """
        计算热容量
        
        Args:
            individual: 优化个体
            facade_data: 立面数据
            
        Returns:
            float: 热容量 (J/K)
        """
        try:
            total_heat_capacity = 0.0
            
            # 墙体热容量
            wall_area = self._calculate_wall_area(individual, facade_data)
            wall_heat_capacity = self._calculate_wall_heat_capacity()
            total_heat_capacity += wall_area * wall_heat_capacity
            
            # 窗户热容量
            window_areas, _ = self._calculate_window_thermal_properties(individual, facade_data)
            glass_heat_capacity = 1875  # J/m²·K (玻璃的面积热容量)
            total_heat_capacity += sum(window_areas) * glass_heat_capacity
            
            # 遮阳构件热容量
            shading_heat_capacity = self._calculate_shading_heat_capacity(individual)
            total_heat_capacity += shading_heat_capacity
            
            return total_heat_capacity
            
        except Exception as e:
            logger.error(f"热容量计算失败: {e}")
            return 15000000  # 返回典型值 (J/K)
    
    def _calculate_wall_heat_capacity(self) -> float:
        """计算墙体面积热容量"""
        heat_capacity = 0.0
        
        wall_layers = [
            ('concrete', 0.2),
            ('insulation', 0.1),
            ('brick', 0.05)
        ]
        
        for material_name, thickness in wall_layers:
            material = self.material_database[material_name]
            layer_heat_capacity = (
                material.density * material.specific_heat * thickness
            )
            heat_capacity += layer_heat_capacity
        
        return heat_capacity
    
    def _calculate_shading_heat_capacity(self, individual: Any) -> float:
        """计算遮阳构件热容量"""
        if not hasattr(individual, 'genes') or 'shading_depths' not in individual.genes:
            return 0.0
        
        total_capacity = 0.0
        material = self.material_database['concrete']
        
        for depth in individual.genes['shading_depths']:
            if depth > 0:
                # 遮阳构件体积
                volume = depth * 1.0 * 0.1  # 深度 × 宽度 × 厚度
                capacity = material.density * material.specific_heat * volume
                total_capacity += capacity
        
        return total_capacity
    
    def calculate_thermal_lag(self, individual: Any, facade_data: Dict) -> float:
        """
        计算热滞后时间
        
        Args:
            individual: 优化个体
            facade_data: 立面数据
            
        Returns:
            float: 热滞后时间 (hours)
        """
        try:
            # 基于热惰性和传热系数计算热滞后
            thermal_mass = self.calculate_thermal_mass(individual, facade_data)
            u_value = self.calculate_overall_u_value(individual, facade_data)
            
            # 热滞后时间计算（简化公式）
            thermal_lag = (thermal_mass / 1000) / (u_value * 10)
            
            # 限制在合理范围内
            return max(0.5, min(thermal_lag, 12.0))
            
        except Exception as e:
            logger.error(f"热滞后计算失败: {e}")
            return 3.0  # 返回典型值
    
    def _get_default_thermal_properties(self) -> ThermalProperties:
        """获取默认热力性能属性"""
        return ThermalProperties(
            overall_u_value=2.5,
            thermal_mass=150000,
            thermal_bridge_factor=0.1,
            dynamic_response=self._get_default_dynamic_response(),
            heat_capacity=15000000,
            thermal_lag=3.0
        )
    
    def _get_default_dynamic_response(self) -> Dict[str, float]:
        """获取默认动态响应特性"""
        return {
            'temperature_swing': 3.0,
            'peak_heat_flow': 50.0,
            'thermal_stability': 0.8,
            'response_time': 2.0,
            'damping_factor': 0.6
        }
    
    def export_thermal_analysis_report(self, thermal_properties: ThermalProperties, 
                                     output_path: str) -> bool:
        """
        导出热力分析报告
        
        Args:
            thermal_properties: 热力性能属性
            output_path: 输出路径
            
        Returns:
            bool: 导出是否成功
        """
        try:
            report_data = {
                'thermal_performance_analysis': {
                    'overall_u_value': {
                        'value': thermal_properties.overall_u_value,
                        'unit': 'W/m²·K',
                        'description': '整体传热系数'
                    },
                    'thermal_mass': {
                        'value': thermal_properties.thermal_mass,
                        'unit': 'J/m²·K',
                        'description': '热惰性'
                    },
                    'thermal_bridge_factor': {
                        'value': thermal_properties.thermal_bridge_factor,
                        'unit': '-',
                        'description': '热桥系数'
                    },
                    'heat_capacity': {
                        'value': thermal_properties.heat_capacity,
                        'unit': 'J/K',
                        'description': '热容量'
                    },
                    'thermal_lag': {
                        'value': thermal_properties.thermal_lag,
                        'unit': 'hours',
                        'description': '热滞后时间'
                    },
                    'dynamic_response': thermal_properties.dynamic_response
                },
                'analysis_timestamp': pd.Timestamp.now().isoformat(),
                'analyzer_version': '1.0.0'
            }
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, ensure_ascii=False, indent=2)
            
            logger.info(f"热力分析报告已导出到: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"报告导出失败: {e}")
            return False


# 工具函数
def create_test_thermal_analyzer() -> ThermalPerformanceAnalyzer:
    """创建测试用的热力性能分析器"""
    return ThermalPerformanceAnalyzer()


def validate_thermal_properties(properties: ThermalProperties) -> bool:
    """验证热力性能属性的合理性"""
    try:
        # 检查传热系数范围
        if not (0.1 <= properties.overall_u_value <= 10.0):
            return False
        
        # 检查热惰性范围
        if not (10000 <= properties.thermal_mass <= 1000000):
            return False
        
        # 检查热桥系数范围
        if not (0.0 <= properties.thermal_bridge_factor <= 1.0):
            return False
        
        # 检查热滞后时间范围
        if not (0.1 <= properties.thermal_lag <= 24.0):
            return False
        
        return True
        
    except Exception:
        return False


if __name__ == "__main__":
    # 测试代码
    analyzer = create_test_thermal_analyzer()
    
    # 创建测试数据
    class TestIndividual:
        def __init__(self):
            self.genes = {
                'window_width_scales': np.array([1.2, 0.8, 1.0]),
                'window_height_scales': np.array([1.1, 0.9, 1.0]),
                'shading_depths': np.array([0.5, 0.3, 0.0]),
                'shading_angles': np.array([45, 30, 0])
            }
    
    test_individual = TestIndividual()
    
    test_facade_data = {
        'total_area': 100.0,
        'windows': [
            {'width': 2.0, 'height': 1.5, 'type': 'double_glazed'},
            {'width': 1.5, 'height': 1.2, 'type': 'double_glazed'},
            {'width': 1.8, 'height': 1.4, 'type': 'double_glazed'}
        ]
    }
    
    test_climate_data = [
        {'dry_bulb_temp': 25.0, 'global_radiation': 500.0},
        {'dry_bulb_temp': 28.0, 'global_radiation': 600.0},
        {'dry_bulb_temp': 22.0, 'global_radiation': 400.0}
    ] * 34  # 扩展到100小时
    
    # 运行分析
    result = analyzer.analyze_thermal_performance(
        test_individual, test_facade_data, test_climate_data
    )
    
    print("热力性能分析结果:")
    print(f"整体传热系数: {result.overall_u_value:.3f} W/m²·K")
    print(f"热惰性: {result.thermal_mass:.0f} J/m²·K")
    print(f"热桥系数: {result.thermal_bridge_factor:.3f}")
    print(f"热容量: {result.heat_capacity:.0f} J/K")
    print(f"热滞后时间: {result.thermal_lag:.1f} hours")
    print(f"动态响应特性: {result.dynamic_response}")
