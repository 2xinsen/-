
"""
建筑朝向调整器
负责根据建筑朝向调整太阳辐射和风压等参数
"""

import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
import math

from ..core.config import config_manager
from ..core.logging_config import get_logger, LogContext
from ..core.exceptions import OrientationAdjustmentError, ClimateDataError
from ..core.data_structures import ClimateDataPoint, ClimateData
from ..core.utils import InteractiveUtils

# 获取日志记录器
logger = get_logger(__name__)


@dataclass
class OrientationFactors:
    """朝向调整系数数据类"""
    solar_factor: float = 1.0      # 太阳辐射调整系数
    wind_factor: float = 1.0       # 风压调整系数
    shading_factor: float = 1.0    # 遮阳效果调整系数
    thermal_factor: float = 1.0    # 热力学调整系数


class OrientationAdjuster:
    """
    建筑朝向调整器
    
    功能：
    1. 根据建筑朝向调整太阳辐射参数
    2. 调整风压系数和风速影响
    3. 计算阴影效应和遮挡影响
    4. 提供朝向优化建议
    """
    
    def __init__(self):
        """初始化朝向调整器"""
        # 获取配置
        self.config = config_manager.get('climate_data', {})
        
        # 朝向调整系数配置
        self.orientation_factors_config = self.config.get('orientation_factors', {
            'south': {'solar': 1.0, 'wind': 1.0},
            'southeast': {'solar': 0.9, 'wind': 0.85},
            'southwest': {'solar': 0.9, 'wind': 0.85},
            'east': {'solar': 0.8, 'wind': 0.9},
            'west': {'solar': 0.8, 'wind': 0.9},
            'northeast': {'solar': 0.7, 'wind': 0.8},
            'northwest': {'solar': 0.7, 'wind': 0.8},
            'north': {'solar': 0.6, 'wind': 0.75}
        })
        
        # 朝向角度映射（度）
        self.orientation_angles = {
            'north': 0,
            'northeast': 45,
            'east': 90,
            'southeast': 135,
            'south': 180,
            'southwest': 225,
            'west': 270,
            'northwest': 315
        }
        
        # 中文朝向映射
        self.chinese_orientations = {
            '北': 'north',
            '东北': 'northeast',
            '东': 'east',
            '东南': 'southeast',
            '南': 'south',
            '西南': 'southwest',
            '西': 'west',
            '西北': 'northwest'
        }
        
        logger.info("建筑朝向调整器初始化完成")
    
    def adjust_climate_data(self, climate_data: ClimateData, 
                           building_orientation: str) -> ClimateData:
        """
        根据建筑朝向调整气候数据
        
        Args:
            climate_data: 原始气候数据
            building_orientation: 建筑朝向（中文或英文）
            
        Returns:
            调整后的气候数据
            
        Raises:
            OrientationAdjustmentError: 调整失败时抛出
        """
        with LogContext(f"朝向调整 ({building_orientation})", logger):
            try:
                # 标准化朝向名称
                orientation = self._normalize_orientation(building_orientation)
                logger.info(f"建筑朝向: {orientation}")
                
                # 获取调整系数
                factors = self._get_orientation_factors(orientation)
                
                # 创建调整后的气候数据副本
                adjusted_climate_data = self._create_climate_data_copy(climate_data)
                
                # 调整小时数据
                adjusted_hourly_data = []
                for data_point in climate_data.hourly_data:
                    adjusted_point = self._adjust_data_point(data_point, factors, orientation)
                    adjusted_hourly_data.append(adjusted_point)
                
                adjusted_climate_data.hourly_data = adjusted_hourly_data
                
                # 更新朝向调整信息
                adjusted_climate_data.orientation_factors = {
                    'orientation': orientation,
                    'solar_factor': factors.solar_factor,
                    'wind_factor': factors.wind_factor,
                    'adjustment_applied': True
                }
                
                # 重新计算设计工况
                adjusted_climate_data.design_conditions = self._recalculate_design_conditions(
                    adjusted_hourly_data
                )
                
                logger.info(f"朝向调整完成，太阳辐射系数: {factors.solar_factor:.2f}, "
                           f"风压系数: {factors.wind_factor:.2f}")
                
                return adjusted_climate_data
                
            except Exception as e:
                error_msg = f"朝向调整失败: {str(e)}"
                logger.error(error_msg)
                raise OrientationAdjustmentError(error_msg) from e
    
    def _normalize_orientation(self, orientation) -> str:
        """标准化朝向名称"""
        try:
            # 处理不同类型的输入
            if isinstance(orientation, (int, float)):
                # 直接处理数值类型的角度输入
                return self._angle_to_orientation(float(orientation))
            
            # 处理字符串类型
            if isinstance(orientation, str):
                orientation = orientation.strip().lower()
                
                # 处理中文朝向
                if orientation in self.chinese_orientations:
                    return self.chinese_orientations[orientation]
                
                # 处理英文朝向
                if orientation in self.orientation_angles:
                    return orientation
                
                # 处理角度输入
                try:
                    angle = float(orientation)
                    return self._angle_to_orientation(angle)
                except ValueError:
                    pass
                
                # 模糊匹配
                for key in self.orientation_angles.keys():
                    if key.startswith(orientation) or orientation in key:
                        return key
            
            # 默认返回南向
            logger.warning(f"无法识别朝向 '{orientation}'，使用默认朝向 'south'")
            return 'south'
            
        except Exception as e:
            logger.warning(f"朝向标准化失败: {str(e)}，使用默认朝向 'south'")
            return 'south'
    
    def _angle_to_orientation(self, angle: float) -> str:
        """将角度转换为朝向名称"""
        # 标准化角度到0-360度
        angle = angle % 360
        
        # 定义角度范围
        angle_ranges = [
            (337.5, 22.5, 'north'),
            (22.5, 67.5, 'northeast'),
            (67.5, 112.5, 'east'),
            (112.5, 157.5, 'southeast'),
            (157.5, 202.5, 'south'),
            (202.5, 247.5, 'southwest'),
            (247.5, 292.5, 'west'),
            (292.5, 337.5, 'northwest')
        ]
        
        for start, end, orientation in angle_ranges:
            if start > end:  # 跨越0度的情况（如north）
                if angle >= start or angle <= end:
                    return orientation
            else:
                if start <= angle <= end:
                    return orientation
        
        return 'south'  # 默认
    
    def _get_orientation_factors(self, orientation: str) -> OrientationFactors:
        """获取朝向调整系数"""
        try:
            config_factors = self.orientation_factors_config.get(orientation, {
                'solar': 0.8, 'wind': 0.9
            })
            
            # 计算额外的调整系数
            solar_factor = config_factors.get('solar', 0.8)
            wind_factor = config_factors.get('wind', 0.9)
            
            # 根据朝向计算遮阳和热力学系数
            shading_factor = self._calculate_shading_factor(orientation)
            thermal_factor = self._calculate_thermal_factor(orientation)
            
            return OrientationFactors(
                solar_factor=solar_factor,
                wind_factor=wind_factor,
                shading_factor=shading_factor,
                thermal_factor=thermal_factor
            )
            
        except Exception as e:
            logger.warning(f"获取朝向系数失败: {str(e)}")
            return OrientationFactors()  # 返回默认系数
    
    def _calculate_shading_factor(self, orientation: str) -> float:
        """计算遮阳效果系数"""
        try:
            # 不同朝向的遮阳效果不同
            shading_factors = {
                'south': 1.2,      # 南向遮阳效果最好
                'southeast': 1.1,
                'southwest': 1.1,
                'east': 0.9,       # 东西向遮阳效果一般
                'west': 0.9,
                'northeast': 0.8,
                'northwest': 0.8,
                'north': 0.7       # 北向遮阳效果最差
            }
            
            return shading_factors.get(orientation, 1.0)
            
        except Exception:
            return 1.0
    
    def _calculate_thermal_factor(self, orientation: str) -> float:
        """计算热力学调整系数"""
        try:
            # 不同朝向的热力学特性
            thermal_factors = {
                'south': 1.0,      # 南向热力学特性标准
                'southeast': 0.95,
                'southwest': 1.05, # 西南向下午受热较多
                'east': 0.9,       # 东向上午受热
                'west': 1.1,       # 西向下午受热最多
                'northeast': 0.85,
                'northwest': 1.0,
                'north': 0.8       # 北向受热最少
            }
            
            return thermal_factors.get(orientation, 1.0)
            
        except Exception:
            return 1.0
    
    def _create_climate_data_copy(self, climate_data: ClimateData) -> ClimateData:
        """创建气候数据的副本"""
        try:
            return ClimateData(
                location_name=climate_data.location_name,
                latitude=climate_data.latitude,
                longitude=climate_data.longitude,
                elevation=climate_data.elevation,
                time_zone=climate_data.time_zone,
                hourly_data=[],  # 将在后续填充
                design_conditions=climate_data.design_conditions.copy(),
                seasonal_patterns=climate_data.seasonal_patterns.copy(),
                extreme_events=climate_data.extreme_events.copy(),
                data_quality=climate_data.data_quality.copy(),
                orientation_factors=climate_data.orientation_factors.copy()
            )
        except Exception as e:
            logger.warning(f"创建气候数据副本失败: {str(e)}")
            return climate_data
    
    def _adjust_data_point(self, data_point: ClimateDataPoint, 
                          factors: OrientationFactors, orientation: str) -> ClimateDataPoint:
        """调整单个数据点"""
        try:
            # 计算太阳位置相关的调整
            solar_adjustment = self._calculate_solar_adjustment(
                data_point, factors, orientation
            )
            
            # 计算风压调整
            wind_adjustment = self._calculate_wind_adjustment(
                data_point, factors, orientation
            )
            
            # 创建调整后的数据点
            adjusted_point = ClimateDataPoint(
                month=data_point.month,
                day=data_point.day,
                hour=data_point.hour,
                dry_bulb_temp=data_point.dry_bulb_temp,  # 温度不直接调整
                wet_bulb_temp=data_point.wet_bulb_temp,
                dew_point_temp=data_point.dew_point_temp,
                relative_humidity=data_point.relative_humidity,
                atmospheric_pressure=data_point.atmospheric_pressure,
                
                # 调整太阳辐射
                global_radiation=data_point.global_radiation * solar_adjustment,
                direct_radiation=data_point.direct_radiation * solar_adjustment,
                diffuse_radiation=data_point.diffuse_radiation * factors.solar_factor,
                
                # 调整风参数
                wind_speed=data_point.wind_speed * wind_adjustment,
                wind_direction=data_point.wind_direction,  # 风向不调整
                
                # 其他参数
                cloud_cover=data_point.cloud_cover,
                visibility=data_point.visibility
            )
            
            return adjusted_point
            
        except Exception as e:
            logger.warning(f"数据点调整失败: {str(e)}")
            return data_point  # 返回原始数据点
    
    def _calculate_solar_adjustment(self, data_point: ClimateDataPoint, 
                                  factors: OrientationFactors, orientation: str) -> float:
        """计算太阳辐射调整系数"""
        try:
            # 基础朝向系数
            base_factor = factors.solar_factor
            
            # 根据时间进行精细调整
            hour_factor = self._get_hourly_solar_factor(data_point.hour, orientation)
            
            # 根据季节进行调整
            seasonal_factor = self._get_seasonal_solar_factor(data_point.month, orientation)
            
            # 综合调整系数
            total_factor = base_factor * hour_factor * seasonal_factor
            
            # 限制调整范围
            return max(0.1, min(2.0, total_factor))
            
        except Exception as e:
            logger.warning(f"太阳辐射调整计算失败: {str(e)}")
            return factors.solar_factor
    
    def _get_hourly_solar_factor(self, hour: int, orientation: str) -> float:
        """获取小时太阳辐射调整系数"""
        try:
            # 不同朝向在不同时间的太阳辐射接收情况
            if orientation == 'east':
                # 东向：上午辐射强，下午弱
                if 6 <= hour <= 12:
                    return 1.2 - 0.1 * (hour - 6)  # 6点最强，逐渐减弱
                else:
                    return 0.3
            elif orientation == 'west':
                # 西向：下午辐射强，上午弱
                if 12 <= hour <= 18:
                    return 0.5 + 0.1 * (hour - 12)  # 12点开始增强，18点最强
                else:
                    return 0.3
            elif orientation == 'south':
                # 南向：中午前后辐射最强
                if 9 <= hour <= 15:
                    return 1.0 + 0.2 * math.cos((hour - 12) * math.pi / 6)
                else:
                    return 0.4
            elif orientation == 'north':
                # 北向：全天辐射较弱且均匀
                return 0.6
            else:
                # 其他朝向的插值计算
                return 0.8
                
        except Exception:
            return 1.0
    
    def _get_seasonal_solar_factor(self, month: int, orientation: str) -> float:
        """获取季节太阳辐射调整系数"""
        try:
            # 太阳高度角的季节变化影响
            if orientation in ['south', 'southeast', 'southwest']:
                # 南向系朝向：冬季太阳高度角低，辐射接收好
                seasonal_factors = [1.2, 1.1, 1.0, 0.9, 0.8, 0.7, 
                                  0.7, 0.8, 0.9, 1.0, 1.1, 1.2]
            elif orientation in ['north', 'northeast', 'northwest']:
                # 北向系朝向：夏季接收更多辐射
                seasonal_factors = [0.5, 0.6, 0.7, 0.8, 0.9, 1.0,
                                  1.0, 0.9, 0.8, 0.7, 0.6, 0.5]
            else:
                # 东西向：季节变化相对较小
                seasonal_factors = [0.9, 0.9, 1.0, 1.0, 1.1, 1.1,
                                  1.1, 1.1, 1.0, 1.0, 0.9, 0.9]
            
            return seasonal_factors[month - 1] if 1 <= month <= 12 else 1.0
            
        except Exception:
            return 1.0
    
    def _calculate_wind_adjustment(self, data_point: ClimateDataPoint, 
                                 factors: OrientationFactors, orientation: str) -> float:
        """计算风压调整系数"""
        try:
            # 基础风压系数
            base_factor = factors.wind_factor
            
            # 根据风向和建筑朝向的关系调整
            wind_direction = data_point.wind_direction
            building_angle = self.orientation_angles.get(orientation, 180)
            
            # 计算风向与建筑朝向的夹角
            angle_diff = abs(wind_direction - building_angle)
            angle_diff = min(angle_diff, 360 - angle_diff)  # 取较小角度
            
            # 正面受风时风压最大，侧面和背面较小
            if angle_diff <= 45:
                # 正面受风
                directional_factor = 1.2
            elif angle_diff <= 135:
                # 侧面受风
                directional_factor = 0.8
            else:
                # 背面受风
                directional_factor = 0.6
            
            return base_factor * directional_factor
            
        except Exception as e:
            logger.warning(f"风压调整计算失败: {str(e)}")
            return factors.wind_factor
    
    def _recalculate_design_conditions(self, hourly_data: List[ClimateDataPoint]) -> Dict[str, Any]:
        """重新计算设计工况"""
        try:
            if not hourly_data:
                return {}
            
            # 提取调整后的数据
            temps = [dp.dry_bulb_temp for dp in hourly_data]
            radiations = [dp.global_radiation for dp in hourly_data]
            wind_speeds = [dp.wind_speed for dp in hourly_data]
            
            design_conditions = {
                'heating_design_temp': np.percentile(temps, 1),
                'cooling_design_temp': np.percentile(temps, 99),
                'mean_temp': np.mean(temps),
                
                # 调整后的太阳辐射统计
                'max_solar_radiation': max(radiations),
                'avg_solar_radiation': np.mean(radiations),
                'summer_avg_radiation': np.mean([dp.global_radiation for dp in hourly_data 
                                               if dp.month in [6, 7, 8]]),
                
                # 调整后的风速统计
                'max_wind_speed': max(wind_speeds),
                'avg_wind_speed': np.mean(wind_speeds),
                
                # 标记为调整后数据
                'orientation_adjusted': True
            }
            
            return design_conditions
            
        except Exception as e:
            logger.warning(f"设计工况重新计算失败: {str(e)}")
            return {}
    
    def calculate_shading_effectiveness(self, orientation: str, 
                                     shading_depth: float, shading_angle: float) -> float:
        """
        计算遮阳效果
        
        Args:
            orientation: 建筑朝向
            shading_depth: 遮阳深度 (m)
            shading_angle: 遮阳角度 (度)
            
        Returns:
            遮阳效果系数 (0-1)
        """
        try:
            # 基础遮阳效果
            base_effectiveness = min(1.0, shading_depth / 0.5)  # 0.5m为参考深度
            
            # 朝向调整
            orientation_factor = self._calculate_shading_factor(orientation)
            
            # 角度调整
            angle_factor = math.cos(math.radians(shading_angle)) if shading_angle <= 90 else 0.1
            
            # 综合效果
            effectiveness = base_effectiveness * orientation_factor * angle_factor
            
            return max(0.0, min(1.0, effectiveness))
            
        except Exception as e:
            logger.warning(f"遮阳效果计算失败: {str(e)}")
            return 0.5  # 默认中等效果
    
    def get_orientation_recommendations(self, climate_data: ClimateData) -> Dict[str, Any]:
        """
        获取朝向优化建议
        
        Args:
            climate_data: 气候数据
            
        Returns:
            朝向建议字典
        """
        try:
            recommendations = {
                'optimal_orientations': [],
                'analysis': {},
                'seasonal_considerations': {},
                'energy_implications': {}
            }
            
            # 分析各朝向的性能
            orientation_scores = {}
            
            for orientation in self.orientation_angles.keys():
                score = self._evaluate_orientation_performance(climate_data, orientation)
                orientation_scores[orientation] = score
            
            # 排序推荐
            sorted_orientations = sorted(orientation_scores.items(), 
                                       key=lambda x: x[1], reverse=True)
            
            recommendations['optimal_orientations'] = [
                {'orientation': orient, 'score': score} 
                for orient, score in sorted_orientations[:3]
            ]
            
            # 详细分析
            recommendations['analysis'] = {
                'best_orientation': sorted_orientations[0][0],
                'worst_orientation': sorted_orientations[-1][0],
                'score_range': {
                    'max': sorted_orientations[0][1],
                    'min': sorted_orientations[-1][1]
                }
            }
            
            # 季节性考虑
            recommendations['seasonal_considerations'] = {
                'summer': '南向和东南向有利于夏季遮阳',
                'winter': '南向有利于冬季采光和得热',
                'year_round': '南向通常是最佳选择'
            }
            
            # 能耗影响
            recommendations['energy_implications'] = {
                'heating': '南向可减少冬季供暖能耗',
                'cooling': '北向可减少夏季制冷能耗',
                'lighting': '南向和东向有利于自然采光'
            }
            
            return recommendations
            
        except Exception as e:
            logger.error(f"朝向建议生成失败: {str(e)}")
            return {}
    
    def _evaluate_orientation_performance(self, climate_data: ClimateData, 
                                        orientation: str) -> float:
        """评估朝向性能得分"""
        try:
            # 获取朝向系数
            factors = self._get_orientation_factors(orientation)
            
            # 计算各项得分
            solar_score = factors.solar_factor * 0.4      # 太阳辐射权重40%
            wind_score = factors.wind_factor * 0.2        # 风压权重20%
            shading_score = factors.shading_factor * 0.2  # 遮阳权重20%
            thermal_score = factors.thermal_factor * 0.2  # 热力学权重20%
            
            total_score = solar_score + wind_score + shading_score + thermal_score
            
            return total_score
            
        except Exception:
            return 0.5  # 默认中等得分
    
    def interactive_orientation_selection(self) -> str:
        """
        交互式朝向选择
        
        Returns:
            选择的朝向
        """
        try:
            logger.info("开始交互式朝向选择")
            
            # 朝向选项（中文）
            orientation_options = [
                "南 (South) - 全天采光好，冬季得热多",
                "东南 (Southeast) - 上午采光好，夏季不过热",
                "东 (East) - 上午采光好，下午较凉爽",
                "东北 (Northeast) - 上午有阳光，全天较凉爽",
                "北 (North) - 全天较凉爽，夏季舒适",
                "西北 (Northwest) - 下午有阳光，上午较凉爽",
                "西 (West) - 下午采光好，夏季较热",
                "西南 (Southwest) - 下午采光好，冬季得热多"
            ]
            
            selected_option = InteractiveUtils.select_option(
                "请选择建筑朝向",
                orientation_options,
                default_index=0  # 默认选择南向
            )
            
            # 提取朝向
            orientation_mapping = {
                0: '南', 1: '东南', 2: '东', 3: '东北',
                4: '北', 5: '西北', 6: '西', 7: '西南'
            }
            
            selected_index = orientation_options.index(selected_option)
            selected_orientation = orientation_mapping[selected_index]
            
            logger.info(f"用户选择了朝向: {selected_orientation}")
            return selected_orientation
            
        except Exception as e:
            logger.error(f"交互式朝向选择失败: {str(e)}")
            return '南'  # 默认返回南向


def create_orientation_adjuster() -> OrientationAdjuster:
    """
    创建建筑朝向调整器实例
    
    Returns:
        配置好的调整器实例
    """
    return OrientationAdjuster()
