
"""
EPW文件解析器
负责解析标准EPW格式的气候数据文件
"""

import re
import csv
from typing import Dict, List, Tuple, Optional, Any
from pathlib import Path
from datetime import datetime
import numpy as np

from ..core.config import config_manager
from ..core.logging_config import get_logger, LogContext
from ..core.exceptions import EPWParsingError, ClimateDataError
from ..core.data_structures import ClimateDataPoint, ClimateData
from ..core.utils import FileUtils, ValidationUtils, InteractiveUtils

# 获取日志记录器
logger = get_logger(__name__)


class EPWHeader:
    """EPW文件头信息类"""
    
    def __init__(self):
        self.location_name: str = ""
        self.state_province: str = ""
        self.country: str = ""
        self.data_source: str = ""
        self.wmo_number: str = ""
        self.latitude: float = 0.0
        self.longitude: float = 0.0
        self.time_zone: float = 0.0
        self.elevation: float = 0.0


class EPWFileParser:
    """
    EPW文件解析器
    
    功能：
    1. 解析标准EPW格式文件
    2. 提取8760小时气候数据（温度、湿度、辐射、风速等）
    3. 解析文件头信息和地理位置
    4. 数据完整性检查和缺失值处理
    """
    
    def __init__(self):
        """初始化EPW文件解析器"""
        # 获取配置
        self.config = config_manager.get('climate_data', {})
        
        # EPW文件字段映射（标准EPW格式）
        self.epw_field_mapping = {
            0: 'year',
            1: 'month',
            2: 'day',
            3: 'hour',
            4: 'minute',
            5: 'data_source_flag',
            6: 'dry_bulb_temp',           # 干球温度 (°C)
            7: 'dew_point_temp',          # 露点温度 (°C)
            8: 'relative_humidity',       # 相对湿度 (%)
            9: 'atmospheric_pressure',    # 大气压力 (Pa)
            10: 'extraterrestrial_horizontal_radiation',  # 地外水平辐射
            11: 'extraterrestrial_direct_normal_radiation',  # 地外直射辐射
            12: 'horizontal_infrared_radiation',  # 水平红外辐射
            13: 'global_horizontal_radiation',    # 全球水平辐射 (Wh/m²)
            14: 'direct_normal_radiation',        # 直射法向辐射 (Wh/m²)
            15: 'diffuse_horizontal_radiation',   # 散射水平辐射 (Wh/m²)
            16: 'global_horizontal_illuminance',  # 全球水平照度
            17: 'direct_normal_illuminance',      # 直射法向照度
            18: 'diffuse_horizontal_illuminance', # 散射水平照度
            19: 'zenith_luminance',               # 天顶亮度
            20: 'wind_direction',                 # 风向 (度)
            21: 'wind_speed',                     # 风速 (m/s)
            22: 'total_sky_cover',                # 总云量
            23: 'opaque_sky_cover',               # 不透明云量
            24: 'visibility',                     # 能见度 (km)
            25: 'ceiling_height',                 # 云底高度 (m)
            26: 'present_weather_observation',    # 当前天气观测
            27: 'present_weather_codes',          # 当前天气代码
            28: 'precipitable_water',             # 可降水量 (mm)
            29: 'aerosol_optical_depth',          # 气溶胶光学厚度
            30: 'snow_depth',                     # 积雪深度 (cm)
            31: 'days_since_last_snowfall',       # 距上次降雪天数
            32: 'albedo',                         # 反照率
            33: 'liquid_precipitation_depth',     # 液体降水深度 (mm)
            34: 'liquid_precipitation_quantity'   # 液体降水量 (hr)
        }
        
        # 必需字段
        self.required_fields = self.config.get('epw_processing', {}).get('required_fields', [
            'dry_bulb_temperature', 'relative_humidity', 'global_horizontal_radiation',
            'direct_normal_radiation', 'diffuse_horizontal_radiation', 'wind_speed',
            'wind_direction', 'atmospheric_station_pressure'
        ])
        
        logger.info("EPW文件解析器初始化完成")
    
    def parse_epw_file(self, file_path: str) -> ClimateData:
        """
        解析EPW文件
        
        Args:
            file_path: EPW文件路径
            
        Returns:
            气候数据对象
            
        Raises:
            EPWParsingError: 解析失败时抛出
        """
        with LogContext("EPW文件解析", logger):
            try:
                # 验证文件
                if not self._validate_epw_file(file_path):
                    raise EPWParsingError(f"EPW文件验证失败: {file_path}")
                
                # 解析文件头
                header = self._parse_header(file_path)
                logger.info(f"解析EPW文件头: {header.location_name}")
                
                # 解析小时数据
                hourly_data = self._parse_hourly_data(file_path)
                logger.info(f"解析了 {len(hourly_data)} 小时的气候数据")
                
                # 创建气候数据对象
                climate_data = ClimateData(
                    location_name=header.location_name,
                    latitude=header.latitude,
                    longitude=header.longitude,
                    elevation=header.elevation,
                    time_zone=header.time_zone,
                    hourly_data=hourly_data
                )
                
                # 数据质量检查
                quality_info = self._check_data_quality(hourly_data)
                climate_data.data_quality = quality_info
                
                # 计算设计工况
                climate_data.design_conditions = self._calculate_design_conditions(hourly_data)
                
                logger.info("EPW文件解析完成")
                return climate_data
                
            except Exception as e:
                error_msg = f"EPW文件解析失败: {str(e)}"
                logger.error(error_msg)
                raise EPWParsingError(error_msg) from e
    
    def _validate_epw_file(self, file_path: str) -> bool:
        """验证EPW文件"""
        try:
            # 检查文件是否存在
            if not ValidationUtils.validate_file_exists(file_path):
                logger.error(f"EPW文件不存在: {file_path}")
                return False
            
            # 检查文件扩展名
            if not file_path.lower().endswith('.epw'):
                logger.error(f"文件扩展名不正确: {file_path}")
                return False
            
            # 检查文件大小（EPW文件通常较大）
            file_size = Path(file_path).stat().st_size
            if file_size < 1024:  # 至少1KB
                logger.error(f"EPW文件过小: {file_size} bytes")
                return False
            
            # 检查文件头格式
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                first_line = f.readline().strip()
                if not first_line.startswith('LOCATION'):
                    logger.error("EPW文件格式不正确，缺少LOCATION行")
                    return False
            
            return True
            
        except Exception as e:
            logger.error(f"EPW文件验证失败: {str(e)}")
            return False
    
    def _parse_header(self, file_path: str) -> EPWHeader:
        """解析EPW文件头"""
        try:
            header = EPWHeader()
            
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                # 读取前8行（EPW标准头部）
                header_lines = []
                for i in range(8):
                    line = f.readline().strip()
                    if line:
                        header_lines.append(line)
                
                # 解析LOCATION行
                if header_lines and header_lines[0].startswith('LOCATION'):
                    location_parts = header_lines[0].split(',')
                    if len(location_parts) >= 10:
                        header.location_name = location_parts[1].strip()
                        header.state_province = location_parts[2].strip()
                        header.country = location_parts[3].strip()
                        header.data_source = location_parts[4].strip()
                        header.wmo_number = location_parts[5].strip()
                        
                        # 解析数值字段
                        try:
                            header.latitude = float(location_parts[6])
                            header.longitude = float(location_parts[7])
                            header.time_zone = float(location_parts[8])
                            header.elevation = float(location_parts[9])
                        except (ValueError, IndexError) as e:
                            logger.warning(f"解析地理信息失败: {str(e)}")
            
            return header
            
        except Exception as e:
            raise EPWParsingError(f"EPW文件头解析失败: {str(e)}") from e
    
    def _parse_hourly_data(self, file_path: str) -> List[ClimateDataPoint]:
        """解析小时数据"""
        try:
            hourly_data = []
            
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                # 跳过头部行（通常是前8行）
                for _ in range(8):
                    f.readline()
                
                # 使用CSV读取器解析数据行
                csv_reader = csv.reader(f)
                
                for row_num, row in enumerate(csv_reader):
                    try:
                        if len(row) < 35:  # EPW标准至少35个字段
                            logger.warning(f"第{row_num + 9}行字段不足: {len(row)}")
                            continue
                        
                        # 解析时间信息
                        year = int(row[0]) if row[0] else 2023
                        month = int(row[1]) if row[1] else 1
                        day = int(row[2]) if row[2] else 1
                        hour = int(row[3]) if row[3] else 1
                        
                        # 验证时间合理性
                        if not (1 <= month <= 12 and 1 <= day <= 31 and 1 <= hour <= 24):
                            logger.warning(f"第{row_num + 9}行时间无效: {month}/{day} {hour}:00")
                            continue
                        
                        # 解析气象数据
                        data_point = self._parse_data_point(row, month, day, hour)
                        
                        if data_point:
                            hourly_data.append(data_point)
                        
                    except Exception as e:
                        logger.warning(f"第{row_num + 9}行解析失败: {str(e)}")
                        continue
            
            # 验证数据完整性
            if len(hourly_data) != 8760:
                logger.warning(f"小时数据不完整: {len(hourly_data)}/8760")
                
                # 如果数据不足，尝试填补
                if len(hourly_data) > 0:
                    hourly_data = self._fill_missing_hours(hourly_data)
            
            return hourly_data
            
        except Exception as e:
            raise EPWParsingError(f"小时数据解析失败: {str(e)}") from e
    
    def _parse_data_point(self, row: List[str], month: int, day: int, hour: int) -> Optional[ClimateDataPoint]:
        """解析单个数据点"""
        try:
            # 安全地解析数值字段
            def safe_float(value: str, default: float = 0.0) -> float:
                try:
                    return float(value) if value and value.strip() else default
                except (ValueError, AttributeError):
                    return default
            
            # 创建气候数据点
            data_point = ClimateDataPoint(
                month=month,
                day=day,
                hour=hour,
                dry_bulb_temp=safe_float(row[6]),
                wet_bulb_temp=self._calculate_wet_bulb_temp(
                    safe_float(row[6]), safe_float(row[8])
                ),
                dew_point_temp=safe_float(row[7]),
                relative_humidity=safe_float(row[8]),
                atmospheric_pressure=safe_float(row[9]),
                global_radiation=safe_float(row[13]),
                direct_radiation=safe_float(row[14]),
                diffuse_radiation=safe_float(row[15]),
                wind_speed=safe_float(row[21]),
                wind_direction=safe_float(row[20]),
                cloud_cover=safe_float(row[22]),
                visibility=safe_float(row[24])
            )
            
            return data_point
            
        except Exception as e:
            logger.warning(f"数据点解析失败: {str(e)}")
            return None
    
    def _calculate_wet_bulb_temp(self, dry_bulb: float, humidity: float) -> float:
        """
        计算湿球温度（简化公式）
        
        Args:
            dry_bulb: 干球温度 (°C)
            humidity: 相对湿度 (%)
            
        Returns:
            湿球温度 (°C)
        """
        try:
            if humidity <= 0:
                return dry_bulb
            
            # 使用简化的湿球温度计算公式
            # Tw = T * atan(0.151977 * sqrt(RH + 8.313659)) + atan(T + RH) - atan(RH - 1.676331) + 0.00391838 * RH^1.5 * atan(0.023101 * RH) - 4.686035
            rh = humidity / 100.0
            t = dry_bulb
            
            wet_bulb = (t * np.arctan(0.151977 * np.sqrt(rh + 8.313659)) + 
                       np.arctan(t + humidity) - 
                       np.arctan(humidity - 1.676331) + 
                       0.00391838 * (humidity ** 1.5) * np.arctan(0.023101 * humidity) - 
                       4.686035)
            
            return float(wet_bulb)
            
        except Exception:
            # 如果计算失败，返回干球温度作为近似值
            return dry_bulb
    
    def _fill_missing_hours(self, hourly_data: List[ClimateDataPoint]) -> List[ClimateDataPoint]:
        """填补缺失的小时数据"""
        try:
            if len(hourly_data) >= 8760:
                return hourly_data[:8760]  # 截取前8760小时
            
            # 创建完整的8760小时数据结构
            complete_data = []
            data_index = 0
            
            for month in range(1, 13):
                days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1]
                
                for day in range(1, days_in_month + 1):
                    for hour in range(1, 25):
                        # 查找对应的数据点
                        found_data = None
                        
                        if data_index < len(hourly_data):
                            current_data = hourly_data[data_index]
                            if (current_data.month == month and 
                                current_data.day == day and 
                                current_data.hour == hour):
                                found_data = current_data
                                data_index += 1
                        
                        if found_data:
                            complete_data.append(found_data)
                        else:
                            # 创建插值数据点
                            interpolated_data = self._create_interpolated_data_point(
                                month, day, hour, hourly_data, len(complete_data)
                            )
                            complete_data.append(interpolated_data)
            
            logger.info(f"填补了 {8760 - len(hourly_data)} 个缺失的小时数据")
            return complete_data
            
        except Exception as e:
            logger.error(f"填补缺失数据失败: {str(e)}")
            return hourly_data
    
    def _create_interpolated_data_point(self, month: int, day: int, hour: int, 
                                      existing_data: List[ClimateDataPoint], 
                                      current_index: int) -> ClimateDataPoint:
        """创建插值数据点"""
        try:
            # 查找最近的有效数据点进行插值
            if not existing_data:
                # 如果没有有效数据，创建默认数据点
                return self._create_default_data_point(month, day, hour)
            
            # 简单策略：使用最近的数据点
            nearest_data = existing_data[-1] if existing_data else existing_data[0]
            
            # 根据月份调整温度（简单的季节性调整）
            temp_adjustment = self._get_seasonal_temperature_adjustment(month)
            
            interpolated_data = ClimateDataPoint(
                month=month,
                day=day,
                hour=hour,
                dry_bulb_temp=nearest_data.dry_bulb_temp + temp_adjustment,
                wet_bulb_temp=nearest_data.wet_bulb_temp + temp_adjustment * 0.8,
                dew_point_temp=nearest_data.dew_point_temp + temp_adjustment * 0.6,
                relative_humidity=nearest_data.relative_humidity,
                atmospheric_pressure=nearest_data.atmospheric_pressure,
                global_radiation=nearest_data.global_radiation,
                direct_radiation=nearest_data.direct_radiation,
                diffuse_radiation=nearest_data.diffuse_radiation,
                wind_speed=nearest_data.wind_speed,
                wind_direction=nearest_data.wind_direction,
                cloud_cover=nearest_data.cloud_cover,
                visibility=nearest_data.visibility
            )
            
            return interpolated_data
            
        except Exception as e:
            logger.warning(f"创建插值数据点失败: {str(e)}")
            return self._create_default_data_point(month, day, hour)
    
    def _create_default_data_point(self, month: int, day: int, hour: int) -> ClimateDataPoint:
        """创建默认数据点"""
        # 基于月份的典型气候数据
        typical_temps = [5, 8, 12, 18, 23, 28, 30, 29, 25, 19, 12, 7]  # 各月典型温度
        base_temp = typical_temps[month - 1]
        
        # 基于小时的温度调整
        hour_adjustment = -5 + 10 * np.sin((hour - 6) * np.pi / 12)  # 简单的日变化
        
        return ClimateDataPoint(
            month=month,
            day=day,
            hour=hour,
            dry_bulb_temp=base_temp + hour_adjustment,
            wet_bulb_temp=base_temp + hour_adjustment - 2,
            dew_point_temp=base_temp + hour_adjustment - 5,
            relative_humidity=60.0,
            atmospheric_pressure=101325.0,
            global_radiation=500.0 if 6 <= hour <= 18 else 0.0,
            direct_radiation=400.0 if 6 <= hour <= 18 else 0.0,
            diffuse_radiation=100.0 if 6 <= hour <= 18 else 0.0,
            wind_speed=3.0,
            wind_direction=180.0,
            cloud_cover=5.0,
            visibility=10.0
        )
    
    def _get_seasonal_temperature_adjustment(self, month: int) -> float:
        """获取季节性温度调整"""
        # 简单的季节性调整（相对于年平均）
        adjustments = [
            -8, -6, -2, 3, 8, 12, 15, 14, 10, 4, -2, -6
        ]
        return adjustments[month - 1] if 1 <= month <= 12 else 0
    
    def _check_data_quality(self, hourly_data: List[ClimateDataPoint]) -> Dict[str, Any]:
        """检查数据质量"""
        try:
            quality_info = {
                'total_hours': len(hourly_data),
                'completeness': len(hourly_data) / 8760.0,
                'missing_hours': max(0, 8760 - len(hourly_data)),
                'temperature_range': {},
                'humidity_range': {},
                'radiation_range': {},
                'wind_range': {},
                'anomalies': []
            }
            
            if not hourly_data:
                return quality_info
            
            # 提取各类数据
            temps = [dp.dry_bulb_temp for dp in hourly_data]
            humidities = [dp.relative_humidity for dp in hourly_data]
            radiations = [dp.global_radiation for dp in hourly_data]
            wind_speeds = [dp.wind_speed for dp in hourly_data]
            
            # 计算范围
            quality_info['temperature_range'] = {
                'min': min(temps), 'max': max(temps), 'mean': np.mean(temps)
            }
            quality_info['humidity_range'] = {
                'min': min(humidities), 'max': max(humidities), 'mean': np.mean(humidities)
            }
            quality_info['radiation_range'] = {
                'min': min(radiations), 'max': max(radiations), 'mean': np.mean(radiations)
            }
            quality_info['wind_range'] = {
                'min': min(wind_speeds), 'max': max(wind_speeds), 'mean': np.mean(wind_speeds)
            }
            
            # 检查异常值
            anomalies = []
            
            # 温度异常
            if min(temps) < -50 or max(temps) > 60:
                anomalies.append("温度超出合理范围")
            
            # 湿度异常
            if min(humidities) < 0 or max(humidities) > 100:
                anomalies.append("湿度超出合理范围")
            
            # 辐射异常
            if max(radiations) > 1500:
                anomalies.append("太阳辐射异常高")
            
            # 风速异常
            if max(wind_speeds) > 50:
                anomalies.append("风速异常高")
            
            quality_info['anomalies'] = anomalies
            
            return quality_info
            
        except Exception as e:
            logger.warning(f"数据质量检查失败: {str(e)}")
            return {'error': str(e)}
    
    def _calculate_design_conditions(self, hourly_data: List[ClimateDataPoint]) -> Dict[str, Any]:
        """计算设计工况"""
        try:
            if not hourly_data:
                return {}
            
            temps = [dp.dry_bulb_temp for dp in hourly_data]
            humidities = [dp.relative_humidity for dp in hourly_data]
            
            design_conditions = {
                # 温度设计工况
                'heating_design_temp': np.percentile(temps, 1),    # 99%保证率
                'cooling_design_temp': np.percentile(temps, 99),   # 1%保证率
                'mean_temp': np.mean(temps),
                
                # 湿度设计工况
                'design_humidity': np.percentile(humidities, 95),  # 5%保证率
                'mean_humidity': np.mean(humidities),
                
                # 季节性统计
                'summer_avg_temp': np.mean([dp.dry_bulb_temp for dp in hourly_data 
                                          if dp.month in [6, 7, 8]]),
                'winter_avg_temp': np.mean([dp.dry_bulb_temp for dp in hourly_data 
                                          if dp.month in [12, 1, 2]]),
                
                # 太阳辐射统计
                'max_solar_radiation': max([dp.global_radiation for dp in hourly_data]),
                'avg_solar_radiation': np.mean([dp.global_radiation for dp in hourly_data])
            }
            
            return design_conditions
            
        except Exception as e:
            logger.warning(f"设计工况计算失败: {str(e)}")
            return {}
    
    def get_default_climate_data(self, location_name: str = "默认地点") -> ClimateData:
        """
        获取默认气候数据（当EPW文件不可用时）
        
        Args:
            location_name: 地点名称
            
        Returns:
            默认气候数据对象
        """
        with LogContext("生成默认气候数据", logger):
            try:
                logger.info("生成默认气候数据")
                
                # 生成8760小时的典型气候数据
                hourly_data = []
                
                for month in range(1, 13):
                    days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1]
                    
                    for day in range(1, days_in_month + 1):
                        for hour in range(1, 25):
                            data_point = self._create_default_data_point(month, day, hour)
                            hourly_data.append(data_point)
                
                # 创建默认气候数据对象
                climate_data = ClimateData(
                    location_name=location_name,
                    latitude=39.9,      # 北京纬度
                    longitude=116.4,    # 北京经度
                    elevation=50.0,     # 海拔50米
                    time_zone=8.0,      # 东八区
                    hourly_data=hourly_data
                )
                
                # 设置数据质量信息
                climate_data.data_quality = {
                    'total_hours': 8760,
                    'completeness': 1.0,
                    'data_source': 'generated_default',
                    'note': '这是生成的默认气候数据，仅用于测试和演示'
                }
                
                # 计算设计工况
                climate_data.design_conditions = self._calculate_design_conditions(hourly_data)
                
                logger.info("默认气候数据生成完成")
                return climate_data
                
            except Exception as e:
                error_msg = f"默认气候数据生成失败: {str(e)}"
                logger.error(error_msg)
                raise ClimateDataError(error_msg) from e
    
    def interactive_file_selection(self) -> Optional[str]:
        """
        交互式EPW文件选择
        
        Returns:
            选择的文件路径，如果取消则返回None
        """
        try:
            logger.info("开始交互式EPW文件选择")
            
            # 使用交互式工具选择文件
            selected_file = InteractiveUtils.select_file(
                prompt="请选择EPW气候数据文件",
                file_types=['.epw'],
                default_path="data"
            )
            
            if selected_file:
                logger.info(f"用户选择了EPW文件: {selected_file}")
                return selected_file
            else:
                logger.info("用户取消了文件选择")
                return None
                
        except Exception as e:
            logger.error(f"交互式文件选择失败: {str(e)}")
            return None


def create_epw_parser() -> EPWFileParser:
    """
    创建EPW文件解析器实例
    
    Returns:
        配置好的解析器实例
    """
    return EPWFileParser()
