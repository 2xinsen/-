"""科研SCI主题配置模块
基于科研论文标准的配色方案，提供专业的图表视觉效果
"""

import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np
from typing import Dict, List, Tuple, Optional

class SciThemeConfig:
    """科研SCI主题配置类"""
    
    def __init__(self):
        """初始化科研SCI主题配置"""
        self.setup_sci_color_schemes()
        self.setup_sci_styles()
        
    def setup_sci_color_schemes(self):
        """设置科研SCI配色方案"""
        # 基于科研论文标准的配色方案 - 适合期刊发表
        self.sci_color_schemes = {
            'white_background_dark_colors': {
                'background': '#FFFFFF',        # 白色背景
                'surface': '#F8F9FA',          # 浅灰表面
                'card': '#F1F3F4',             # 卡片背景
                'text_primary': '#212529',      # 深色文字
                'text_secondary': '#495057',    # 次要文字
                'text_tertiary': '#6C757D',     # 三级文字
                'accent_teal': '#1F4E4A',       # 深青色 - 对应R034
                'accent_dark_teal': '#2D5B57',  # 深蓝绿 - 对应R040  
                'accent_blue_teal': '#3B6B66',  # 蓝绿色 - 对应R041
                'accent_sage': '#6B8E64',       # 鼠尾草绿 - 对应R136
                'accent_yellow': '#B8860B',     # 暗金黄 - 对应R252
                'accent_orange': '#D2691E',     # 暗橙色 - 对应R243
                'accent_red': '#B22222',        # 暗红色 - 对应R250
                'grid': '#E9ECEF',              # 浅灰网格
                'border': '#DEE2E6',            # 浅灰边框
                'palette': ['#1F4E4A', '#2D5B57', '#3B6B66', '#6B8E64', '#B8860B', '#D2691E', '#B22222', '#8B4513']
            },
            'premium_dark': {
                'background': '#0D1117',
                'surface': '#161B22', 
                'card': '#21262D',
                'text_primary': '#F0F6FC',
                'text_secondary': '#C9D1D9',
                'text_tertiary': '#8B949E',
                'accent_teal': '#1F4E4A',      # 深青色 - 对应R034
                'accent_dark_teal': '#2D5B57', # 深蓝绿 - 对应R040  
                'accent_blue_teal': '#3B6B66', # 蓝绿色 - 对应R041
                'accent_sage': '#6B8E64',      # 鼠尾草绿 - 对应R136
                'accent_yellow': '#B8860B',    # 暗金黄 - 对应R252
                'accent_orange': '#D2691E',    # 暗橙色 - 对应R243
                'accent_red': '#B22222',       # 暗红色 - 对应R250
                'grid': '#30363D',
                'border': '#484F58',
                'palette': ['#1F4E4A', '#2D5B57', '#3B6B66', '#6B8E64', '#B8860B', '#D2691E', '#B22222', '#8B4513']
            },
            'elegant_dark': {
                'background': '#0F1419',
                'surface': '#1E2328',
                'card': '#2A2D32',
                'text_primary': '#F0F6FC',
                'text_secondary': '#C9D1D9',
                'text_tertiary': '#8B949E',
                'accent_teal': '#39C5BB',
                'accent_blue': '#58A6FF',
                'accent_green': '#56D364',
                'accent_orange': '#FF8C42',
                'accent_red': '#F85149',
                'accent_purple': '#A855F7',
                'grid': '#30363D',
                'border': '#484F58',
                'palette': ['#39C5BB', '#58A6FF', '#56D364', '#FF8C42', '#F85149', '#A855F7', '#FFC107', '#17A2B8']
            },
            'professional_dark': {
                'background': '#0A0C10',
                'surface': '#1C1F26', 
                'card': '#252932',
                'text_primary': '#FAFBFC',
                'text_secondary': '#C9D1D9',
                'text_tertiary': '#8B949E',
                'accent_teal': '#1F4E4A',
                'accent_blue': '#2D5B57',
                'accent_green': '#6B8E64',
                'accent_orange': '#D2691E',
                'accent_red': '#B22222',
                'accent_purple': '#8B4513',
                'grid': '#2D333B',
                'border': '#444C56',
                'palette': ['#1F4E4A', '#2D5B57', '#3B6B66', '#6B8E64', '#B8860B', '#D2691E', '#B22222', '#8B4513']
            },
            'reference_matched': {
                'background': '#0A0E14',
                'surface': '#1A1F25',
                'card': '#242B33',
                'text_primary': '#FFFFFF',
                'text_secondary': '#C5CDD5',
                'text_tertiary': '#8D959D',
                'accent_teal': '#1F4E4A',      # 精确匹配参考图R034
                'accent_dark_blue': '#2D5B57', # 精确匹配参考图R040
                'accent_med_teal': '#3B6B66',  # 精确匹配参考图R041
                'accent_sage': '#6B8E64',      # 精确匹配参考图R136  
                'accent_gold': '#B8860B',      # 精确匹配参考图R252
                'accent_burnt_orange': '#D2691E', # 精确匹配参考图R243
                'accent_crimson': '#B22222',   # 精确匹配参考图R250
                'grid': '#323842',
                'border': '#4A5058',
                'palette': ['#1F4E4A', '#2D5B57', '#3B6B66', '#6B8E64', '#B8860B', '#D2691E', '#B22222', '#8B4513']
            },
            'white_background_dark_colors': {
                'background': '#FFFFFF',
                'surface': '#F8F9FA',
                'card': '#FFFFFF',
                'text': '#212529',
                'text_primary': '#212529',
                'text_secondary': '#495057',
                'text_tertiary': '#6C757D',
                'accent_teal': '#1F4E4A',
                'accent_dark_blue': '#2D5B57',
                'accent_med_teal': '#3B6B66',
                'accent_sage': '#6B8E64',
                'accent_gold': '#B8860B',
                'accent_burnt_orange': '#D2691E',
                'accent_crimson': '#B22222',
                'grid': '#E9ECEF',
                'border': '#DEE2E6',
                'palette': ['#1F4E4A', '#2D5B57', '#3B6B66', '#6B8E64', '#B8860B', '#D2691E', '#B22222', '#8B4513']
            }
        }
        
        # 渐变色配置 - 基于科研标准的专业渐变
        self.sci_gradients = {
            'reference_teal_gradient': ['#0F2F2C', '#1F4E4A', '#2D5B57', '#3B6B66', '#4A7A75', '#598A84'],
            'reference_warm_gradient': ['#8B4513', '#A0522D', '#B8860B', '#CD853F', '#D2691E', '#DAA520'],
            'reference_cool_gradient': ['#1F4E4A', '#2D5B57', '#3B6B66', '#4A7A75', '#6B8E64', '#7A9D73'],
            'crimson_gradient': ['#8B0000', '#A0342D', '#B22222', '#CD5C5C', '#DC143C', '#F08080'],
            'sage_gradient': ['#556B2F', '#6B8E64', '#7A9D73', '#8FBC8F', '#98FB98', '#ADFF2F'],
            'gold_gradient': ['#B8860B', '#DAA520', '#FFD700', '#FFF8DC', '#FFFACD', '#FFFFE0']
        }
        
    def setup_sci_styles(self):
        """设置科研SCI样式预设"""
        self.sci_styles = {
            'white_background': {
                'figure.facecolor': '#FFFFFF',
                'axes.facecolor': '#F8F9FA',
                'axes.edgecolor': '#DEE2E6',
                'axes.linewidth': 1.5,
                'axes.spines.top': False,
                'axes.spines.right': False,
                'axes.spines.left': True,
                'axes.spines.bottom': True,
                'axes.labelcolor': '#212529',
                'axes.titlecolor': '#212529',
                'text.color': '#212529',
                'xtick.color': '#495057',
                'ytick.color': '#495057',
                'grid.color': '#E9ECEF',
                'grid.linewidth': 0.8,
                'grid.alpha': 0.6,
                'legend.facecolor': '#F8F9FA',
                'legend.edgecolor': '#DEE2E6',
                'legend.framealpha': 0.9
            },
            'sci_standard': {
                'figure.facecolor': '#FFFFFF',
                'axes.facecolor': '#FFFFFF',
                'axes.edgecolor': '#000000',
                'axes.linewidth': 1.5,
                'axes.spines.top': False,
                'axes.spines.right': False,
                'axes.spines.left': True,
                'axes.spines.bottom': True,
                'axes.labelcolor': '#000000',
                'axes.titlecolor': '#000000',
                'text.color': '#000000',
                'xtick.color': '#000000',
                'ytick.color': '#000000',
                'grid.color': '#CCCCCC',
                'grid.linewidth': 0.8,
                'grid.alpha': 0.6,
                'legend.facecolor': '#FFFFFF',
                'legend.edgecolor': '#000000',
                'legend.framealpha': 0.9
            },
            'sci_elegant': {
                'figure.facecolor': '#FFFFFF',
                'axes.facecolor': '#FAFAFA',
                'axes.edgecolor': '#333333',
                'axes.linewidth': 1.2,
                'axes.spines.top': False,
                'axes.spines.right': False,
                'axes.labelcolor': '#000000',
                'axes.titlecolor': '#000000',
                'text.color': '#000000',
                'xtick.color': '#333333',
                'ytick.color': '#333333',
                'grid.color': '#E0E0E0',
                'grid.linewidth': 0.6,
                'grid.alpha': 0.8,
                'legend.facecolor': '#FAFAFA',
                'legend.edgecolor': '#333333',
                'legend.framealpha': 0.95
            },
            'sci_professional': {
                'figure.facecolor': '#FFFFFF',
                'axes.facecolor': '#FFFFFF',
                'axes.edgecolor': '#000000',
                'axes.linewidth': 1.0,
                'axes.spines.top': False,
                'axes.spines.right': False,
                'axes.labelcolor': '#000000',
                'axes.titlecolor': '#000000',
                'text.color': '#000000',
                'xtick.color': '#000000',
                'ytick.color': '#000000',
                'grid.color': '#DDDDDD',
                'grid.linewidth': 0.5,
                'grid.alpha': 0.7,
                'legend.facecolor': '#FFFFFF',
                'legend.edgecolor': '#000000',
                'legend.framealpha': 0.9
            }
        }
        
    def apply_sci_theme(self, theme: str = 'white_background_dark_colors', style: str = 'white_background'):
        """应用科研SCI主题"""
        # 应用样式预设
        if style in self.sci_styles:
            for key, value in self.sci_styles[style].items():
                plt.rcParams[key] = value
                
        # 应用配色方案
        if theme in self.sci_color_schemes:
            scheme = self.sci_color_schemes[theme]
            plt.rcParams['axes.prop_cycle'] = plt.cycler('color', scheme['palette'])
            
        # 设置科研级高质量渲染参数 - 符合SCI期刊标准
        plt.rcParams.update({
            'figure.dpi': 200,           # 更高显示DPI用于屏幕显示
            'savefig.dpi': 600,          # 超高保存DPI用于期刊投稿
            'savefig.bbox': 'tight',
            'savefig.facecolor': self.sci_color_schemes[theme]['background'],
            'savefig.edgecolor': 'none',
            'savefig.transparent': False,
            'savefig.format': 'png',
            'font.size': 14,             # 更大字体确保可读性
            'axes.titlesize': 20,        # 标题字体
            'axes.labelsize': 16,        # 轴标签字体
            'xtick.labelsize': 14,       # x轴刻度字体
            'ytick.labelsize': 14,       # y轴刻度字体
            'legend.fontsize': 14,       # 图例字体
            'figure.titlesize': 24,      # 图表总标题字体
            'lines.linewidth': 3.5,      # 更粗线条增强视觉效果
            'lines.markersize': 12,      # 更大标记点
            'patch.linewidth': 1.5,      # 图形边框
            'axes.titleweight': 'bold',
            'axes.labelweight': 'bold',  # 轴标签加粗
            'figure.autolayout': True,
            'font.family': ['Arial', 'DejaVu Sans', 'sans-serif'],
            'mathtext.fontset': 'cm',    # 使用Computer Modern数学字体
            'axes.axisbelow': True,      # 网格在数据下方
            'axes.edgecolor': self.sci_color_schemes[theme]['border'],
            'axes.linewidth': 2.0,       # 更粗坐标轴
            'xtick.major.width': 1.5,    # 刻度线宽度
            'ytick.major.width': 1.5,
            'xtick.minor.width': 1.0,
            'ytick.minor.width': 1.0,
            'grid.linewidth': 1.0,       # 网格线宽度
            'legend.framealpha': 0.9,    # 图例背景透明度
            'legend.edgecolor': self.sci_color_schemes[theme]['border'],
            'legend.fancybox': True,     # 圆角图例框
            'legend.shadow': True        # 图例阴影
        })
        
    def get_sci_color_palette(self, scheme: str = 'white_background_dark_colors', n_colors: int = 8) -> List[str]:
        """获取科研SCI配色方案"""
        if scheme in self.sci_color_schemes:
            palette = self.sci_color_schemes[scheme]['palette']
            if len(palette) >= n_colors:
                return palette[:n_colors]
            else:
                # 如果颜色不够，循环使用
                extended_palette = []
                for i in range(n_colors):
                    extended_palette.append(palette[i % len(palette)])
                return extended_palette
        return ['#1F4E4A', '#2D5B57', '#3B6B66', '#6B8E64', '#B8860B', '#D2691E', '#B22222', '#8B4513'][:n_colors]
        
    def get_sci_gradient_colors(self, gradient: str = 'reference_teal_gradient', n_colors: int = 6) -> List[str]:
        """获取科研SCI渐变色"""
        if gradient in self.sci_gradients:
            colors = self.sci_gradients[gradient]
            if len(colors) >= n_colors:
                return colors[:n_colors]
            else:
                # 插值生成更多颜色
                import matplotlib.colors as mcolors
                cmap = mcolors.LinearSegmentedColormap.from_list('custom', colors)
                return [cmap(i / (n_colors - 1)) for i in range(n_colors)]
        return self.sci_gradients['reference_teal_gradient'][:n_colors]
        
    def get_scheme_colors(self, scheme: str = 'white_background_dark_colors') -> Dict[str, str]:
        """获取配色方案的所有颜色"""
        return self.sci_color_schemes.get(scheme, self.sci_color_schemes['white_background_dark_colors'])
        
    def enhance_plot_for_dark_theme(self, ax, scheme: str = 'premium_dark'):
        """为暗色调主题增强图表"""
        colors = self.get_scheme_colors(scheme)
        
        # 设置背景色
        ax.set_facecolor(colors['surface'])
        
        # 设置网格
        ax.grid(True, color=colors['grid'], alpha=0.6, linewidth=0.8)
        
        # 设置边框
        for spine in ax.spines.values():
            spine.set_color(colors['border'])
            spine.set_linewidth(1.2)
            
        # 隐藏顶部和右侧边框
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        
        # 设置刻度颜色
        ax.tick_params(colors=colors['text_secondary'])
        
        # 设置标签颜色
        ax.xaxis.label.set_color(colors['text_primary'])
        ax.yaxis.label.set_color(colors['text_primary'])
        ax.title.set_color(colors['text_primary'])
        
    def add_premium_effects(self, fig, ax_list=None):
        """添加科研级高级视觉效果"""
        if ax_list is None:
            ax_list = fig.get_axes()
            
        for ax in ax_list:
            # 添加精致的表面效果
            ax.patch.set_alpha(0.98)
            
            # 增强线条效果 - 更专业的视觉层次
            for line in ax.get_lines():
                current_width = line.get_linewidth()
                line.set_linewidth(max(current_width * 1.3, 3.0))  # 确保最小线宽
                line.set_alpha(0.95)
                line.set_solid_capstyle('round')  # 圆形线端
                line.set_solid_joinstyle('round') # 圆形连接
                
            # 增强散点图效果
            for collection in ax.collections:
                if hasattr(collection, 'set_alpha'):
                    collection.set_alpha(0.85)
                if hasattr(collection, 'set_edgecolors'):
                    # 添加细微边框提升层次感
                    collection.set_edgecolors('white')
                    collection.set_linewidths(0.5)
                    
            # 增强条形图效果
            for patch in ax.patches:
                if hasattr(patch, 'set_alpha'):
                    patch.set_alpha(0.9)
                if hasattr(patch, 'set_edgecolor'):
                    patch.set_edgecolor('white')
                    patch.set_linewidth(0.8)
                    
            # 设置专业的网格样式
            ax.grid(True, alpha=0.3, linestyle='-', linewidth=1.0)
            ax.set_axisbelow(True)
            
            # 优化刻度样式
            ax.tick_params(
                axis='both', 
                which='major', 
                length=6, 
                width=1.5, 
                colors='white',
                labelsize=14
            )
            ax.tick_params(
                axis='both', 
                which='minor', 
                length=3, 
                width=1.0, 
                colors='white'
            )
                    
    def create_dark_colormap(self, colors: List[str], name: str = 'custom_dark'):
        """创建暗色调颜色映射"""
        from matplotlib.colors import LinearSegmentedColormap
        return LinearSegmentedColormap.from_list(name, colors)
        
# 全局暗色调主题实例
dark_theme = DarkThemeConfig()

# 便捷函数
def apply_premium_dark_theme(theme: str = 'white_background_dark_colors', style: str = 'white_background'):
    """应用高级暗色调主题"""
    dark_theme.apply_dark_theme(theme, style)
    
def get_premium_dark_colors(scheme: str = 'white_background_dark_colors', n_colors: int = 8) -> List[str]:
    """获取高级暗色调配色"""
    return dark_theme.get_dark_color_palette(scheme, n_colors)
    
def enhance_dark_plot(ax, scheme: str = 'white_background_dark_colors'):
    """增强暗色调图表"""
    dark_theme.enhance_plot_for_dark_theme(ax, scheme)
    
def add_premium_dark_effects(fig, ax_list=None):
    """添加高级暗色调效果"""
    dark_theme.add_premium_effects(fig, ax_list)

def save_publication_quality_chart(fig, filename: str, base_path: str = "charts", 
                                 create_english: bool = True, dpi: int = 600):
    """保存符合期刊要求的高质量图表"""
    import os
    from pathlib import Path
    
    # 创建主图表文件夹
    main_path = Path(base_path)
    main_path.mkdir(exist_ok=True)
    
    # 保存中文版本
    chinese_path = main_path / "chinese"
    chinese_path.mkdir(exist_ok=True)
    chinese_file = chinese_path / f"{filename}.png"
    
    try:
        fig.savefig(
            chinese_file,
            dpi=dpi,
            bbox_inches='tight',
            facecolor=fig.get_facecolor(),
            edgecolor='none',
            transparent=False,
            format='png'
        )
        print(f"中文图表已保存: {chinese_file}")
    except Exception as e:
        print(f"保存中文图表失败: {e}")
    
    # 创建并保存英文版本
    if create_english:
        english_path = main_path / "english"
        english_path.mkdir(exist_ok=True)
        english_file = english_path / f"{filename}_english.png"
        
        try:
            # 这里可以添加英文版本的特殊处理
            fig.savefig(
                english_file,
                dpi=dpi,
                bbox_inches='tight',
                facecolor=fig.get_facecolor(),
                edgecolor='none',
                transparent=False,
                format='png'
            )
            print(f"英文图表已保存: {english_file}")
        except Exception as e:
            print(f"保存英文图表失败: {e}")

def apply_sci_paper_theme(scheme: str = 'reference_matched'):
    """应用符合SCI期刊标准的深色主题"""
    apply_premium_dark_theme(scheme, 'ultra_dark')
    
    # 额外的期刊级别设置
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        'figure.max_open_warning': 0,  # 关闭图表数量警告
        'savefig.pad_inches': 0.1,     # 保存时的边距
        'axes.formatter.use_mathtext': True,  # 使用数学文本
        'axes.formatter.useoffset': False,    # 不使用偏移量
    })
    
def create_scientific_layout(nrows: int = 1, ncols: int = 1, figsize: tuple = (12, 8)):
    """创建符合科研标准的图表布局"""
    import matplotlib.pyplot as plt
    
    fig, axes = plt.subplots(nrows, ncols, figsize=figsize)
    
    # 应用科研主题
    apply_sci_paper_theme()
    
    # 设置子图间距
    if nrows > 1 or ncols > 1:
        plt.subplots_adjust(
            left=0.08, 
            right=0.95, 
            top=0.92, 
            bottom=0.12, 
            hspace=0.3, 
            wspace=0.3
        )
    
    return fig, axes