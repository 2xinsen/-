"""
可视化引擎 - 统一管理所有图表生成（优化版）
支持中英文双语输出，优化排版和字体大小
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
import seaborn as sns
from datetime import datetime

# 设置中英文字体和样式，避免Liberation Sans错误
matplotlib.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans', 'Tahoma', 'SimHei', 'Microsoft YaHei']
matplotlib.rcParams['axes.unicode_minus'] = False
plt.style.use('seaborn-v0_8-whitegrid')

class VisualizationEngine:
    """可视化引擎主类（优化版）- 使用统一样式管理器"""
    
    def __init__(self, output_dir: str = "output", language: str = "zh"):
        self.output_dir = Path(output_dir)
        self.language = language  # "zh" for Chinese, "en" for English
        
        # 根据语言设置输出目录
        if language == "en":
            self.charts_dir = self.output_dir / "analysis_charts_en"
            self.detailed_dir = self.output_dir / "detailed_charts_en"
        else:
            self.charts_dir = self.output_dir / "analysis_charts"
            self.detailed_dir = self.output_dir / "detailed_charts"
        
        # 创建输出目录
        self.charts_dir.mkdir(parents=True, exist_ok=True)
        self.detailed_dir.mkdir(parents=True, exist_ok=True)
        
        # 初始化统一样式管理器
        from .unified_style_manager import UnifiedStyleManager
        self.style_manager = UnifiedStyleManager(language=language)
        self.style_manager.setup_matplotlib_style()
        
        # 获取统一配色方案
        self.colors = self.style_manager.get_colors()
        
        # 设置图表参数 - 论文级别大字体
        self.figure_params = {
            'dpi': 300,
            'figsize_large': (20, 16),      # 增大图表尺寸
            'figsize_medium': (16, 12),     # 增大图表尺寸
            'figsize_small': (12, 9),       # 增大图表尺寸
            'font_size_title': 24,          # 大幅增大标题字体
            'font_size_subtitle': 20,       # 副标题字体
            'font_size_label': 18,          # 大幅增大标签字体
            'font_size_tick': 16,           # 大幅增大刻度字体
            'font_size_legend': 16,         # 大幅增大图例字体
            'line_width': 3,                # 增加线宽
            'marker_size': 10               # 增大标记
        }
        
        # 语言文本映射 - 去除舒适度相关内容
        self.texts = self._get_language_texts()
        
        # 初始化图表生成器
        from .chart_generator import ChartGenerator
        self.chart_generator = ChartGenerator(self)
        
        # 设置图表生成器的样式管理器
        if hasattr(self.chart_generator, 'set_style_manager'):
            self.chart_generator.set_style_manager(self.style_manager)
        
    def _get_language_texts(self) -> Dict[str, str]:
        """
        获取语言文本映射 - 专注能耗和热工性能双目标优化
        
        优化特点：
        1. 完全去除舒适度相关的所有文本和指标
        2. 专注于能耗和热工性能两个核心目标函数
        3. 支持中英文双语完整转换，确保术语一致性
        4. 统一专业术语标准，避免翻译不一致问题
        5. 强调双目标优化的权衡关系
        """
        if self.language == "en":
            return {
                # 图表标题 - 强调双目标优化
                'algorithm_convergence': 'NSGA-III Algorithm Convergence Analysis - Energy & Thermal Performance',
                'pareto_frontier': 'Pareto Frontier Analysis - Energy vs Thermal Performance Trade-off',
                'thermal_performance': 'Building Thermal Performance Comprehensive Analysis',
                'energy_breakdown': 'Building Energy Consumption Breakdown & Optimization Analysis',
                'best_solutions': 'Best Solutions Comparison - Energy & Thermal Performance',
                'grid_layout': 'Building Facade Optimization Solutions Grid - Bi-objective Space',
                'detailed_comparison': 'Detailed Best Solutions Comparison - Energy & Thermal Metrics',
                '3d_solutions': '3D Building Solutions Visualization - Bi-objective Optimization',
                'radar_chart': 'Comprehensive Performance Radar - Energy & Thermal Indicators',
                'clustering': 'Solution Clustering Analysis - Energy & Thermal Performance Based',
                'correlation': 'Parameter Correlation Analysis - Energy & Thermal Performance Factors',
                
                # 轴标签 - 双目标优化专用
                'energy_consumption': 'Energy Consumption (kWh/m²·year)',
                'thermal_performance_index': 'Thermal Performance Index (W/m²·K)',
                'energy_vs_thermal': 'Energy vs Thermal Performance',
                'generation': 'Generation',
                'fitness_value': 'Fitness Value',
                'hypervolume': 'Hypervolume Indicator',
                'diversity': 'Solution Diversity Index',
                
                # 图例标签 - 双目标优化
                'all_solutions': 'All Solutions',
                'pareto_solutions': 'Pareto Optimal Solutions',
                'dominated_solutions': 'Dominated Solutions',
                'energy_optimal': 'Energy Optimal Solution',
                'thermal_optimal': 'Thermal Optimal Solution',
                'balanced_solution': 'Balanced Solution',
                'baseline_design': 'Baseline Design',
                
                # 能耗分类 - 建筑能耗系统
                'heating': 'Space Heating',
                'cooling': 'Space Cooling',
                'lighting': 'Lighting System',
                'equipment': 'Equipment Load',
                'ventilation': 'Ventilation System',
                'hot_water': 'Hot Water System',
                
                # 性能指标 - 双目标优化指标
                'convergence_speed': 'Convergence Speed',
                'solution_quality': 'Solution Quality',
                'diversity_maintenance': 'Diversity Maintenance',
                'computational_efficiency': 'Computational Efficiency',
                'pareto_optimality': 'Pareto Optimality',
                'trade_off_balance': 'Trade-off Balance',
                
                # 统计信息
                'total_generations': 'Total Generations',
                'pareto_solutions_count': 'Pareto Solutions Count',
                'best_energy_fitness': 'Best Energy Fitness',
                'best_thermal_fitness': 'Best Thermal Fitness',
                'improvement_rate': 'Improvement Rate',
                'algorithm_parameters': 'Algorithm Parameters',
                'performance_metrics': 'Performance Metrics',
                
                # 方案类型 - 双目标优化方案
                'energy_focused': 'Energy-Focused Solution',
                'thermal_focused': 'Thermal-Focused Solution',
                'balanced_optimal': 'Balanced Optimal Solution',
                
                # 分析维度
                'energy_thermal_projection': 'Energy-Thermal Performance Projection',
                'pareto_frontier_fitting': 'Pareto Frontier Curve Fitting',
                'objective_space_analysis': 'Objective Space Analysis',
                
                # 质量评估指标
                'hypervolume_indicator': 'Hypervolume Indicator',
                'spacing_indicator': 'Spacing Indicator',
                'spread_indicator': 'Spread Indicator',
                'uniformity_indicator': 'Uniformity Indicator',
                'convergence_indicator': 'Convergence Indicator'
            }
        else:
            return {
                # 图表标题 - 强调双目标优化
                'algorithm_convergence': 'NSGA-III算法收敛性分析 - 能耗与热工性能双目标优化',
                'pareto_frontier': '帕累托前沿分析 - 能耗与热工性能权衡',
                'thermal_performance': '建筑热工性能综合分析',
                'energy_breakdown': '建筑能耗分解与优化分析',
                'best_solutions': '最佳方案对比分析 - 能耗与热工性能',
                'grid_layout': '建筑立面优化方案网格展示 - 双目标解空间',
                'detailed_comparison': '最佳方案详细对比分析 - 能耗与热工指标',
                '3d_solutions': '建筑立面优化方案3D展示 - 双目标优化结果',
                'radar_chart': '综合性能雷达分析 - 能耗与热工指标',
                'clustering': '方案聚类分析 - 基于能耗与热工性能',
                'correlation': '参数相关性分析 - 能耗与热工性能影响因子',
                
                # 轴标签 - 双目标优化专用
                'energy_consumption': '能耗 (kWh/m²·年)',
                'thermal_performance_index': '热工性能指标 (W/m²·K)',
                'energy_vs_thermal': '能耗与热工性能',
                'generation': '代数',
                'fitness_value': '适应度值',
                'hypervolume': '超体积指标',
                'diversity': '解分布性指标',
                
                # 图例标签 - 双目标优化
                'all_solutions': '所有解',
                'pareto_solutions': '帕累托最优解',
                'dominated_solutions': '被支配解',
                'energy_optimal': '能耗最优解',
                'thermal_optimal': '热工最优解',
                'balanced_solution': '平衡解',
                'baseline_design': '基准设计',
                
                # 能耗分类 - 建筑能耗系统
                'heating': '供暖系统',
                'cooling': '制冷系统',
                'lighting': '照明系统',
                'equipment': '设备负荷',
                'ventilation': '通风系统',
                'hot_water': '热水系统',
                
                # 性能指标 - 双目标优化指标
                'convergence_speed': '收敛速度',
                'solution_quality': '解质量',
                'diversity_maintenance': '多样性维持',
                'computational_efficiency': '计算效率',
                'pareto_optimality': '帕累托最优性',
                'trade_off_balance': '权衡平衡性',
                
                # 统计信息
                'total_generations': '总代数',
                'pareto_solutions_count': '帕累托解数量',
                'best_energy_fitness': '最佳能耗适应度',
                'best_thermal_fitness': '最佳热工适应度',
                'improvement_rate': '改进率',
                'algorithm_parameters': '算法参数',
                'performance_metrics': '性能指标',
                
                # 方案类型 - 双目标优化方案
                'energy_focused': '能耗导向方案',
                'thermal_focused': '热工导向方案',
                'balanced_optimal': '平衡最优方案',
                
                # 分析维度
                'energy_thermal_projection': '能耗-热工性能投影',
                'pareto_frontier_fitting': '帕累托前沿曲线拟合',
                'objective_space_analysis': '目标空间分析',
                
                # 质量评估指标
                'hypervolume_indicator': '超体积指标',
                'spacing_indicator': '间距指标',
                'spread_indicator': '扩展度指标',
                'uniformity_indicator': '均匀性指标',
                'convergence_indicator': '收敛性指标'
            }
        
    def generate_all_charts(self, solutions: List[Dict], pareto_solutions: List[Dict], 
                          best_solutions: Dict, evolution_data: Dict) -> Dict[str, str]:
        """生成所有11个专业图表（支持中英文双版本）"""
        
        lang_suffix = "_EN" if self.language == "en" else ""
        print(f"开始生成专业级可视化图表{lang_suffix}...")
        chart_files = {}
        
        # 设置图表生成器的语言
        self.chart_generator.language = self.language
        
        try:
            # 1. 算法收敛分析图
            print(f"生成算法收敛分析图{lang_suffix}...")
            chart_files['convergence'] = self.chart_generator.generate_algorithm_convergence_chart(
                evolution_data, solutions
            )
            
            # 2. 帕累托前沿分析图
            print(f"生成帕累托前沿分析图{lang_suffix}...")
            chart_files['pareto'] = self.chart_generator.generate_pareto_frontier_analysis_chart(
                pareto_solutions, solutions
            )
            
            # 3. 热工性能综合分析图
            print(f"生成热工性能综合分析图{lang_suffix}...")
            chart_files['thermal'] = self.chart_generator.generate_thermal_performance_analysis_chart(
                solutions, pareto_solutions
            )
            
            # 4. 能耗分解分析图
            print(f"生成能耗分解分析图{lang_suffix}...")
            chart_files['energy'] = self.chart_generator.generate_energy_breakdown_analysis_chart(
                solutions, best_solutions
            )
            
            # 5. 最佳方案对比图
            print(f"生成最佳方案对比图{lang_suffix}...")
            chart_files['best_comparison'] = self.chart_generator.generate_best_solutions_comparison_chart(
                best_solutions
            )
            
            # 6. 方案网格展示图
            print(f"生成方案网格展示图{lang_suffix}...")
            chart_files['grid_layout'] = self.chart_generator.generate_solutions_grid_layout_chart(
                solutions, pareto_solutions
            )
            
            # 7. 综合性能雷达图
            print(f"生成综合性能雷达图{lang_suffix}...")
            try:
                chart_files['radar'] = self.chart_generator.generate_comprehensive_performance_radar_chart(
                    solutions, best_solutions
                )
            except Exception as e:
                print(f"雷达图生成失败: {e}")
            
            # 8. 解聚类分析图
            print(f"生成解聚类分析图{lang_suffix}...")
            try:
                chart_files['clustering'] = self.chart_generator.generate_solution_clustering_analysis_chart(
                    solutions, pareto_solutions
                )
            except Exception as e:
                print(f"聚类图生成失败: {e}")
            
            # 9. 参数相关性分析图
            print(f"生成参数相关性分析图{lang_suffix}...")
            try:
                chart_files['correlation'] = self.chart_generator.generate_parameter_correlation_analysis_chart(
                    solutions
                )
            except Exception as e:
                print(f"相关性图生成失败: {e}")
            
            # 10. 详细最佳方案对比图
            print(f"生成详细最佳方案对比图{lang_suffix}...")
            try:
                chart_files['detailed_comparison'] = self.chart_generator.generate_detailed_best_solutions_chart(
                    best_solutions
                )
            except Exception as e:
                print(f"详细对比图生成失败: {e}")
            
            # 11. 3D方案展示图
            print(f"生成3D方案展示图{lang_suffix}...")
            try:
                chart_files['3d_solutions'] = self.chart_generator.generate_3d_solutions_chart(
                    best_solutions
                )
            except Exception as e:
                print(f"3D展示图生成失败: {e}")
            
            successful_charts = len([f for f in chart_files.values() if f])
            print(f"图表生成完成{lang_suffix}！成功生成 {successful_charts} 个图表文件")
            return chart_files
            
        except Exception as e:
            print(f"生成图表时出现错误: {str(e)}")
            import traceback
            traceback.print_exc()
            return chart_files
    
    def save_figure(self, fig, filename: str, subdir: str = "") -> str:
        """保存图表文件（优化排版，支持子文件夹）"""
        if subdir:
            save_dir = self.charts_dir / subdir
            save_dir.mkdir(parents=True, exist_ok=True)
        else:
            save_dir = self.charts_dir
            
        # 添加语言后缀
        if self.language == "en":
            name, ext = filename.rsplit('.', 1)
            filename = f"{name}_EN.{ext}"
            
        filepath = save_dir / filename
        
        # 优化布局，避免重叠
        fig.tight_layout(pad=3.0)  # 增加内边距
        
        # 保存高质量PNG文件
        fig.savefig(
            filepath,
            dpi=self.figure_params['dpi'],
            bbox_inches='tight',
            facecolor='white',
            edgecolor='none',
            format='png',
            pad_inches=0.5  # 增加外边距
        )
        
        plt.close(fig)
        return str(filepath)
    
    def create_figure(self, figsize: Tuple[float, float] = None, 
                     nrows: int = 1, ncols: int = 1) -> Tuple[plt.Figure, Any]:
        """创建标准化的图表（优化排版）"""
        if figsize is None:
            figsize = self.figure_params['figsize_medium']
            
        fig, axes = plt.subplots(nrows, ncols, figsize=figsize)
        fig.patch.set_facecolor('white')
        
        # 优化子图间距
        if nrows > 1 or ncols > 1:
            fig.subplots_adjust(hspace=0.4, wspace=0.3)
        
        return fig, axes
    
    def apply_style(self, ax, title: str = "", xlabel: str = "", ylabel: str = ""):
        """应用统一的图表样式（论文级字体）"""
        if title:
            ax.set_title(title, fontsize=self.figure_params['font_size_title'], 
                        fontweight='bold', color=self.colors['text'], pad=20)
        if xlabel:
            ax.set_xlabel(xlabel, fontsize=self.figure_params['font_size_label'], 
                         fontweight='600', labelpad=15)
        if ylabel:
            ax.set_ylabel(ylabel, fontsize=self.figure_params['font_size_label'], 
                         fontweight='600', labelpad=15)
            
        ax.tick_params(labelsize=self.figure_params['font_size_tick'])
        ax.grid(True, alpha=0.3, color=self.colors['grid'])
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        
        # 设置更粗的轴线
        ax.spines['left'].set_linewidth(2)
        ax.spines['bottom'].set_linewidth(2)
        
    def get_color_palette(self, n_colors: int) -> List[str]:
        """获取调色板"""
        if n_colors <= len(self.colors):
            return list(self.colors.values())[:n_colors]
        else:
            # 使用seaborn生成更多颜色
            return sns.color_palette("husl", n_colors).as_hex()
    
    def get_text(self, key: str) -> str:
        """获取对应语言的文本"""
        return self.texts.get(key, key)
    
    def set_language(self, language: str):
        """
        设置语言并更新所有相关组件
        
        参数:
            language: 语言设置 ("zh" 中文, "en" 英文)
        """
        self.language = language
        
        # 更新样式管理器的语言设置
        self.style_manager.set_language(language)
        
        # 更新图表生成器的语言设置
        if hasattr(self.chart_generator, 'language'):
            self.chart_generator.language = language
        
        # 重新获取语言文本
        self.texts = self._get_language_texts()
        
        # 更新输出目录
        if language == "en":
            self.charts_dir = self.output_dir / "analysis_charts_en"
            self.detailed_dir = self.output_dir / "detailed_charts_en"
        else:
            self.charts_dir = self.output_dir / "analysis_charts"
            self.detailed_dir = self.output_dir / "detailed_charts"
        
        # 创建新的输出目录
        self.charts_dir.mkdir(parents=True, exist_ok=True)
        self.detailed_dir.mkdir(parents=True, exist_ok=True)
        
        print(f"✓ 可视化引擎语言已设置为: {'中文' if language == 'zh' else 'English'}")
    
    def generate_charts_in_both_languages(self, solutions: List[Dict], pareto_solutions: List[Dict], 
                                        best_solutions: Dict, evolution_data: Dict) -> Dict[str, Dict[str, str]]:
        """
        生成中英文双语版本的所有图表
        
        返回:
            Dict[str, Dict[str, str]]: 包含中英文版本图表文件路径的字典
        """
        results = {}
        
        # 生成中文版本
        print("开始生成中文版本图表...")
        self.set_language("zh")
        results['zh'] = self.generate_all_charts(solutions, pareto_solutions, best_solutions, evolution_data)
        
        # 生成英文版本
        print("开始生成英文版本图表...")
        self.set_language("en")
        results['en'] = self.generate_all_charts(solutions, pareto_solutions, best_solutions, evolution_data)
        
        print("✓ 中英文双语版本图表生成完成！")
        return results