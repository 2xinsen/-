"""
建筑立面优化系统 - 可视化模块

该模块提供完整的专业级可视化功能，包括：
1. 算法收敛分析图
2. 帕累托前沿分析图  
3. 热工性能综合分析图
4. 能耗分解分析图
5. 最佳方案对比图
6. 方案网格展示图
7. 最佳方案对比图
8. 方案3D展示图
9. 综合性能雷达图
10. 解聚类分析图
11. 参数相关性分析图
"""

from .visualization_engine import VisualizationEngine
from .chart_generator import ChartGenerator

__all__ = ['VisualizationEngine', 'ChartGenerator']