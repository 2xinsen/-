"""
统一样式管理器 - 管理所有图表的配色和语言设置
确保所有图表配色统一，支持中英文双语版本
"""

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from typing import Dict, List, Any
import numpy as np

class UnifiedStyleManager:
    """
    统一样式管理器
    
    功能特点：
    1. 统一配色管理，确保所有图表使用相同的颜色方案
    2. 中英文双语支持，确保英文版语言正确
    3. 统一字体和布局设置
    4. 支持样式规则的动态切换
    """
    
    def __init__(self, language: str = "zh"):
        """
        初始化统一样式管理器
        
        参数:
            language: 语言设置 ("zh" 中文, "en" 英文)
        """
        self.language = language
        self.current_style = "professional"
        self.styles = self._initialize_styles()
        
    def _initialize_styles(self) -> Dict:
        """初始化样式配置"""
        return {
            "professional": {
                # 统一配色方案 - 确保所有图表使用相同颜色
                "colors": {
                    # 主要色彩 - 能耗和热工性能双目标
                    'energy_primary': '#1e40af',     # 能耗主色 - 专业蓝
                    'energy_secondary': '#3b82f6',   # 能耗次色 - 中蓝
                    'energy_light': '#60a5fa',       # 能耗浅色 - 亮蓝
                    
                    'thermal_primary': '#dc2626',    # 热工主色 - 专业红
                    'thermal_secondary': '#ef4444',  # 热工次色 - 中红
                    'thermal_light': '#f87171',      # 热工浅色 - 亮红
                    
                    # 通用色彩
                    'primary': '#1e40af',        # 主色调
                    'secondary': '#dc2626',      # 次色调
                    'accent': '#ea580c',         # 强调色
                    'success': '#16a34a',        # 成功色
                    'warning': '#d97706',        # 警告色
                    'info': '#0891b2',           # 信息色
                    'neutral': '#6b7280',        # 中性色
                    'neutral_light': '#9ca3af',  # 浅中性色
                    'neutral_dark': '#374151',   # 深中性色
                    
                    # 背景色
                    'background': '#ffffff',
                    'background_light': '#f9fafb',
                    'background_dark': '#f3f4f6',
                },
                
                # 统一调色板 - 确保所有图表使用相同的颜色序列
                "palette": [
                    '#1e40af', '#dc2626', '#ea580c', '#16a34a',  # 主要色彩
                    '#3b82f6', '#ef4444', '#f97316', '#22c55e',  # 次要色彩
                    '#60a5fa', '#f87171', '#fb923c', '#4ade80',  # 浅色系列
                    '#0891b2', '#d97706', '#6b7280', '#8b5cf6',  # 辅助色彩
                    '#06b6d4', '#eab308', '#84cc16', '#a855f7'   # 扩展色彩
                ],
                
                # 字体配置
                "fonts": {
                    'family': ['Arial', 'DejaVu Sans', 'Tahoma', 'SimHei', 'Microsoft YaHei'],
                    'title_size': 36,
                    'subtitle_size': 32,
                    'label_size': 28,
                    'tick_size': 24,
                    'legend_size': 22,
                    'annotation_size': 20,
                },
                
                # 线条和标记样式
                "lines": {
                    'line_width': 5.0,
                    'line_width_thin': 3.5,
                    'marker_size': 15,
                    'marker_edge_width': 3.0,
                },
                
                # 布局设置
                "layout": {
                    'title_pad': 60,
                    'label_pad': 35,
                    'legend_spacing': 1.5,
                    'legend_margin': 0.02,
                    'subplot_hspace': 1.0,
                    'subplot_wspace': 0.8,
                    'fill_alpha': 0.35,
                    'marker_alpha': 0.9,
                    'grid_alpha': 0.4,
                    'main_left': 0.08,
                    'main_right': 0.88,
                    'main_top': 0.93,
                    'main_bottom': 0.08,
                },
                
                # 图表尺寸
                "sizes": {
                    'figsize_huge': (33.1, 23.4),    # A3尺寸
                    'figsize_xlarge': (29.7, 21.0),  # A4横向
                    'figsize_large': (23.4, 16.5),   # A4纵向
                    'figsize_medium': (16.5, 11.7),  # A5尺寸
                }
            }
        }
    
    def set_language(self, language: str):
        """设置语言"""
        self.language = language
        print(f"✓ 语言已设置为: {'中文' if language == 'zh' else 'English'}")
    
    def get_colors(self) -> Dict[str, str]:
        """获取当前样式的颜色配置"""
        return self.styles[self.current_style]["colors"]
    
    def get_palette(self) -> List[str]:
        """获取当前样式的调色板"""
        return self.styles[self.current_style]["palette"]
    
    def get_fonts(self) -> Dict[str, Any]:
        """获取当前样式的字体配置"""
        return self.styles[self.current_style]["fonts"]
    
    def get_layout(self) -> Dict[str, Any]:
        """获取当前样式的布局配置"""
        return self.styles[self.current_style]["layout"]
    
    def get_sizes(self) -> Dict[str, tuple]:
        """获取当前样式的尺寸配置"""
        return self.styles[self.current_style]["sizes"]
    
    def get_title(self, chart_type: str) -> str:
        """
        获取图表标题 - 中英文双语支持
        
        参数:
            chart_type: 图表类型
            
        返回:
            str: 对应语言的图表标题
        """
        titles = {
            'algorithm_convergence': {
                'zh': 'NSGA-III算法收敛性分析 - 能耗与热工性能双目标优化',
                'en': 'NSGA-III Algorithm Convergence Analysis - Energy & Thermal Performance Bi-objective Optimization'
            },
            'pareto_frontier': {
                'zh': '帕累托前沿分析 - 能耗与热工性能权衡',
                'en': 'Pareto Frontier Analysis - Energy vs Thermal Performance Trade-offs'
            },
            'energy_breakdown': {
                'zh': '建筑能耗分解与优化分析',
                'en': 'Building Energy Consumption Breakdown & Optimization Analysis'
            },
            'best_solutions': {
                'zh': '最佳方案对比分析 - 能耗与热工性能',
                'en': 'Best Solutions Comparison Analysis - Energy & Thermal Performance'
            },
            'solutions_grid': {
                'zh': '优化方案网格展示 - 双目标解空间',
                'en': 'Optimization Solutions Grid Display - Bi-objective Solution Space'
            },
            'performance_radar': {
                'zh': '综合性能雷达分析 - 能耗与热工指标',
                'en': 'Comprehensive Performance Radar Analysis - Energy & Thermal Metrics'
            },
            'clustering_analysis': {
                'zh': '方案聚类分析 - 基于能耗与热工性能',
                'en': 'Solution Clustering Analysis - Based on Energy & Thermal Performance'
            },
            'correlation_analysis': {
                'zh': '参数相关性分析 - 能耗与热工性能影响因子',
                'en': 'Parameter Correlation Analysis - Energy & Thermal Performance Impact Factors'
            },
            'thermal_performance': {
                'zh': '建筑热工性能综合分析',
                'en': 'Building Thermal Performance Comprehensive Analysis'
            },
            'detailed_solutions': {
                'zh': '详细方案分析 - 能耗与热工性能详解',
                'en': 'Detailed Solutions Analysis - Energy & Thermal Performance Breakdown'
            },
            '3d_solutions': {
                'zh': '三维解决方案展示 - 双目标优化结果',
                'en': '3D Solutions Visualization - Bi-objective Optimization Results'
            }
        }
        
        if chart_type in titles:
            return titles[chart_type].get(self.language, titles[chart_type]['zh'])
        
        return f"数据分析图表" if self.language == 'zh' else "Data Analysis Chart"
    
    def get_label(self, label_type: str) -> str:
        """
        获取图表标签 - 中英文双语支持
        
        参数:
            label_type: 标签类型
            
        返回:
            str: 对应语言的标签文本
        """
        labels = {
            'energy_consumption': {
                'zh': '能耗 (kWh/m²·年)',
                'en': 'Energy Consumption (kWh/m²·year)'
            },
            'thermal_performance': {
                'zh': '热工性能指标',
                'en': 'Thermal Performance Index'
            },
            'generation': {
                'zh': '代数',
                'en': 'Generation'
            },
            'fitness_value': {
                'zh': '适应度值',
                'en': 'Fitness Value'
            },
            'hypervolume': {
                'zh': '超体积指标',
                'en': 'Hypervolume Indicator'
            },
            'diversity': {
                'zh': '解分布性指标',
                'en': 'Solution Diversity Index'
            },
            'pareto_solutions': {
                'zh': '帕累托最优解',
                'en': 'Pareto Optimal Solutions'
            },
            'all_solutions': {
                'zh': '所有解',
                'en': 'All Solutions'
            },
            'dominated_solutions': {
                'zh': '被支配解',
                'en': 'Dominated Solutions'
            },
            'energy_optimal': {
                'zh': '能耗最优解',
                'en': 'Energy Optimal Solution'
            },
            'thermal_optimal': {
                'zh': '热工最优解',
                'en': 'Thermal Optimal Solution'
            },
            'balanced_solution': {
                'zh': '平衡解',
                'en': 'Balanced Solution'
            },
            'baseline_design': {
                'zh': '基准设计',
                'en': 'Baseline Design'
            },
            # 能耗分类
            'heating': {
                'zh': '供暖系统',
                'en': 'Space Heating'
            },
            'cooling': {
                'zh': '制冷系统',
                'en': 'Space Cooling'
            },
            'lighting': {
                'zh': '照明系统',
                'en': 'Lighting System'
            },
            'equipment': {
                'zh': '设备负荷',
                'en': 'Equipment Load'
            },
            'ventilation': {
                'zh': '通风系统',
                'en': 'Ventilation System'
            },
            'hot_water': {
                'zh': '热水系统',
                'en': 'Hot Water System'
            },
            # 性能指标
            'convergence_speed': {
                'zh': '收敛速度',
                'en': 'Convergence Speed'
            },
            'solution_quality': {
                'zh': '解质量',
                'en': 'Solution Quality'
            },
            'diversity_maintenance': {
                'zh': '多样性维持',
                'en': 'Diversity Maintenance'
            },
            'computational_efficiency': {
                'zh': '计算效率',
                'en': 'Computational Efficiency'
            }
        }
        
        if label_type in labels:
            return labels[label_type].get(self.language, labels[label_type]['zh'])
        
        return label_type
    
    def setup_matplotlib_style(self):
        """设置matplotlib全局样式"""
        fonts = self.get_fonts()
        layout = self.get_layout()
        
        plt.rcParams.update({
            'font.family': fonts["family"],
            'font.size': 16,
            'axes.titlesize': fonts["title_size"],
            'axes.labelsize': fonts["label_size"],
            'xtick.labelsize': fonts["tick_size"],
            'ytick.labelsize': fonts["tick_size"],
            'legend.fontsize': fonts["legend_size"],
            'lines.linewidth': self.styles[self.current_style]["lines"]["line_width"],
            'lines.markersize': self.styles[self.current_style]["lines"]["marker_size"],
            'figure.subplot.hspace': layout["subplot_hspace"],
            'figure.subplot.wspace': layout["subplot_wspace"],
            'grid.alpha': layout["grid_alpha"],
        })
    
    def create_figure(self, figsize_key: str = 'figsize_huge') -> plt.Figure:
        """创建具有正确布局的figure"""
        sizes = self.get_sizes()
        figsize = sizes[figsize_key]
        
        fig = plt.figure(figsize=figsize)
        fig.patch.set_facecolor('white')
        
        return fig
    
    def create_gridspec(self, nrows: int, ncols: int, 
                       has_legend: bool = True, 
                       has_title: bool = True) -> gridspec.GridSpec:
        """创建具有正确间距的GridSpec"""
        layout = self.get_layout()
        
        # 根据是否有图例和标题调整边距
        left = layout["main_left"]
        right = layout["main_right"] if has_legend else 0.95
        top = layout["main_top"] if has_title else 0.95
        bottom = layout["main_bottom"]
        
        gs = gridspec.GridSpec(
            nrows, ncols,
            hspace=layout["subplot_hspace"],
            wspace=layout["subplot_wspace"],
            left=left,
            right=right,
            top=top,
            bottom=bottom
        )
        
        return gs
    
    def add_legend(self, ax, handles=None, labels=None, 
                   location='upper right', outside=True):
        """添加优化的图例，避免与图表重叠"""
        colors = self.get_colors()
        fonts = self.get_fonts()
        
        if handles is None or labels is None:
            handles, labels = ax.get_legend_handles_labels()
        
        if not handles:
            return
        
        legend_props = {
            'fontsize': fonts["legend_size"],
            'frameon': True,
            'fancybox': True,
            'shadow': True,
            'framealpha': 0.9,
            'edgecolor': colors["neutral"],
            'facecolor': 'white'
        }
        
        if outside:
            # 放置在图表外部，避免重叠
            if 'right' in location:
                legend_props['bbox_to_anchor'] = (1.02, 1.0)
                legend_props['loc'] = 'upper left'
            elif 'left' in location:
                legend_props['bbox_to_anchor'] = (-0.02, 1.0)
                legend_props['loc'] = 'upper right'
            elif 'upper' in location:
                legend_props['bbox_to_anchor'] = (0.5, 1.02)
                legend_props['loc'] = 'lower center'
            elif 'lower' in location:
                legend_props['bbox_to_anchor'] = (0.5, -0.02)
                legend_props['loc'] = 'upper center'
        else:
            legend_props['loc'] = location
        
        legend = ax.legend(handles, labels, **legend_props)
        
        # 设置图例文字颜色
        for text in legend.get_texts():
            text.set_color(colors["neutral_dark"])
        
        return legend
    
    def add_title(self, fig_or_ax, title: str, subtitle: str = None):
        """添加图表标题 - 统一的标题样式"""
        colors = self.get_colors()
        fonts = self.get_fonts()
        layout = self.get_layout()
        
        if hasattr(fig_or_ax, 'suptitle'):  # Figure对象
            fig_or_ax.suptitle(
                title,
                fontsize=fonts["title_size"],
                fontweight='bold',
                color=colors["neutral_dark"],
                y=0.97
            )
            
            if subtitle:
                fig_or_ax.text(
                    0.5, 0.94, subtitle,
                    transform=fig_or_ax.transFigure,
                    fontsize=fonts["subtitle_size"],
                    ha='center',
                    color=colors["neutral"]
                )
        else:  # Axes对象
            fig_or_ax.set_title(
                title,
                fontsize=fonts["title_size"],
                fontweight='bold',
                color=colors["neutral_dark"],
                pad=layout["title_pad"]
            )
            
            if subtitle:
                fig_or_ax.text(
                    0.5, 1.05, subtitle,
                    transform=fig_or_ax.transAxes,
                    fontsize=fonts["subtitle_size"],
                    ha='center',
                    color=colors["neutral"]
                )
    
    def apply_axis_style(self, ax, xlabel: str = "", ylabel: str = ""):
        """应用统一的坐标轴样式"""
        colors = self.get_colors()
        fonts = self.get_fonts()
        layout = self.get_layout()
        
        if xlabel:
            ax.set_xlabel(xlabel, fontsize=fonts["label_size"], 
                         fontweight='600', labelpad=layout["label_pad"],
                         color=colors["neutral_dark"])
        if ylabel:
            ax.set_ylabel(ylabel, fontsize=fonts["label_size"], 
                         fontweight='600', labelpad=layout["label_pad"],
                         color=colors["neutral_dark"])
            
        ax.tick_params(labelsize=fonts["tick_size"], colors=colors["neutral_dark"])
        ax.grid(True, alpha=layout["grid_alpha"], color=colors["neutral_light"])
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        
        # 设置更粗的轴线
        ax.spines['left'].set_linewidth(2)
        ax.spines['bottom'].set_linewidth(2)
        ax.spines['left'].set_color(colors["neutral"])
        ax.spines['bottom'].set_color(colors["neutral"])