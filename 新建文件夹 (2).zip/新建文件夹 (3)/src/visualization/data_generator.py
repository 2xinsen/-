"""
数据生成器 - 为可视化模块生成模拟数据
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Any
from datetime import datetime, timedelta
import random

class DataGenerator:
    """专业数据生成器"""
    
    def __init__(self, seed: int = 42):
        """初始化数据生成器"""
        np.random.seed(seed)
        random.seed(seed)
        
    def generate_optimization_solutions(self, n_solutions: int = 100) -> List[Dict]:
        """生成优化解数据"""
        solutions = []
        
        for i in range(n_solutions):
            # 基础参数
            window_ratio = np.random.uniform(0.2, 0.8)
            shading_depth = np.random.uniform(0.3, 1.5)
            insulation_thickness = np.random.uniform(0.05, 0.25)
            
            # 计算双目标性能指标（能耗和热工性能）- 增强个体差异性
            # 能耗计算：与窗墙比正相关，与保温厚度和遮阳深度负相关
            base_energy = 120 - 180 * insulation_thickness + 60 * window_ratio - 30 * shading_depth
            energy_consumption = max(40, base_energy + np.random.normal(0, 12))
            
            # 热工性能计算：与保温厚度正相关，与遮阳深度正相关，与窗墙比负相关
            base_thermal = 0.4 + 2.2 * insulation_thickness + 0.3 * shading_depth - 0.4 * window_ratio
            thermal_performance = max(0.3, min(1.0, base_thermal + np.random.normal(0, 0.1)))
            
            solution = {
                'id': i,
                # 双目标函数 - 能耗和热工性能
                'energy_consumption': energy_consumption,
                'thermal_performance': thermal_performance,
                'system_efficiency': max(0.3, min(0.95, 0.6 + 0.3 * thermal_performance + np.random.normal(0, 0.05))),
                
                # 设计参数
                'window_area_ratio': window_ratio,
                'shading_depth': shading_depth,
                'insulation_thickness': insulation_thickness,
                
                # 经济性指标
                'investment_cost': self._calculate_investment_cost(window_ratio, shading_depth, insulation_thickness),
                'payback_period': np.random.uniform(3, 12),
                'maintenance_cost': np.random.uniform(2, 8),
                
                # 其他性能指标
                'environmental_impact': np.random.uniform(0.6, 0.95),
                'economic_performance': np.random.uniform(0.5, 0.9),
                'construction_difficulty': np.random.uniform(0.3, 0.9),
                'aesthetic_score': np.random.uniform(0.5, 0.9),
                
                # 双目标综合评分
                'energy_score': 1.0 - (energy_consumption - 40) / 160,  # 归一化能耗评分
                'thermal_score': thermal_performance  # 热工性能评分
            }
            
            solutions.append(solution)
        
        return solutions
    
    def generate_pareto_solutions(self, all_solutions: List[Dict]) -> List[Dict]:
        """
        从所有解中提取帕累托最优解 - 双目标优化（能耗与热工性能）
        
        目标函数：
        1. 最小化能耗 (energy_consumption)
        2. 最大化热工性能 (thermal_performance)
        
        帕累托支配关系：
        解A支配解B当且仅当：
        - A的能耗 <= B的能耗 且 A的热工性能 >= B的热工性能
        - 且至少有一个目标严格优于B
        """
        if not all_solutions:
            return []
        
        pareto_solutions = []
        
        for i, sol1 in enumerate(all_solutions):
            is_dominated = False
            
            for j, sol2 in enumerate(all_solutions):
                if i != j:
                    # 双目标帕累托支配检查
                    # sol2支配sol1的条件：
                    # 1. sol2的能耗不大于sol1的能耗
                    # 2. sol2的热工性能不小于sol1的热工性能
                    # 3. 至少有一个目标严格优于sol1
                    energy_better_or_equal = sol2['energy_consumption'] <= sol1['energy_consumption']
                    thermal_better_or_equal = sol2['thermal_performance'] >= sol1['thermal_performance']
                    
                    # 至少有一个目标严格更优
                    energy_strictly_better = sol2['energy_consumption'] < sol1['energy_consumption']
                    thermal_strictly_better = sol2['thermal_performance'] > sol1['thermal_performance']
                    
                    if (energy_better_or_equal and thermal_better_or_equal and 
                        (energy_strictly_better or thermal_strictly_better)):
                        is_dominated = True
                        break
            
            if not is_dominated:
                pareto_solutions.append(sol1)
        
        return pareto_solutions
    
    def generate_best_solutions(self, all_solutions: List[Dict]) -> Dict[str, Dict]:
        """
        生成最佳方案 - 双目标优化的典型解
        
        生成三种典型的最优解：
        1. 能耗最优解：能耗最低的方案
        2. 热工性能最优解：热工性能最高的方案
        3. 平衡最优解：综合考虑两个目标的平衡方案
        """
        if not all_solutions:
            return {}
        
        # 1. 能耗最优方案（单目标优化 - 最小化能耗）
        energy_best = min(all_solutions, key=lambda x: x['energy_consumption'])
        
        # 2. 热工性能最优方案（单目标优化 - 最大化热工性能）
        thermal_best = max(all_solutions, key=lambda x: x['thermal_performance'])
        
        # 3. 平衡最优方案（双目标加权评分）
        def balanced_score(sol):
            # 获取能耗和热工性能的范围用于归一化
            energy_values = [s['energy_consumption'] for s in all_solutions]
            thermal_values = [s['thermal_performance'] for s in all_solutions]
            
            energy_min, energy_max = min(energy_values), max(energy_values)
            thermal_min, thermal_max = min(thermal_values), max(thermal_values)
            
            # 归一化到[0,1]区间
            if energy_max > energy_min:
                energy_norm = 1 - (sol['energy_consumption'] - energy_min) / (energy_max - energy_min)
            else:
                energy_norm = 1.0
                
            if thermal_max > thermal_min:
                thermal_norm = (sol['thermal_performance'] - thermal_min) / (thermal_max - thermal_min)
            else:
                thermal_norm = 1.0
            
            # 平衡权重：能耗50%，热工性能50%
            return 0.5 * energy_norm + 0.5 * thermal_norm
        
        balanced_best = max(all_solutions, key=balanced_score)
        
        return {
            '能耗最优方案': energy_best,
            '热工性能最优方案': thermal_best,
            '平衡最优方案': balanced_best
        }
    
    def generate_evolution_data(self, generations: int = 100) -> Dict:
        """生成进化算法数据"""
        
        # 适应度历史
        best_fitness_history = []
        avg_fitness_history = []
        worst_fitness_history = []
        
        initial_fitness = 1000
        target_fitness = 200
        
        for gen in range(generations):
            # 模拟收敛过程
            progress = gen / generations
            convergence_factor = 1 - np.exp(-progress * 4)
            
            # 最佳适应度
            best_fitness = initial_fitness - (initial_fitness - target_fitness) * convergence_factor
            best_fitness += np.random.normal(0, 10) * (1 - progress)  # 噪声随进化减少
            best_fitness = max(target_fitness, best_fitness)
            
            # 平均适应度
            avg_fitness = best_fitness + np.random.uniform(50, 200) * (1 - progress * 0.8)
            
            # 最差适应度
            worst_fitness = avg_fitness + np.random.uniform(100, 300) * (1 - progress * 0.6)
            
            best_fitness_history.append(best_fitness)
            avg_fitness_history.append(avg_fitness)
            worst_fitness_history.append(worst_fitness)
        
        # 超体积历史
        hypervolume_history = []
        for gen in range(generations):
            progress = gen / generations
            hv = 0.1 + 0.8 * (1 - np.exp(-progress * 3)) + np.random.normal(0, 0.02)
            hypervolume_history.append(max(0.1, min(0.9, hv)))
        
        # 多样性历史
        diversity_history = []
        for gen in range(generations):
            progress = gen / generations
            # 多样性先增加后稳定
            diversity = 0.3 + 0.4 * np.sin(progress * np.pi) * np.exp(-progress * 2)
            diversity += np.random.normal(0, 0.05)
            diversity_history.append(max(0.1, min(0.8, diversity)))
        
        return {
            'best_fitness_history': best_fitness_history,
            'avg_fitness_history': avg_fitness_history,
            'worst_fitness_history': worst_fitness_history,
            'hypervolume_history': hypervolume_history,
            'diversity_history': diversity_history,
            'total_generations': generations,
            'total_evaluations': generations * 50,  # 假设每代50次评估
            'convergence_generation': int(generations * 0.8),
            'runtime': 120 + np.random.normal(0, 20),
            'memory_usage': 256 + np.random.normal(0, 50)
        }
    
    def generate_thermal_performance_data(self, solutions: List[Dict]) -> Dict:
        """生成热工性能详细数据"""
        
        # 传热系数分布数据
        thermal_conductivity_map = self._generate_thermal_map()
        
        # 热桥效应数据
        thermal_bridges = {
            '窗框': np.random.uniform(0.6, 1.2),
            '阳台': np.random.uniform(0.8, 1.5),
            '结构柱': np.random.uniform(0.4, 0.8),
            '楼板': np.random.uniform(0.7, 1.1),
            '墙体接缝': np.random.uniform(0.3, 0.6)
        }
        
        # 热惰性数据
        thermal_inertia = {
            '混凝土': 8.5,
            '砖墙': 6.2,
            '保温层': 12.3,
            '玻璃': 0.5,
            '钢材': 2.1
        }
        
        # 季节性性能数据
        seasonal_performance = {
            '春季': 0.75 + np.random.normal(0, 0.05),
            '夏季': 0.65 + np.random.normal(0, 0.05),
            '秋季': 0.80 + np.random.normal(0, 0.05),
            '冬季': 0.70 + np.random.normal(0, 0.05)
        }
        
        # 朝向性能数据
        orientation_performance = {}
        orientations = ['北', '东北', '东', '东南', '南', '西南', '西', '西北']
        base_values = [0.6, 0.7, 0.75, 0.85, 0.9, 0.8, 0.7, 0.65]
        
        for orient, base_val in zip(orientations, base_values):
            orientation_performance[orient] = base_val + np.random.normal(0, 0.03)
        
        return {
            'thermal_conductivity_map': thermal_conductivity_map,
            'thermal_bridges': thermal_bridges,
            'thermal_inertia': thermal_inertia,
            'seasonal_performance': seasonal_performance,
            'orientation_performance': orientation_performance
        }
    
    def generate_energy_breakdown_data(self, solutions: List[Dict]) -> Dict:
        """生成能耗分解数据"""
        
        # 年度能耗分解
        annual_breakdown = {
            '供暖': 35,
            '制冷': 28,
            '照明': 22,
            '设备': 15
        }
        
        # 月度能耗数据
        months = ['1月', '2月', '3月', '4月', '5月', '6月', 
                 '7月', '8月', '9月', '10月', '11月', '12月']
        
        heating_energy = [45, 40, 30, 15, 5, 0, 0, 0, 5, 20, 35, 42]
        cooling_energy = [0, 0, 2, 8, 15, 25, 30, 28, 18, 8, 2, 0]
        lighting_energy = [25, 23, 20, 18, 16, 15, 16, 18, 20, 22, 24, 26]
        equipment_energy = [15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15]
        
        monthly_data = {
            'months': months,
            'heating': heating_energy,
            'cooling': cooling_energy,
            'lighting': lighting_energy,
            'equipment': equipment_energy
        }
        
        # 日负荷曲线数据
        hours = list(range(24))
        summer_load = [20, 18, 16, 15, 16, 20, 25, 35, 45, 50, 55, 60,
                      65, 68, 70, 72, 70, 65, 55, 45, 35, 30, 25, 22]
        winter_load = [40, 38, 36, 35, 36, 40, 45, 50, 55, 50, 45, 40,
                      38, 35, 38, 42, 48, 55, 60, 58, 52, 48, 45, 42]
        
        daily_load_data = {
            'hours': hours,
            'summer_load': summer_load,
            'winter_load': winter_load
        }
        
        # 节能措施数据
        energy_saving_measures = {
            '外墙保温': {'saving': 15, 'cost': 8, 'payback': 3.2},
            '窗户升级': {'saving': 12, 'cost': 15, 'payback': 6.5},
            '遮阳优化': {'saving': 8, 'cost': 3, 'payback': 2.1},
            '设备更新': {'saving': 10, 'cost': 12, 'payback': 5.8},
            '控制系统': {'saving': 6, 'cost': 5, 'payback': 4.2}
        }
        
        return {
            'annual_breakdown': annual_breakdown,
            'monthly_data': monthly_data,
            'daily_load_data': daily_load_data,
            'energy_saving_measures': energy_saving_measures
        }
    
    def generate_clustering_data(self, solutions: List[Dict]) -> Dict:
        """
        生成聚类分析数据 - 基于双目标优化特征
        
        特征选择：
        1. 目标函数：能耗、热工性能
        2. 设计参数：窗墙比、遮阳深度、保温厚度
        3. 性能评分：能耗评分、热工评分
        """
        
        if not solutions:
            return {}
        
        # 提取双目标优化特征矩阵
        features = []
        for sol in solutions:
            feature_vector = [
                sol['energy_consumption'],      # 目标函数1：能耗
                sol['thermal_performance'],     # 目标函数2：热工性能
                sol['window_area_ratio'],       # 设计参数1：窗墙比
                sol['shading_depth'],          # 设计参数2：遮阳深度
                sol['insulation_thickness'],   # 设计参数3：保温厚度
                sol['energy_score'],           # 能耗评分
                sol['thermal_score']           # 热工评分
            ]
            features.append(feature_vector)
        
        features = np.array(features)
        
        # 聚类质量评估数据
        k_range = range(2, 10)
        silhouette_scores = []
        inertia_scores = []
        
        for k in k_range:
            # 模拟聚类质量指标
            # 轮廓系数通常在2-6个聚类时较高
            if k <= 5:
                sil_score = 0.3 + 0.4 * np.exp(-(k-3)**2) + np.random.normal(0, 0.05)
            else:
                sil_score = 0.2 + 0.1 * np.exp(-(k-5)) + np.random.normal(0, 0.03)
            
            # 惯性随k增加而减少
            inertia = 1000 * np.exp(-k/3) + np.random.normal(0, 50)
            
            silhouette_scores.append(max(0, min(1, sil_score)))
            inertia_scores.append(max(0, inertia))
        
        return {
            'features': features,
            'k_range': list(k_range),
            'silhouette_scores': silhouette_scores,
            'inertia_scores': inertia_scores
        }
    
    def generate_correlation_data(self, solutions: List[Dict]) -> Dict:
        """
        生成参数相关性数据 - 双目标优化参数关系分析
        
        分析参数：
        1. 目标函数：能耗、热工性能
        2. 设计参数：窗墙比、遮阳深度、保温厚度
        3. 经济指标：投资成本、回收期
        4. 性能评分：能耗评分、热工评分
        """
        
        if not solutions:
            return {}
        
        # 构建双目标优化参数数据框
        parameter_data = {
            # 目标函数
            'energy_consumption': [sol['energy_consumption'] for sol in solutions],
            'thermal_performance': [sol['thermal_performance'] for sol in solutions],
            
            # 设计参数
            'window_area_ratio': [sol['window_area_ratio'] for sol in solutions],
            'shading_depth': [sol['shading_depth'] for sol in solutions],
            'insulation_thickness': [sol['insulation_thickness'] for sol in solutions],
            
            # 经济指标
            'investment_cost': [sol['investment_cost'] for sol in solutions],
            'payback_period': [sol['payback_period'] for sol in solutions],
            
            # 性能评分
            'energy_score': [sol['energy_score'] for sol in solutions],
            'thermal_score': [sol['thermal_score'] for sol in solutions]
        }
        
        df = pd.DataFrame(parameter_data)
        
        # 计算相关性矩阵
        correlation_matrix = df.corr()
        
        # 主成分分析数据
        from sklearn.decomposition import PCA
        from sklearn.preprocessing import StandardScaler
        
        scaler = StandardScaler()
        scaled_data = scaler.fit_transform(df)
        
        pca = PCA()
        pca.fit(scaled_data)
        
        explained_variance_ratio = pca.explained_variance_ratio_
        components = pca.components_
        
        return {
            'parameter_data': parameter_data,
            'correlation_matrix': correlation_matrix.values,
            'feature_names': list(df.columns),
            'explained_variance_ratio': explained_variance_ratio,
            'pca_components': components
        }
    
    def _calculate_investment_cost(self, window_ratio: float, shading_depth: float, 
                                 insulation_thickness: float) -> float:
        """计算投资成本"""
        base_cost = 30
        
        # 窗户成本
        window_cost = window_ratio * 40
        
        # 遮阳成本
        shading_cost = shading_depth * 15
        
        # 保温成本
        insulation_cost = insulation_thickness * 200
        
        total_cost = base_cost + window_cost + shading_cost + insulation_cost
        
        # 添加随机波动
        total_cost += np.random.normal(0, 5)
        
        return max(20, total_cost)
    
    def _generate_thermal_map(self) -> np.ndarray:
        """生成热工性能分布图数据"""
        # 创建20x16的热工性能分布图
        x = np.linspace(0, 10, 20)
        y = np.linspace(0, 8, 16)
        X, Y = np.meshgrid(x, y)
        
        # 基础传热系数分布
        thermal_map = 0.3 + 0.2 * np.sin(X) * np.cos(Y) + 0.1 * np.random.random((16, 20))
        
        # 添加窗户区域（传热系数较高）
        thermal_map[6:10, 4:8] += 1.5    # 窗户1
        thermal_map[6:10, 12:16] += 1.5  # 窗户2
        
        # 添加热桥区域
        thermal_map[0:2, :] += 0.5       # 楼板热桥
        thermal_map[-2:, :] += 0.5       # 楼板热桥
        thermal_map[:, 0:2] += 0.3       # 结构柱热桥
        thermal_map[:, -2:] += 0.3       # 结构柱热桥
        
        return thermal_map
    
    def generate_comprehensive_dataset(self, n_solutions: int = 100) -> Dict[str, Any]:
        """生成完整的数据集"""
        
        print(f"生成 {n_solutions} 个优化解的完整数据集...")
        
        # 生成基础解数据
        solutions = self.generate_optimization_solutions(n_solutions)
        
        # 生成帕累托解
        pareto_solutions = self.generate_pareto_solutions(solutions)
        
        # 生成最佳方案
        best_solutions = self.generate_best_solutions(solutions)
        
        # 生成进化数据
        evolution_data = self.generate_evolution_data()
        
        # 生成热工性能数据
        thermal_data = self.generate_thermal_performance_data(solutions)
        
        # 生成能耗数据
        energy_data = self.generate_energy_breakdown_data(solutions)
        
        # 生成聚类数据
        clustering_data = self.generate_clustering_data(solutions)
        
        # 生成相关性数据
        correlation_data = self.generate_correlation_data(solutions)
        
        dataset = {
            'solutions': solutions,
            'pareto_solutions': pareto_solutions,
            'best_solutions': best_solutions,
            'evolution_data': evolution_data,
            'thermal_data': thermal_data,
            'energy_data': energy_data,
            'clustering_data': clustering_data,
            'correlation_data': correlation_data,
            'metadata': {
                'n_solutions': len(solutions),
                'n_pareto_solutions': len(pareto_solutions),
                'n_best_solutions': len(best_solutions),
                'generation_time': datetime.now().isoformat(),
                'data_version': '1.0'
            }
        }
        
        print(f"数据集生成完成:")
        print(f"  - 总解数: {len(solutions)}")
        print(f"  - 帕累托解数: {len(pareto_solutions)}")
        print(f"  - 最佳方案数: {len(best_solutions)}")
        
        return dataset