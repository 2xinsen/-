# 可视化模块重构设计文档

## 概述

本设计文档详细描述了建筑立面优化系统可视化模块的重构方案。新的可视化模块将采用现代化的架构设计，提供高质量的SCI级别图表，使用统一的暗蓝到暗红渐变配色方案，并支持自适应画布功能。

## 架构设计

### 整体架构

新的可视化模块采用分层架构设计：

```
src/visualization/
├── core/                          # 核心模块
│   ├── __init__.py               # 模块初始化
│   ├── theme_manager.py          # 主题管理器
│   ├── canvas_manager.py         # 画布管理器
│   ├── color_palette.py          # 配色方案管理
│   └── font_manager.py           # 字体管理器
├── charts/                        # 图表生成器
│   ├── __init__.py               # 图表模块初始化
│   ├── base_chart.py             # 基础图表类
│   ├── grid_layout_chart.py      # 网格布局图表
│   ├── pareto_3d_chart.py        # 3D帕累托图表
│   ├── radar_chart.py            # 雷达图表
│   ├── convergence_chart.py      # 收敛曲线图表
│   ├── heatmap_chart.py          # 热力图表
│   ├── comparison_chart.py       # 对比图表
│   └── performance_chart.py      # 性能图表
├── renderers/                     # 渲染器
│   ├── __init__.py               # 渲染器初始化
│   ├── building_renderer.py      # 建筑渲染器
│   ├── facade_renderer.py        # 立面渲染器
│   └── 3d_renderer.py            # 3D渲染器
├── utils/                         # 工具模块
│   ├── __init__.py               # 工具模块初始化
│   ├── data_processor.py         # 数据处理器
│   ├── export_manager.py         # 导出管理器
│   └── validation.py             # 数据验证
└── __init__.py                   # 主模块初始化
```

### 核心组件设计

#### 1. 主题管理器 (ThemeManager)

负责管理整个可视化系统的主题配置，包括：

- **配色方案管理**：统一的暗蓝到暗红渐变配色
- **字体配置**：SCI级别的专业字体设置
- **样式标准**：线宽、透明度、边距等视觉参数
- **质量设置**：DPI、分辨率等输出质量参数

**核心功能**：
```python
class ThemeManager:
    def __init__(self):
        self.color_palette = DarkBlueToRedPalette()
        self.font_config = SCIFontConfig()
        self.style_config = ProfessionalStyleConfig()
    
    def apply_theme(self, chart_type: str) -> dict
    def get_color_scheme(self, data_type: str) -> list
    def configure_matplotlib(self) -> None
```

#### 2. 画布管理器 (CanvasManager)

实现自适应画布功能：

- **尺寸计算**：根据数据量和图表类型自动计算最佳画布尺寸
- **布局优化**：智能调整子图布局和间距
- **响应式设计**：支持不同屏幕尺寸和分辨率
- **内存管理**：优化大型图表的内存使用

**核心功能**：
```python
class CanvasManager:
    def calculate_optimal_size(self, data_size: int, chart_type: str) -> tuple
    def create_adaptive_layout(self, num_subplots: int) -> GridSpec
    def optimize_spacing(self, figure: Figure) -> None
```

#### 3. 配色方案管理器 (ColorPalette)

管理暗蓝到暗红的渐变配色：

- **渐变生成**：创建平滑的颜色过渡
- **语义映射**：将颜色映射到不同的数据含义
- **对比度优化**：确保文字和背景的可读性
- **色彩无障碍**：支持色盲友好的配色方案

**配色定义**：
```python
GRADIENT_COLORS = {
    'primary_dark_blue': '#1a237e',      # 主要深蓝色
    'secondary_blue': '#3949ab',         # 次要蓝色
    'middle_purple': '#7b1fa2',          # 中间紫色
    'transition_red': '#c62828',         # 过渡红色
    'primary_dark_red': '#b71c1c',       # 主要深红色
    'accent_colors': ['#283593', '#5e35b1', '#8e24aa', '#ad1457', '#c62828']
}
```

### 图表组件设计

#### 1. 基础图表类 (BaseChart)

所有图表的基类，提供通用功能：

```python
class BaseChart:
    def __init__(self, theme_manager: ThemeManager, canvas_manager: CanvasManager):
        self.theme = theme_manager
        self.canvas = canvas_manager
        self.figure = None
        self.axes = None
    
    def create_figure(self, data: dict) -> Figure
    def apply_styling(self) -> None
    def add_annotations(self, annotations: list) -> None
    def export(self, filepath: str, format: str = 'png') -> None
```

#### 2. 专业图表类型

每种图表类型都继承自BaseChart，实现特定的绘制逻辑：

**网格布局图表 (GridLayoutChart)**：
- 智能方案排列
- 自适应缩略图尺寸
- 性能指标标注
- 帕累托最优标识

**3D帕累托图表 (Pareto3DChart)**：
- 真实3D渲染效果
- 交互式视角调整
- 动态光照和阴影
- 高质量材质渲染

**雷达图表 (RadarChart)**：
- 多维性能对比
- 平滑曲线渲染
- 区域填充效果
- 动态标签布局

### 渲染器设计

#### 1. 建筑渲染器 (BuildingRenderer)

专门处理建筑元素的渲染：

```python
class BuildingRenderer:
    def render_facade(self, facade_data: dict) -> patches.Polygon
    def render_windows(self, window_data: list) -> list
    def render_shading(self, shading_data: dict) -> patches.Rectangle
    def apply_materials(self, element: patches.Patch, material: str) -> None
```

#### 2. 3D渲染器 (Renderer3D)

处理复杂的3D视觉效果：

```python
class Renderer3D:
    def create_isometric_projection(self, points_3d: np.ndarray) -> np.ndarray
    def calculate_lighting(self, surface_normal: np.ndarray) -> float
    def render_shadows(self, objects: list) -> list
    def apply_depth_sorting(self, elements: list) -> list
```

## 数据模型

### 图表数据结构

```python
@dataclass
class ChartData:
    title: str
    data: dict
    metadata: dict
    styling_hints: dict

@dataclass
class VisualizationRequest:
    chart_type: str
    data: ChartData
    output_config: dict
    theme_overrides: dict = None
```

### 配置数据结构

```python
@dataclass
class ThemeConfig:
    color_palette: dict
    font_settings: dict
    style_parameters: dict
    quality_settings: dict

@dataclass
class CanvasConfig:
    base_size: tuple
    dpi: int
    adaptive_scaling: bool
    max_size_limit: tuple
```

## 接口设计

### 主要API接口

```python
class VisualizationEngine:
    """可视化引擎主接口"""
    
    def __init__(self, config: dict = None):
        """初始化可视化引擎"""
        pass
    
    def create_grid_layout(self, solutions: list, **kwargs) -> Figure:
        """创建网格布局图表"""
        pass
    
    def create_pareto_3d(self, pareto_data: dict, **kwargs) -> Figure:
        """创建3D帕累托图表"""
        pass
    
    def create_radar_chart(self, performance_data: dict, **kwargs) -> Figure:
        """创建雷达图表"""
        pass
    
    def create_convergence_chart(self, evolution_data: dict, **kwargs) -> Figure:
        """创建收敛曲线图表"""
        pass
    
    def create_comparison_chart(self, comparison_data: dict, **kwargs) -> Figure:
        """创建对比图表"""
        pass
    
    def export_all_charts(self, output_dir: str, formats: list = ['png', 'pdf']) -> dict:
        """批量导出所有图表"""
        pass
```

### 向后兼容接口

为了保持与现有代码的兼容性，提供适配器：

```python
class LegacyAdapter:
    """遗留接口适配器"""
    
    def __init__(self, engine: VisualizationEngine):
        self.engine = engine
    
    def GridLayoutGenerator(self, *args, **kwargs):
        """适配原有的GridLayoutGenerator"""
        return self.engine.create_grid_layout(*args, **kwargs)
    
    def Enhanced3DFacadeVisualizer(self, *args, **kwargs):
        """适配原有的3D可视化器"""
        return self.engine.create_pareto_3d(*args, **kwargs)
```

## 错误处理

### 异常类型定义

```python
class VisualizationError(Exception):
    """可视化模块基础异常"""
    pass

class DataValidationError(VisualizationError):
    """数据验证异常"""
    pass

class RenderingError(VisualizationError):
    """渲染异常"""
    pass

class ExportError(VisualizationError):
    """导出异常"""
    pass
```

### 错误处理策略

1. **数据验证**：在渲染前验证输入数据的完整性和格式
2. **渐进降级**：当高质量渲染失败时，自动降级到基础渲染
3. **资源管理**：确保内存和文件句柄的正确释放
4. **用户友好**：提供清晰的中文错误信息和解决建议

## 测试策略

### 单元测试

- 每个核心组件都有对应的单元测试
- 测试覆盖率目标：90%以上
- 包含边界条件和异常情况测试

### 集成测试

- 测试各组件之间的协作
- 验证完整的可视化流程
- 测试与main.py的集成

### 视觉回归测试

- 生成标准参考图像
- 自动比较输出图像的差异
- 确保重构后视觉效果的一致性

## 性能优化

### 渲染优化

1. **延迟渲染**：只在需要时才进行复杂的渲染计算
2. **缓存机制**：缓存常用的颜色、字体和样式配置
3. **批量处理**：优化大量数据点的渲染性能
4. **内存管理**：及时释放不需要的图形对象

### 导出优化

1. **格式选择**：根据用途选择最适合的输出格式
2. **压缩优化**：在保证质量的前提下减小文件大小
3. **并行导出**：支持多格式并行导出
4. **进度反馈**：为长时间操作提供进度指示

## 部署和维护

### 配置管理

- 支持通过配置文件自定义主题和样式
- 提供预设的主题模板
- 支持运行时动态调整配置

### 日志和监控

- 详细的操作日志记录
- 性能指标监控
- 错误统计和分析

### 文档和示例

- 完整的API文档
- 使用示例和最佳实践
- 故障排除指南

这个设计确保了新的可视化模块既能满足高质量专业图表的需求，又能保持良好的可维护性和扩展性。