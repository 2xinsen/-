"""
建筑立面优化系统 - 新版主程序
集成专业级可视化模块

该程序提供完整的建筑立面优化和可视化功能：
1. 数据生成和处理
2. 多目标优化算法
3. 专业级可视化图表生成
4. 完整的分析报告
"""

import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
import numpy as np

# 添加项目路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 导入可视化模块
from src.visualization.visualization_engine import VisualizationEngine
from src.visualization.data_generator import DataGenerator

class BuildingFacadeOptimizerNew:
    """建筑立面优化系统 - 新版本"""
    
    def __init__(self):
        self.output_dir = Path("output")
        self.output_dir.mkdir(exist_ok=True)
        
        # 初始化组件
        self.data_generator = DataGenerator()
        self.visualization_engine = VisualizationEngine(str(self.output_dir))
        
        # 注释掉优化版本，先使用标准版本测试
        # from src.visualization.chart_generator_optimized import ChartGeneratorOptimized
        # self.optimized_chart_generator = ChartGeneratorOptimized(self.visualization_engine)
        
        print("=" * 80)
        print("🏢 建筑立面优化系统 v2.0 - 专业可视化版")
        print("=" * 80)
        print("✨ 功能特色:")
        print("   📊 11类专业级分析图表")
        print("   🎯 多目标优化算法")
        print("   📈 高质量图表输出")
        print("   🔬 深度数据分析")
        print("=" * 80)
    
    def show_main_menu(self):
        """显示主菜单"""
        print("\n🎯 请选择操作模式：")
        print("1. 🚀 运行完整优化和可视化流程")
        print("2. 📊 仅生成可视化图表（使用模拟数据）")
        print("3. 🌐 生成中英文双语图表")
        print("4. 🔧 自定义参数优化")
        print("5. 📋 查看系统状态")
        print("6. 🚪 退出程序")
        
        while True:
            choice = input("\n请输入选择 (1-6): ").strip()
            if choice == "1":
                return "full_optimization"
            elif choice == "2":
                return "visualization_only"
            elif choice == "3":
                return "bilingual_charts"
            elif choice == "4":
                return "custom_optimization"
            elif choice == "5":
                return "system_status"
            elif choice == "6":
                return "exit"
            else:
                print("❌ 错误：请输入1-6之间的数字")
    
    def run_full_optimization(self):
        """运行完整的优化和可视化流程"""
        print("\n" + "=" * 80)
        print("🚀 开始完整优化和可视化流程")
        print("=" * 80)
        
        try:
            # 步骤1: 生成优化数据
            self.log("📊 步骤1/4: 生成优化解数据...")
            n_solutions = self.get_solution_count()
            dataset = self.data_generator.generate_comprehensive_dataset(n_solutions)
            
            # 步骤2: 保存数据
            self.log("💾 步骤2/4: 保存数据集...")
            self.save_dataset(dataset)
            
            # 步骤3: 生成可视化图表
            self.log("🎨 步骤3/4: 生成专业级可视化图表...")
            chart_files = self.generate_all_visualizations(dataset)
            
            # 步骤4: 生成报告
            self.log("📄 步骤4/4: 生成分析报告...")
            self.generate_analysis_report(dataset, chart_files)
            
            self.log("✅ 完整流程执行成功！")
            self.show_results_summary(chart_files)
            
        except Exception as e:
            print(f"❌ 执行过程中出现错误: {str(e)}")
            import traceback
            traceback.print_exc()
    

    
    def run_visualization_only(self):
        """仅运行可视化生成"""
        print("\n" + "=" * 80)
        print("📊 生成专业级可视化图表")
        print("=" * 80)
        
        try:
            # 生成模拟数据
            self.log("🎲 生成模拟数据...")
            n_solutions = self.get_solution_count()
            dataset = self.data_generator.generate_comprehensive_dataset(n_solutions)
            
            # 生成图表
            self.log("🎨 生成可视化图表...")
            chart_files = self.generate_all_visualizations(dataset)
            
            self.log("✅ 可视化图表生成完成！")
            self.show_results_summary(chart_files)
            
        except Exception as e:
            print(f"❌ 生成图表时出现错误: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def run_bilingual_charts(self):
        """生成中英文双语图表"""
        print("\n" + "=" * 80)
        print("🌐 生成中英文双语专业级可视化图表")
        print("=" * 80)
        
        try:
            # 生成数据
            self.log("📊 生成优化解数据...")
            n_solutions = self.get_solution_count()
            dataset = self.data_generator.generate_comprehensive_dataset(n_solutions)
            
            # 生成中文图表
            self.log("🎨 生成中文版图表...")
            viz_engine_zh = VisualizationEngine(str(self.output_dir), language="zh")
            chart_files_zh = viz_engine_zh.generate_all_charts(
                dataset['solutions'], dataset['pareto_solutions'], 
                dataset['best_solutions'], dataset['evolution_data']
            )
            
            # 生成英文图表
            self.log("🎨 生成英文版图表...")
            viz_engine_en = VisualizationEngine(str(self.output_dir), language="en")
            chart_files_en = viz_engine_en.generate_all_charts(
                dataset['solutions'], dataset['pareto_solutions'], 
                dataset['best_solutions'], dataset['evolution_data']
            )
            
            self.log("✅ 中英文双语图表生成完成！")
            
            # 显示结果摘要
            print("\n" + "=" * 80)
            print("✅ 双语图表生成完成！结果摘要")
            print("=" * 80)
            
            print(f"📁 输出目录: {self.output_dir.absolute()}")
            print(f"📊 中文图表数量: {len([f for f in chart_files_zh.values() if f])}")
            print(f"📊 英文图表数量: {len([f for f in chart_files_en.values() if f])}")
            
            print("\n🎨 生成的图表类型:")
            chart_descriptions = {
                'convergence': '算法收敛分析图 / Algorithm Convergence Analysis',
                'pareto': '帕累托前沿分析图 / Pareto Frontier Analysis',
                'thermal': '热工性能分析图 / Thermal Performance Analysis',
                'energy': '能耗分解分析图 / Energy Breakdown Analysis',
                'best_comparison': '最佳方案对比图 / Best Solutions Comparison',
                'grid_layout': '方案网格展示图 / Solutions Grid Layout',
                'radar': '综合性能雷达图 / Performance Radar Chart',
                'clustering': '解聚类分析图 / Solution Clustering Analysis',
                'correlation': '参数相关性分析图 / Parameter Correlation Analysis',
                'detailed_comparison': '详细方案对比图 / Detailed Solutions Comparison',
                '3d_solutions': '3D方案展示图 / 3D Solutions Visualization'
            }
            
            for chart_type, description in chart_descriptions.items():
                zh_status = "✅" if chart_files_zh.get(chart_type) else "❌"
                en_status = "✅" if chart_files_en.get(chart_type) else "❌"
                print(f"   {zh_status}/{en_status} {description}")
            
            self.show_bilingual_results_summary()
            
        except Exception as e:
            print(f"❌ 生成双语图表时出现错误: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def show_bilingual_results_summary(self):
        """显示双语结果摘要"""
        print("\n" + "=" * 80)
        while True:
            open_folder = input("🔍 是否打开结果文件夹查看图表? (y/n) [默认: y]: ").strip().lower()
            if not open_folder or open_folder in ['y', 'yes']:
                self.open_output_folder()
                break
            elif open_folder in ['n', 'no']:
                break
            else:
                print("❌ 请输入 y 或 n")
    
    def run_custom_optimization(self):
        """运行自定义参数优化"""
        print("\n" + "=" * 80)
        print("🔧 自定义参数优化")
        print("=" * 80)
        
        # 获取自定义参数
        params = self.get_custom_parameters()
        
        try:
            # 使用自定义参数生成数据
            self.log("⚙️ 使用自定义参数生成数据...")
            dataset = self.generate_custom_dataset(params)
            
            # 生成图表
            self.log("🎨 生成可视化图表...")
            chart_files = self.generate_all_visualizations(dataset)
            
            self.log("✅ 自定义优化完成！")
            self.show_results_summary(chart_files)
            
        except Exception as e:
            print(f"❌ 自定义优化时出现错误: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def show_system_status(self):
        """显示系统状态"""
        print("\n" + "=" * 80)
        print("📋 系统状态")
        print("=" * 80)
        
        # 检查输出目录
        charts_dir = self.output_dir / "analysis_charts"
        detailed_dir = self.output_dir / "detailed_charts"
        
        print(f"📁 输出目录: {self.output_dir.absolute()}")
        print(f"   - 主图表目录: {charts_dir} ({'存在' if charts_dir.exists() else '不存在'})")
        print(f"   - 详细图表目录: {detailed_dir} ({'存在' if detailed_dir.exists() else '不存在'})")
        
        # 统计已生成的图表
        if charts_dir.exists():
            chart_files = list(charts_dir.glob("*.png"))
            print(f"   - 已生成图表数量: {len(chart_files)}")
            
            if chart_files:
                print("   - 图表列表:")
                for chart_file in sorted(chart_files):
                    file_size = chart_file.stat().st_size / 1024  # KB
                    print(f"     • {chart_file.name} ({file_size:.1f} KB)")
        
        # 检查依赖
        print(f"\n🔧 系统组件状态:")
        print(f"   - 数据生成器: ✅ 正常")
        print(f"   - 可视化引擎: ✅ 正常")
        print(f"   - 图表生成器: ✅ 正常")
        
        # 内存使用情况
        import psutil
        process = psutil.Process()
        memory_info = process.memory_info()
        print(f"\n💾 内存使用:")
        print(f"   - 当前内存: {memory_info.rss / 1024 / 1024:.1f} MB")
        print(f"   - 虚拟内存: {memory_info.vms / 1024 / 1024:.1f} MB")
    
    def get_solution_count(self) -> int:
        """获取解的数量"""
        print("\n🔢 请设置优化解的数量:")
        print("1. 快速模式 (50个解)")
        print("2. 标准模式 (100个解)")
        print("3. 详细模式 (200个解)")
        print("4. 自定义数量")
        
        while True:
            choice = input("\n请选择模式 (1-4) [默认: 2]: ").strip()
            
            if not choice or choice == "2":
                return 100
            elif choice == "1":
                return 50
            elif choice == "3":
                return 200
            elif choice == "4":
                while True:
                    try:
                        custom_count = int(input("请输入解的数量 (10-500): "))
                        if 10 <= custom_count <= 500:
                            return custom_count
                        else:
                            print("❌ 数量必须在10-500之间")
                    except ValueError:
                        print("❌ 请输入有效的数字")
            else:
                print("❌ 请输入1-4之间的数字")
    
    def get_custom_parameters(self) -> dict:
        """获取自定义参数"""
        print("\n⚙️ 自定义优化参数:")
        
        params = {}
        
        # 建筑类型
        print("\n🏢 建筑类型:")
        print("1. 办公建筑")
        print("2. 住宅建筑")
        print("3. 商业建筑")
        print("4. 教育建筑")
        
        building_types = ['office', 'residential', 'commercial', 'educational']
        while True:
            choice = input("请选择建筑类型 (1-4) [默认: 1]: ").strip()
            if not choice or choice == "1":
                params['building_type'] = 'office'
                break
            elif choice in ['2', '3', '4']:
                params['building_type'] = building_types[int(choice) - 1]
                break
            else:
                print("❌ 请输入1-4之间的数字")
        
        # 气候区域
        print("\n🌡️ 气候区域:")
        print("1. 严寒地区")
        print("2. 寒冷地区")
        print("3. 夏热冬冷地区")
        print("4. 夏热冬暖地区")
        print("5. 温和地区")
        
        climate_zones = ['severe_cold', 'cold', 'hot_summer_cold_winter', 
                        'hot_summer_warm_winter', 'temperate']
        while True:
            choice = input("请选择气候区域 (1-5) [默认: 3]: ").strip()
            if not choice or choice == "3":
                params['climate_zone'] = 'hot_summer_cold_winter'
                break
            elif choice in ['1', '2', '4', '5']:
                params['climate_zone'] = climate_zones[int(choice) - 1]
                break
            else:
                print("❌ 请输入1-5之间的数字")
        
        # 优化目标权重
        print("\n🎯 优化目标权重 (总和应为1.0):")
        try:
            energy_weight = float(input("能耗权重 [默认: 0.4]: ") or "0.4")
            comfort_weight = float(input("热舒适权重 [默认: 0.3]: ") or "0.3")
            thermal_weight = float(input("热工性能权重 [默认: 0.3]: ") or "0.3")
            
            # 归一化权重
            total_weight = energy_weight + comfort_weight + thermal_weight
            if abs(total_weight - 1.0) > 0.01:
                energy_weight /= total_weight
                comfort_weight /= total_weight
                thermal_weight /= total_weight
                print(f"⚠️ 权重已归一化: 能耗={energy_weight:.3f}, 舒适={comfort_weight:.3f}, 热工={thermal_weight:.3f}")
            
            params['weights'] = {
                'energy': energy_weight,
                'comfort': comfort_weight,
                'thermal': thermal_weight
            }
            
        except ValueError:
            print("⚠️ 输入错误，使用默认权重")
            params['weights'] = {'energy': 0.4, 'comfort': 0.3, 'thermal': 0.3}
        
        return params
    
    def generate_custom_dataset(self, params: dict) -> dict:
        """根据自定义参数生成数据集"""
        # 设置随机种子以确保可重复性
        seed = hash(str(params)) % 1000
        custom_generator = DataGenerator(seed=seed)
        
        # 生成基础数据集
        n_solutions = self.get_solution_count()
        dataset = custom_generator.generate_comprehensive_dataset(n_solutions)
        
        # 根据参数调整数据
        self.adjust_dataset_by_parameters(dataset, params)
        
        return dataset
    
    def adjust_dataset_by_parameters(self, dataset: dict, params: dict):
        """根据参数调整数据集"""
        building_type = params.get('building_type', 'office')
        climate_zone = params.get('climate_zone', 'hot_summer_cold_winter')
        weights = params.get('weights', {'energy': 0.4, 'comfort': 0.3, 'thermal': 0.3})
        
        # 根据建筑类型调整能耗基准
        building_energy_factors = {
            'office': 1.0,
            'residential': 0.8,
            'commercial': 1.2,
            'educational': 0.9
        }
        
        energy_factor = building_energy_factors.get(building_type, 1.0)
        
        # 根据气候区域调整能耗
        climate_energy_factors = {
            'severe_cold': 1.3,
            'cold': 1.1,
            'hot_summer_cold_winter': 1.0,
            'hot_summer_warm_winter': 0.9,
            'temperate': 0.8
        }
        
        climate_factor = climate_energy_factors.get(climate_zone, 1.0)
        
        # 调整所有解的能耗
        total_factor = energy_factor * climate_factor
        for sol in dataset['solutions']:
            sol['energy_consumption'] *= total_factor
        
        # 重新计算帕累托解和最佳方案
        dataset['pareto_solutions'] = self.data_generator.generate_pareto_solutions(dataset['solutions'])
        dataset['best_solutions'] = self.data_generator.generate_best_solutions(dataset['solutions'])
        
        # 保存参数信息
        dataset['custom_parameters'] = params
    
    def generate_all_visualizations(self, dataset: dict) -> dict:
        """生成所有可视化图表"""
        solutions = dataset['solutions']
        pareto_solutions = dataset['pareto_solutions']
        best_solutions = dataset['best_solutions']
        evolution_data = dataset['evolution_data']
        
        return self.visualization_engine.generate_all_charts(
            solutions, pareto_solutions, best_solutions, evolution_data
        )
    
    def save_dataset(self, dataset: dict):
        """保存数据集"""
        # 保存为JSON格式（排除numpy数组）
        json_dataset = self.prepare_json_dataset(dataset)
        
        json_file = self.output_dir / "optimization_dataset.json"
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(json_dataset, f, indent=2, ensure_ascii=False, default=str)
        
        print(f"📁 数据集已保存到: {json_file}")
    
    def prepare_json_dataset(self, dataset: dict) -> dict:
        """准备JSON格式的数据集"""
        json_dataset = {}
        
        for key, value in dataset.items():
            if key in ['thermal_data', 'clustering_data', 'correlation_data']:
                # 跳过包含numpy数组的复杂数据
                continue
            elif isinstance(value, np.ndarray):
                json_dataset[key] = value.tolist()
            elif isinstance(value, dict):
                json_dataset[key] = self.prepare_json_dict(value)
            elif isinstance(value, list):
                json_dataset[key] = [self.prepare_json_dict(item) if isinstance(item, dict) else item 
                                   for item in value]
            else:
                json_dataset[key] = value
        
        return json_dataset
    
    def prepare_json_dict(self, data: dict) -> dict:
        """准备JSON格式的字典"""
        json_dict = {}
        for key, value in data.items():
            if isinstance(value, np.ndarray):
                json_dict[key] = value.tolist()
            elif isinstance(value, (np.integer, np.floating)):
                json_dict[key] = float(value)
            else:
                json_dict[key] = value
        return json_dict
    
    def generate_analysis_report(self, dataset: dict, chart_files: dict):
        """生成分析报告"""
        report_file = self.output_dir / "analysis_report.md"
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write("# 建筑立面优化系统分析报告\n\n")
            f.write(f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            # 数据概览
            f.write("## 📊 数据概览\n\n")
            f.write(f"- **总解数量**: {len(dataset['solutions'])}\n")
            f.write(f"- **帕累托最优解数量**: {len(dataset['pareto_solutions'])}\n")
            f.write(f"- **最佳方案数量**: {len(dataset['best_solutions'])}\n\n")
            
            # 性能统计
            f.write("## 📈 性能统计\n\n")
            solutions = dataset['solutions']
            
            energy_values = [sol['energy_consumption'] for sol in solutions]
            comfort_values = [sol['thermal_comfort'] for sol in solutions]
            thermal_values = [sol['thermal_performance'] for sol in solutions]
            
            f.write(f"### 能耗性能\n")
            f.write(f"- 平均值: {np.mean(energy_values):.2f} kWh/m²·年\n")
            f.write(f"- 最小值: {np.min(energy_values):.2f} kWh/m²·年\n")
            f.write(f"- 最大值: {np.max(energy_values):.2f} kWh/m²·年\n")
            f.write(f"- 标准差: {np.std(energy_values):.2f}\n\n")
            
            f.write(f"### 热舒适度\n")
            f.write(f"- 平均值: {np.mean(comfort_values):.3f}\n")
            f.write(f"- 最小值: {np.min(comfort_values):.3f}\n")
            f.write(f"- 最大值: {np.max(comfort_values):.3f}\n")
            f.write(f"- 标准差: {np.std(comfort_values):.3f}\n\n")
            
            f.write(f"### 热工性能\n")
            f.write(f"- 平均值: {np.mean(thermal_values):.3f}\n")
            f.write(f"- 最小值: {np.min(thermal_values):.3f}\n")
            f.write(f"- 最大值: {np.max(thermal_values):.3f}\n")
            f.write(f"- 标准差: {np.std(thermal_values):.3f}\n\n")
            
            # 最佳方案
            f.write("## 🏆 最佳方案\n\n")
            for name, solution in dataset['best_solutions'].items():
                f.write(f"### {name}\n")
                f.write(f"- 能耗: {solution['energy_consumption']:.2f} kWh/m²·年\n")
                f.write(f"- 热舒适度: {solution['thermal_comfort']:.3f}\n")
                f.write(f"- 热工性能: {solution['thermal_performance']:.3f}\n")
                f.write(f"- 窗墙比: {solution['window_area_ratio']:.3f}\n")
                f.write(f"- 遮阳深度: {solution['shading_depth']:.3f} m\n")
                f.write(f"- 保温厚度: {solution['insulation_thickness']:.3f} m\n\n")
            
            # 图表列表
            f.write("## 🎨 生成的图表\n\n")
            for chart_type, chart_path in chart_files.items():
                if chart_path:
                    chart_name = Path(chart_path).name
                    f.write(f"- **{chart_type}**: {chart_name}\n")
            
            f.write("\n---\n")
            f.write("*报告由建筑立面优化系统自动生成*\n")
        
        print(f"📄 分析报告已保存到: {report_file}")
    
    def show_results_summary(self, chart_files: dict):
        """显示结果摘要"""
        print("\n" + "=" * 80)
        print("✅ 执行完成！结果摘要")
        print("=" * 80)
        
        print(f"📁 输出目录: {self.output_dir.absolute()}")
        print(f"📊 生成图表数量: {len([f for f in chart_files.values() if f])}")
        
        print("\n🎨 生成的图表:")
        chart_descriptions = {
            'convergence': '01_算法收敛分析图',
            'pareto': '02_帕累托前沿分析图',
            'thermal': '03_热工性能综合分析图',
            'energy': '04_能耗分解分析图',
            'best_comparison': '05_最佳方案对比图',
            'grid_layout': '06_方案网格展示图',
            'detailed_comparison': '07_最佳方案详细对比图',
            '3d_solutions': '08_方案3D展示图',
            'radar': '09_综合性能雷达图',
            'clustering': '10_解聚类分析图',
            'correlation': '11_参数相关性分析图'
        }
        
        for chart_type, chart_path in chart_files.items():
            if chart_path:
                description = chart_descriptions.get(chart_type, chart_type)
                status = "✅" if Path(chart_path).exists() else "❌"
                print(f"   {status} {description}")
        
        # 询问是否打开结果文件夹
        print("\n" + "=" * 80)
        while True:
            open_folder = input("🔍 是否打开结果文件夹查看图表? (y/n) [默认: y]: ").strip().lower()
            if not open_folder or open_folder in ['y', 'yes']:
                self.open_output_folder()
                break
            elif open_folder in ['n', 'no']:
                break
            else:
                print("❌ 请输入 y 或 n")
    
    def open_output_folder(self):
        """打开输出文件夹"""
        try:
            import subprocess
            import platform
            
            if platform.system() == "Windows":
                os.startfile(str(self.output_dir))
            elif platform.system() == "Darwin":  # macOS
                subprocess.run(["open", str(self.output_dir)])
            else:  # Linux
                subprocess.run(["xdg-open", str(self.output_dir)])
            
            print(f"📂 已打开输出文件夹: {self.output_dir.absolute()}")
        except Exception as e:
            print(f"⚠️ 无法自动打开文件夹: {e}")
            print(f"📂 请手动打开: {self.output_dir.absolute()}")
    
    def log(self, message: str):
        """记录日志"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] {message}")
    
    def run(self):
        """运行主程序"""
        try:
            while True:
                choice = self.show_main_menu()
                
                if choice == "full_optimization":
                    self.run_full_optimization()
                elif choice == "visualization_only":
                    self.run_visualization_only()
                elif choice == "bilingual_charts":
                    self.run_bilingual_charts()
                elif choice == "custom_optimization":
                    self.run_custom_optimization()
                elif choice == "system_status":
                    self.show_system_status()
                elif choice == "exit":
                    print("\n👋 感谢使用建筑立面优化系统！")
                    break
                
                # 询问是否继续
                print("\n" + "=" * 80)
                while True:
                    continue_choice = input("🔄 是否继续使用系统? (y/n) [默认: y]: ").strip().lower()
                    if not continue_choice or continue_choice in ['y', 'yes']:
                        break
                    elif continue_choice in ['n', 'no']:
                        print("\n👋 感谢使用建筑立面优化系统！")
                        return
                    else:
                        print("❌ 请输入 y 或 n")
        
        except KeyboardInterrupt:
            print("\n\n⚠️ 用户中断程序")
        except Exception as e:
            print(f"\n❌ 程序运行出现错误: {str(e)}")
            import traceback
            traceback.print_exc()

def main():
    """主函数"""
    optimizer = BuildingFacadeOptimizerNew()
    optimizer.run()

if __name__ == "__main__":
    main()