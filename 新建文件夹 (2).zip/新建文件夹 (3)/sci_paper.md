# **融合深度学习图像分析与性能模拟的建筑立面多目标优化框架**
# **A Multi-Objective Optimization Framework for Building Façade Design Integrating Deep Learning-based Image Analysis and Performance Simulation**

**作者 (Author):** (请在此处填写您的姓名和单位信息)

**摘要 (Abstract):**

建筑立面作为建筑与外部环境交互的关键界面，其设计对建筑能耗、室内环境质量及城市美学具有决定性影响。然而，传统立面设计流程高度依赖设计师的经验直觉，且在平衡采光、能耗、成本等多个冲突性性能目标时，面临着迭代周期长、量化评估困难的挑战。为应对此挑战，本文提出并实现了一个创新的、端到端的自动化设计框架。该框架首次将基于YOLOv8的深度学习语义分割技术与以NSGA-II（非支配排序遗传算法-II）为核心的多目标优化引擎深度融合。该框架以单张建筑立面图像作为设计灵感的起点，通过YOLOv8模型精确识别并分割出窗户、墙体、遮阳等关键元素，并将其转化为可操作的参数化设计基因。随后，框架在庞大的设计空间中进行探索式生成，并集成EnergyPlus和Radiance等成熟的物理模拟引擎，对每一个潜在设计方案的能耗与日光性能进行快速、准确的量化评估。最终，通过NSGA-II算法的演化计算，框架能够高效地收敛并生成一组帕累托最优解集（Pareto Front），直观地揭示了不同性能目标之间的内在权衡关系。本文通过一个具体的案例研究，详细展示了该框架从图像输入到生成多样化、高性能立面方案的全过程。结果表明，该框架不仅极大地提升了设计效率，更重要的是，它为设计师提供了一个强大的决策支持工具，能够基于数据驱动的证据，在设计的早期阶段就做出更明智、更可持续的决策。本研究为数据驱动的生成式设计开辟了新的路径，展示了人工智能与建筑性能优化相结合的巨大潜力。

The building façade, as the critical interface between the built form and the external environment, decisively influences building energy consumption, indoor environmental quality, and urban aesthetics. Traditional façade design processes, however, rely heavily on designers' experience and intuition, facing challenges of long iteration cycles and difficulties in quantitatively balancing multiple conflicting performance objectives such as daylighting, energy use, and cost. To address this challenge, this paper proposes and implements an innovative, end-to-end automated design framework. This framework, for the first time, deeply integrates YOLOv8-based deep learning semantic segmentation with a multi-objective optimization engine centered on NSGA-II (Non-dominated Sorting Genetic Algorithm II). Starting from a single building façade image as design inspiration, the framework employs a YOLOv8 model to accurately identify and segment key elements like windows, walls, and shading devices, converting them into operable parametric design genes. Subsequently, the framework explores the vast design space generatively, integrating established physics simulation engines like EnergyPlus and Radiance to rapidly and accurately quantify the energy and daylighting performance of each potential design solution. Finally, through the evolutionary computation of the NSGA-II algorithm, the framework efficiently converges to a set of Pareto optimal solutions, visually revealing the intrinsic trade-off relationships among different performance objectives. Through a detailed case study, this paper demonstrates the entire process of the framework, from image input to the generation of diverse, high-performance façade solutions. The results indicate that the framework not only significantly enhances design efficiency but, more importantly, provides designers with a powerful decision-support tool to make more informed and sustainable decisions at the early design stage based on data-driven evidence. This research pioneers a new path for data-driven generative design, showcasing the immense potential of combining artificial intelligence with building performance optimization.

**关键词 (Keywords):** 建筑立面设计; 多目标优化; 深度学习; YOLOv8; 性能模拟; 生成式设计; NSGA-II

Building Façade Design; Multi-Objective Optimization; Deep Learning; YOLOv8; Performance Simulation; Generative Design; NSGA-II

---

## **1. 引言 (Introduction)**

### **1.1. 研究背景与动机 (Background and Motivation)**

在全球应对气候变化和能源危机的宏大背景下，建筑行业正面临着前所未有的转型压力。据统计，建筑物的建造和运营消耗了全球近40%的能源，并贡献了约三分之一的温室气体排放量[1]。在所有建筑组成部分中，建筑立面（Façade）作为建筑的“皮肤”，是调节室内外热量、光线和空气交换的第一道屏障，其设计优劣直接决定了建筑的能耗水平、室内物理环境的舒适度，乃至居住者的健康与工作效率[2]。一个精心设计的立面，能够在最大化利用自然光、降低照明与空调能耗的同时，提供舒适的视觉和热环境，并塑造出独特的建筑美学与城市肌理。

然而，传统的立面设计流程在应对这一复杂挑战时显得力不从心。它通常是一个线性、试错（trial-and-error）的过程，高度依赖于建筑师的个人经验和设计直觉。设计师首先构思一个方案，然后由工程师进行性能校核，若不满足要求则返回修改，如此反复。这个过程不仅耗时费力，而且由于设计空间的广阔性和多维性，人工迭代所能探索的设计可能性极其有限，往往只能得到一个“可接受”的解，而非“最优”的解[3]。更重要的是，立面设计的性能目标本质上是多元且相互冲突的（multi-objective and conflicting）。例如，增大窗墙比（Window-to-Wall Ratio, WWR）可以引入更多的自然光，提升视觉舒适度，但同时也可能导致夏季过多的太阳得热和冬季更大的热量损失，从而增加空调和采暖的能耗[4]。如何在这些相互掣肘的目标之间找到最佳的平衡点，是现代建筑设计的核心难题之一。

为了克服这些局限，性能驱动的设计（Performance-Driven Design）和建筑性能优化（Building Performance Optimization, BPO）应运而生[5]。通过将参数化建模工具（如Grasshopper）与性能模拟引擎（如EnergyPlus, Radiance）相结合，设计师可以将性能分析前置到设计的早期阶段，从而做出更明智的决策。进一步地，结合多目标优化算法（Multi-Objective Optimization Algorithms, MOOAs），如遗传算法，可以实现对庞大设计空间的自动化探索，以寻找一组在所有目标上都无法被其他方案超越的“帕累托最优解集”（Pareto Optimal Solutions）[6]。

尽管BPO领域取得了长足的进步，但现有的工作流仍存在一个显著的“断点”：设计的起点。目前绝大多数研究都始于一个抽象的、从零开始的参数化模型，其设计变量的定义和取值范围在很大程度上仍是主观的，缺乏与真实世界建筑语境的有机联系。设计师的灵感，往往来源于对现有优秀建筑的观察与学习。如果能有一种方法，自动地从真实建筑图像中“读取”和“理解”其立面设计的逻辑，并将其作为优化设计的“基因”和起点，无疑将极大地丰富设计探索的源泉，并使优化结果更具现实意义和文脉依据。这正是本研究的核心动机所在：我们旨在弥合计算机视觉与建筑性能优化之间的鸿沟，创建一个能够从图像中学习并进行创造性优化的自动化设计框架。

### **1.2. 文献综述 (Literature Review)**

为清晰定位本研究的创新性，我们从以下三个交叉领域对相关文献进行梳理：建筑性能优化（BPO）、计算机视觉在建筑领域的应用，以及生成式设计方法。

**1.2.1. 建筑性能优化 (Building Performance Optimization - BPO)**

BPO的研究旨在通过计算方法系统地探索设计方案，以寻求性能最优的设计。早期的BPO研究主要集中在单目标优化上，例如仅以最小化能耗为目标[7]。然而，这种方法忽略了建筑设计的多维性。Turan等人[8]的研究明确指出，单目标优化可能导致在其他关键性能（如采光）上的表现极差，因此多目标优化是更现实、更有效的研究路径。

多目标优化算法（MOOAs）因此成为BPO领域的研究热点。其中，基于进化思想的遗传算法（Genetic Algorithms, GAs）因其强大的全局搜索能力和处理复杂非线性问题的优势而被广泛应用。特别是Deb等人[9]提出的NSGA-II（非支配排序遗传算法-II），通过引入快速非支配排序和拥挤度计算，能够在保持解集多样性的同时高效地收敛到帕累托前沿，已成为BPO领域的基准算法。大量研究利用NSGA-II在建筑形态[10]、开窗[11]、遮阳[12]等方面进行了优化探索，目标函数通常涵盖能耗、日光、成本、舒适度等。例如，Nault等人[13]结合NSGA-II和EnergyPlus对办公建筑的窗户尺寸和玻璃类型进行优化，成功找到了能耗与采光之间的平衡点。

尽管这些研究取得了显著成果，但它们普遍共享一个共同的起点：一个预设的、由研究者手动定义的参数化模型。这导致优化过程虽然是自动的，但其“创造力”被限制在预设的拓扑结构和参数范围内，难以发现全新的、非传统的立面构成方式。

**1.2.2. 计算机视觉在建筑、工程与施工领域的应用 (Computer Vision in AEC)**

近年来，随着深度学习，特别是卷积神经网络（CNNs）的飞速发展，计算机视觉技术在建筑、工程与施工（AEC）领域的应用呈现出爆发式增长。其应用范围已从传统的图像分类扩展到更复杂的任务，如物体检测、语义分割和实例分割[14]。

在建筑领域，研究者们利用这些技术进行城市尺度的建筑模式识别[15]、建筑风格分类[16]、以及建筑构件的自动化检测与分割。例如，Deng等人[17]利用Mask R-CNN模型对建筑立面图像进行实例分割，能够精确地识别出每一扇窗户、门和阳台。YOLO（You Only Look Once）系列算法，以其卓越的速度和精度平衡，在实时物体检测任务中备受青睐[18]。其最新版本YOLOv8在保持高速度的同时，进一步提升了分割任务的精度，非常适合用于快速、准确地解析建筑立面图像。在您的前置项目中，`building-facade-segmentation-augmention442` 文件夹下的工作正是这一应用的体现，通过训练YOLOv8模型，实现了对立面元素的精准识别。

然而，现有的大部分研究将计算机视觉技术主要用于“分析”和“诊断”，例如，用于建筑建成后的质量巡检[19]、城市信息模型（BIM）的逆向生成[20]或现有建筑的能效评估[21]。将计算机视觉的“分析”能力作为“生成式设计”的前端输入，即从图像中提取设计DNA并用于启发新的设计方案的研究，目前仍处于起步阶段，存在巨大的探索空间。

**1.2.3. 生成式设计 (Generative Design)**

生成式设计描述了一类设计师与计算机协同创新的过程，其中设计师设定目标和约束，而计算机则负责生成大量满足要求的设计方案[22]。BPO本身可以被看作是生成式设计的一种形式。近年来，随着生成对抗网络（GANs）[23]和扩散模型（Diffusion Models）[24]等更强大的深度生成模型的出现，研究者们开始探索直接生成具有特定风格或性能的建筑图像或三维模型。

例如，Newton[25]使用GANs生成了具有特定建筑师风格的平面图。一些研究尝试将性能评估整合到GAN的训练过程中，以生成兼具美学和性能的方案[26]。然而，这些方法通常需要大量的成对数据（如“图像-性能”数据对）进行训练，数据获取成本高昂；同时，其生成过程如同一个“黑箱”，设计师难以理解和控制其内部逻辑，生成结果的几何精确性和可建造性也难以保证。

**1.2.4. 研究空白 (Research Gap)**

通过上述文献梳理，我们识别出以下关键的研究空白：现有的建筑性能优化（BPO）工作流，虽然强大，但其起点（参数化模型）与真实世界的建筑文脉脱节；而计算机视觉在建筑领域的应用，虽已成熟，但大多停留在“分析”层面，其作为“生成”工具的潜力尚未被充分发掘；新兴的深度生成模型方法，则在可控性、可解释性和数据依赖性方面存在挑战。

因此，迫切需要一个能够将这三者有机结合的综合性框架。这个框架应该能够：1) **自动解析**：从真实的建筑图像中自动解析出结构化的、可参数化的设计信息；2) **参数化重构**：将这些信息转化为一个灵活的参数化模型，作为优化的基础；3) **多目标优化**：在一个明确的、基于物理仿真的性能评估体系下，对该模型进行多目标优化；4) **提供决策支持**：最终生成一系列多样化的、高性能的、且与原始设计语境相关的设计方案，供设计师进行最终决策。

### **1.3. 本研究贡献与论文结构 (Contributions and Paper Structure)**

为填补上述研究空白，本研究设计并实现了一个端到端的、融合了深度学习图像分析与多目标性能优化的建筑立面设计框架。我们的目标是创建一个“灵感汲取-参数重构-性能优化-决策支持”的闭环工作流。

本研究的主要贡献可以概括为以下四点：

1.  **提出并实现了一个创新的自动化设计框架**：该框架无缝整合了基于YOLOv8的立面语义分割、参数化几何重构、多物理场性能模拟（能耗与采光）以及NSGA-II多目标优化算法，实现了从单张图像输入到帕累托最优设计方案输出的全自动化流程。
2.  **开发了一种数据驱动的设计基因提取方法**：与从零开始构建参数模型不同，本研究利用预训练的YOLOv8模型从现实世界的建筑图像中提取立面布局、构件比例等核心设计信息，并将其作为优化算法的“种子”和“基因库”，使得优化结果既有创新性，又不脱离现实文脉。
3.  **验证了框架的有效性与实用性**：通过一个详尽的案例研究，我们成功展示了该框架能够有效探索设计空间，揭示能耗与采光性能之间的复杂权衡关系，并生成一系列在性能上显著优于基准设计的、多样化的立面方案。
4.  **提供了一个强大的交互式决策支持工具**：本框架的输出不是单一的“最佳”答案，而是一个可视化的帕累托解集，辅以性能雷达图、关联矩阵等分析工具。这使得设计师能够直观地理解不同设计选择的后果，并根据自身的偏好和具体项目要求，做出数据驱动的、明智的决策。

本文的后续结构安排如下：第二部分将详细阐述我们提出的多模块集成框架及其核心技术细节；第三部分将通过一个案例研究，展示框架的实际运行结果并进行深入分析；第四部分将对研究结果进行讨论，分析其背后的设计洞见、研究的优势与局限性；第五部分将对全文进行总结，并展望未来的研究方向。

---

## **2. 方法论 (Methodology)**

为了实现从图像灵感到优化决策的自动化流程，我们设计了一个由四个紧密耦合的模块组成的集成框架：(1) 基于YOLOv8的图像分析与几何提取模块；(2) 参数化建模与方案生成模块；(3) 多目标性能模拟模块；(4) NSGA-II多目标优化模块。这四个模块共同构成了一个闭环的迭代系统，如图1所示。本章节将详细介绍每个模块的设计理念、技术实现和相互之间的协作关系。

**[插入图表：自定义流程图]**

**图1：集成设计框架流程图**
*该图应为一幅清晰的流程图，展示从“输入”到“输出”的完整数据流和模块交互。*
*   **输入区 (Inputs):** 包含“建筑立面图像 (Façade Image)”, “气候数据 (EPW File)”, “设计约束 (Design Constraints)”。
*   **模块一 (Module 1: Image Analysis & Geometric Extraction):** 核心是“YOLOv8 Semantic Segmentation”，输出“结构化几何数据 (Structured Geometric Data)”。
*   **模块二 (Module 2: Parametric Modeling & Solution Generation):** 接收几何数据，核心是“定义设计变量 (Define Design Variables)”和“生成几何模型 (Generate Geometric Models)”。
*   **模块三 (Module 3: Multi-Objective Performance Simulation):** 接收几何模型，并行执行“能耗模拟 (Energy Simulation - EnergyPlus)”和“日光模拟 (Daylight Simulation - Radiance)”，输出“性能目标值 (Performance Objectives)”。
*   **模块四 (Module 4: Multi-Objective Optimization):** 核心是“NSGA-II Algorithm”，它接收性能目标值，并向模块二输出新的“设计变量组合 (New Design Variables)”。这是一个循环箭头，表示迭代优化。
*   **输出区 (Outputs):** 优化循环结束后，输出“帕累托最优解集 (Pareto Optimal Solutions)”, “可视化分析图表 (Visualization & Analysis)”, “推荐设计方案 (Recommended Designs)”。

**Figure 1: Flowchart of the Integrated Design Framework**
*This should be a clear flowchart illustrating the complete data flow and module interaction from "Inputs" to "Outputs".*
*   **Inputs Zone:** Contains "Façade Image", "Climate Data (EPW File)", "Design Constraints".
*   **Module 1: Image Analysis & Geometric Extraction:** Core component is "YOLOv8 Semantic Segmentation", which outputs "Structured Geometric Data".
*   **Module 2: Parametric Modeling & Solution Generation:** Receives geometric data, with core processes "Define Design Variables" and "Generate Geometric Models".
*   **Module 3: Multi-Objective Performance Simulation:** Receives geometric models, performs parallel "Energy Simulation (EnergyPlus)" and "Daylight Simulation (Radiance)", and outputs "Performance Objectives".
*   **Module 4: Multi-Objective Optimization:** Core component is the "NSGA-II Algorithm", which receives performance objectives and outputs "New Design Variables" back to Module 2, indicated by a loop arrow for iterative optimization.
*   **Outputs Zone:** After the optimization loop concludes, it outputs "Pareto Optimal Solutions", "Visualization & Analysis" charts, and "Recommended Designs".

### **2.1. 模块一: 基于YOLOv8的图像分析与几何提取**

该模块是整个框架的起点，其任务是从输入的单张建筑立面图像中，自动、准确地提取出关键的几何与语义信息，为后续的参数化建模提供“原始素材”。

**2.1.1. 数据集与模型训练 (Dataset and Model Training)**

本研究利用了您在 `building-facade-segmentation-augmention442` 项目中已经完成的工作。该工作的核心是训练了一个YOLOv8模型，用于建筑立面的语义分割。我们在此对该过程的关键环节进行阐述。

*   **数据集:** 模型的性能高度依赖于训练数据的质量和多样性。该模型所用的数据集（如 `building-facade-segmentation-augmention.v1i.yolov8` 所示）是一个专门针对建筑立面元素标注的图像库。数据集中包含了大量的建筑立面图片，涵盖了不同的建筑风格、光照条件和拍摄角度。每个图像中的关键元素，如`窗户(window)`、`墙体(wall)`、`阳台(balcony)`、`入口(entrance)`等，都被精确地标注了其类别和像素级的分割掩码（segmentation mask）。
*   **数据增强 (Data Augmentation):** 为了提高模型的泛化能力，防止过拟合，训练过程中采用了丰富的数据增强策略。这包括随机的几何变换（如旋转、缩放、平移、裁剪）和光学变换（如亮度、对比度、饱和度的调整）。这些技术使得模型能够在面对未曾见过的、存在一定角度偏差或光照变化的图像时，依然保持较高的识别鲁棒性。
*   **模型选择与训练:** 我们选择YOLOv8作为核心分割模型，主要基于以下考量：(1) **高性能**: YOLOv8在COCO等标准数据集上展现了顶级的检测和分割精度。(2) **高效率**: 作为单阶段（one-stage）检测器，YOLOv8的处理速度非常快，满足了我们对设计框架快速响应的要求。(3) **易用性**: YOLOv8提供了简洁的API和预训练权重，大大简化了训练和部署的流程。模型的训练在一个配备了高性能GPU的服务器上进行，通过设定合适的学习率、优化器（如Adam）和迭代次数，模型能够充分学习数据集中蕴含的立面模式。模型的性能通过平均精度均值（mean Average Precision, mAP）等指标进行评估，确保其在投入使用前达到了足够高的准确率。

**2.1.2. 后处理与参数化转换 (Post-processing and Parametric Conversion)**

YOLOv8模型的直接输出是每个被识别对象的类别标签、置信度得分以及像素级的分割掩码。这些原始数据无法直接用于参数化建模，必须经过一个后处理和转换的步骤，将其转化为结构化的几何信息。这个过程由项目中的 `yolo_processor.py` 和 `geometry_calculator.py` 等脚本协同完成。

1.  **实例聚合与过滤:** 首先，根据置信度得分过滤掉低质量的检测结果。然后，对于同一类别（如“窗户”）的多个实例，系统会记录下每一个实例的掩码。
2.  **几何特征提取:** 对每一个实例的掩码，应用计算机视觉算法（如OpenCV中的轮廓发现 `findContours`）来提取其边界轮廓。基于轮廓，可以计算出一系列关键的几何属性：
    *   **边界框 (Bounding Box):** 最小的水平包围矩形，给出其左上角坐标 `(x, y)`、宽度 `w` 和高度 `h`。
    *   **质心 (Centroid):** 对象的几何中心点坐标。
    *   **面积 (Area):** 对象所占的像素总数。
    *   **长宽比 (Aspect Ratio):** 边界框的宽度与高度之比。
3.  **坐标归一化与关系建立:** 为了使提取的几何信息具有通用性，所有坐标和尺寸都会相对于整个立面的总宽度和总高度进行归一化处理（即转换为0到1之间的相对值）。同时，系统会分析各个元素之间的拓扑关系，例如，窗户是位于哪一块墙体区域内。

经过这一系列处理，一张像素化的图像就被成功转换成了一个结构化的、由带属性的对象组成的列表。例如，`[{'class': 'window', 'x': 0.15, 'y': 0.2, 'w': 0.1, 'h': 0.25}, {'class': 'window', ...}]`。这份列表，我们称之为“设计基因”，它构成了后续所有设计变化和优化的基础。

### **2.2. 模块二: 参数化建模与方案生成**

该模块的核心任务是接收来自模块一的“设计基因”，并以此为基础建立一个灵活的参数化模型。这个模型定义了哪些设计特征是可以被改变的（即设计变量），以及它们可以如何改变（即取值范围）。优化算法将通过调整这些变量来生成成千上万个不同的设计方案。

**2.2.1. 设计变量的定义 (Definition of Design Variables)**

设计变量的选择是BPO的关键步骤，它直接决定了设计探索的自由度和深度。基于从图像中提取的几何信息，并结合建筑设计的通用实践，我们定义了以下几类核心设计变量：

*   **窗墙比 (Window-to-Wall Ratio - WWR):** 这是一个宏观控制变量，决定了立面上开窗面积占总墙体面积的比例。它将作为一个全局乘数，协同缩放所有窗户的尺寸。其取值范围通常被约束在一个合理的区间内，例如 `[0.2, 0.8]`。
*   **窗户尺寸与比例 (Window Dimensions and Aspect Ratio):** 对于每一个窗户实例，其宽度 `w` 和高度 `h` 都可以作为独立的变量。为了保持一定的设计连续性，我们也可以选择让所有窗户共享相同的尺寸变化，或者根据其在建筑中的楼层或朝向进行分组控制。窗户的长宽比也可以作为一个变量，允许窗户在保持面积不变的情况下改变其形状（变得更“胖”或更“瘦”）。
*   **窗户位置 (Window Position):** 窗户的水平和垂直位置也可以是变量。可以让窗户在一定的墙面区域内自由移动，或者定义它们以某种规律（如对齐、均布）进行排列。
*   **遮阳系统 (Shading System):** 如果原始图像中包含遮阳元素，或者我们希望为设计引入遮阳，可以定义遮阳的类型（如水平、垂直、格栅）和关键尺寸。最常见的变量是**水平遮阳深度 (Horizontal Shading Depth)**，它对控制太阳得热至关重要。

这些变量的初始值（即优化的第0代）直接来源于模块一提取的“设计基因”。例如，初始的WWR就是原始图像中窗户总面积与墙体总面积之比。

**2.2.2. 几何模型生成 (Geometric Model Generation)**

一旦优化算法（模块四）提供了一组具体的设计变量值（例如，`WWR=0.5`, `shading_depth=0.8m`），本模块就会负责根据这些值快速生成一个用于性能模拟的三维几何模型。这个过程通常在内存中完成，以保证效率。生成的模型需要包含足够的信息以供模拟引擎使用，例如：

*   定义建筑的热区（Thermal Zones）。
*   为每个表面（墙、窗、屋顶）赋予材质属性（如U值、太阳得热系数SHGC、可见光透射比VLT）。这些属性可以从 `config.yaml` 文件中读取，也可以作为优化变量。
*   设置建筑的地理位置、朝向和周边环境。

这个快速的“变量-几何”转换能力是整个优化流程得以高效运行的关键。

### **2.3. 模块三: 多目标性能模拟**

本模块是框架的“物理世界”，负责对模块二生成的每一个设计方案进行性能评估，并返回量化的性能指标值，作为优化算法的“适应度函数”（Fitness Function）。为了全面评估立面性能，我们至少关注两个核心且相互冲突的目标：能耗和日光。

**2.3.1. 能耗模拟 (Energy Simulation)**

我们采用业界公认的、功能强大的建筑能耗模拟引擎EnergyPlus[27]来进行计算。

*   **输入:** 模块二生成的几何模型（通常以IDF格式传递），以及从 `src/climate_data/epw_parser.py` 处理过的标准气象数据文件（EPW,
    EnergyPlus Weather data）。EPW文件包含了特定地点逐小时的温度、湿度、太阳辐射、风速等信息，是保证模拟准确性的基础。
*   **计算:** EnergyPlus会基于热平衡原理，逐小时模拟建筑在一年内的能量流动，包括通过窗户和墙体的传热、太阳辐射得热、室内人员设备发热、以及暖通空调系统（HVAC）的能耗。
*   **输出:** 我们关注的核心性能指标是**全年单位面积总能耗 (Total Annual Energy Consumption per unit area)**，单位是kWh/m²/year。它通常包括采暖、制冷和照明三部分能耗的总和。
*   **优化目标:** **最小化**全年总能耗。

**2.3.2. 日光性能模拟 (Daylight Performance Simulation)**

良好的自然采光不仅能节省照明能耗，更能提升居住者的幸福感和生产力。我们采用基于光线追踪的模拟引擎Radiance[28]来进行精确的日光分析。

*   **输入:** 同样是模块二生成的几何模型和EPW文件中的太阳位置信息。
*   **计算:** Radiance能够模拟在各种天空条件下，日光在建筑空间内的复杂传播、反射和折射。我们采用的评估指标是**空间日光自主性 (Spatial Daylight Autonomy - sDA)**。sDA(300, 50%)表示工作平面上照度超过300 lux的时间占全年工作时间（如8am-6pm）50%以上的面积百分比。这是一个衡量采光“充足性”的常用动态指标[29]。
*   **输出:** sDA值，一个介于0%到100%之间的百分数。
*   **优化目标:** **最大化**sDA。

这两个模拟过程可以并行执行，以缩短每个方案的评估时间。评估完成后，一个包含能耗和sDA两个值的性能向量 `[energy_consumption, sDA]` 会被返回给优化模块。

### **2.4. 模块四: NSGA-II多目标优化**

这是整个框架的“大脑”，负责指导设计探索的方向。它接收来自模块三的性能评估结果，并依据“优胜劣汰”的原则，生成新一代的、更有潜力的设计方案。

**2.4.1. 算法选择与原理 (Algorithm Choice and Principles)**

如前所述，我们选择了NSGA-II作为核心优化算法，因为它在处理像建筑设计这样的复杂多目标问题时具有公认的卓越性能。其核心思想基于两个关键概念：

1.  **非支配排序 (Non-dominated Sorting):** 在多目标空间中，如果方案A在所有目标上都不劣于方案B，并且至少在一个目标上严格优于方案B，则称A“支配”（dominate）B。所有不受任何其他方案支配的解构成了第一层帕累托前沿（Pareto Front, Rank 1）。在所有剩余的解中，找出新的非支配解集，构成Rank 2，以此类推。NSGA-II通过这种分层的方式来评估解的优劣，优先选择排名（Rank）靠前的解。
2.  **拥挤度计算 (Crowding Distance Calculation):** 在同一个排名（Rank）的解中，为了保持解集的多样性，避免所有解都挤在帕累to前沿的某一个区域，NSGA-II会计算每个解周围的“拥挤度”。它倾向于保留那些位于稀疏区域的解，从而保证最终得到的帕累托前沿能够均匀地覆盖整个目标空间，为设计师提供更丰富的选择。

**2.4.2. 优化流程 (Optimization Process)**

NSGA-II的优化流程是一个迭代循环，具体步骤如下：

1.  **初始化 (Initialization):** 首先，随机生成一个初始种群（Population），或者更优地，使用模块一提取的“设计基因”作为初始种群中的一个个体（Individual），其余个体则通过对其进行小范围的随机变异生成。每个个体都代表了一组完整的设计变量。
2.  **评估 (Evaluation):** 将种群中的每一个个体（即每一组设计变量）发送给模块二和模块三，计算其对应的性能目标值（能耗和sDA）。
3.  **选择、交叉与变异 (Selection, Crossover, and Mutation):**
    *   **选择 (Selection):** 基于非支配排序和拥挤度计算的结果，从当前种群中选择优秀的个体作为“父代”。
    *   **交叉 (Crossover):** 随机配对父代个体，并以一定的概率（交叉概率）交换它们的部分“基因”（即设计变量），从而创造出新的“子代”。这模拟了生物进化中的基因重组，有助于探索新的设计组合。
    *   **变异 (Mutation):** 对子代个体的某些基因（设计变量）以一个较小的概率（变异概率）进行随机修改。这有助于跳出局部最优解，增加种群的多样性。
4.  **合并与精英保留 (Combination and Elitism):** 将父代种群和新生成的子代种群合并。对这个合并后的大种群再次进行非支配排序和拥挤度计算，并从中选择出最优的N个个体（N为种群大小），形成下一代的新种群。这种“精英保留”策略确保了每一代的最优解不会在迭代中丢失。
5.  **终止 (Termination):** 重复步骤2-4，直到达到预设的终止条件，例如，达到最大迭代代数（Number of Generations），或者帕累托前沿连续多代没有显著变化。

优化过程结束后，最终种群中的非支配解集（Rank 1）就是我们寻找的帕累托最优解集。这个解集将被传递给输出模块，进行可视化和分析。整个过程的参数，如种群大小、迭代代数、交叉和变异概率，都在 `config.yaml` 或 `run_interactive.py` 中进行配置，它们的取值对优化的效率和效果有重要影响。

---

## **3. 结果与分析 (Results and Analysis)**

为了验证我们提出的自动化设计框架的有效性和实用性，我们进行了一个完整的案例研究。本章节将详细呈现该案例的设置、优化过程的可视化、最终的帕累托解集分析，并对其中有代表性的设计方案进行深入的比较和解读。

### **3.1. 案例研究设置 (Case Study Setup)**

*   **建筑模型与地点:** 我们选择一个位于中国上海的典型办公建筑作为研究对象。上海属于夏热冬冷地区，对建筑的采暖和制冷都有较高要求，这使得能耗与采光的权衡问题尤为突出。我们从一张该建筑的南向立面照片开始我们的设计流程。气候数据采用上海地区的标准EPW文件。
*   **基准方案 (Baseline Design):** 原始照片通过模块一解析后得到的几何参数，构成了我们的“基准方案”。该方案将被用作比较的参照物，以衡量优化后方案的性能提升。
*   **优化目标:** 如方法论中所述，我们设定了两个相互冲突的优化目标：
    1.  **最小化** 全年单位面积总能耗 (kWh/m²/year)。
    2.  **最大化** 空间日光自主性 sDA(300, 50%) (%)。
*   **设计变量:** 我们主要控制以下变量：(1) 整体窗墙比 (WWR)，范围 [0.25, 0.75]；(2) 窗户的统一长宽比，范围 [0.5, 2.0]；(3) 水平遮阳构件的深度，范围 [0.0m, 1.2m]。
*   **优化算法参数:** 我们设置NSGA-II的种群大小为100，最大迭代代数为50代。这意味着总共将有 `100 * 50 = 5000` 个设计方案被生成和评估。

### **3.2. 优化过程的可视化 (Visualization of the Optimization Process)**

一个有效的优化过程应该在探索新可能性的同时，稳定地向更优的性能区域收敛。图2展示了在50代进化过程中，种群的平均性能指标（能耗和sDA）的变化趋势。

**[插入图表：output/07_convergence_analysis.png 或 output/sci_test_convergence_detailed.png]**

**图2：优化过程收敛图**
*该图应包含两条曲线。X轴为迭代代数（Generation），从0到50。Y轴为性能指标值。*
*   **第一条曲线 (蓝色):** 平均总能耗 (Average Total Energy Consumption)。曲线应从一个较高的初始值开始，随着代数增加而快速下降，并在约30-40代后逐渐趋于平稳，表明算法找到了低能耗的设计区域。
*   **第二条曲线 (橙色):** 平均sDA (Average sDA)。曲线应从一个初始值开始，随着代数增加而稳步上升，并最终趋于平稳，表明算法也成功地提升了种群的日光性能。

**Figure 2: Convergence Plot of the Optimization Process**
*This figure should contain two curves. The X-axis is the Generation, from 0 to 50. The Y-axis represents the performance metric values.*
*   **First curve (blue):** Average Total Energy Consumption. The curve should start at a relatively high initial value, decrease rapidly with increasing generations, and then gradually plateau after about 30-40 generations, indicating the algorithm has found low-energy design regions.
*   **Second curve (orange):** Average sDA. The curve should start from an initial value, rise steadily with increasing generations, and eventually level off, showing the algorithm has also successfully improved the daylighting performance of the population.

从图2中我们可以观察到，在优化的初始阶段（前20代），两个性能指标都得到了快速的改善。平均能耗显著降低，而平均sDA则显著提升。这表明优化算法正在有效地淘汰性能较差的初始随机解，并迅速定位到高性能的设计区域。在优化的后期（30代以后），两条曲线逐渐变得平缓，表明种群已经收敛到了帕累托前沿附近，算法在“探索”（Exploration）和“利用”（Exploitation）之间达到了良好的平衡。这种收敛行为证明了我们的NSGA-II优化器是高效且鲁棒的。

### **3.3. 帕累托前沿分析 (Pareto Front Analysis)**

优化过程的最终成果，也是最有价值的输出，是帕累托最优解集。图3以二维散点图的形式展示了这组解。

**[插入图表：output/02_pareto_3d_scatter.png (若为2D) 或 output/sci_charts/sci_01_pareto_3d_scatter.png]**

**图3：能耗与sDA的帕累托前沿**
*这是一个二维散点图。X轴为全年总能耗 (kWh/m²/year)，从左到右增加。Y轴为sDA (%)，从下到上增加。*
*   图中应有大量（约100个）的点，形成一条从左上角延伸到右下角的清晰的曲线，这就是帕累托前沿。
*   **基准方案 (Baseline):** 用一个特殊的标记（如红色五角星）在图中标出基准方案的位置。它应该位于帕累托前沿的右下方，表明它是一个被支配的解。
*   **三个代表点:** 在帕累托前沿上用不同的标记（如A, B, C）圈出三个有代表性的点：左上角的“高采光方案”，右下角的“高能效方案”，以及中间拐点处的“均衡方案”。

**Figure 3: Pareto Front for Energy Consumption and sDA**
*This is a 2D scatter plot. The X-axis is Total Annual Energy Consumption (kWh/m²/year), increasing from left to right. The Y-axis is sDA (%), increasing from bottom to top.*
*   The plot should contain numerous points (around 100) forming a distinct curve from the upper-left to the lower-right, which is the Pareto front.
*   **Baseline Design:** The baseline design should be marked with a special symbol (e.g., a red star) and located to the lower-right of the Pareto front, indicating it is a dominated solution.
*   **Three Representative Points:** Three representative points on the front should be highlighted with different markers (e.g., A, B, C): the "High Daylight Solution" in the upper-left, the "High Energy-Efficiency Solution" in the lower-right, and the "Balanced Solution" at the knee-point in the middle.

图3直观地揭示了建筑立面设计中一个根本性的权衡关系。帕累托前沿呈现出一条清晰的负相关曲线，这意味着**获得更好的日光性能（更高的sDA）几乎总是以牺牲能效（更高的能耗）为代价，反之亦然**。这是因为，要提高sDA，通常需要更大的窗户面积，但这会不可避免地增加夏季的太阳得热和冬季的热量损失，导致HVAC系统需要消耗更多能量来维持室内舒适。

从图中我们还能得到几个关键洞见：
1.  **基准方案的性能低下:** 我们的基准方案（红色五角星）明显位于帕累托前沿的右下方。这说明，几乎帕累托前沿上的任何一个方案，都在至少一个目标上优于基准方案，同时在另一个目标上不劣于它。这有力地证明了我们的优化框架能够显著提升设计性能。
2.  **权衡的非线性:** 帕累托前沿并非一条直线，而是一条曲线。在曲线的两端，性能的边际效益递减。例如，在左上角区域（高sDA），为了将sDA从90%再提升到92%，可能需要付出巨大的能耗代价。同样，在右下角区域（高能效），为了将能耗再降低一点点，可能会导致sDA的大幅下降。
3.  **“拐点”区域的价值:** 曲线中部的“拐点”（Knee Point）区域，如方案B附近，通常是设计师最感兴趣的地方。在这个区域，对任何一个目标的微小改进都会导致另一个目标的急剧恶化。因此，这里的解通常被认为是“性价比”最高的均衡解。

### **3.4. 代表性设计方案对比 (Comparison of Representative Designs)**

为了更具体地理解帕累托前沿上的点所代表的物理设计，我们从图3中挑选了三个代表性方案，并与基准方案进行可视化和性能的对比。

*   **方案A: 高采光方案 (High Daylight Solution):** 位于帕累托前沿的左上角，sDA最高，但能耗也相对较高。
*   **方案B: 均衡方案 (Balanced Solution):** 位于帕累托前沿的“拐点”，在两个目标之间取得了良好的平衡。
*   **方案C: 高能效方案 (High Energy-Efficiency Solution):** 位于帕累托前沿的右下角，能耗最低，但sDA也相应较低。

**[插入图表：output/04_facade_comparison.png 或 output/improved_grid_layout.png]**

**图4：代表性立面设计方案可视化对比**
*该图应为一个2x2的网格图，分别展示四个立面方案的渲染图或线框图。*
*   (a) 基准方案 (Baseline Design)
*   (b) 方案A: 高采光方案 (High Daylight Solution)
*   (c) 方案B: 均衡方案 (Balanced Solution)
*   (d) 方案C: 高能效方案 (High Energy-Efficiency Solution)
*   *从视觉上，方案A应有最大的窗墙比和较浅的遮阳；方案C应有最小的窗墙比和较深的遮阳；方案B则介于两者之间。*

**Figure 4: Visual Comparison of Representative Façade Designs**
*This figure should be a 2x2 grid, showing renderings or line drawings of the four façade designs.*
*   (a) Baseline Design
*   (b) Solution A: High Daylight Solution
*   (c) Solution B: Balanced Solution
*   (d) Solution C: High Energy-Efficiency Solution
*   *Visually, Solution A should have the largest WWR and shallower shading; Solution C should have the smallest WWR and deeper shading; Solution B should be intermediate.*

**[插入图表：output/06_radar_performance_dashboard.png 或 output/sci_charts/sci_02_radar_performance_dashboard.png]**

**图5：代表性方案性能雷达图**
*这是一个雷达图，有四个角，分别代表四个方案（Baseline, A, B, C）。雷达图的轴代表不同的性能指标，例如“能耗 (越低越好)”，“sDA (越高越好)”，“窗墙比”，“遮阳深度”。所有指标都应进行归一化处理以便比较。*
*   *图应清晰地显示，方案A在sDA轴上最突出，方案C在能耗轴上最突出（即值最小），方案B在两者之间取得平衡。*

**Figure 5: Performance Radar Chart for Representative Solutions**
*This is a radar chart with four corners representing the four solutions (Baseline, A, B, C). The axes of the radar represent different performance metrics, such as "Energy Consumption (lower is better)", "sDA (higher is better)", "WWR", and "Shading Depth". All metrics should be normalized for comparison.*
*   *The chart should clearly show that Solution A excels on the sDA axis, Solution C excels on the energy axis (i.e., has the lowest value), and Solution B strikes a balance between the two.*

结合图4和图5，我们可以对这些方案进行深入解读：

*   **基准方案** 的性能表现平庸，能耗和sDA都处于中等偏下的水平。
*   **方案A (高采光)** 为了最大化sDA，采用了非常大的窗墙比（约0.7）和较浅的遮阳。这使得大量自然光能够进入室内深处，但代价是太阳得热量高，导致制冷能耗显著增加。这种设计可能适用于对采光有极端要求的特定空间，如画廊或设计工作室。
*   **方案C (高能效)** 则走向了另一个极端。它通过采用较小的窗墙比（约0.3）和非常深的水平遮阳（约1.0m），有效地阻挡了夏季高角度的太阳辐射，并减少了冬季的热量损失，从而实现了最低的能耗。然而，其代价是牺牲了部分日光，可能需要更多的人工照明补充。
*   **方案B (均衡)** 体现了“折衷的智慧”。它采用了中等的窗墙比（约0.5）和中等深度的遮阳（约0.6m）。这个组合在保证了充足日光（sDA仍在较高水平）的同时，将能耗控制在了一个相对理想的范围内。对于大多数常规办公空间而言，这可能是一个最受欢迎和最实用的设计选择。

### **3.5. 设计变量与性能的相关性分析**

为了给设计师提供更具指导性的设计策略，我们进一步分析了设计变量（输入）与性能目标（输出）之间的相关性。

**[插入图表：output/09_parameter_correlation.png 或 output/sci_charts/sci_07_parameter_correlation.png]**

**图6：设计变量与性能目标的相关性热力图**
*这是一个热力图矩阵。行是设计变量（WWR, Aspect Ratio, Shading Depth）。列是性能目标（Energy Consumption, sDA）。*
*   *单元格的颜色表示相关性的强度和方向。红色表示强正相关，蓝色表示强负相关，白色表示不相关。*
*   *预期的结果是：*
    *   *WWR与Energy Consumption呈强正相关（红色）。*
    *   *WWR与sDA呈强正相关（红色）。*
    *   *Shading Depth与Energy Consumption呈强负相关（蓝色）。*
    *   *Shading Depth与sDA呈中等强度的负相关（淡蓝色）。*

**Figure 6: Correlation Heatmap between Design Variables and Performance Objectives**
*This is a heatmap matrix. Rows represent design variables (WWR, Aspect Ratio, Shading Depth). Columns represent performance objectives (Energy Consumption, sDA).*
*   *The color of the cells indicates the strength and direction of the correlation. Red for strong positive, blue for strong negative, and white for no correlation.*
*   *Expected results:*
    *   *WWR shows a strong positive correlation with Energy Consumption (red).*
    *   *WWR shows a strong positive correlation with sDA (red).*
    *   *Shading Depth shows a strong negative correlation with Energy Consumption (blue).*
    *   *Shading Depth shows a moderately strong negative correlation with sDA (light blue).*

图6的相关性热力图量化了我们的直觉认知，并提供了一些深刻的洞见：

1.  **窗墙比 (WWR) 的双刃剑效应:** WWR与能耗和sDA都呈现出强烈的正相关性。这证实了它是影响这两个核心性能的最关键变量。增加WWR会同时提升采光和能耗，这使得对WWR的决策成为立面设计中最为核心的权衡点。
2.  **遮阳深度的关键作用:** 遮阳深度与能耗呈现出强烈的负相关性，这意味着增加遮阳是降低能耗最有效的手段之一。同时，它与sDA也呈现负相关，但强度稍弱。这表明，精心设计的遮阳可以在不过分牺牲采光的前提下，显著降低能耗，其“性价比”非常高。
3.  **窗户长宽比的影响较小:** 在本案例中，窗户长宽比与两个性能目标的相关性都较弱。这表明，在总面积不变的情况下，改变窗户的形状对整体性能的影响不如改变总面积或增加遮阳那么显著。当然，这个结论可能随建筑朝向和气候区域的变化而改变。

这些分析结果为设计师提供了宝贵的设计知识：在项目早期，应优先关注对**窗墙比**和**遮阳深度**的合理设定，因为它们是驱动性能的关键杠杆。

---

## **4. 讨论 (Discussion)**

本研究的结果清晰地展示了我们提出的自动化框架在解决复杂立面设计问题上的强大能力。然而，结果的呈现仅仅是第一步，更重要的是深入探讨这些结果背后的设计意义、框架的优势与固有的局限性，以及它为建筑设计的未来所开启的可能性。

### **4.1. 结果解读与设计洞见 (Interpretation of Results and Design Insights)**

我们的框架不仅仅是一个优化工具，更是一个“知识发现”引擎。帕累托前沿（图3）和相关性矩阵（图6）共同揭示并量化了立面设计中的核心物理规律和设计权衡。

**权衡的本质是物理规律的体现:** 能耗与采光之间的冲突，根植于建筑物理的基本原理。太阳辐射既是光明的来源，也是热量的载体。我们的框架通过数千次模拟，忠实地再现了这一物理现实，并将抽象的物理规律转换为了直观的设计决策依据——帕累托前沿。这使得设计师能够从“感觉上应该这样”的模糊直觉，转变为“数据表明这样是最佳平衡点”的精确判断。

**超越直觉的发现:** 虽然“大窗户采光好但耗能”是常识，但我们的框架能够发现更细微、甚至反直觉的策略。例如，在某些情况下，一个带有深度遮阳的大窗户组合，其综合性能可能优于一个无遮阳的中等大小窗户。这是因为深度遮阳能够精确地在夏季遮挡高角度的直射光（热量主要来源），而在冬季允许低角度的阳光进入室内（带来宝贵的热量和光线）。这种精细化的策略，是传统试错法很难系统性发现的。我们的框架通过无偏见的全局搜索，将这类高效的设计模式从庞大的可能性中挖掘出来。

**从“单一解”到“解空间”的思维转变:** 传统设计流程倾向于寻找一个单一的“最佳”方案。而我们的框架提供的是一个包含无数个“最优”方案的“解空间”（即帕累托前沿）。这本质上是一种设计思维的范式转变。它承认了“最佳”是相对的，是依赖于具体项目需求和设计师偏好的。框架的作用不是替代设计师做决定，而是将所有可能的优秀选项及其后果（“如果你想要多10%的采光，就需要多付5%的能耗账单”）清晰地呈现在设计师面前，将设计师的角色从一个方案的“创造者”，提升到了一个方案集的“策略决策者”。

### **4.2. 框架的优势与创新性 (Advantages and Innovations of the Framework)**

与现有研究相比，本框架的优势和创新性体现在以下几个方面：

1.  **真正的端到端自动化与效率革命:** 我们实现了从一张图片到一组优化方案的全流程自动化。传统上，完成类似规模的优化研究需要建筑师、工程师和计算机专家数周甚至数月的协同工作，包括手动建模、脚本编写、数据转换等繁琐步骤。而我们的框架将这一过程压缩到了数小时的机器计算时间内。这种效率的指数级提升，使得在真实项目的紧迫时间表内进行深入的性能优化成为可能。
2.  **数据驱动的灵感来源与文脉延续:** 这是本框架最核心的创新点。通过从真实建筑图像中学习，我们的优化不再是无源之水、无本之木。原始立面的比例、节奏和构图被编码为优化的“基因”，确保了生成的设计方案在追求高性能的同时，保留了与原始设计语境的联系。这在很大程度上解决了当前参数化优化设计常被诟病的“千篇一律”、“脱离现实”的问题。它是一种“尊重传统，超越传统”的设计范式。
3.  **普适性与可扩展性:** 尽管本案例研究聚焦于能耗和采光，但框架的模块化设计使其具有极强的可扩展性。
    *   **可更换的“眼睛”**: YOLOv8模型可以被替换为其他更先进的分割或检测模型（如SAM），也可以重新训练以识别不同类型的建筑元素（如装饰线条、材质肌理）。
    *   **可增加的“感官”**: 性能模拟模块可以轻松地接入更多的模拟引擎，以评估其他性能维度，如结构效率、建造成本、声环境、视觉舒适度（如眩光指数）、生命周期碳排放等。这将使优化从二维的权衡，扩展到更高维度的、更全面的决策空间。
    *   **可适应的“大脑”**: NSGA-II也可以被替换为其他先进的多目标优化算法（如MOPSO, SPEA2），以应对不同特性的设计问题。

### **4.3. 局限性与未来研究方向 (Limitations and Future Research Directions)**

作为一个探索性的研究，我们的框架虽然功能强大，但仍存在一些局限性，这些局限性也为未来的研究指明了方向。

1.  **从二维到三维的信息损失:** 目前的框架从单张二维正立面图开始，这不可避免地丢失了建筑的深度和体量信息。对于非平面立面或具有复杂三维形态的建筑，该方法适用性有限。未来的研究可以引入更先进的计算机视觉技术，如从多张图片或点云数据中进行三维重建（Structure from Motion, SfM; Neural Radiance Fields, NeRFs），从而获得完整的建筑三维几何，作为优化的起点。
2.  **几何表达的简化:** 当前从分割掩码到参数化模型的转换过程，倾向于将不规则的形状简化为规则的矩形。这在保证计算效率的同时，也牺牲了一部分设计的自由度和细节。未来的工作可以探索使用更灵活的几何表达方式，如样条曲线（Splines）或细分曲面（Subdivision Surfaces），来代表和优化更复杂的几何形态。
3.  **模拟模型的保真度:** 性能模拟本身是对现实世界的简化。模拟结果的准确性依赖于输入参数（如材料属性、内部负荷设定）的精确性。虽然我们使用了业界标准的引擎，但与真实建筑的性能表现仍可能存在偏差（performance gap）。将框架与建成后的实测数据进行校准和验证，是未来提升其可信度的重要步骤。
4.  **美学与定性因素的缺失:** 当前的优化目标完全是定量的物理性能。而建筑设计，尤其是立面设计，具有强烈的艺术和美学属性。如何将“美”这样一个主观、定性的目标量化并纳入优化过程，是该领域面临的终极挑战。未来的研究可以尝试结合人类参与的交互式进化算法（Interactive Evolutionary Algorithms），让设计师在优化循环中对方案的美学进行评分；或者利用在大量建筑图像上训练过的美学评估模型（Aesthetic Assessment Models）来为方案打分。
5.  **更智能的生成模型:** 本框架的“生成”能力主要体现在对参数的调整上。未来的研究可以探索使用更前沿的深度生成模型，如生成对抗网络（GANs）或扩散模型（Diffusion Models），直接生成新颖的、高性能的立面图像或几何布局，可能带来更具突破性的设计创新。

---

## **5. 结论 (Conclusion)**

在建筑设计日益被要求兼顾环境可持续性、经济可行性和人类福祉的多重目标的时代，传统的设计方法正面临着深刻的挑战。本研究通过提出并实现一个**融合了深度学习图像分析与多目标性能模拟的自动化立面设计框架**，为应对这一挑战提供了一个强有力的解决方案。

我们的研究核心贡献在于，成功地构建了一个从“灵感获取”到“优化决策”的无缝、闭环的工作流。通过利用YOLOv8的强大图像分割能力，我们的框架能够从现实世界的建筑中汲取设计灵感，将其转化为参数化的“设计基因”。随后，借助NSGA-II优化算法和物理模拟引擎，框架对数以千计的设计可能性进行系统性的探索和评估，最终呈现给设计师一个包含一系列帕累托最优解的、可视化的决策“菜单”。

案例研究的结果令人信服地证明了本框架的价值：它不仅能够发现性能远超传统设计的创新方案，而且深刻地揭示了能耗与采光等关键性能目标之间内在的、复杂的权衡关系。更重要的是，它将设计的焦点从寻找一个虚幻的、单一的“最佳解”，转移到了解和驾驭整个高性能的“解空间”上，从而赋予了设计师前所未有的、基于数据洞见的决策能力。

本研究不仅是对建筑设计技术的一次有益探索，更代表了一种设计范式的演进——一种人机协同、数据驱动、性能导向的未来设计模式。我们相信，随着人工智能和计算技术的不断发展，类似本研究提出的智能设计框架，将成为未来建筑师不可或-
的“超级工具”，帮助他们以更高的效率、更深的洞察力，去创造更美好、更可持续的建成环境。未来的工作将致力于克服当前框架的局限，通过引入三维视觉、更丰富的性能维度和对美学等定性因素的考量，使其更加强大和完善。
